//! Compatibility static-export plot layout (M2 #275 / ABI 126 / ABI 198).
//!
//! SVG, raster, and pyplot share these padding, title-band, colorbar, right-y,
//! polar-recut, and `_svg.layout()` combination formulas. Hosts still iterate
//! axes, format `_tick_text`, measure rooms through ABI 125, resolve CSS
//! visibility, and decide whether a polar legend gutter is reserved.

use crate::layout_rooms::AXIS_TEXT_EDGE_PAD;

/// Canvas width below which static exporters use compact gutters.
pub const COMPACT_WIDTH: f64 = 520.0;
/// Smallest plot side the combination formulas will emit.
pub const PLOT_MIN: f64 = 40.0;

pub const PAD_TOP_COMPACT: f64 = 6.0;
pub const PAD_RIGHT_COMPACT: f64 = 8.0;
pub const PAD_BOTTOM_COMPACT: f64 = 36.0;
pub const PAD_LEFT_COMPACT: f64 = 46.0;
pub const PAD_TOP: f64 = 10.0;
pub const PAD_RIGHT: f64 = 14.0;
pub const PAD_BOTTOM: f64 = 42.0;
pub const PAD_LEFT: f64 = 62.0;

pub const TITLE_BAND_COMPACT: f64 = 26.0;
pub const TITLE_BAND: f64 = 30.0;
pub const X_TOP_FLOOR_COMPACT: f64 = 26.0;
pub const X_TOP_FLOOR: f64 = 32.0;
pub const X_BOTTOM_FLOOR_COMPACT: f64 = 36.0;
pub const X_BOTTOM_FLOOR: f64 = 42.0;
pub const RIGHT_Y_COMPACT: f64 = 42.0;
pub const RIGHT_Y: f64 = 54.0;

pub const COLORBAR_NONE: u32 = 0;
pub const COLORBAR_AXES_HORIZONTAL: u32 = 1;
pub const COLORBAR_AXES_VERTICAL: u32 = 2;
pub const COLORBAR_FIGURE_HORIZONTAL: u32 = 3;
pub const COLORBAR_FIGURE_VERTICAL: u32 = 4;

pub const LEGEND_SIDE_NONE: u32 = 0;
pub const LEGEND_SIDE_LEFT: u32 = 1;
pub const LEGEND_SIDE_RIGHT: u32 = 2;
pub const LEGEND_SIDE_BOTTOM: u32 = 3;

pub const POLAR_LABEL_ROOM: f64 = 30.0;
pub const POLAR_LABEL_ROOM_MAX: f64 = 90.0;
pub const POLAR_TICK_GAP: f64 = 8.0;
pub const POLAR_LEGEND_ROOM_FRACTION: f64 = 0.22;
pub const POLAR_LEGEND_ROOM_MIN: f64 = 120.0;
pub const POLAR_LEGEND_ROOM_MAX: f64 = 200.0;
pub const POLAR_LEGEND_BAND: f64 = 64.0;

pub const DEFAULT_PADDING_LEN: usize = 4;
pub const RECUT_OUT_LEN: usize = 9;

/// Whether a canvas width uses compact static gutters.
pub fn is_compact(width: f64) -> Option<bool> {
    width.is_finite().then_some(width < COMPACT_WIDTH)
}

/// Default `(top, right, bottom, left)` when the spec did not author padding.
pub fn default_padding(compact: bool) -> [f64; 4] {
    if compact {
        [
            PAD_TOP_COMPACT,
            PAD_RIGHT_COMPACT,
            PAD_BOTTOM_COMPACT,
            PAD_LEFT_COMPACT,
        ]
    } else {
        [PAD_TOP, PAD_RIGHT, PAD_BOTTOM, PAD_LEFT]
    }
}

/// Width a chart title wraps at, from authored/default horizontal gutters.
pub fn title_wrap_width(width: f64, left: f64, right: f64) -> Option<f64> {
    if ![width, left, right].iter().all(|value| value.is_finite()) {
        return None;
    }
    Some(PLOT_MIN.max(width - left - right))
}

/// Outward title-band room for one title entry after the host measured height.
pub fn title_room(
    compact: bool,
    block_height: f64,
    pad: f64,
    automatic_y: bool,
    y: f64,
) -> Option<f64> {
    if ![block_height, pad, y].iter().all(|value| value.is_finite())
        || block_height < 0.0
        || pad < 0.0
    {
        return None;
    }
    let candidate = if automatic_y {
        (if compact {
            TITLE_BAND_COMPACT
        } else {
            TITLE_BAND
        })
        .max(block_height + pad)
    } else if y >= 1.0 {
        block_height + pad
    } else {
        0.0
    };
    Some(candidate.max(0.0))
}

/// Compact floor plus measured x-axis room for one side.
///
/// Returns `(reserved, measured_bottom_contrib)`. `measured_bottom_contrib` is
/// the raw measured room on the bottom side and 0 on the top side.
pub fn x_axis_side_room(compact: bool, top: bool, measured: f64) -> Option<(f64, f64)> {
    if !measured.is_finite() || measured < 0.0 {
        return None;
    }
    if top {
        let floor = if compact {
            X_TOP_FLOOR_COMPACT
        } else {
            X_TOP_FLOOR
        };
        Some((floor.max(measured), 0.0))
    } else {
        let floor = if compact {
            X_BOTTOM_FLOOR_COMPACT
        } else {
            X_BOTTOM_FLOOR
        };
        Some((floor.max(measured), measured))
    }
}

/// Extra `(right, bottom)` claimed by a colorbar after host resolved kind.
pub fn colorbar_extra(kind: u32, has_label: bool, pad_zero: bool) -> Option<(f64, f64)> {
    let label_h = if has_label { 16.0 } else { 0.0 };
    let label_v = if has_label { 18.0 } else { 0.0 };
    match kind {
        COLORBAR_NONE => Some((0.0, 0.0)),
        COLORBAR_AXES_HORIZONTAL => Some((0.0, 24.0 + label_h)),
        COLORBAR_AXES_VERTICAL => Some((44.0 + label_v, 0.0)),
        COLORBAR_FIGURE_HORIZONTAL => Some((0.0, (if pad_zero { 18.0 } else { 38.0 }) + label_h)),
        COLORBAR_FIGURE_VERTICAL => Some(((if pad_zero { 62.0 } else { 86.0 }) + label_v, 0.0)),
        _ => None,
    }
}

/// Shared right-side y-axis gutter.
pub fn right_y_room(compact: bool) -> f64 {
    if compact {
        RIGHT_Y_COMPACT
    } else {
        RIGHT_Y
    }
}

/// Polar legend side-gutter width on a `width`-px canvas.
pub fn polar_legend_room(width: f64) -> Option<f64> {
    if !width.is_finite() || width < 0.0 {
        return None;
    }
    let scaled = (width * POLAR_LEGEND_ROOM_FRACTION).floor();
    Some(POLAR_LEGEND_ROOM_MAX.min(POLAR_LEGEND_ROOM_MIN.max(scaled)))
}

/// Compact charts reserve a bottom band; otherwise loc chooses left vs right.
pub fn polar_legend_reserve(compact: bool, loc_has_left: bool, width: f64) -> Option<(u32, f64)> {
    if compact {
        Some((LEGEND_SIDE_BOTTOM, POLAR_LEGEND_BAND))
    } else {
        let side = if loc_has_left {
            LEGEND_SIDE_LEFT
        } else {
            LEGEND_SIDE_RIGHT
        };
        Some((side, polar_legend_room(width)?))
    }
}

/// Uniform angular-label inset. `widest` is `None` when no authored labels.
pub fn polar_label_room(widest: Option<f64>) -> Option<f64> {
    let Some(widest) = widest else {
        return Some(POLAR_LABEL_ROOM);
    };
    if !widest.is_finite() || widest < 0.0 {
        return None;
    }
    Some(
        POLAR_LABEL_ROOM_MAX
            .min(POLAR_LABEL_ROOM.max(widest + POLAR_TICK_GAP + AXIS_TEXT_EDGE_PAD)),
    )
}

/// Cartesian plot rect plus optional polar legend box after recut.
#[derive(Clone, Debug, PartialEq)]
pub struct PolarPlot {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub top_axis_room: f64,
    pub legend_box: Option<[f64; 4]>,
}

/// Re-cut a cartesian plot rect into a polar disc, matching `_svg._recut_polar_plot`.
pub fn recut_polar_plot(
    mut plot: PolarPlot,
    mut width: f64,
    mut height: f64,
    legend_side: u32,
    legend_room: f64,
    polar_label_room: f64,
    authored_padding: bool,
    y_titled: bool,
    keeps_bottom: bool,
) -> Option<PolarPlot> {
    if ![
        plot.x,
        plot.y,
        plot.w,
        plot.h,
        plot.top_axis_room,
        width,
        height,
        legend_room,
        polar_label_room,
    ]
    .iter()
    .all(|value| value.is_finite())
        || width <= 0.0
        || height <= 0.0
        || legend_room < 0.0
        || polar_label_room < 0.0
        || !matches!(
            legend_side,
            LEGEND_SIDE_NONE | LEGEND_SIDE_LEFT | LEGEND_SIDE_RIGHT | LEGEND_SIDE_BOTTOM
        )
    {
        return None;
    }
    let mut canvas_x0 = 0.0;
    if legend_side != LEGEND_SIDE_NONE && legend_room > 0.0 {
        let box_rect = match legend_side {
            LEGEND_SIDE_LEFT => {
                canvas_x0 = legend_room;
                plot.x = plot.x.max(legend_room);
                [0.0, plot.y, legend_room, plot.h]
            }
            LEGEND_SIDE_RIGHT => {
                width -= legend_room;
                [width, plot.y, legend_room, plot.h]
            }
            LEGEND_SIDE_BOTTOM => {
                height -= legend_room;
                [plot.x, height, plot.w, legend_room]
            }
            _ => return None,
        };
        plot.legend_box = Some(box_rect);
        plot.w = PLOT_MIN.max(plot.w.min(width - plot.x));
        plot.h = PLOT_MIN.max(plot.h.min(height - plot.y));
    }
    let reserved_top = plot.y;
    let reserved_right = width - plot.x - plot.w;
    let reserved_bottom = height - plot.y - plot.h;
    let room = polar_label_room;
    if authored_padding {
        let left = plot.x + room;
        let right = plot.x + plot.w - room;
        let top = plot.y + room;
        let bottom = plot.y + plot.h - room;
        let box_w = right - left;
        let box_h = bottom - top;
        if box_w >= PLOT_MIN && box_h >= PLOT_MIN {
            plot.x = left;
            plot.y = top;
            plot.w = box_w;
            plot.h = box_h;
            plot.top_axis_room += room;
        }
        return Some(plot);
    }
    let side = room.max(reserved_right);
    let left = (if y_titled { side.max(plot.x) } else { side }).max(canvas_x0 + room);
    let right = width - side;
    let bottom_reserve = if keeps_bottom {
        reserved_bottom
    } else {
        reserved_bottom.min(reserved_top)
    };
    let bottom = height - room.max(bottom_reserve);
    let top = reserved_top + room;
    let box_w = right - left;
    let box_h = bottom - top;
    if box_w < PLOT_MIN || box_h < PLOT_MIN {
        let margin = 4.0_f64.min(width / 8.0).min(height / 8.0);
        plot.x = margin;
        plot.y = margin.max(reserved_top.min(height / 4.0));
        plot.w = 8.0_f64.max(width - 2.0 * margin);
        plot.h = 8.0_f64.max(height - plot.y - margin);
        return Some(plot);
    }
    plot.x = left;
    plot.y = top;
    plot.w = box_w;
    plot.h = box_h;
    plot.top_axis_room += room;
    if let Some(box_rect) = plot.legend_box.as_mut() {
        if legend_side == LEGEND_SIDE_LEFT || legend_side == LEGEND_SIDE_RIGHT {
            box_rect[1] = plot.y;
            box_rect[3] = plot.h;
        } else if legend_side == LEGEND_SIDE_BOTTOM {
            box_rect[0] = plot.x;
            box_rect[2] = plot.w;
        }
    }
    Some(plot)
}

pub const COMBINE_OUT_LEN: usize = 12;

/// Optional polar recut applied after cartesian gutters converge.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PolarCombine {
    pub legend_side: u32,
    pub legend_room: f64,
    pub polar_label_room: f64,
    pub authored_padding: bool,
    pub y_titled: bool,
    pub keeps_bottom: bool,
}

/// Host-measured rooms plus flags for [`combine_plot`].
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CombinePlotRequest {
    pub width: f64,
    pub height: f64,
    pub authored_padding: Option<[f64; 4]>,
    pub title_room: f64,
    pub x_top_room: f64,
    pub x_bottom_room: f64,
    pub x_measured_bottom: f64,
    pub colorbar_kind: u32,
    pub colorbar_has_label: bool,
    pub colorbar_pad_zero: bool,
    pub has_right_y: bool,
    /// `None` skips the y-left floor (preview height after title/x/colorbar).
    pub y_left_room: Option<f64>,
    /// Additional left/right floors (tick overhang, or accumulated gutters).
    pub edge_left: Option<f64>,
    pub edge_right: Option<f64>,
    /// Second-pass x rooms when plot width changed. `(top, bottom, measured_bottom)`.
    pub x_rooms_final: Option<(f64, f64, f64)>,
    pub polar: Option<PolarCombine>,
}

/// Cartesian plot rect plus title/axis metadata after combination.
#[derive(Clone, Debug, PartialEq)]
pub struct CombinedPlot {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub title_room: f64,
    pub title_wrap_width: f64,
    pub top_axis_room: f64,
    pub bottom_axis_room: f64,
    pub legend_box: Option<[f64; 4]>,
}

/// Combine padding, title, axis rooms, colorbar extra, right-y, floors, and polar recut.
///
/// Hosts still iterate axes, format ticks, measure ABI 125 rooms, resolve CSS
/// visibility, and decide polar legend reservation. The combination itself
/// (ABI 198 / #299) lives here so `_svg.layout()` cannot drift from Node.
pub fn combine_plot(request: CombinePlotRequest) -> Option<CombinedPlot> {
    let CombinePlotRequest {
        width,
        height,
        authored_padding,
        title_room,
        x_top_room,
        x_bottom_room,
        x_measured_bottom,
        colorbar_kind,
        colorbar_has_label,
        colorbar_pad_zero,
        has_right_y,
        y_left_room,
        edge_left,
        edge_right,
        x_rooms_final,
        polar,
    } = request;
    if ![
        width,
        height,
        title_room,
        x_top_room,
        x_bottom_room,
        x_measured_bottom,
    ]
    .iter()
    .all(|value| value.is_finite())
        || width <= 0.0
        || height <= 0.0
        || title_room < 0.0
        || x_top_room < 0.0
        || x_bottom_room < 0.0
        || x_measured_bottom < 0.0
    {
        return None;
    }
    if let Some(room) = y_left_room {
        if !room.is_finite() || room < 0.0 {
            return None;
        }
    }
    if let Some(room) = edge_left {
        if !room.is_finite() || room < 0.0 {
            return None;
        }
    }
    if let Some(room) = edge_right {
        if !room.is_finite() || room < 0.0 {
            return None;
        }
    }
    if let Some((top_room, bottom_room, measured_bottom)) = x_rooms_final {
        if ![top_room, bottom_room, measured_bottom]
            .iter()
            .all(|value| value.is_finite() && *value >= 0.0)
        {
            return None;
        }
    }
    let compact = is_compact(width)?;
    let (mut top, mut right, mut bottom, mut left) = match authored_padding {
        Some([pad_top, pad_right, pad_bottom, pad_left]) => {
            if [pad_top, pad_right, pad_bottom, pad_left]
                .iter()
                .any(|value| !value.is_finite() || *value < 0.0)
            {
                return None;
            }
            (pad_top, pad_right, pad_bottom, pad_left)
        }
        None => {
            let pad = default_padding(compact);
            (pad[0], pad[1], pad[2], pad[3])
        }
    };
    let wrap = title_wrap_width(width, left, right)?;
    let mut top_axis_room = x_top_room;
    let mut bottom_axis_room = x_bottom_room;
    let measured_bottom_room = x_measured_bottom;
    top += title_room;
    top += top_axis_room;
    if measured_bottom_room != 0.0 {
        bottom = bottom.max(measured_bottom_room);
    }
    let (extra_right, extra_bottom) =
        colorbar_extra(colorbar_kind, colorbar_has_label, colorbar_pad_zero)?;
    right += extra_right;
    bottom += extra_bottom;
    if has_right_y {
        right += right_y_room(compact);
    }
    if let Some(room) = y_left_room {
        left = left.max(room);
    }
    if let Some(room) = edge_left {
        left = left.max(room);
    }
    if let Some(room) = edge_right {
        right = right.max(room);
    }
    if let Some((measured_top, measured_bottom, final_measured_bottom)) = x_rooms_final {
        if measured_top > top_axis_room {
            top += measured_top - top_axis_room;
            top_axis_room = measured_top;
        }
        if final_measured_bottom > measured_bottom_room {
            bottom = bottom.max(final_measured_bottom);
        }
        bottom_axis_room = bottom_axis_room.max(measured_bottom);
    }
    let mut plot = CombinedPlot {
        x: left,
        y: top,
        w: PLOT_MIN.max(width - left - right),
        h: PLOT_MIN.max(height - top - bottom),
        title_room,
        title_wrap_width: wrap,
        top_axis_room,
        bottom_axis_room,
        legend_box: None,
    };
    if let Some(polar) = polar {
        let recut = recut_polar_plot(
            PolarPlot {
                x: plot.x,
                y: plot.y,
                w: plot.w,
                h: plot.h,
                top_axis_room: plot.top_axis_room,
                legend_box: None,
            },
            width,
            height,
            polar.legend_side,
            polar.legend_room,
            polar.polar_label_room,
            polar.authored_padding,
            polar.y_titled,
            polar.keeps_bottom,
        )?;
        plot.x = recut.x;
        plot.y = recut.y;
        plot.w = recut.w;
        plot.h = recut.h;
        plot.top_axis_room = recut.top_axis_room;
        plot.legend_box = recut.legend_box;
    }
    Some(plot)
}

/// Figure-edge extras for [`tight_layout_solve`] after the host measured chrome.
///
/// Returns `(left, right, bottom, top)`. `suptitle_height`, `xlabel_size`,
/// `ylabel_size`, and `legend_box_w` are `None` when that decoration is absent.
pub fn tight_figure_extra(
    canvas_w: f64,
    canvas_h: f64,
    suptitle_height: Option<f64>,
    suptitle_y: f64,
    xlabel_size: Option<f64>,
    ylabel_size: Option<f64>,
    legend_box_w: Option<f64>,
) -> Option<[f64; 4]> {
    if ![canvas_w, canvas_h, suptitle_y]
        .iter()
        .all(|value| value.is_finite())
        || canvas_w <= 0.0
        || canvas_h <= 0.0
    {
        return None;
    }
    let extra_top = match suptitle_height {
        Some(height) if height.is_finite() && height >= 0.0 => {
            (1.0 - suptitle_y).max(0.0) * canvas_h + height + 6.0
        }
        None => 0.0,
        Some(_) => return None,
    };
    let extra_bottom = match xlabel_size {
        Some(size) if size.is_finite() && size >= 0.0 => size + 8.0,
        None => 0.0,
        Some(_) => return None,
    };
    let extra_left = match ylabel_size {
        Some(size) if size.is_finite() && size >= 0.0 => size + 8.0,
        None => 0.0,
        Some(_) => return None,
    };
    let extra_right = match legend_box_w {
        Some(width) if width.is_finite() && width >= 0.0 => width + 12.0,
        None => 0.0,
        Some(_) => return None,
    };
    Some([extra_left, extra_right, extra_bottom, extra_top])
}

/// One gridspec cell's chrome, in px, plus its integer row/col span.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TightPanel {
    pub row0: i32,
    pub row1: i32,
    pub col0: i32,
    pub col1: i32,
    pub left: f64,
    pub top: f64,
    pub right: f64,
    pub bottom: f64,
}

/// `subplots_adjust` fractions: left, right, bottom, top, wspace, hspace.
pub const TIGHT_OUT_LEN: usize = 6;
pub const TIGHT_PANEL_STRIDE: usize = 8;
pub const TIGHT_BASE_PAD: f64 = 1.08;

/// Pyplot tight-layout grid solve after the host measured per-panel chrome.
///
/// `extra` is `(left, right, bottom, top)` figure-edge additions already
/// measured by the host (suptitle, figure labels, outside legends). `pad`,
/// `w_pad`, and `h_pad` are Matplotlib font-size multiples; `None` means
/// omitted. `rect` is `[left, bottom, right, top]` in figure fractions.
pub fn tight_layout_solve(
    canvas_w: f64,
    canvas_h: f64,
    nrows: u32,
    ncols: u32,
    compact: bool,
    panels: &[TightPanel],
    extra: [f64; 4],
    pad: Option<f64>,
    w_pad: Option<f64>,
    h_pad: Option<f64>,
    point_px: f64,
    rect: [f64; 4],
) -> Option<[f64; 6]> {
    if ![canvas_w, canvas_h, point_px]
        .iter()
        .chain(extra.iter())
        .chain(rect.iter())
        .all(|value| value.is_finite())
        || canvas_w <= 0.0
        || canvas_h <= 0.0
        || nrows == 0
        || ncols == 0
        || point_px < 0.0
        || extra.iter().any(|value| *value < 0.0)
        || pad.is_some_and(|value| !value.is_finite())
        || w_pad.is_some_and(|value| !value.is_finite())
        || h_pad.is_some_and(|value| !value.is_finite())
    {
        return None;
    }
    for panel in panels {
        if panel.row1 <= panel.row0
            || panel.col1 <= panel.col0
            || ![panel.left, panel.top, panel.right, panel.bottom]
                .iter()
                .all(|value| value.is_finite() && *value >= 0.0)
        {
            return None;
        }
    }
    let mut left_px = if panels.is_empty() {
        if compact {
            PAD_LEFT_COMPACT
        } else {
            PAD_LEFT
        }
    } else {
        panels
            .iter()
            .map(|panel| panel.left)
            .fold(f64::NEG_INFINITY, f64::max)
    };
    let right_floor: f64 = if compact { 20.0 } else { 26.0 };
    let mut right_px = right_floor.max(if panels.is_empty() {
        0.0
    } else {
        panels
            .iter()
            .map(|panel| panel.right)
            .fold(f64::NEG_INFINITY, f64::max)
    });
    let mut bottom_px = if panels.is_empty() {
        if compact {
            PAD_BOTTOM_COMPACT
        } else {
            PAD_BOTTOM
        }
    } else {
        panels
            .iter()
            .map(|panel| panel.bottom)
            .fold(f64::NEG_INFINITY, f64::max)
    };
    let mut top_px = 20.0_f64.max(if panels.is_empty() {
        0.0
    } else {
        panels
            .iter()
            .map(|panel| panel.top)
            .fold(f64::NEG_INFINITY, f64::max)
    });
    let mut horizontal_gap: f64 = if compact { 58.0 } else { 76.0 };
    let mut vertical_gap: f64 = if compact { 44.0 } else { 56.0 };
    for (index, panel) in panels.iter().enumerate() {
        for (other_index, other) in panels.iter().enumerate() {
            if index == other_index {
                continue;
            }
            let rows_overlap = panel.row0.max(other.row0) < panel.row1.min(other.row1);
            let cols_overlap = panel.col0.max(other.col0) < panel.col1.min(other.col1);
            if rows_overlap && panel.col1 == other.col0 {
                horizontal_gap = f64::max(horizontal_gap, panel.right + other.left);
            }
            if cols_overlap && panel.row1 == other.row0 {
                vertical_gap = f64::max(vertical_gap, panel.bottom + other.top);
            }
        }
    }
    left_px += extra[0];
    right_px += extra[1];
    bottom_px += extra[2];
    top_px += extra[3];
    let base_pad = pad.unwrap_or(TIGHT_BASE_PAD);
    if let Some(w_pad) = w_pad {
        horizontal_gap += (w_pad - base_pad) * point_px;
    }
    if let Some(h_pad) = h_pad {
        vertical_gap += (h_pad - base_pad) * point_px;
    }
    if let Some(pad) = pad {
        let extra_pad = (pad - TIGHT_BASE_PAD) * point_px;
        left_px += extra_pad;
        right_px += extra_pad;
        bottom_px += extra_pad;
        top_px += extra_pad;
    }
    let left = rect[0] + left_px.max(0.0) / canvas_w;
    let right = rect[2] - right_px.max(0.0) / canvas_w;
    let bottom = rect[1] + bottom_px.max(0.0) / canvas_h;
    let top = rect[3] - top_px.max(0.0) / canvas_h;
    let inner_w = 1.0_f64.max((right - left) * canvas_w);
    let inner_h = 1.0_f64.max((top - bottom) * canvas_h);
    let cell_w = 1.0_f64.max(
        (inner_w - horizontal_gap * f64::from(ncols.saturating_sub(1))) / f64::from(ncols.max(1)),
    );
    let cell_h = 1.0_f64.max(
        (inner_h - vertical_gap * f64::from(nrows.saturating_sub(1))) / f64::from(nrows.max(1)),
    );
    Some([
        left,
        right,
        bottom,
        top,
        horizontal_gap / cell_w,
        vertical_gap / cell_h,
    ])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn compact_default_padding_matches_static_exporters() {
        assert_eq!(default_padding(true), [6.0, 8.0, 36.0, 46.0]);
        assert_eq!(default_padding(false), [10.0, 14.0, 42.0, 62.0]);
        assert_eq!(is_compact(519.0), Some(true));
        assert_eq!(is_compact(520.0), Some(false));
    }

    #[test]
    fn title_wrap_width_is_a_floor_of_forty() {
        assert_eq!(title_wrap_width(100.0, 40.0, 40.0), Some(40.0));
        assert_eq!(title_wrap_width(200.0, 46.0, 14.0), Some(140.0));
    }

    #[test]
    fn polar_legend_room_clamps_fraction() {
        assert_eq!(polar_legend_room(400.0), Some(120.0));
        assert_eq!(polar_legend_room(1000.0), Some(200.0));
        let mid = polar_legend_room(700.0).unwrap();
        assert!((mid - (700.0 * POLAR_LEGEND_ROOM_FRACTION).floor()).abs() < 1e-12);
    }

    #[test]
    fn recut_authored_padding_insets_by_label_room() {
        let plot = PolarPlot {
            x: 0.0,
            y: 0.0,
            w: 200.0,
            h: 200.0,
            top_axis_room: 10.0,
            legend_box: None,
        };
        let out = recut_polar_plot(
            plot,
            200.0,
            200.0,
            LEGEND_SIDE_NONE,
            0.0,
            30.0,
            true,
            false,
            false,
        )
        .unwrap();
        assert_eq!(out.x, 30.0);
        assert_eq!(out.y, 30.0);
        assert_eq!(out.w, 140.0);
        assert_eq!(out.h, 140.0);
        assert_eq!(out.top_axis_room, 40.0);
    }

    #[test]
    fn tight_layout_empty_wide_canvas_uses_default_edges() {
        let out = tight_layout_solve(
            800.0,
            600.0,
            1,
            1,
            false,
            &[],
            [0.0, 0.0, 0.0, 0.0],
            None,
            None,
            None,
            1.0,
            [0.0, 0.0, 1.0, 1.0],
        )
        .unwrap();
        assert!((out[0] - 62.0 / 800.0).abs() < 1e-12);
        assert!((out[1] - (1.0 - 26.0 / 800.0)).abs() < 1e-12);
        assert!((out[2] - 42.0 / 600.0).abs() < 1e-12);
        assert!((out[3] - (1.0 - 20.0 / 600.0)).abs() < 1e-12);
    }

    #[test]
    fn tight_layout_neighbor_gap_uses_adjacent_chrome() {
        let panels = [
            TightPanel {
                row0: 0,
                row1: 1,
                col0: 0,
                col1: 1,
                left: 10.0,
                top: 5.0,
                right: 40.0,
                bottom: 8.0,
            },
            TightPanel {
                row0: 0,
                row1: 1,
                col0: 1,
                col1: 2,
                left: 50.0,
                top: 5.0,
                right: 10.0,
                bottom: 8.0,
            },
        ];
        let out = tight_layout_solve(
            800.0,
            400.0,
            1,
            2,
            false,
            &panels,
            [0.0, 0.0, 0.0, 0.0],
            None,
            None,
            None,
            1.0,
            [0.0, 0.0, 1.0, 1.0],
        )
        .unwrap();
        let horizontal_gap = 90.0_f64.max(76.0);
        let left = 50.0 / 800.0;
        let right = 1.0 - 40.0 / 800.0;
        let inner_w = (right - left) * 800.0;
        let cell_w = (inner_w - horizontal_gap) / 2.0;
        assert!((out[0] - left).abs() < 1e-12);
        assert!((out[1] - right).abs() < 1e-12);
        assert!((out[4] - horizontal_gap / cell_w).abs() < 1e-12);
    }

    fn blank_combine(width: f64, height: f64) -> CombinePlotRequest {
        CombinePlotRequest {
            width,
            height,
            authored_padding: None,
            title_room: 0.0,
            x_top_room: 0.0,
            x_bottom_room: 0.0,
            x_measured_bottom: 0.0,
            colorbar_kind: COLORBAR_NONE,
            colorbar_has_label: false,
            colorbar_pad_zero: false,
            has_right_y: false,
            y_left_room: None,
            edge_left: None,
            edge_right: None,
            x_rooms_final: None,
            polar: None,
        }
    }

    #[test]
    fn combine_plot_default_padding_is_the_plot_rect() {
        let out = combine_plot(blank_combine(900.0, 420.0)).unwrap();
        assert_eq!(out.x, PAD_LEFT);
        assert_eq!(out.y, PAD_TOP);
        assert_eq!(out.w, 900.0 - PAD_LEFT - PAD_RIGHT);
        assert_eq!(out.h, 420.0 - PAD_TOP - PAD_BOTTOM);
        assert_eq!(out.title_wrap_width, 900.0 - PAD_LEFT - PAD_RIGHT);
        assert_eq!(out.legend_box, None);
    }

    #[test]
    fn combine_plot_title_and_colorbar_are_additive() {
        let mut request = blank_combine(900.0, 420.0);
        request.title_room = 30.0;
        request.colorbar_kind = COLORBAR_FIGURE_VERTICAL;
        let out = combine_plot(request).unwrap();
        assert_eq!(out.y, PAD_TOP + 30.0);
        assert_eq!(out.x, PAD_LEFT);
        let extra = colorbar_extra(COLORBAR_FIGURE_VERTICAL, false, false).unwrap();
        assert_eq!(out.w, 900.0 - PAD_LEFT - (PAD_RIGHT + extra.0));
        assert_eq!(out.title_room, 30.0);
    }

    #[test]
    fn combine_plot_polar_recut_insets_authored_padding() {
        let mut request = blank_combine(200.0, 200.0);
        request.authored_padding = Some([0.0, 0.0, 0.0, 0.0]);
        request.polar = Some(PolarCombine {
            legend_side: LEGEND_SIDE_NONE,
            legend_room: 0.0,
            polar_label_room: 30.0,
            authored_padding: true,
            y_titled: false,
            keeps_bottom: false,
        });
        let out = combine_plot(request).unwrap();
        assert_eq!(out.x, 30.0);
        assert_eq!(out.y, 30.0);
        assert_eq!(out.w, 140.0);
        assert_eq!(out.h, 140.0);
        assert_eq!(out.top_axis_room, 30.0);
    }

    #[test]
    fn tight_figure_extra_suptitle_and_outside_legend() {
        let extra =
            tight_figure_extra(800.0, 600.0, Some(20.0), 0.98, None, Some(12.0), Some(80.0))
                .unwrap();
        assert_eq!(extra[0], 20.0);
        assert_eq!(extra[1], 92.0);
        assert_eq!(extra[2], 0.0);
        assert!((extra[3] - ((1.0 - 0.98) * 600.0 + 20.0 + 6.0)).abs() < 1e-12);
    }
}
