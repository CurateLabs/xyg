//! Compact Figure→Scene row packing (M2 #271).
//!
//! Hosts validate authoring (axis keys, hidden traces, density, style
//! allowlists) and pass literal columns plus product kind/flags. Rust owns
//! product-kind → pack-kind mapping, Scene record kinds, stable-id splitting,
//! expansion-mode assignment, heatmap lattice framing, ribbon/triangle
//! doubling, rule/band/marker domain expansion, and finite-coordinate
//! rejection so Python and Node cannot drift on the packed row contract.
//! ABI 140 maps line `step_mode=4` onto expansion `CurveFlatten=11`.
//! ABI 141 maps band `step_mode=4` onto expansion `BandFlatten=12`.
//! ABI 142 admits cartesian mean-color density as XYHP paint kind 4 on the
//! existing `DensityBlit` Image blit (no new pack kind).
//! ABI 144 admits cartesian `error_band(curve="smooth")` on that same
//! `BandFlatten` mapping; polar `curve="smooth"` line/area/error_band pack as
//! identity chords (no `step_mode=4`). ABI 169 admits polar `curve="smooth"`
//! plus `step` on that same identity-chord packing: authored `step_mode` 1–3
//! expands, and smooth does not promote to `CurveFlatten`. ABI 172 admits
//! cartesian line `curve="smooth"` plus `step` the same way: authored
//! `step_mode` 1–3 expands, and smooth does not promote to `CurveFlatten`.
//! ABI 181 admits cartesian area/error_band `curve="smooth"` plus `step` the
//! same way on `PACK_BAND`: authored `step_mode` 1–3 expands both edges, and
//! smooth does not promote to `BandFlatten`. ABI 182 admits triangle_mesh
//! `joined_fill` as one identity PolyFill ring from `geom::triangle_mesh_boundary`
//! (disconnected meshes and holes keep per-face `TriangleFace` rows).
//! ABI 183 admits constant ribbon `color2_ch` as XYGR mark-space `dir=right`
//! (no new pack kind; encoded Scene keeps XYGR). ABI 190 intern per-item
//! two-ended ribbon `color2_ch` from packed XYHP kind 5 (`FLAG_HEATMAP_PAINTED`
//! is allowed on `PACK_RIBBON` so the plane rides extras; Band expansion intern
//! unique pairs onto XYGR). Polar ribbon and explicit `FLAG_COLOR2` stay
//! fail-closed. ABI 195 intern triangle-mesh per-item fill/stroke/width from
//! packed XYHP kind 6 (`FLAG_HEATMAP_PAINTED` is allowed on `PACK_TRIANGLE` so
//! the plane rides extras; TriangleFace expansion intern unique triples).
//! ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP
//! kind 7 (`FLAG_HEATMAP_PAINTED` is allowed on `PACK_SCATTER` so the plane
//! rides extras; identity Scatter records intern unique triples by order).
//! colormap hexbin as `PACK_HEXBIN` plus `FLAG_HEATMAP_PAINTED` (XYHP 1×N
//! plane; HexCell expansion interns per-cell fills; no new pack kind).
//! ABI 187 admits cartesian unwrapped text `rotation` as XYAW `wrap=0` (XYAW v2
//! when nonzero; encoded Scene labels use XYLB v6). ABI 188 admits labelled
//! cartesian marker `rotation` on that same XYAW v2 path (nums[8]).
//! ABI 170 admits
//! constant scatter `marker_glyph` via XYMG (no new pack kind).
//! ABI 145 admits constant `marker_path` via an XYMP extras sidecar;
//! tessellation is Scene-owned after pixel mapping (no new pack kind).
//! ABI 146 admits constant mark `fill` linear-gradients via an XYGR extras
//! sidecar (no new pack kind); encoded Scene keeps XYGR.
//! ABI 147 owns product packing facts from packed XYPK v1: hosts pass authored
//! kind, coords, step, curve-smooth, stroke-perimeter, density/heatmap paint
//! presence, hex pitch, and grid shape; Rust resolves flags, `step_mode`, and
//! extra0/extra1 so Python and Node cannot drift on cartesian-vs-polar smooth
//! or painted-vs-lattice heatmap dispatch. ABI 148 lives in
//! `scene_annotations.rs`: XYAF v2 facts pack wrap/text/arrow/callout/rule
//! routing so those families cannot drift. ABI 149 lives in
//! `scene_heatmap.rs`: XYHF v1 facts pack heatmap/density XYHP kind routing
//! so painted-lattice sidecars cannot drift. ABI 150 lives in
//! `scene_extras.rs`: XYSS v1 facts pack XYDS/XYLC/XYMP/XYGR/XYMG layout, concat
//! order, omit-empty, and XYEX wrapping so extras cannot drift. ABI 151 lives
//! in `scene_density.rs`: Scene density blit owns `bin_2d`, `density_log_u8`,
//! optional mean-color, and XYDE wrapping. ABI 152 owns public-export
//! XYEP layout, kind/step/annotation codes, and flag derivation from packed
//! XYEF v1.

use crate::scene::{MAX_SCENE_MARKS, SCENE_RECORD_Y2_BIT};

pub const PACKED_SCENE_ROW_BYTES: usize = 56;

pub const PACK_SCATTER: u8 = 0;
pub const PACK_LINE: u8 = 1;
pub const PACK_RECT: u8 = 2;
pub const PACK_BAND: u8 = 3;
pub const PACK_RIBBON: u8 = 4;
pub const PACK_TRIANGLE: u8 = 5;
pub const PACK_HEXBIN: u8 = 6;
pub const PACK_HEATMAP: u8 = 7;
pub const PACK_SEGMENT: u8 = 8;
pub const PACK_HEATMAP_PAINTED: u8 = 9;
pub const PACK_DENSITY_BLIT: u8 = 10;
/// Graph edge segments with border-aware ends (#33): two Polyline rows per
/// segment carrying each endpoint's node border radius and flag byte.
pub const PACK_EDGE_SEGMENT: u8 = 11;

pub const FLAG_STROKE_PERIMETER: u8 = 1 << 0;
pub const FLAG_HEATMAP_PAINTED: u8 = 1 << 1;
pub const FLAG_DENSITY_BLIT: u8 = 1 << 2;
pub const FLAG_JOINED_FILL: u8 = 1 << 3;
/// A `segments` trace's `base` column carries `edge_route::EDGE_ENDS_STRIDE`
/// values per segment (node center deltas, radii px, flag byte) (#33).
pub const FLAG_EDGE_ENDS: u8 = 1 << 4;
const PACK_FLAGS: u8 = FLAG_STROKE_PERIMETER
    | FLAG_HEATMAP_PAINTED
    | FLAG_DENSITY_BLIT
    | FLAG_JOINED_FILL
    | FLAG_EDGE_ENDS;

pub const XYPK_MAGIC: &[u8; 4] = b"XYPK";
pub const XYPK_VERSION: u32 = 1;
pub const XYPK_V1_HEADER_BYTES: usize = 64;
pub const FACT_STROKE_PERIMETER: u8 = 1 << 0;
pub const FACT_CURVE_SMOOTH: u8 = 1 << 1;
pub const FACT_DENSITY_PLANE: u8 = 1 << 2;
pub const FACT_HEATMAP_PAINT: u8 = 1 << 3;
pub const FACT_JOINED_FILL: u8 = 1 << 4;
/// Host observation: the segments trace ships graph edge ends (#33).
pub const FACT_EDGE_ENDS: u8 = 1 << 5;
const FACT_BITS: u8 = FACT_STROKE_PERIMETER
    | FACT_CURVE_SMOOTH
    | FACT_DENSITY_PLANE
    | FACT_HEATMAP_PAINT
    | FACT_JOINED_FILL
    | FACT_EDGE_ENDS;
pub const COORDS_CARTESIAN: u8 = 0;
pub const COORDS_POLAR: u8 = 1;

const KIND_SCATTER: u8 = 0;
const KIND_POLYLINE: u8 = 1;
const KIND_RECT: u8 = 2;
const KIND_BAND: u8 = 3;
const KIND_POLYFILL: u8 = 4;

const EXP_NONE: u8 = 0;
const EXP_RIBBON: u8 = 4;
const EXP_HEX: u8 = 5;
const EXP_HEATMAP: u8 = 6;
const EXP_SEGMENT: u8 = 7;
const EXP_TRIANGLE: u8 = 8;
const EXP_HEATMAP_PAINTED: u8 = 9;
const EXP_DENSITY_BLIT: u8 = 10;
const EXP_CURVE_FLATTEN: u8 = 11;
const EXP_BAND_FLATTEN: u8 = 12;
const EXP_EDGE_SEGMENT: u8 = 13;

/// Why a pack request was rejected. Discriminants are the C-ABI error codes
/// (returned negated by `xyg_scene_pack_trace`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(dead_code)] // Version is reserved for a future envelope; C ABI returns -2.
pub enum PackError {
    Length = 1,
    Version = 2,
    Limit = 3,
    Output = 4,
    NonFinite = 5,
    UnknownKind = 6,
}

/// One packed Scene row before `xyg_scene_batch_encode`.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PackedSceneRow {
    pub kind: u8,
    pub symbol: u8,
    pub expansion_mode: u8,
    pub style_ref: u32,
    pub stable_id: u64,
    pub diameter: f64,
    pub x0: f64,
    pub y0: f64,
    pub x1: f64,
    pub y1: f64,
    /// Plotted against the secondary y scale: row byte 3 bit
    /// [`crate::scene::SCENE_RECORD_Y2_BIT`]. Every other bit of byte 3 is
    /// reserved zero.
    pub y2: bool,
}

impl PackedSceneRow {
    pub fn to_bytes(self) -> [u8; PACKED_SCENE_ROW_BYTES] {
        let mut out = [0u8; PACKED_SCENE_ROW_BYTES];
        out[0] = self.kind;
        out[1] = self.symbol;
        out[2] = self.expansion_mode;
        out[3] = if self.y2 { SCENE_RECORD_Y2_BIT } else { 0 };
        out[4..8].copy_from_slice(&self.style_ref.to_le_bytes());
        out[8..16].copy_from_slice(&self.stable_id.to_le_bytes());
        out[16..24].copy_from_slice(&self.diameter.to_le_bytes());
        out[24..32].copy_from_slice(&self.x0.to_le_bytes());
        out[32..40].copy_from_slice(&self.y0.to_le_bytes());
        out[40..48].copy_from_slice(&self.x1.to_le_bytes());
        out[48..56].copy_from_slice(&self.y1.to_le_bytes());
        out
    }

    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() != PACKED_SCENE_ROW_BYTES {
            return None;
        }
        if bytes[3] & !SCENE_RECORD_Y2_BIT != 0 {
            return None;
        }
        Some(Self {
            kind: bytes[0],
            symbol: bytes[1],
            expansion_mode: bytes[2],
            y2: bytes[3] & SCENE_RECORD_Y2_BIT != 0,
            style_ref: u32::from_le_bytes(bytes[4..8].try_into().ok()?),
            stable_id: u64::from_le_bytes(bytes[8..16].try_into().ok()?),
            diameter: f64::from_le_bytes(bytes[16..24].try_into().ok()?),
            x0: f64::from_le_bytes(bytes[24..32].try_into().ok()?),
            y0: f64::from_le_bytes(bytes[32..40].try_into().ok()?),
            x1: f64::from_le_bytes(bytes[40..48].try_into().ok()?),
            y1: f64::from_le_bytes(bytes[48..56].try_into().ok()?),
        })
    }
}

/// Authoring literals for one trace's geometry columns.
#[derive(Clone, Copy)]
pub struct TracePackInput<'a> {
    pub pack_kind: u8,
    pub flags: u8,
    pub step_mode: u8,
    pub symbol: u8,
    pub style_ref: u32,
    pub trace_id: u64,
    pub diameter: f64,
    pub extra0: f64,
    pub extra1: f64,
    pub columns: &'a [&'a [f64]],
}

/// Canonical host envelope for one product-kind trace.
///
/// Column slots are `x`, `y`, `x0`, `y0`, `x1`, `y1`, `base`. Unused slots
/// may be empty. Rust maps `kind` plus flags onto `pack_trace` column order.
#[derive(Clone, Copy)]
pub struct ProductPackInput<'a> {
    pub kind: &'a str,
    pub flags: u8,
    pub step_mode: u8,
    pub symbol: u8,
    pub style_ref: u32,
    pub trace_id: u64,
    pub diameter: f64,
    pub extra0: f64,
    pub extra1: f64,
    pub x: &'a [f64],
    pub y: &'a [f64],
    pub x0: &'a [f64],
    pub y0: &'a [f64],
    pub x1: &'a [f64],
    pub y1: &'a [f64],
    pub base: &'a [f64],
}

/// Resolved packing fields from one XYPK v1 envelope.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ProductFacts<'a> {
    pub kind: &'a str,
    pub flags: u8,
    pub step_mode: u8,
    pub symbol: u8,
    pub style_ref: u32,
    pub trace_id: u64,
    pub diameter: f64,
    pub extra0: f64,
    pub extra1: f64,
}

fn require_cols<'a>(columns: &'a [&'a [f64]], count: usize) -> Result<&'a [&'a [f64]], PackError> {
    if columns.len() < count {
        return Err(PackError::Length);
    }
    let used = &columns[..count];
    if used.iter().any(|column| column.len() != used[0].len()) {
        return Err(PackError::Length);
    }
    Ok(used)
}

fn require_finite(columns: &[&[f64]]) -> Result<(), PackError> {
    if columns
        .iter()
        .any(|column| column.iter().any(|value| !value.is_finite()))
    {
        return Err(PackError::NonFinite);
    }
    Ok(())
}

fn split_id(trace_id: u64, index: usize) -> Result<u64, PackError> {
    let index = u64::try_from(index).map_err(|_| PackError::Limit)?;
    if index > u64::from(u32::MAX) {
        return Err(PackError::Limit);
    }
    Ok((trace_id << 32) | index)
}

fn push_row(out: &mut Vec<PackedSceneRow>, row: PackedSceneRow) -> Result<(), PackError> {
    if out.len() >= MAX_SCENE_MARKS {
        return Err(PackError::Limit);
    }
    out.push(row);
    Ok(())
}

/// Number of Scene rows one packed trace will emit.
pub fn packed_row_count(pack_kind: u8, n: usize) -> Result<usize, PackError> {
    let count = match pack_kind {
        PACK_SCATTER | PACK_LINE | PACK_RECT | PACK_BAND | PACK_HEXBIN | PACK_SEGMENT => n,
        PACK_EDGE_SEGMENT => n.checked_mul(2).ok_or(PackError::Limit)?,
        PACK_RIBBON => n.checked_mul(2).ok_or(PackError::Limit)?,
        // Unjoined faces emit 2 rows; a joined ring can emit 3 vertices per face.
        PACK_TRIANGLE => n.checked_mul(3).ok_or(PackError::Limit)?,
        PACK_HEATMAP | PACK_HEATMAP_PAINTED | PACK_DENSITY_BLIT => 2,
        _ => return Err(PackError::Length),
    };
    if count > MAX_SCENE_MARKS {
        return Err(PackError::Limit);
    }
    Ok(count)
}

/// Map a public product kind plus packing flags to a compact pack kind.
pub fn resolve_pack_kind(kind: &str, flags: u8) -> Result<u8, PackError> {
    if flags & !PACK_FLAGS != 0 {
        return Err(PackError::Length);
    }
    let painted = flags & FLAG_HEATMAP_PAINTED != 0;
    let density = flags & FLAG_DENSITY_BLIT != 0;
    if flags & FLAG_EDGE_ENDS != 0 {
        return if kind == "segments" && !painted && !density {
            Ok(PACK_EDGE_SEGMENT)
        } else {
            Err(PackError::Length)
        };
    }
    if painted && density {
        return Err(PackError::Length);
    }
    let pack_kind = match kind {
        "scatter" => {
            if density {
                PACK_DENSITY_BLIT
            } else {
                PACK_SCATTER
            }
        }
        "line" => PACK_LINE,
        "bar" | "column" | "histogram" | "violin" | "box" => PACK_RECT,
        "area" | "error_band" => PACK_BAND,
        "ribbon" => PACK_RIBBON,
        "triangle_mesh" => PACK_TRIANGLE,
        "hexbin" => PACK_HEXBIN,
        "heatmap" => {
            if painted {
                PACK_HEATMAP_PAINTED
            } else {
                PACK_HEATMAP
            }
        }
        "segments" | "errorbar" | "stem" | "contour" | "box_whisker" | "box_median" => PACK_SEGMENT,
        _ => return Err(PackError::UnknownKind),
    };
    if painted
        && pack_kind != PACK_HEATMAP_PAINTED
        && pack_kind != PACK_HEXBIN
        && pack_kind != PACK_RIBBON
        && pack_kind != PACK_TRIANGLE
        && pack_kind != PACK_SEGMENT
        && pack_kind != PACK_SCATTER
    {
        return Err(PackError::Length);
    }
    if density && pack_kind != PACK_DENSITY_BLIT {
        return Err(PackError::Length);
    }
    Ok(pack_kind)
}

/// Pack one product-kind trace from the canonical host column envelope.
pub fn pack_product(input: ProductPackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    let pack_kind = resolve_pack_kind(input.kind, input.flags)?;
    let flags = input.flags & (FLAG_STROKE_PERIMETER | FLAG_JOINED_FILL);
    let pack = |columns: &[&[f64]]| {
        pack_trace(TracePackInput {
            pack_kind,
            flags,
            step_mode: input.step_mode,
            symbol: input.symbol,
            style_ref: input.style_ref,
            trace_id: input.trace_id,
            diameter: input.diameter,
            extra0: input.extra0,
            extra1: input.extra1,
            columns,
        })
    };
    match pack_kind {
        PACK_SCATTER | PACK_LINE => {
            // An empty point/line trace draws nothing (a boxplot without
            // fliers, a legend proxy): a validated no-op, not a malformed pack.
            let columns = [input.x, input.y];
            if require_cols(&columns, 2)?[0].is_empty() {
                return Ok(Vec::new());
            }
            pack(&[input.x, input.y])
        }
        PACK_HEXBIN => {
            require_used(&[input.x, input.y])?;
            pack(&[input.x, input.y])
        }
        PACK_RECT | PACK_SEGMENT => {
            require_used(&[input.x0, input.y0, input.x1, input.y1])?;
            pack(&[input.x0, input.y0, input.x1, input.y1])
        }
        PACK_EDGE_SEGMENT => {
            // `base` carries EDGE_ENDS_STRIDE values per segment (#33).
            require_used(&[input.x0, input.y0, input.x1, input.y1])?;
            pack(&[input.x0, input.y0, input.x1, input.y1, input.base])
        }
        PACK_BAND => {
            require_used(&[input.x, input.y, input.base])?;
            pack(&[input.x, input.y, input.base])
        }
        PACK_RIBBON => {
            require_used(&[input.x0, input.x1, input.y0, input.y1, input.x, input.y])?;
            pack(&[input.x0, input.x1, input.y0, input.y1, input.x, input.y])
        }
        PACK_TRIANGLE => {
            require_used(&[input.x0, input.y0, input.x1, input.y1, input.x, input.y])?;
            pack(&[input.x0, input.y0, input.x1, input.y1, input.x, input.y])
        }
        PACK_HEATMAP | PACK_HEATMAP_PAINTED | PACK_DENSITY_BLIT => {
            let extent = heatmap_extent_columns(&input)?;
            pack(&[
                extent[0].as_slice(),
                extent[1].as_slice(),
                extent[2].as_slice(),
                extent[3].as_slice(),
            ])
        }
        _ => Err(PackError::Length),
    }
}

fn read_u32_at(bytes: &[u8], at: usize) -> Result<u32, PackError> {
    let slice = bytes.get(at..at + 4).ok_or(PackError::Length)?;
    Ok(u32::from_le_bytes(
        slice.try_into().map_err(|_| PackError::Length)?,
    ))
}

fn read_u64_at(bytes: &[u8], at: usize) -> Result<u64, PackError> {
    let slice = bytes.get(at..at + 8).ok_or(PackError::Length)?;
    Ok(u64::from_le_bytes(
        slice.try_into().map_err(|_| PackError::Length)?,
    ))
}

fn read_f64_at(bytes: &[u8], at: usize) -> Result<f64, PackError> {
    let slice = bytes.get(at..at + 8).ok_or(PackError::Length)?;
    Ok(f64::from_le_bytes(
        slice.try_into().map_err(|_| PackError::Length)?,
    ))
}

/// Parse XYPK v1 and resolve flags, step_mode, and extras from authored facts.
///
/// Header is 64 bytes; remaining UTF-8 is the product kind name.
pub fn parse_product_facts(bytes: &[u8]) -> Result<ProductFacts<'_>, PackError> {
    if bytes.len() < XYPK_V1_HEADER_BYTES || bytes.get(..4) != Some(&XYPK_MAGIC[..]) {
        return Err(PackError::Length);
    }
    if read_u32_at(bytes, 4)? != XYPK_VERSION {
        return Err(PackError::Version);
    }
    let style_ref = read_u32_at(bytes, 8)?;
    let coords = bytes[12];
    let mut symbol = bytes[13];
    let authored_step = bytes[14];
    let facts = bytes[15];
    if coords > COORDS_POLAR || facts & !FACT_BITS != 0 || authored_step > 3 {
        return Err(PackError::Length);
    }
    let trace_id = read_u64_at(bytes, 16)?;
    let mut diameter = read_f64_at(bytes, 24)?;
    let hex_dx = read_f64_at(bytes, 32)?;
    let hex_dy = read_f64_at(bytes, 40)?;
    let grid_rows = read_f64_at(bytes, 48)?;
    let grid_cols = read_f64_at(bytes, 56)?;
    let kind =
        std::str::from_utf8(&bytes[XYPK_V1_HEADER_BYTES..]).map_err(|_| PackError::Length)?;
    if kind.is_empty() || kind.len() > 32 || kind.contains('\0') {
        return Err(PackError::Length);
    }
    let density = facts & FACT_DENSITY_PLANE != 0;
    if density {
        symbol = 0;
        diameter = 0.0;
    }
    let mut flags = 0u8;
    if facts & FACT_STROKE_PERIMETER != 0 && matches!(kind, "area" | "error_band") {
        flags |= FLAG_STROKE_PERIMETER;
    }
    if facts & FACT_HEATMAP_PAINT != 0 {
        flags |= FLAG_HEATMAP_PAINTED;
    }
    if density {
        flags |= FLAG_DENSITY_BLIT;
    }
    if facts & FACT_JOINED_FILL != 0 && kind == "triangle_mesh" {
        flags |= FLAG_JOINED_FILL;
    }
    if facts & FACT_EDGE_ENDS != 0 && kind == "segments" && coords == COORDS_CARTESIAN {
        flags |= FLAG_EDGE_ENDS;
    }
    let mut step_mode = authored_step;
    if authored_step == 0
        && facts & FACT_CURVE_SMOOTH != 0
        && coords == COORDS_CARTESIAN
        && matches!(kind, "line" | "area" | "error_band")
    {
        step_mode = 4;
    }
    let (extra0, extra1) = if kind == "hexbin" {
        (hex_dx, hex_dy)
    } else if kind == "heatmap" || density {
        (grid_rows, grid_cols)
    } else {
        (0.0, 0.0)
    };
    Ok(ProductFacts {
        kind,
        flags,
        step_mode,
        symbol,
        style_ref,
        trace_id,
        diameter,
        extra0,
        extra1,
    })
}

/// Pack one product-kind trace from packed XYPK facts plus canonical columns.
pub fn pack_product_facts(
    facts: &[u8],
    x: &[f64],
    y: &[f64],
    x0: &[f64],
    y0: &[f64],
    x1: &[f64],
    y1: &[f64],
    base: &[f64],
) -> Result<Vec<PackedSceneRow>, PackError> {
    let parsed = parse_product_facts(facts)?;
    pack_product(ProductPackInput {
        kind: parsed.kind,
        flags: parsed.flags,
        step_mode: parsed.step_mode,
        symbol: parsed.symbol,
        style_ref: parsed.style_ref,
        trace_id: parsed.trace_id,
        diameter: parsed.diameter,
        extra0: parsed.extra0,
        extra1: parsed.extra1,
        x,
        y,
        x0,
        y0,
        x1,
        y1,
        base,
    })
}

fn require_used<'a>(columns: &'a [&'a [f64]]) -> Result<&'a [&'a [f64]], PackError> {
    let used = require_cols(columns, columns.len())?;
    if used[0].is_empty() {
        return Err(PackError::Length);
    }
    Ok(used)
}

fn heatmap_extent_columns(input: &ProductPackInput<'_>) -> Result<[Vec<f64>; 4], PackError> {
    let (x0, y0, x1, y1) = if input.x.len() == 2 && input.y.len() == 2 {
        (input.x[0], input.y[0], input.x[1], input.y[1])
    } else if input.x0.len() == 1
        && input.y0.len() == 1
        && input.x1.len() == 1
        && input.y1.len() == 1
    {
        (input.x0[0], input.y0[0], input.x1[0], input.y1[0])
    } else {
        return Err(PackError::Length);
    };
    Ok([vec![x0], vec![y0], vec![x1], vec![y1]])
}

/// Pack one trace's columns into Scene rows (kind, id, coords, expansion).
pub fn pack_trace(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    if input.flags & !(FLAG_STROKE_PERIMETER | FLAG_JOINED_FILL) != 0 {
        return Err(PackError::Length);
    }
    if input.flags & FLAG_JOINED_FILL != 0 && input.pack_kind != PACK_TRIANGLE {
        return Err(PackError::Length);
    }
    if input.step_mode > 4 {
        return Err(PackError::Length);
    }
    if input.step_mode != 0 && input.pack_kind != PACK_LINE && input.pack_kind != PACK_BAND {
        return Err(PackError::Length);
    }
    match input.pack_kind {
        PACK_SCATTER => pack_xy(input, KIND_SCATTER, input.symbol, input.diameter, EXP_NONE),
        PACK_LINE => {
            let expansion = if input.step_mode == 4 {
                EXP_CURVE_FLATTEN
            } else {
                input.step_mode
            };
            pack_xy(input, KIND_POLYLINE, 0, 0.0, expansion)
        }
        PACK_RECT => pack_quad(input, KIND_RECT, 0, 0.0, EXP_NONE, false),
        PACK_SEGMENT => pack_quad(input, KIND_POLYLINE, 0, 0.0, EXP_SEGMENT, true),
        PACK_EDGE_SEGMENT => pack_edge_segment(input),
        PACK_BAND => pack_band(input),
        PACK_RIBBON => pack_ribbon(input),
        PACK_TRIANGLE => pack_triangle(input),
        PACK_HEXBIN => pack_hexbin(input),
        PACK_HEATMAP => pack_heatmap(input, EXP_HEATMAP),
        PACK_HEATMAP_PAINTED => pack_heatmap(input, EXP_HEATMAP_PAINTED),
        PACK_DENSITY_BLIT => pack_heatmap(input, EXP_DENSITY_BLIT),
        _ => Err(PackError::Length),
    }
}

fn pack_xy(
    input: TracePackInput<'_>,
    kind: u8,
    symbol: u8,
    diameter: f64,
    expansion: u8,
) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 2)?;
    require_finite(cols)?;
    let mut out = Vec::with_capacity(cols[0].len());
    for index in 0..cols[0].len() {
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind,
                symbol,
                expansion_mode: expansion,
                style_ref: input.style_ref,
                stable_id: input.trace_id,
                diameter,
                x0: cols[0][index],
                y0: cols[1][index],
                x1: 0.0,
                y1: 0.0,
            },
        )?;
    }
    Ok(out)
}

fn pack_quad(
    input: TracePackInput<'_>,
    kind: u8,
    symbol: u8,
    diameter: f64,
    expansion: u8,
    split_ids: bool,
) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 4)?;
    require_finite(cols)?;
    let mut out = Vec::with_capacity(cols[0].len());
    for index in 0..cols[0].len() {
        let stable_id = if split_ids {
            split_id(input.trace_id, index)?
        } else {
            input.trace_id
        };
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind,
                symbol,
                expansion_mode: expansion,
                style_ref: input.style_ref,
                stable_id,
                diameter,
                x0: cols[0][index],
                y0: cols[1][index],
                x1: cols[2][index],
                y1: cols[3][index],
            },
        )?;
    }
    Ok(out)
}

/// Two Polyline rows per graph edge segment: each endpoint keeps its node
/// border radius (`diameter`) and flag byte (`symbol`) so the Scene pixel
/// pass can trim to the node outline and add the arrowhead (#33).
fn pack_edge_segment(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    use crate::edge_route::{
        EDGE_ENDS_STRIDE, EDGE_END_HEAD, EDGE_END_MARK, EDGE_END_SHAPE_MASK, EDGE_END_TERMINAL,
        EDGE_SEGMENT_FLAG_MASK, EDGE_START_SHAPE_SHIFT,
    };
    let cols = require_cols(input.columns, 4)?;
    require_finite(cols)?;
    let n = cols[0].len();
    let ends = input.columns.get(4).ok_or(PackError::Length)?;
    if ends.len() != n.checked_mul(EDGE_ENDS_STRIDE).ok_or(PackError::Limit)? {
        return Err(PackError::Length);
    }
    require_finite(&[ends])?;
    let mut out = Vec::with_capacity(n * 2);
    for index in 0..n {
        let row = &ends[index * EDGE_ENDS_STRIDE..(index + 1) * EDGE_ENDS_STRIDE];
        let (r0, r1, bits) = (row[2], row[5], row[6]);
        if r0 < 0.0 || r1 < 0.0 || bits < 0.0 || bits > 255.0 || bits.fract() != 0.0 {
            return Err(PackError::Length);
        }
        let bits = bits as u8;
        if bits & !EDGE_SEGMENT_FLAG_MASK != 0 {
            return Err(PackError::Length);
        }
        let start_shape = (bits >> EDGE_START_SHAPE_SHIFT) & EDGE_END_SHAPE_MASK;
        let end = bits & (EDGE_END_HEAD | EDGE_END_TERMINAL | EDGE_END_SHAPE_MASK);
        let (ax, ay) = (cols[0][index], cols[1][index]);
        let stable_id = split_id(input.trace_id, index)?;
        // Each endpoint row carries its node's absolute center in x1/y1.
        for (x, y, cx, cy, radius, symbol) in [
            (
                ax,
                ay,
                ax + row[0],
                ay + row[1],
                r0,
                EDGE_END_MARK | start_shape,
            ),
            (
                cols[2][index],
                cols[3][index],
                ax + row[3],
                ay + row[4],
                r1,
                EDGE_END_MARK | end,
            ),
        ] {
            push_row(
                &mut out,
                PackedSceneRow {
                    y2: false,
                    kind: KIND_POLYLINE,
                    symbol,
                    expansion_mode: EXP_EDGE_SEGMENT,
                    style_ref: input.style_ref,
                    stable_id,
                    diameter: radius,
                    x0: x,
                    y0: y,
                    x1: cx,
                    y1: cy,
                },
            )?;
        }
    }
    Ok(out)
}

fn pack_band(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 3)?;
    require_finite(cols)?;
    let outline = if input.flags & FLAG_STROKE_PERIMETER != 0 {
        2
    } else {
        1
    };
    let expansion = if input.step_mode == 4 {
        EXP_BAND_FLATTEN
    } else {
        input.step_mode
    };
    let mut out = Vec::with_capacity(cols[0].len());
    for index in 0..cols[0].len() {
        let x = cols[0][index];
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind: KIND_BAND,
                symbol: outline,
                expansion_mode: expansion,
                style_ref: input.style_ref,
                stable_id: input.trace_id,
                diameter: 0.0,
                x0: x,
                y0: cols[1][index],
                x1: x,
                y1: cols[2][index],
            },
        )?;
    }
    Ok(out)
}

fn pack_ribbon(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 6)?;
    require_finite(cols)?;
    let mut out = Vec::with_capacity(cols[0].len().saturating_mul(2));
    for index in 0..cols[0].len() {
        let stable_id = split_id(input.trace_id, index)?;
        let x0 = cols[0][index];
        let x1 = cols[1][index];
        let source_lo = cols[2][index];
        let source_hi = cols[3][index];
        let target_lo = cols[4][index];
        let target_hi = cols[5][index];
        for (start_y, end_y) in [(source_hi, target_hi), (source_lo, target_lo)] {
            push_row(
                &mut out,
                PackedSceneRow {
                    y2: false,
                    kind: KIND_BAND,
                    symbol: 2,
                    expansion_mode: EXP_RIBBON,
                    style_ref: input.style_ref,
                    stable_id,
                    diameter: 0.0,
                    x0,
                    y0: start_y,
                    x1,
                    y1: end_y,
                },
            )?;
        }
    }
    Ok(out)
}

fn pack_triangle(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 6)?;
    require_finite(cols)?;
    if input.flags & FLAG_JOINED_FILL != 0 {
        if let Some(boundary) = crate::geom::triangle_mesh_boundary(
            cols[0], cols[1], cols[2], cols[3], cols[4], cols[5],
        ) {
            if boundary.len() >= 3 {
                let mut out = Vec::with_capacity(boundary.len());
                for &(x, y) in &boundary {
                    push_row(
                        &mut out,
                        PackedSceneRow {
                            y2: false,
                            kind: KIND_POLYFILL,
                            symbol: 0,
                            expansion_mode: EXP_NONE,
                            style_ref: input.style_ref,
                            stable_id: input.trace_id,
                            diameter: 0.0,
                            x0: x,
                            y0: y,
                            x1: 0.0,
                            y1: 0.0,
                        },
                    )?;
                }
                return Ok(out);
            }
        }
    }
    let mut out = Vec::with_capacity(cols[0].len().saturating_mul(2));
    for index in 0..cols[0].len() {
        let stable_id = split_id(input.trace_id, index)?;
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind: KIND_POLYFILL,
                symbol: 0,
                expansion_mode: EXP_TRIANGLE,
                style_ref: input.style_ref,
                stable_id,
                diameter: 0.0,
                x0: cols[0][index],
                y0: cols[1][index],
                x1: cols[2][index],
                y1: cols[3][index],
            },
        )?;
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind: KIND_POLYFILL,
                symbol: 0,
                expansion_mode: EXP_TRIANGLE,
                style_ref: input.style_ref,
                stable_id,
                diameter: 0.0,
                x0: cols[4][index],
                y0: cols[5][index],
                x1: 0.0,
                y1: 0.0,
            },
        )?;
    }
    Ok(out)
}

fn pack_hexbin(input: TracePackInput<'_>) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 2)?;
    require_finite(cols)?;
    if !input.extra0.is_finite()
        || !input.extra1.is_finite()
        || input.extra0 <= 0.0
        || input.extra1 <= 0.0
    {
        return Err(PackError::NonFinite);
    }
    let mut out = Vec::with_capacity(cols[0].len());
    for index in 0..cols[0].len() {
        push_row(
            &mut out,
            PackedSceneRow {
                y2: false,
                kind: KIND_POLYFILL,
                symbol: 0,
                expansion_mode: EXP_HEX,
                style_ref: input.style_ref,
                stable_id: split_id(input.trace_id, index)?,
                diameter: 0.0,
                x0: cols[0][index],
                y0: cols[1][index],
                x1: input.extra0,
                y1: input.extra1,
            },
        )?;
    }
    Ok(out)
}

fn pack_heatmap(
    input: TracePackInput<'_>,
    expansion: u8,
) -> Result<Vec<PackedSceneRow>, PackError> {
    let cols = require_cols(input.columns, 4)?;
    if cols[0].len() != 1 {
        return Err(PackError::Length);
    }
    require_finite(cols)?;
    let rows = input.extra0;
    let cols_n = input.extra1;
    if !(rows.is_finite() && cols_n.is_finite() && rows >= 1.0 && cols_n >= 1.0)
        || rows.fract() != 0.0
        || cols_n.fract() != 0.0
    {
        return Err(PackError::NonFinite);
    }
    let x0 = cols[0][0];
    let y0 = cols[1][0];
    let x1 = cols[2][0];
    let y1 = cols[3][0];
    if x0 >= x1 || y0 >= y1 {
        return Err(PackError::NonFinite);
    }
    let mut out = Vec::with_capacity(2);
    push_row(
        &mut out,
        PackedSceneRow {
            y2: false,
            kind: KIND_RECT,
            symbol: 0,
            expansion_mode: expansion,
            style_ref: input.style_ref,
            stable_id: input.trace_id,
            diameter: rows,
            x0,
            y0,
            x1,
            y1,
        },
    )?;
    push_row(
        &mut out,
        PackedSceneRow {
            y2: false,
            kind: KIND_RECT,
            symbol: 0,
            expansion_mode: expansion,
            style_ref: input.style_ref,
            stable_id: input.trace_id,
            diameter: cols_n,
            x0: 0.0,
            y0: 0.0,
            x1: 0.0,
            y1: 0.0,
        },
    )?;
    Ok(out)
}

pub const ANN_MARK_ROW_BYTES: usize = 40;
pub const ANN_KIND_RULE: u8 = 1;
pub const ANN_KIND_BAND: u8 = 2;
pub const ANN_KIND_MARKER: u8 = 3;
/// Scene rows `pack_annotation_marks` emits per annotation kind (#1006):
/// a rule is a two-vertex Polyline, a band one Rect, a marker one Scatter.
/// The public predicate charges these against `MAX_SCENE_MARKS`; the
/// `annotation_mark_row_counts_match_the_packer` test pins them.
pub const ANN_RULE_ROWS: usize = 2;
pub const ANN_BAND_ROWS: usize = 1;
pub const ANN_MARKER_ROWS: usize = 1;
const ANN_AXIS_X: u8 = 0;
const ANN_AXIS_Y: u8 = 1;
const ANN_ID_PREFIX: u64 = 0x5859_0000_0000_0000;

/// One authored rule/band/marker before domain expansion.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AnnotationMarkInput {
    pub kind: u8,
    pub axis: u8,
    pub symbol: u8,
    pub style_ref: u32,
    pub index: u32,
    pub value0: f64,
    pub value1: f64,
    pub size: f64,
}

fn annotation_stable_id(tag: u8, index: u32) -> u64 {
    ANN_ID_PREFIX | (u64::from(tag) << 40) | u64::from(index)
}

fn parse_annotation_mark_row(bytes: &[u8]) -> Result<AnnotationMarkInput, PackError> {
    if bytes.len() != ANN_MARK_ROW_BYTES {
        return Err(PackError::Length);
    }
    if bytes[3] != 0 || bytes[12..16] != [0, 0, 0, 0] {
        return Err(PackError::Length);
    }
    Ok(AnnotationMarkInput {
        kind: bytes[0],
        axis: bytes[1],
        symbol: bytes[2],
        style_ref: u32::from_le_bytes(bytes[4..8].try_into().unwrap()),
        index: u32::from_le_bytes(bytes[8..12].try_into().unwrap()),
        value0: f64::from_le_bytes(bytes[16..24].try_into().unwrap()),
        value1: f64::from_le_bytes(bytes[24..32].try_into().unwrap()),
        size: f64::from_le_bytes(bytes[32..40].try_into().unwrap()),
    })
}

/// Parse a packed `ANN_MARK_ROW_BYTES` table.
pub fn parse_annotation_mark_rows(bytes: &[u8]) -> Result<Vec<AnnotationMarkInput>, PackError> {
    if bytes.len() % ANN_MARK_ROW_BYTES != 0 {
        return Err(PackError::Length);
    }
    bytes
        .chunks_exact(ANN_MARK_ROW_BYTES)
        .map(parse_annotation_mark_row)
        .collect()
}

fn push_ann_row(
    out: &mut Vec<PackedSceneRow>,
    kind: u8,
    symbol: u8,
    style_ref: u32,
    stable_id: u64,
    diameter: f64,
    x0: f64,
    y0: f64,
    x1: f64,
    y1: f64,
) -> Result<(), PackError> {
    if ![x0, y0, x1, y1, diameter]
        .iter()
        .all(|value| value.is_finite())
    {
        return Err(PackError::NonFinite);
    }
    push_row(
        out,
        PackedSceneRow {
            y2: false,
            kind,
            symbol,
            expansion_mode: EXP_NONE,
            style_ref,
            stable_id,
            diameter,
            x0,
            y0,
            x1,
            y1,
        },
    )
}

/// Expand authored rule/band/marker scalars across the primary axis domains
/// into ordinary Scene polyline/rect/scatter rows. Hosts pack kind, axis,
/// style ref, index, and scalars; Rust owns tags, domain spanning, and
/// finite rejection.
pub fn pack_annotation_marks(
    rows: &[AnnotationMarkInput],
    x0: f64,
    x1: f64,
    y0: f64,
    y1: f64,
) -> Result<Vec<PackedSceneRow>, PackError> {
    if ![x0, x1, y0, y1].iter().all(|value| value.is_finite()) {
        return Err(PackError::NonFinite);
    }
    let mut out = Vec::new();
    for row in rows {
        match row.kind {
            ANN_KIND_RULE => {
                if row.axis != ANN_AXIS_X && row.axis != ANN_AXIS_Y {
                    return Err(PackError::Length);
                }
                let stable_id = annotation_stable_id(1, row.index);
                let (ax, ay, bx, by) = if row.axis == ANN_AXIS_X {
                    (row.value0, y0, row.value0, y1)
                } else {
                    (x0, row.value0, x1, row.value0)
                };
                push_ann_row(
                    &mut out,
                    KIND_POLYLINE,
                    0,
                    row.style_ref,
                    stable_id,
                    0.0,
                    ax,
                    ay,
                    0.0,
                    0.0,
                )?;
                push_ann_row(
                    &mut out,
                    KIND_POLYLINE,
                    0,
                    row.style_ref,
                    stable_id,
                    0.0,
                    bx,
                    by,
                    0.0,
                    0.0,
                )?;
            }
            ANN_KIND_BAND => {
                if row.axis != ANN_AXIS_X && row.axis != ANN_AXIS_Y {
                    return Err(PackError::Length);
                }
                let tag = if row.axis == ANN_AXIS_Y { 4 } else { 2 };
                let stable_id = annotation_stable_id(tag, row.index);
                let (ax, ay, bx, by) = if row.axis == ANN_AXIS_X {
                    (row.value0, y0, row.value1, y1)
                } else {
                    (x0, row.value0, x1, row.value1)
                };
                push_ann_row(
                    &mut out,
                    KIND_RECT,
                    0,
                    row.style_ref,
                    stable_id,
                    0.0,
                    ax,
                    ay,
                    bx,
                    by,
                )?;
            }
            ANN_KIND_MARKER => {
                if !row.size.is_finite() || row.size <= 0.0 {
                    return Err(PackError::Length);
                }
                let stable_id = annotation_stable_id(3, row.index);
                push_ann_row(
                    &mut out,
                    KIND_SCATTER,
                    row.symbol,
                    row.style_ref,
                    stable_id,
                    row.size,
                    row.value0,
                    row.value1,
                    0.0,
                    0.0,
                )?;
            }
            _ => return Err(PackError::Length),
        }
    }
    Ok(out)
}

/// Encode packed rows into the C-ABI output buffer. Returns the row count.
pub fn encode_packed_rows(rows: &[PackedSceneRow], out: &mut [u8]) -> Result<i32, PackError> {
    let needed = rows
        .len()
        .checked_mul(PACKED_SCENE_ROW_BYTES)
        .ok_or(PackError::Limit)?;
    if out.len() < needed {
        return Err(PackError::Output);
    }
    for (index, row) in rows.iter().enumerate() {
        let start = index * PACKED_SCENE_ROW_BYTES;
        out[start..start + PACKED_SCENE_ROW_BYTES].copy_from_slice(&row.to_bytes());
    }
    i32::try_from(rows.len()).map_err(|_| PackError::Limit)
}

#[cfg(test)]
mod tests {

    #[test]
    fn edge_segment_pack_emits_two_flagged_endpoint_rows() {
        let (x0, y0, x1, y1) = ([1.0], [1.0], [4.0], [3.0]);
        // Source center (0,0) and target center (5,4) as deltas from (1,1).
        let flags = f64::from(0x40 | 0x20 | 1 | (2 << 2));
        let ends = [-1.0, -1.0, 4.0, 4.0, 3.0, 6.0, flags];
        let pack = |ends: &[f64], kind| {
            pack_product(ProductPackInput {
                kind,
                flags: FLAG_EDGE_ENDS,
                step_mode: 0,
                symbol: 0,
                style_ref: 2,
                trace_id: 5,
                diameter: 0.0,
                extra0: 0.0,
                extra1: 0.0,
                x: &[],
                y: &[],
                x0: &x0,
                y0: &y0,
                x1: &x1,
                y1: &y1,
                base: ends,
            })
        };
        let rows = pack(&ends, "segments").expect("edge pack");
        assert_eq!(rows.len(), 2);
        assert_eq!(packed_row_count(PACK_EDGE_SEGMENT, 1), Ok(2));
        let row0 = (rows[0].x0, rows[0].y0, rows[0].x1, rows[0].y1);
        assert_eq!(row0, (1.0, 1.0, 0.0, 0.0));
        assert_eq!((rows[0].diameter, rows[0].symbol), (4.0, 0x80 | 2));
        let row1 = (rows[1].x0, rows[1].y0, rows[1].x1, rows[1].y1);
        assert_eq!(row1, (4.0, 3.0, 5.0, 4.0));
        assert_eq!(
            (rows[1].diameter, rows[1].symbol),
            (6.0, 0x80 | 0x40 | 0x20 | 1)
        );
        assert!(rows
            .iter()
            .all(|row| row.stable_id == 5 << 32 && row.expansion_mode == EXP_EDGE_SEGMENT));
        // Unknown flag bits, negative radii, short ends, and non-segment kinds
        // are rejected.
        let mut bad_flag = ends;
        bad_flag[6] = 128.0;
        let mut bad_radius = ends;
        bad_radius[2] = -1.0;
        assert!(pack(&bad_flag, "segments").is_err());
        assert!(pack(&bad_radius, "segments").is_err());
        assert!(pack(&ends[..6], "segments").is_err());
        assert!(pack(&ends, "line").is_err());
    }
    use super::*;

    #[test]
    fn annotation_mark_row_counts_match_the_packer() {
        for (kind, expected) in [
            (ANN_KIND_RULE, ANN_RULE_ROWS),
            (ANN_KIND_BAND, ANN_BAND_ROWS),
            (ANN_KIND_MARKER, ANN_MARKER_ROWS),
        ] {
            let row = AnnotationMarkInput {
                kind,
                axis: ANN_AXIS_X,
                symbol: 0,
                style_ref: 0,
                index: 0,
                value0: 0.25,
                value1: 0.75,
                size: 6.0,
            };
            let rows = pack_annotation_marks(&[row], 0.0, 1.0, 0.0, 1.0).unwrap();
            assert_eq!(rows.len(), expected, "kind {kind}");
        }
    }

    #[test]
    fn scatter_keeps_one_row_per_point() {
        let x = [0.0, 1.0];
        let y = [2.0, 3.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_SCATTER,
            flags: 0,
            step_mode: 0,
            symbol: 4,
            style_ref: 1,
            trace_id: 7,
            diameter: 6.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x, &y],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[1].kind, KIND_SCATTER);
        assert_eq!(rows[1].symbol, 4);
        assert_eq!(rows[1].stable_id, 7);
        assert_eq!(rows[1].diameter, 6.0);
        assert_eq!(
            (rows[1].x0, rows[1].y0, rows[1].x1, rows[1].y1),
            (1.0, 3.0, 0.0, 0.0)
        );
    }

    #[test]
    fn ribbon_emits_upper_then_lower_with_split_ids() {
        let x0 = [0.0];
        let x1 = [1.0];
        let y0 = [2.0];
        let y1 = [4.0];
        let tx = [3.0];
        let ty = [5.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_RIBBON,
            flags: 0,
            step_mode: 0,
            symbol: 0,
            style_ref: 0,
            trace_id: 1,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x0, &x1, &y0, &y1, &tx, &ty],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].expansion_mode, EXP_RIBBON);
        assert_eq!(rows[0].stable_id, (1 << 32) | 0);
        assert_eq!((rows[0].y0, rows[0].y1), (4.0, 5.0));
        assert_eq!((rows[1].y0, rows[1].y1), (2.0, 3.0));
    }

    #[test]
    fn heatmap_frames_extent_then_shape() {
        let x0 = [1.0];
        let y0 = [2.0];
        let x1 = [3.0];
        let y1 = [4.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_HEATMAP,
            flags: 0,
            step_mode: 0,
            symbol: 0,
            style_ref: 9,
            trace_id: 11,
            diameter: 0.0,
            extra0: 2.0,
            extra1: 3.0,
            columns: &[&x0, &y0, &x1, &y1],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].diameter, 2.0);
        assert_eq!(rows[1].diameter, 3.0);
        assert_eq!(rows[0].stable_id, 11);
        assert_eq!(rows[1].expansion_mode, EXP_HEATMAP);
        assert_eq!(
            (rows[1].x0, rows[1].y0, rows[1].x1, rows[1].y1),
            (0.0, 0.0, 0.0, 0.0)
        );
    }

    #[test]
    fn painted_heatmap_frames_extent_with_painted_mode() {
        let x0 = [1.0];
        let y0 = [2.0];
        let x1 = [3.0];
        let y1 = [4.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_HEATMAP_PAINTED,
            flags: 0,
            step_mode: 0,
            symbol: 0,
            style_ref: 9,
            trace_id: 11,
            diameter: 0.0,
            extra0: 2.0,
            extra1: 3.0,
            columns: &[&x0, &y0, &x1, &y1],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].expansion_mode, EXP_HEATMAP_PAINTED);
        assert_eq!(rows[1].expansion_mode, EXP_HEATMAP_PAINTED);
        assert_eq!(rows[0].diameter, 2.0);
        assert_eq!(rows[1].diameter, 3.0);
    }

    #[test]
    fn nonfinite_coordinates_fail_closed() {
        let x = [0.0, f64::NAN];
        let y = [1.0, 2.0];
        assert_eq!(
            pack_trace(TracePackInput {
                pack_kind: PACK_LINE,
                flags: 0,
                step_mode: 0,
                symbol: 0,
                style_ref: 0,
                trace_id: 0,
                diameter: 0.0,
                extra0: 0.0,
                extra1: 0.0,
                columns: &[&x, &y],
            }),
            Err(PackError::NonFinite)
        );
    }

    #[test]
    fn smooth_line_packs_curve_flatten_expansion() {
        let x = [0.0, 1.0, 2.0];
        let y = [0.0, 1.0, 0.5];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_LINE,
            flags: 0,
            step_mode: 4,
            symbol: 0,
            style_ref: 0,
            trace_id: 11,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x, &y],
        })
        .unwrap();
        assert_eq!(rows.len(), 3);
        assert!(rows
            .iter()
            .all(|row| row.expansion_mode == EXP_CURVE_FLATTEN && row.kind == KIND_POLYLINE));
        assert_eq!(
            pack_trace(TracePackInput {
                pack_kind: PACK_LINE,
                flags: 0,
                step_mode: 5,
                symbol: 0,
                style_ref: 0,
                trace_id: 0,
                diameter: 0.0,
                extra0: 0.0,
                extra1: 0.0,
                columns: &[&x, &y],
            }),
            Err(PackError::Length)
        );
    }

    #[test]
    fn smooth_area_packs_band_flatten_expansion() {
        let x = [0.0, 1.0, 2.0];
        let y = [0.0, 1.0, 0.5];
        let base = [0.0, 0.0, 0.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_BAND,
            flags: 0,
            step_mode: 4,
            symbol: 0,
            style_ref: 0,
            trace_id: 11,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x, &y, &base],
        })
        .unwrap();
        assert_eq!(rows.len(), 3);
        assert!(rows.iter().all(|row| {
            row.expansion_mode == EXP_BAND_FLATTEN
                && row.kind == KIND_BAND
                && row.x0 == row.x1
                && row.symbol == 1
        }));
        let stepped = pack_trace(TracePackInput {
            pack_kind: PACK_BAND,
            flags: 0,
            step_mode: 1,
            symbol: 0,
            style_ref: 0,
            trace_id: 0,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x, &y, &base],
        })
        .unwrap();
        assert_eq!(stepped.len(), 3);
        assert!(stepped.iter().all(|row| {
            row.expansion_mode == 1 && row.kind == KIND_BAND && row.x0 == row.x1 && row.symbol == 1
        }));
    }

    fn ann_row(
        kind: u8,
        axis: u8,
        symbol: u8,
        style_ref: u32,
        index: u32,
        value0: f64,
        value1: f64,
        size: f64,
    ) -> AnnotationMarkInput {
        AnnotationMarkInput {
            kind,
            axis,
            symbol,
            style_ref,
            index,
            value0,
            value1,
            size,
        }
    }

    #[test]
    fn rule_spans_the_opposite_axis_domain() {
        let rows = pack_annotation_marks(
            &[ann_row(ANN_KIND_RULE, ANN_AXIS_X, 0, 3, 7, 1.5, 0.0, 0.0)],
            0.0,
            4.0,
            10.0,
            20.0,
        )
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].kind, KIND_POLYLINE);
        assert_eq!(rows[0].style_ref, 3);
        assert_eq!(rows[0].stable_id, ANN_ID_PREFIX | (1 << 40) | 7);
        assert_eq!(
            (rows[0].x0, rows[0].y0, rows[1].x0, rows[1].y0),
            (1.5, 10.0, 1.5, 20.0)
        );
    }

    #[test]
    fn y_band_uses_tag_four_and_spans_x_domain() {
        let rows = pack_annotation_marks(
            &[ann_row(ANN_KIND_BAND, ANN_AXIS_Y, 0, 1, 2, 3.0, 5.0, 0.0)],
            0.0,
            10.0,
            -1.0,
            1.0,
        )
        .unwrap();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].kind, KIND_RECT);
        assert_eq!(rows[0].stable_id, ANN_ID_PREFIX | (4 << 40) | 2);
        assert_eq!(
            (rows[0].x0, rows[0].y0, rows[0].x1, rows[0].y1),
            (0.0, 3.0, 10.0, 5.0)
        );
    }

    #[test]
    fn marker_keeps_authored_point_size_and_symbol() {
        let rows = pack_annotation_marks(
            &[ann_row(ANN_KIND_MARKER, 0, 4, 8, 9, 1.0, 2.0, 6.0)],
            0.0,
            1.0,
            0.0,
            1.0,
        )
        .unwrap();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].kind, KIND_SCATTER);
        assert_eq!(rows[0].symbol, 4);
        assert_eq!(rows[0].diameter, 6.0);
        assert_eq!(rows[0].stable_id, ANN_ID_PREFIX | (3 << 40) | 9);
        assert_eq!((rows[0].x0, rows[0].y0), (1.0, 2.0));
    }

    #[test]
    fn annotation_marks_reject_bad_kind_and_nonfinite_domain() {
        assert_eq!(
            pack_annotation_marks(&[ann_row(9, 0, 0, 0, 0, 0.0, 0.0, 1.0)], 0.0, 1.0, 0.0, 1.0),
            Err(PackError::Length)
        );
        assert_eq!(
            pack_annotation_marks(
                &[ann_row(ANN_KIND_RULE, 0, 0, 0, 0, 0.0, 0.0, 0.0)],
                0.0,
                f64::NAN,
                0.0,
                1.0
            ),
            Err(PackError::NonFinite)
        );
    }

    #[test]
    fn product_kind_maps_heatmap_paint_flag() {
        assert_eq!(resolve_pack_kind("scatter", 0).unwrap(), PACK_SCATTER);
        assert_eq!(resolve_pack_kind("column", 0).unwrap(), PACK_RECT);
        assert_eq!(resolve_pack_kind("contour", 0).unwrap(), PACK_SEGMENT);
        assert_eq!(resolve_pack_kind("heatmap", 0).unwrap(), PACK_HEATMAP);
        assert_eq!(
            resolve_pack_kind("heatmap", FLAG_HEATMAP_PAINTED).unwrap(),
            PACK_HEATMAP_PAINTED
        );
        assert_eq!(
            resolve_pack_kind("hexbin", FLAG_HEATMAP_PAINTED).unwrap(),
            PACK_HEXBIN
        );
        assert_eq!(
            resolve_pack_kind("ribbon", FLAG_HEATMAP_PAINTED).unwrap(),
            PACK_RIBBON
        );
        assert_eq!(
            resolve_pack_kind("triangle_mesh", FLAG_HEATMAP_PAINTED).unwrap(),
            PACK_TRIANGLE
        );
        assert_eq!(
            resolve_pack_kind("scatter", FLAG_HEATMAP_PAINTED).unwrap(),
            PACK_SCATTER
        );
        assert_eq!(
            resolve_pack_kind("line", FLAG_HEATMAP_PAINTED),
            Err(PackError::Length)
        );
        assert_eq!(
            resolve_pack_kind("scatter", FLAG_DENSITY_BLIT).unwrap(),
            PACK_DENSITY_BLIT
        );
        assert_eq!(
            resolve_pack_kind("heatmap", FLAG_DENSITY_BLIT),
            Err(PackError::Length)
        );
        assert_eq!(
            resolve_pack_kind("scatter", FLAG_HEATMAP_PAINTED | FLAG_DENSITY_BLIT),
            Err(PackError::Length)
        );
        assert_eq!(resolve_pack_kind("density", 0), Err(PackError::UnknownKind));
    }

    #[test]
    fn pack_product_scatter_matches_pack_trace() {
        let x = [0.0, 1.0];
        let y = [2.0, 3.0];
        let packed = pack_product(ProductPackInput {
            kind: "scatter",
            flags: 0,
            step_mode: 0,
            symbol: 4,
            style_ref: 1,
            trace_id: 7,
            diameter: 6.0,
            extra0: 0.0,
            extra1: 0.0,
            x: &x,
            y: &y,
            x0: &[],
            y0: &[],
            x1: &[],
            y1: &[],
            base: &[],
        })
        .unwrap();
        let direct = pack_trace(TracePackInput {
            pack_kind: PACK_SCATTER,
            flags: 0,
            step_mode: 0,
            symbol: 4,
            style_ref: 1,
            trace_id: 7,
            diameter: 6.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x, &y],
        })
        .unwrap();
        assert_eq!(packed, direct);
    }

    #[test]
    fn pack_product_heatmap_reads_range_endpoints() {
        let x = [1.0, 3.0];
        let y = [2.0, 4.0];
        let rows = pack_product(ProductPackInput {
            kind: "heatmap",
            flags: FLAG_HEATMAP_PAINTED,
            step_mode: 0,
            symbol: 0,
            style_ref: 9,
            trace_id: 11,
            diameter: 0.0,
            extra0: 2.0,
            extra1: 3.0,
            x: &x,
            y: &y,
            x0: &[],
            y0: &[],
            x1: &[],
            y1: &[],
            base: &[],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].expansion_mode, EXP_HEATMAP_PAINTED);
        assert_eq!(rows[0].diameter, 2.0);
        assert_eq!(rows[1].diameter, 3.0);
        assert_eq!(
            (rows[0].x0, rows[0].y0, rows[0].x1, rows[0].y1),
            (1.0, 2.0, 3.0, 4.0)
        );
    }

    #[test]
    fn pack_product_density_blit_uses_extent_envelope() {
        let x0 = [0.0];
        let y0 = [1.0];
        let x1 = [2.0];
        let y1 = [3.0];
        let rows = pack_product(ProductPackInput {
            kind: "scatter",
            flags: FLAG_DENSITY_BLIT,
            step_mode: 0,
            symbol: 0,
            style_ref: 0,
            trace_id: 4,
            diameter: 0.0,
            extra0: 384.0,
            extra1: 512.0,
            x: &[],
            y: &[],
            x0: &x0,
            y0: &y0,
            x1: &x1,
            y1: &y1,
            base: &[],
        })
        .unwrap();
        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0].kind, KIND_RECT);
        assert_eq!(rows[0].expansion_mode, EXP_DENSITY_BLIT);
        assert_eq!(rows[0].diameter, 384.0);
        assert_eq!(rows[1].diameter, 512.0);
        assert_eq!(
            (rows[0].x0, rows[0].y0, rows[0].x1, rows[0].y1),
            (0.0, 1.0, 2.0, 3.0)
        );
    }

    #[test]
    fn pack_product_ribbon_remaps_canonical_envelope() {
        let x0 = [0.0];
        let x1 = [1.0];
        let y0 = [2.0];
        let y1 = [4.0];
        let x = [3.0];
        let y = [5.0];
        let packed = pack_product(ProductPackInput {
            kind: "ribbon",
            flags: 0,
            step_mode: 0,
            symbol: 0,
            style_ref: 0,
            trace_id: 1,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            x: &x,
            y: &y,
            x0: &x0,
            y0: &y0,
            x1: &x1,
            y1: &y1,
            base: &[],
        })
        .unwrap();
        assert_eq!(packed.len(), 2);
        assert_eq!(packed[0].expansion_mode, EXP_RIBBON);
        assert_eq!((packed[0].y0, packed[0].y1), (4.0, 5.0));
        assert_eq!((packed[1].y0, packed[1].y1), (2.0, 3.0));
    }

    #[test]
    fn pack_product_rejects_empty_required_columns() {
        assert_eq!(
            pack_product(ProductPackInput {
                kind: "bar",
                flags: 0,
                step_mode: 0,
                symbol: 0,
                style_ref: 0,
                trace_id: 0,
                diameter: 0.0,
                extra0: 0.0,
                extra1: 0.0,
                x: &[],
                y: &[],
                x0: &[0.0, 1.0],
                y0: &[0.0, 0.0],
                x1: &[],
                y1: &[1.0, 2.0],
                base: &[],
            }),
            Err(PackError::Length)
        );
    }

    fn xypk_bytes(
        kind: &str,
        style_ref: u32,
        coords: u8,
        symbol: u8,
        step: u8,
        facts: u8,
        trace_id: u64,
        diameter: f64,
        hex_dx: f64,
        hex_dy: f64,
        grid_rows: f64,
        grid_cols: f64,
    ) -> Vec<u8> {
        let mut out = Vec::with_capacity(XYPK_V1_HEADER_BYTES + kind.len());
        out.extend_from_slice(XYPK_MAGIC);
        out.extend_from_slice(&XYPK_VERSION.to_le_bytes());
        out.extend_from_slice(&style_ref.to_le_bytes());
        out.push(coords);
        out.push(symbol);
        out.push(step);
        out.push(facts);
        out.extend_from_slice(&trace_id.to_le_bytes());
        out.extend_from_slice(&diameter.to_le_bytes());
        out.extend_from_slice(&hex_dx.to_le_bytes());
        out.extend_from_slice(&hex_dy.to_le_bytes());
        out.extend_from_slice(&grid_rows.to_le_bytes());
        out.extend_from_slice(&grid_cols.to_le_bytes());
        out.extend_from_slice(kind.as_bytes());
        out
    }

    #[test]
    fn product_facts_apply_cartesian_smooth_and_ignore_polar() {
        let cartesian_bytes = xypk_bytes(
            "line",
            3,
            COORDS_CARTESIAN,
            0,
            0,
            FACT_CURVE_SMOOTH,
            9,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let cartesian = parse_product_facts(&cartesian_bytes).unwrap();
        assert_eq!(cartesian.step_mode, 4);
        assert_eq!(cartesian.flags, 0);
        let polar_bytes = xypk_bytes(
            "line",
            3,
            COORDS_POLAR,
            0,
            0,
            FACT_CURVE_SMOOTH,
            9,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let polar = parse_product_facts(&polar_bytes).unwrap();
        assert_eq!(polar.step_mode, 0);
        let stepped_bytes = xypk_bytes(
            "line",
            1,
            COORDS_CARTESIAN,
            0,
            1,
            FACT_CURVE_SMOOTH,
            2,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let stepped = parse_product_facts(&stepped_bytes).unwrap();
        assert_eq!(stepped.step_mode, 1);
        let area_stepped_bytes = xypk_bytes(
            "area",
            1,
            COORDS_CARTESIAN,
            0,
            2,
            FACT_CURVE_SMOOTH,
            2,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let area_stepped = parse_product_facts(&area_stepped_bytes).unwrap();
        assert_eq!(area_stepped.step_mode, 2);
        let band_stepped_bytes = xypk_bytes(
            "error_band",
            1,
            COORDS_CARTESIAN,
            0,
            3,
            FACT_CURVE_SMOOTH,
            2,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let band_stepped = parse_product_facts(&band_stepped_bytes).unwrap();
        assert_eq!(band_stepped.step_mode, 3);
    }

    #[test]
    fn product_facts_select_heatmap_paint_hex_and_density_extras() {
        let painted_bytes = xypk_bytes(
            "heatmap",
            4,
            COORDS_CARTESIAN,
            0,
            0,
            FACT_HEATMAP_PAINT,
            8,
            0.0,
            0.0,
            0.0,
            3.0,
            5.0,
        );
        let painted = parse_product_facts(&painted_bytes).unwrap();
        assert_eq!(painted.flags, FLAG_HEATMAP_PAINTED);
        assert_eq!((painted.extra0, painted.extra1), (3.0, 5.0));
        let hex_bytes = xypk_bytes(
            "hexbin",
            0,
            COORDS_CARTESIAN,
            0,
            0,
            0,
            1,
            0.0,
            0.5,
            0.25,
            9.0,
            9.0,
        );
        let hex = parse_product_facts(&hex_bytes).unwrap();
        assert_eq!((hex.extra0, hex.extra1), (0.5, 0.25));
        let density_bytes = xypk_bytes(
            "scatter",
            2,
            COORDS_CARTESIAN,
            4,
            0,
            FACT_DENSITY_PLANE,
            7,
            6.0,
            0.0,
            0.0,
            384.0,
            512.0,
        );
        let density = parse_product_facts(&density_bytes).unwrap();
        assert_eq!(density.flags, FLAG_DENSITY_BLIT);
        assert_eq!(density.symbol, 0);
        assert_eq!(density.diameter, 0.0);
        assert_eq!((density.extra0, density.extra1), (384.0, 512.0));
    }

    #[test]
    fn pack_product_facts_flattens_cartesian_smooth_line() {
        let x = [0.0, 1.0, 2.0];
        let y = [0.0, 1.0, 0.0];
        let facts = xypk_bytes(
            "line",
            1,
            COORDS_CARTESIAN,
            0,
            0,
            FACT_CURVE_SMOOTH,
            11,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let rows = pack_product_facts(&facts, &x, &y, &[], &[], &[], &[], &[]).unwrap();
        assert_eq!(rows.len(), 3);
        assert!(rows
            .iter()
            .all(|row| row.expansion_mode == EXP_CURVE_FLATTEN));
        assert!(rows
            .iter()
            .all(|row| row.style_ref == 1 && row.stable_id == 11));
    }

    #[test]
    fn joined_fill_packs_one_identity_polyfill_ring() {
        let x0 = [0.0, 1.0];
        let y0 = [0.0, 0.0];
        let x1 = [1.0, 1.0];
        let y1 = [0.0, 1.0];
        let x2 = [0.0, 0.0];
        let y2 = [1.0, 1.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_TRIANGLE,
            flags: FLAG_JOINED_FILL,
            step_mode: 0,
            symbol: 0,
            style_ref: 4,
            trace_id: 11,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x0, &y0, &x1, &y1, &x2, &y2],
        })
        .unwrap();
        assert_eq!(rows.len(), 4);
        assert!(rows.iter().all(|row| {
            row.kind == KIND_POLYFILL
                && row.expansion_mode == EXP_NONE
                && row.stable_id == 11
                && row.x1 == 0.0
                && row.y1 == 0.0
        }));
        let unjoined = pack_trace(TracePackInput {
            pack_kind: PACK_TRIANGLE,
            flags: 0,
            step_mode: 0,
            symbol: 0,
            style_ref: 4,
            trace_id: 11,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x0, &y0, &x1, &y1, &x2, &y2],
        })
        .unwrap();
        assert_eq!(unjoined.len(), 4);
        assert!(unjoined
            .iter()
            .all(|row| row.expansion_mode == EXP_TRIANGLE && row.stable_id != 11));
    }

    #[test]
    fn joined_fill_falls_back_when_the_mesh_is_disconnected() {
        let x0 = [0.0, 2.0];
        let y0 = [0.0, 2.0];
        let x1 = [1.0, 3.0];
        let y1 = [0.0, 2.0];
        let x2 = [0.5, 2.5];
        let y2 = [1.0, 3.0];
        let rows = pack_trace(TracePackInput {
            pack_kind: PACK_TRIANGLE,
            flags: FLAG_JOINED_FILL,
            step_mode: 0,
            symbol: 0,
            style_ref: 1,
            trace_id: 7,
            diameter: 0.0,
            extra0: 0.0,
            extra1: 0.0,
            columns: &[&x0, &y0, &x1, &y1, &x2, &y2],
        })
        .unwrap();
        assert_eq!(rows.len(), 4);
        assert!(rows.iter().all(|row| row.expansion_mode == EXP_TRIANGLE));
    }

    #[test]
    fn product_facts_map_joined_fill_only_for_triangle_mesh() {
        let mesh_bytes = xypk_bytes(
            "triangle_mesh",
            0,
            COORDS_CARTESIAN,
            0,
            0,
            FACT_JOINED_FILL,
            9,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let mesh = parse_product_facts(&mesh_bytes).unwrap();
        assert_eq!(mesh.flags, FLAG_JOINED_FILL);
        let line_bytes = xypk_bytes(
            "line",
            0,
            COORDS_CARTESIAN,
            0,
            0,
            FACT_JOINED_FILL,
            9,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        );
        let line = parse_product_facts(&line_bytes).unwrap();
        assert_eq!(line.flags, 0);
        assert_eq!(
            pack_trace(TracePackInput {
                pack_kind: PACK_LINE,
                flags: FLAG_JOINED_FILL,
                step_mode: 0,
                symbol: 0,
                style_ref: 0,
                trace_id: 0,
                diameter: 0.0,
                extra0: 0.0,
                extra1: 0.0,
                columns: &[&[0.0, 1.0], &[0.0, 1.0]],
            }),
            Err(PackError::Length)
        );
    }
}
