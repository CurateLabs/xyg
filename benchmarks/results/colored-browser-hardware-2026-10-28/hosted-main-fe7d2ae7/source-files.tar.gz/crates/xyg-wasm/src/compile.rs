//! Packed typed-column compile requests for the direct-browser WASM host.
//!
//! The Worker copies one little-endian `XYCC` request into the staging arena.
//! Rust validates lengths and scale fields, then builds the same canonical
//! Scene batch that native hosts encode through `xyg_scene_batch_encode`.

pub use crate::typed_series_abi_generated::*;
use xyg_engine::auto_domain;
use xyg_engine::graph_style::{
    CompoundGraphSceneInput, MAX_SEMANTIC_GRAPH_SCENE_PRIMITIVES, SEMANTIC_GRAPH_SCENE_VERSION,
    SemanticGraphSceneInput, encode_compound_graph_scene,
};
use xyg_engine::kernels::default_mark_rgba8;
use xyg_engine::scene::{
    self, AxisScale, BandOutline, CartesianLayoutRequest, PlotLayout, ScaleKind, SceneBatch,
    SceneChromeStyle, SceneChromeText, SceneError,
};

pub const COMPILE_MAGIC: &[u8; 4] = b"XYCC";
pub const COMPILE_VERSION: u32 = 1;
// Conservative simultaneous logical storage for one expanded record: parsed
// columns, mark metadata, the canonical Scene record, packed output, and Vec
// capacity slack. Keep this above the sum of those representations whenever
// the lowering pipeline changes.
/// When set, Rust derives axis domains from finite column values so the browser
/// main thread does not scan O(N) data for lo/hi.

#[derive(Debug)]
pub struct CompiledScene {
    pub bytes: Vec<u8>,
    pub records: usize,
    pub styles: usize,
}

#[derive(Clone, Copy)]
struct SemanticGraphOffsets {
    nodes: usize,
    edges: usize,
    x: usize,
    y: usize,
    node_class: usize,
    node_epistemic: usize,
    node_status: usize,
    node_metric: usize,
    node_flags: usize,
    sources: usize,
    targets: usize,
    edge_class: usize,
    edge_epistemic: usize,
    edge_status: usize,
    edge_metric: usize,
    edge_flags: usize,
    parents: usize,
    parent_validity: usize,
    collapsed: usize,
}

fn semantic_graph_offsets(bytes: &[u8]) -> Result<SemanticGraphOffsets, SceneError> {
    if bytes.len() < SEMANTIC_GRAPH_HEADER_BYTES
        || bytes.get(..4) != Some(SEMANTIC_GRAPH_MAGIC)
        || u32_at(bytes, 4)? != SEMANTIC_GRAPH_REQUEST_VERSION
        || u32_at(bytes, 8)? as usize != SEMANTIC_GRAPH_HEADER_BYTES
        || u32_at(bytes, 28)? != 0
        || bytes[48..64] != [0; 16]
    {
        return Err(SceneError::Length);
    }
    let nodes = u32_at(bytes, 16)? as usize;
    let edges = u32_at(bytes, 20)? as usize;
    if nodes == 0
        || nodes
            .checked_add(edges)
            .is_none_or(|v| v > SEMANTIC_GRAPH_MAX_INPUT_ELEMENTS)
    {
        return Err(SceneError::Limit);
    }
    let title = u32_at(bytes, 24)? as usize;
    if title > 4_096 {
        return Err(SceneError::Limit);
    }
    let x = align8(
        SEMANTIC_GRAPH_HEADER_BYTES
            .checked_add(title)
            .ok_or(SceneError::Limit)?,
    );
    let y = x
        .checked_add(nodes.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let node_class = y
        .checked_add(nodes.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let node_epistemic = node_class.checked_add(nodes).ok_or(SceneError::Limit)?;
    let node_status = node_epistemic.checked_add(nodes).ok_or(SceneError::Limit)?;
    let node_metric = align8(node_status.checked_add(nodes).ok_or(SceneError::Limit)?);
    let node_flags = node_metric
        .checked_add(nodes.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let sources = align8(
        node_flags
            .checked_add(nodes.checked_mul(4).ok_or(SceneError::Limit)?)
            .ok_or(SceneError::Limit)?,
    );
    let targets = sources
        .checked_add(edges.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let edge_class = targets
        .checked_add(edges.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let edge_epistemic = edge_class.checked_add(edges).ok_or(SceneError::Limit)?;
    let edge_status = edge_epistemic.checked_add(edges).ok_or(SceneError::Limit)?;
    let edge_metric = align8(edge_status.checked_add(edges).ok_or(SceneError::Limit)?);
    let edge_flags = edge_metric
        .checked_add(edges.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let parents = align8(
        edge_flags
            .checked_add(edges.checked_mul(4).ok_or(SceneError::Limit)?)
            .ok_or(SceneError::Limit)?,
    );
    let parent_validity = parents
        .checked_add(nodes.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let collapsed = parent_validity
        .checked_add(nodes)
        .ok_or(SceneError::Limit)?;
    let label_lengths = align8(collapsed.checked_add(nodes).ok_or(SceneError::Limit)?);
    let label_count = nodes.checked_add(edges).ok_or(SceneError::Limit)?;
    let edge_label_lengths = align8(
        label_lengths
            .checked_add(nodes.checked_mul(4).ok_or(SceneError::Limit)?)
            .ok_or(SceneError::Limit)?,
    );
    let label_payload = edge_label_lengths
        .checked_add(edges.checked_mul(4).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let mut label_bytes = 0usize;
    for index in 0..label_count {
        let table = if index < nodes {
            label_lengths + index * 4
        } else {
            edge_label_lengths + (index - nodes) * 4
        };
        label_bytes = label_bytes
            .checked_add(u32_at(bytes, table)? as usize)
            .ok_or(SceneError::Limit)?;
    }
    if label_bytes > 8_192 {
        return Err(SceneError::Limit);
    }
    let payload_end = label_payload
        .checked_add(label_bytes)
        .ok_or(SceneError::Limit)?;
    let end = align8(payload_end);
    if end != bytes.len() {
        return Err(SceneError::Length);
    }
    if bytes
        .get(payload_end..end)
        .ok_or(SceneError::Length)?
        .iter()
        .any(|&value| value != 0)
    {
        return Err(SceneError::Length);
    }
    Ok(SemanticGraphOffsets {
        nodes,
        edges,
        x,
        y,
        node_class,
        node_epistemic,
        node_status,
        node_metric,
        node_flags,
        sources,
        targets,
        edge_class,
        edge_epistemic,
        edge_status,
        edge_metric,
        edge_flags,
        parents,
        parent_validity,
        collapsed,
    })
}

fn align_zero(bytes: &[u8], cursor: &mut usize) -> Result<(), SceneError> {
    let aligned = cursor.checked_add(7).ok_or(SceneError::Limit)? & !7;
    if bytes
        .get(*cursor..aligned)
        .ok_or(SceneError::Length)?
        .iter()
        .any(|&v| v != 0)
    {
        return Err(SceneError::Length);
    }
    *cursor = aligned;
    Ok(())
}

fn take_u8s(bytes: &[u8], cursor: &mut usize, count: usize) -> Result<Vec<u8>, SceneError> {
    Ok(take(bytes, cursor, count)?.to_vec())
}

fn compile_semantic_graph_request(
    bytes: &[u8],
    peak_budget: usize,
) -> Result<CompiledScene, SceneError> {
    if bytes.len() < SEMANTIC_GRAPH_HEADER_BYTES
        || bytes.get(..4) != Some(SEMANTIC_GRAPH_MAGIC)
        || u32_at(bytes, 4)? != SEMANTIC_GRAPH_REQUEST_VERSION
        || u32_at(bytes, 8)? as usize != SEMANTIC_GRAPH_HEADER_BYTES
        || u32_at(bytes, 28)? != 0
        || bytes[48..64] != [0; 16]
    {
        return Err(SceneError::Length);
    }
    let theme = u32_at(bytes, 12)?;
    let node_count = u32_at(bytes, 16)? as usize;
    let edge_count = u32_at(bytes, 20)? as usize;
    let title_len = u32_at(bytes, 24)? as usize;
    // Bound peak storage before allocating parsed columns. This includes the
    // request, owned input planes, routed geometry, canonical records/styles,
    // and encoded Scene with conservative Vec capacity slack.
    let elements = node_count
        .checked_add(edge_count)
        .ok_or(SceneError::Limit)?;
    let peak = bytes
        .len()
        .checked_mul(2)
        .and_then(|value| value.checked_add(elements.checked_mul(160)?))
        .and_then(|value| value.checked_add(MAX_SEMANTIC_GRAPH_SCENE_PRIMITIVES.checked_mul(512)?))
        .ok_or(SceneError::Limit)?;
    if node_count == 0
        || node_count
            .checked_add(edge_count)
            .is_none_or(|value| value > SEMANTIC_GRAPH_MAX_INPUT_ELEMENTS)
        || theme > u8::MAX as u32
        || title_len > 4_096
        || peak > peak_budget
    {
        return Err(SceneError::Limit);
    }
    let width = f64_at(bytes, 32)?;
    let height = f64_at(bytes, 40)?;
    let mut cursor = SEMANTIC_GRAPH_HEADER_BYTES;
    let title = std::str::from_utf8(take(bytes, &mut cursor, title_len)?)
        .map_err(|_| SceneError::Length)?;
    align_zero(bytes, &mut cursor)?;
    let x = take_f64s(bytes, &mut cursor, node_count)?;
    let y = take_f64s(bytes, &mut cursor, node_count)?;
    let node_classes = take_u8s(bytes, &mut cursor, node_count)?;
    let node_epistemic = take_u8s(bytes, &mut cursor, node_count)?;
    let node_statuses = take_u8s(bytes, &mut cursor, node_count)?;
    align_zero(bytes, &mut cursor)?;
    let node_metric = take_f64s(bytes, &mut cursor, node_count)?;
    let node_flags = take_u32s(bytes, &mut cursor, node_count)?;
    align_zero(bytes, &mut cursor)?;
    let sources = take_u64s(bytes, &mut cursor, edge_count)?;
    let targets = take_u64s(bytes, &mut cursor, edge_count)?;
    let edge_classes = take_u8s(bytes, &mut cursor, edge_count)?;
    let edge_epistemic = take_u8s(bytes, &mut cursor, edge_count)?;
    let edge_statuses = take_u8s(bytes, &mut cursor, edge_count)?;
    align_zero(bytes, &mut cursor)?;
    let edge_metric = take_f64s(bytes, &mut cursor, edge_count)?;
    let edge_flags = take_u32s(bytes, &mut cursor, edge_count)?;
    align_zero(bytes, &mut cursor)?;
    let parents = take_u64s(bytes, &mut cursor, node_count)?;
    let parent_validity = take_u8s(bytes, &mut cursor, node_count)?;
    let collapsed = take_u8s(bytes, &mut cursor, node_count)?;
    align_zero(bytes, &mut cursor)?;
    let node_label_lengths = take_u32s(bytes, &mut cursor, node_count)?;
    let edge_label_lengths = take_u32s(bytes, &mut cursor, edge_count)?;
    let label_bytes = node_label_lengths
        .iter()
        .chain(&edge_label_lengths)
        .try_fold(0usize, |total, &len| total.checked_add(len as usize))
        .ok_or(SceneError::Limit)?;
    if label_bytes > 8_192 {
        return Err(SceneError::Limit);
    }
    let label_payload = take(bytes, &mut cursor, label_bytes)?;
    let mut label_cursor = 0usize;
    let mut decode_labels = |lengths: &[u32]| -> Result<Vec<&str>, SceneError> {
        lengths
            .iter()
            .map(|&len| {
                let end = label_cursor
                    .checked_add(len as usize)
                    .ok_or(SceneError::Limit)?;
                let text = std::str::from_utf8(
                    label_payload
                        .get(label_cursor..end)
                        .ok_or(SceneError::Length)?,
                )
                .map_err(|_| SceneError::Length)?;
                label_cursor = end;
                Ok(text)
            })
            .collect()
    };
    let node_labels = decode_labels(&node_label_lengths)?;
    let edge_labels = decode_labels(&edge_label_lengths)?;
    align_zero(bytes, &mut cursor)?;
    if cursor != bytes.len() {
        return Err(SceneError::Length);
    }
    let graph = SemanticGraphSceneInput {
        version: SEMANTIC_GRAPH_SCENE_VERSION,
        width,
        height,
        theme: theme as u8,
        title,
        x: &x,
        y: &y,
        node_classes: &node_classes,
        node_epistemic: &node_epistemic,
        node_statuses: &node_statuses,
        node_metric: &node_metric,
        node_flags: &node_flags,
        node_labels: &node_labels,
        sources: &sources,
        targets: &targets,
        edge_classes: &edge_classes,
        edge_epistemic: &edge_epistemic,
        edge_statuses: &edge_statuses,
        edge_metric: &edge_metric,
        edge_flags: &edge_flags,
        edge_labels: &edge_labels,
    };
    let scene = encode_compound_graph_scene(CompoundGraphSceneInput {
        graph,
        parents: &parents,
        parent_validity: &parent_validity,
        collapsed: &collapsed,
    })?;
    if scene
        .len()
        .checked_add(bytes.len())
        .is_none_or(|peak| peak > peak_budget)
    {
        return Err(SceneError::Limit);
    }
    let summary = scene::validate_scene_batch(&scene)?;
    Ok(CompiledScene {
        bytes: scene,
        records: summary.records,
        styles: summary.styles,
    })
}

fn u32_at(bytes: &[u8], offset: usize) -> Result<u32, SceneError> {
    let end = offset.checked_add(4).ok_or(SceneError::Length)?;
    let slice = bytes.get(offset..end).ok_or(SceneError::Length)?;
    Ok(u32::from_le_bytes(
        slice.try_into().map_err(|_| SceneError::Length)?,
    ))
}

fn u64_at(bytes: &[u8], offset: usize) -> Result<u64, SceneError> {
    let end = offset.checked_add(8).ok_or(SceneError::Length)?;
    let slice = bytes.get(offset..end).ok_or(SceneError::Length)?;
    Ok(u64::from_le_bytes(
        slice.try_into().map_err(|_| SceneError::Length)?,
    ))
}

fn f64_at(bytes: &[u8], offset: usize) -> Result<f64, SceneError> {
    let end = offset.checked_add(8).ok_or(SceneError::Length)?;
    let slice = bytes.get(offset..end).ok_or(SceneError::Length)?;
    Ok(f64::from_le_bytes(
        slice.try_into().map_err(|_| SceneError::Length)?,
    ))
}

fn align8(offset: usize) -> usize {
    offset.saturating_add(7) & !7
}

fn take<'a>(bytes: &'a [u8], offset: &mut usize, len: usize) -> Result<&'a [u8], SceneError> {
    let end = offset.checked_add(len).ok_or(SceneError::Length)?;
    let out = bytes.get(*offset..end).ok_or(SceneError::Length)?;
    *offset = end;
    Ok(out)
}

fn take_f64s(bytes: &[u8], offset: &mut usize, count: usize) -> Result<Vec<f64>, SceneError> {
    *offset = align8(*offset);
    let byte_len = count.checked_mul(8).ok_or(SceneError::Limit)?;
    let raw = take(bytes, offset, byte_len)?;
    let mut values = Vec::with_capacity(count);
    for chunk in raw.chunks_exact(8) {
        values.push(f64::from_le_bytes(
            chunk.try_into().map_err(|_| SceneError::Length)?,
        ));
    }
    Ok(values)
}

fn take_u64s(bytes: &[u8], offset: &mut usize, count: usize) -> Result<Vec<u64>, SceneError> {
    *offset = align8(*offset);
    let byte_len = count.checked_mul(8).ok_or(SceneError::Limit)?;
    let raw = take(bytes, offset, byte_len)?;
    let mut values = Vec::with_capacity(count);
    for chunk in raw.chunks_exact(8) {
        values.push(u64::from_le_bytes(
            chunk.try_into().map_err(|_| SceneError::Length)?,
        ));
    }
    Ok(values)
}

fn take_u32s(bytes: &[u8], offset: &mut usize, count: usize) -> Result<Vec<u32>, SceneError> {
    *offset = align8(*offset);
    let byte_len = count.checked_mul(4).ok_or(SceneError::Limit)?;
    let raw = take(bytes, offset, byte_len)?;
    let mut values = Vec::with_capacity(count);
    for chunk in raw.chunks_exact(4) {
        values.push(u32::from_le_bytes(
            chunk.try_into().map_err(|_| SceneError::Length)?,
        ));
    }
    Ok(values)
}

fn scale_kind(value: u32) -> Result<ScaleKind, SceneError> {
    match value {
        0 => Ok(ScaleKind::Linear),
        1 => Ok(ScaleKind::Log),
        2 => Ok(ScaleKind::SymLog),
        _ => Err(SceneError::Length),
    }
}

fn consider_finite(value: f64, lo: &mut f64, hi: &mut f64, any: &mut bool) {
    if !value.is_finite() {
        return;
    }
    if !*any {
        *lo = value;
        *hi = value;
        *any = true;
        return;
    }
    if value < *lo {
        *lo = value;
    }
    if value > *hi {
        *hi = value;
    }
}

/// Derive axis domains from finite geometry columns. Scatter/polyline use
/// `(x0, y0)`; rect/band also include `(x1, y1)`. Degenerate spans use the
/// shared engine `auto_domain` pad so WASM cannot fork Python/Node widening.
/// Returns `None` when either axis has no finite coordinate.
fn auto_domain_from_columns(
    kinds: &[u8],
    x0: &[f64],
    y0: &[f64],
    x1: &[f64],
    y1: &[f64],
) -> Option<(f64, f64, f64, f64)> {
    let mut x_lo = 0.0;
    let mut x_hi = 0.0;
    let mut y_lo = 0.0;
    let mut y_hi = 0.0;
    let mut any_x = false;
    let mut any_y = false;
    for (index, kind) in kinds.iter().copied().enumerate() {
        consider_finite(x0[index], &mut x_lo, &mut x_hi, &mut any_x);
        consider_finite(y0[index], &mut y_lo, &mut y_hi, &mut any_y);
        // Rect (2) and band (3) span both corners; scatter/polyline leave x1/y1 unused.
        if matches!(kind as u32, KIND_BAR | KIND_AREA) {
            consider_finite(x1[index], &mut x_lo, &mut x_hi, &mut any_x);
            consider_finite(y1[index], &mut y_lo, &mut y_hi, &mut any_y);
        }
    }
    if !any_x || !any_y {
        return None;
    }
    let (x_lo, x_hi) = auto_domain(Some((x_lo, x_hi)));
    let (y_lo, y_hi) = auto_domain(Some((y_lo, y_hi)));
    Some((x_lo, x_hi, y_lo, y_hi))
}

fn compile_columns_request(bytes: &[u8], literal_ids: bool) -> Result<CompiledScene, SceneError> {
    if bytes.len() < COMPILE_HEADER_BYTES {
        return Err(SceneError::Length);
    }
    if &bytes[..4] != COMPILE_MAGIC {
        return Err(SceneError::Length);
    }
    if u32_at(bytes, HEADER_VERSION)? != COMPILE_VERSION {
        return Err(SceneError::Version);
    }
    if u32_at(bytes, HEADER_HEADER_BYTES)? as usize != COMPILE_HEADER_BYTES {
        return Err(SceneError::Length);
    }
    let flags = u32_at(bytes, HEADER_FLAGS)?;
    if flags & !HEADER_FLAG_KNOWN != 0 {
        return Err(SceneError::Length);
    }
    let record_count = u32_at(bytes, HEADER_SERIES_COUNT)? as usize;
    let style_count = u32_at(bytes, HEADER_RECORD_COUNT)? as usize;
    let title_len = u32_at(bytes, HEADER_TITLE_BYTES)? as usize;
    let x_label_len = u32_at(bytes, HEADER_X_LABEL_BYTES)? as usize;
    let y_label_len = u32_at(bytes, HEADER_Y_LABEL_BYTES)? as usize;
    if u32_at(bytes, HEADER_RESERVED0)? != 0 {
        return Err(SceneError::Length);
    }
    if record_count > scene::MAX_SCENE_MARKS
        || style_count > scene::MAX_SCENE_STYLES
        || title_len > scene::MAX_SCENE_TEXT_BYTES
        || x_label_len > scene::MAX_SCENE_TEXT_BYTES
        || y_label_len > scene::MAX_SCENE_TEXT_BYTES
    {
        return Err(SceneError::Limit);
    }

    let viewport_width = f64_at(bytes, HEADER_WIDTH)?;
    let viewport_height = f64_at(bytes, HEADER_HEIGHT)?;
    let margin_left = f64_at(bytes, HEADER_MARGINS)?;
    let margin_right = f64_at(bytes, HEADER_MARGINS + 8)?;
    let margin_top = f64_at(bytes, HEADER_MARGINS + 16)?;
    let margin_bottom = f64_at(bytes, HEADER_MARGINS + 24)?;
    let x_axis_id = u64_at(bytes, HEADER_X_AXIS_ID)?;
    let y_axis_id = u64_at(bytes, HEADER_Y_AXIS_ID)?;
    let x_kind = scale_kind(u32_at(bytes, HEADER_X_SCALE_KIND)?)?;
    let y_kind = scale_kind(u32_at(bytes, HEADER_Y_SCALE_KIND)?)?;
    let x_mask = u32_at(bytes, HEADER_X_MASK_NONPOSITIVE)?;
    let y_mask = u32_at(bytes, HEADER_Y_MASK_NONPOSITIVE)?;
    if !matches!(x_mask, 0 | 1) || !matches!(y_mask, 0 | 1) {
        return Err(SceneError::Length);
    }
    let mut x_lo = f64_at(bytes, HEADER_X_LO)?;
    let mut x_hi = f64_at(bytes, HEADER_X_HI)?;
    let x_constant = f64_at(bytes, HEADER_X_CONSTANT)?;
    let mut y_lo = f64_at(bytes, HEADER_Y_LO)?;
    let mut y_hi = f64_at(bytes, HEADER_Y_HI)?;
    let y_constant = f64_at(bytes, HEADER_Y_CONSTANT)?;
    for reserved in (HEADER_RESERVED_TAIL..COMPILE_HEADER_BYTES).step_by(4) {
        if u32_at(bytes, reserved)? != 0 {
            return Err(SceneError::Length);
        }
    }

    let mut offset = COMPILE_HEADER_BYTES;
    let kinds = take(bytes, &mut offset, record_count)?.to_vec();
    let stable_ids = take_u64s(bytes, &mut offset, record_count)?;
    let style_refs = take_u32s(bytes, &mut offset, record_count)?;
    let diameter = take_f64s(bytes, &mut offset, record_count)?;
    let symbols = take(bytes, &mut offset, record_count)?.to_vec();
    let x0 = take_f64s(bytes, &mut offset, record_count)?;
    let y0 = take_f64s(bytes, &mut offset, record_count)?;
    let x1 = take_f64s(bytes, &mut offset, record_count)?;
    let y1 = take_f64s(bytes, &mut offset, record_count)?;
    let fill_rgba = take(bytes, &mut offset, style_count.saturating_mul(4))?.to_vec();
    let stroke_rgba = take(bytes, &mut offset, style_count.saturating_mul(4))?.to_vec();
    let stroke_width = take_f64s(bytes, &mut offset, style_count)?;
    let title_bytes = take(bytes, &mut offset, title_len)?;
    let x_label_bytes = take(bytes, &mut offset, x_label_len)?;
    let y_label_bytes = take(bytes, &mut offset, y_label_len)?;
    if offset != bytes.len() {
        return Err(SceneError::Length);
    }

    let title = std::str::from_utf8(title_bytes).map_err(|_| SceneError::Length)?;
    let x_label = std::str::from_utf8(x_label_bytes).map_err(|_| SceneError::Length)?;
    let y_label = std::str::from_utf8(y_label_bytes).map_err(|_| SceneError::Length)?;
    let text = SceneChromeText::from_parts(title, x_label, y_label)?;

    if flags & HEADER_FLAG_AUTO_DOMAIN != 0 {
        let Some(domain) = auto_domain_from_columns(&kinds, &x0, &y0, &x1, &y1) else {
            return Err(SceneError::NonFinite);
        };
        x_lo = domain.0;
        x_hi = domain.1;
        y_lo = domain.2;
        y_hi = domain.3;
    }

    let (margin_left, margin_right, margin_top, margin_bottom) =
        if flags & HEADER_FLAG_AUTO_MARGINS != 0 {
            scene::cartesian_scene_margins(CartesianLayoutRequest {
                viewport_width,
                viewport_height,
                authored_padding: None,
                title,
                x_label,
                y_label,
                x_kind,
                x_lo,
                x_hi,
                x_constant,
                x_mask_nonpositive: x_mask != 0,
                x_format: None,
                x_tick_kind: 0,
                y_kind,
                y_lo,
                y_hi,
                y_constant,
                y_mask_nonpositive: y_mask != 0,
                y_format: None,
                y_tick_kind: 0,
                colorbar_side: scene::ColorbarSide::None,
                collision: scene::TickCollisionLayout::default(),
            })?
        } else {
            (margin_left, margin_right, margin_top, margin_bottom)
        };

    let layout = PlotLayout::new(
        viewport_width,
        viewport_height,
        margin_left,
        margin_right,
        margin_top,
        margin_bottom,
    )?;
    let x_scale = AxisScale::new(
        x_kind,
        x_lo,
        x_hi,
        layout.left,
        layout.right,
        x_constant,
        x_mask != 0,
    )?;
    let y_scale = AxisScale::new(
        y_kind,
        y_lo,
        y_hi,
        layout.bottom,
        layout.top,
        y_constant,
        y_mask != 0,
    )?;
    let batch = if literal_ids {
        SceneBatch::new_with_chrome_literal_ids(
            layout,
            x_axis_id,
            y_axis_id,
            x_scale,
            y_scale,
            SceneChromeStyle::default(),
            text,
            &kinds,
            &stable_ids,
            &style_refs,
            &fill_rgba,
            &stroke_rgba,
            &stroke_width,
            &diameter,
            &symbols,
            &x0,
            &y0,
            &x1,
            &y1,
        )?
    } else {
        SceneBatch::new_with_chrome(
            layout,
            x_axis_id,
            y_axis_id,
            x_scale,
            y_scale,
            SceneChromeStyle::default(),
            text,
            &kinds,
            &stable_ids,
            &style_refs,
            &fill_rgba,
            &stroke_rgba,
            &stroke_width,
            &diameter,
            &symbols,
            &x0,
            &y0,
            &x1,
            &y1,
        )?
    };
    Ok(CompiledScene {
        records: record_count,
        styles: style_count,
        bytes: batch.encode(),
    })
}

fn append_aligned_u64s(out: &mut Vec<u8>, values: &[u64]) {
    while !out.len().is_multiple_of(8) {
        out.push(0);
    }
    for value in values {
        out.extend_from_slice(&value.to_le_bytes());
    }
}

fn append_aligned_u32s(out: &mut Vec<u8>, values: &[u32]) {
    while !out.len().is_multiple_of(8) {
        out.push(0);
    }
    for value in values {
        out.extend_from_slice(&value.to_le_bytes());
    }
}

fn append_aligned_f64s(out: &mut Vec<u8>, values: &[f64]) {
    while !out.len().is_multiple_of(8) {
        out.push(0);
    }
    for value in values {
        out.extend_from_slice(&value.to_le_bytes());
    }
}

fn default_bar_half_width(xs: &[f64], domain_lo: f64, domain_hi: f64) -> Result<f64, SceneError> {
    if xs.iter().any(|value| !value.is_finite()) {
        return Err(SceneError::NonFinite);
    }
    let mut sorted = xs.to_vec();
    sorted.sort_by(f64::total_cmp);
    let spacing = sorted
        .windows(2)
        .map(|pair| pair[1] - pair[0])
        .filter(|value| *value > 0.0)
        .min_by(f64::total_cmp);
    let domain_span = (domain_hi - domain_lo).abs();
    let basis =
        spacing.or_else(|| (domain_span.is_finite() && domain_span > 0.0).then_some(domain_span));
    basis.map(|value| value * 0.4).ok_or(SceneError::NonFinite)
}

fn series_f64s(
    bytes: &[u8],
    offset: u32,
    count: usize,
    data_start: usize,
) -> Result<Vec<f64>, SceneError> {
    let start = offset as usize;
    if start < data_start || !start.is_multiple_of(8) {
        return Err(SceneError::Length);
    }
    let end = start
        .checked_add(count.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    let raw = bytes.get(start..end).ok_or(SceneError::Length)?;
    raw.chunks_exact(8)
        .map(|chunk| {
            Ok(f64::from_le_bytes(
                chunk.try_into().map_err(|_| SceneError::Length)?,
            ))
        })
        .collect()
}

fn next_series_f64s(
    bytes: &[u8],
    offset: u32,
    count: usize,
    data_start: usize,
    cursor: &mut usize,
) -> Result<Vec<f64>, SceneError> {
    if offset as usize != *cursor {
        return Err(SceneError::Length);
    }
    let values = series_f64s(bytes, offset, count, data_start)?;
    *cursor = cursor
        .checked_add(count.checked_mul(8).ok_or(SceneError::Limit)?)
        .ok_or(SceneError::Limit)?;
    Ok(values)
}

fn next_series_u64s(
    bytes: &[u8],
    offset: u32,
    count: usize,
    data_start: usize,
    cursor: &mut usize,
) -> Result<Vec<u64>, SceneError> {
    if offset as usize != *cursor || !(offset as usize).is_multiple_of(8) {
        return Err(SceneError::Length);
    }
    let byte_len = count.checked_mul(8).ok_or(SceneError::Limit)?;
    let end = cursor.checked_add(byte_len).ok_or(SceneError::Limit)?;
    let raw = bytes.get(*cursor..end).ok_or(SceneError::Length)?;
    let values = raw
        .chunks_exact(8)
        .map(|chunk| {
            Ok(u64::from_le_bytes(
                chunk.try_into().map_err(|_| SceneError::Length)?,
            ))
        })
        .collect::<Result<Vec<_>, _>>()?;
    if *cursor < data_start {
        return Err(SceneError::Length);
    }
    *cursor = end;
    Ok(values)
}

/// Expand packed transferable typed-series descriptors in Rust, then compile
/// through the canonical typed-column path. TypeScript never assigns stable
/// ids, chooses mark defaults, or performs per-record expansion.
fn series_peak_bytes(
    input_bytes: usize,
    record_count: usize,
    series_count: usize,
) -> Result<usize, SceneError> {
    input_bytes
        .checked_mul(SERIES_PEAK_INPUT_MULTIPLIER)
        .and_then(|value| {
            value.checked_add(record_count.checked_mul(SERIES_PEAK_BYTES_PER_RECORD)?)
        })
        .and_then(|value| {
            value.checked_add(series_count.checked_mul(SERIES_PEAK_BYTES_PER_SERIES)?)
        })
        .and_then(|value| value.checked_add(SERIES_PEAK_FIXED_BYTES))
        .ok_or(SceneError::Limit)
}

fn compile_series_request(bytes: &[u8], peak_budget: usize) -> Result<CompiledScene, SceneError> {
    if bytes.len() < COMPILE_HEADER_BYTES || &bytes[..4] != SERIES_MAGIC {
        return Err(SceneError::Length);
    }
    if u32_at(bytes, HEADER_VERSION)? != SERIES_VERSION {
        return Err(SceneError::Version);
    }
    if u32_at(bytes, HEADER_HEADER_BYTES)? as usize != COMPILE_HEADER_BYTES {
        return Err(SceneError::Length);
    }
    let series_count = u32_at(bytes, HEADER_SERIES_COUNT)? as usize;
    let record_count = u32_at(bytes, HEADER_RECORD_COUNT)? as usize;
    let domain_x_lo = f64_at(bytes, HEADER_X_LO)?;
    let domain_x_hi = f64_at(bytes, HEADER_X_HI)?;
    if series_count == 0
        || series_count > MAX_SERIES.min(scene::MAX_SCENE_STYLES)
        || record_count > MAX_RECORDS.min(scene::MAX_SCENE_MARKS)
    {
        return Err(SceneError::Limit);
    }
    if series_peak_bytes(bytes.len(), record_count, series_count)? > peak_budget {
        return Err(SceneError::Limit);
    }
    let descriptors_end = COMPILE_HEADER_BYTES
        .checked_add(
            series_count
                .checked_mul(SERIES_DESCRIPTOR_BYTES)
                .ok_or(SceneError::Limit)?,
        )
        .ok_or(SceneError::Limit)?;
    if descriptors_end > bytes.len() {
        return Err(SceneError::Length);
    }
    let title_len = u32_at(bytes, HEADER_TITLE_BYTES)? as usize;
    let x_label_len = u32_at(bytes, HEADER_X_LABEL_BYTES)? as usize;
    let y_label_len = u32_at(bytes, HEADER_Y_LABEL_BYTES)? as usize;
    if title_len > MAX_TEXT_BYTES || x_label_len > MAX_TEXT_BYTES || y_label_len > MAX_TEXT_BYTES {
        return Err(SceneError::Limit);
    }
    let text_bytes = title_len
        .checked_add(x_label_len)
        .and_then(|value| value.checked_add(y_label_len))
        .ok_or(SceneError::Limit)?;
    let data_start = align8(
        descriptors_end
            .checked_add(text_bytes)
            .ok_or(SceneError::Limit)?,
    );
    if data_start > bytes.len()
        || bytes[descriptors_end + text_bytes..data_start]
            .iter()
            .any(|byte| *byte != 0)
    {
        return Err(SceneError::Length);
    }

    let mut kinds = Vec::with_capacity(record_count);
    let mut stable_ids = Vec::with_capacity(record_count);
    let mut style_refs = Vec::with_capacity(record_count);
    let mut diameter = Vec::with_capacity(record_count);
    let mut symbols = Vec::with_capacity(record_count);
    let mut x0 = Vec::with_capacity(record_count);
    let mut y0 = Vec::with_capacity(record_count);
    let mut x1 = Vec::with_capacity(record_count);
    let mut y1 = Vec::with_capacity(record_count);
    let mut fill_rgba = Vec::with_capacity(series_count * 4);
    let mut stroke_rgba = Vec::with_capacity(series_count * 4);
    let mut stroke_width = Vec::with_capacity(series_count);
    let mut next_default_id = 1u64;
    let mut data_cursor = data_start;

    for series_index in 0..series_count {
        let base = COMPILE_HEADER_BYTES + series_index * SERIES_DESCRIPTOR_BYTES;
        let kind = u32_at(bytes, base + DESCRIPTOR_KIND)?;
        if !matches!(kind, KIND_SCATTER | KIND_LINE | KIND_BAR | KIND_AREA) {
            return Err(SceneError::Length);
        }
        let symbol = u32_at(bytes, base + DESCRIPTOR_SYMBOL)?;
        if symbol > MAX_SYMBOL_CODE {
            return Err(SceneError::Length);
        }
        let count = u32_at(bytes, base + DESCRIPTOR_RECORD_COUNT)? as usize;
        let flags = u32_at(bytes, base + DESCRIPTOR_FLAGS)?;
        if count == 0 || flags & !DESCRIPTOR_FLAG_KNOWN != 0 {
            return Err(SceneError::Length);
        }
        if flags & DESCRIPTOR_FLAG_STABLE_ID_BASE != 0 && flags & DESCRIPTOR_FLAG_STABLE_IDS != 0 {
            return Err(SceneError::Length);
        }
        let stable_base = if flags & DESCRIPTOR_FLAG_STABLE_ID_BASE != 0 {
            u64_at(bytes, base + DESCRIPTOR_STABLE_ID_BASE)?
        } else {
            next_default_id
        };
        let identity_count = if matches!(kind, KIND_LINE | KIND_AREA) {
            1
        } else {
            count as u64
        };
        let scalar_diameter = f64_at(bytes, base + DESCRIPTOR_DIAMETER)?;
        let authored_stroke = f64_at(bytes, base + DESCRIPTOR_STROKE_WIDTH)?;
        if flags & DESCRIPTOR_FLAG_FILL_RGBA != 0 {
            fill_rgba.extend_from_slice(
                bytes
                    .get(base + DESCRIPTOR_FILL_RGBA..base + DESCRIPTOR_FILL_RGBA + 4)
                    .ok_or(SceneError::Length)?,
            );
        } else if kind == KIND_LINE {
            fill_rgba.extend_from_slice(&[0, 0, 0, 0]);
        } else {
            fill_rgba.extend_from_slice(&default_mark_rgba8());
        }
        if flags & DESCRIPTOR_FLAG_STROKE_RGBA != 0 {
            stroke_rgba.extend_from_slice(
                bytes
                    .get(base + DESCRIPTOR_STROKE_RGBA..base + DESCRIPTOR_STROKE_RGBA + 4)
                    .ok_or(SceneError::Length)?,
            );
        } else if kind == KIND_LINE {
            stroke_rgba.extend_from_slice(&default_mark_rgba8());
        } else {
            stroke_rgba.extend_from_slice(&[0, 0, 0, 0]);
        }
        stroke_width.push(if authored_stroke.is_nan() {
            if kind == KIND_LINE { 1.5 } else { 0.0 }
        } else {
            authored_stroke
        });
        let xs = next_series_f64s(
            bytes,
            u32_at(bytes, base + DESCRIPTOR_X)?,
            count,
            data_start,
            &mut data_cursor,
        )?;
        let ys = next_series_f64s(
            bytes,
            u32_at(bytes, base + DESCRIPTOR_Y)?,
            count,
            data_start,
            &mut data_cursor,
        )?;
        let lower = if flags & DESCRIPTOR_FLAG_Y0 != 0 {
            Some(next_series_f64s(
                bytes,
                u32_at(bytes, base + DESCRIPTOR_Y0)?,
                count,
                data_start,
                &mut data_cursor,
            )?)
        } else {
            None
        };
        let upper = if flags & DESCRIPTOR_FLAG_Y1 != 0 {
            Some(next_series_f64s(
                bytes,
                u32_at(bytes, base + DESCRIPTOR_Y1)?,
                count,
                data_start,
                &mut data_cursor,
            )?)
        } else {
            None
        };
        let diameters = if flags & DESCRIPTOR_FLAG_DIAMETERS != 0 {
            Some(next_series_f64s(
                bytes,
                u32_at(bytes, base + DESCRIPTOR_DIAMETERS)?,
                count,
                data_start,
                &mut data_cursor,
            )?)
        } else {
            None
        };
        let authored_stable_ids = if flags & DESCRIPTOR_FLAG_STABLE_IDS != 0 {
            Some(next_series_u64s(
                bytes,
                u32_at(bytes, base + DESCRIPTOR_STABLE_IDS)?,
                count,
                data_start,
                &mut data_cursor,
            )?)
        } else {
            None
        };
        next_default_id = if let Some(ids) = &authored_stable_ids {
            ids.iter()
                .copied()
                .max()
                .unwrap_or(0)
                .checked_add(1)
                .ok_or(SceneError::Limit)?
                .max(next_default_id)
        } else {
            stable_base
                .checked_add(identity_count)
                .ok_or(SceneError::Limit)?
                .max(next_default_id)
        };
        let bar_half_width = if kind == KIND_BAR {
            Some(default_bar_half_width(&xs, domain_x_lo, domain_x_hi)?)
        } else {
            None
        };
        for index in 0..count {
            kinds.push(kind as u8);
            stable_ids.push(if let Some(ids) = &authored_stable_ids {
                ids[index]
            } else if matches!(kind, KIND_LINE | KIND_AREA) {
                stable_base
            } else {
                stable_base
                    .checked_add(index as u64)
                    .ok_or(SceneError::Limit)?
            });
            style_refs.push(series_index as u32);
            symbols.push(if kind == KIND_SCATTER {
                symbol as u8
            } else if kind == KIND_AREA
                && stroke_width[series_index] > 0.0
                && stroke_rgba[series_index * 4 + 3] != 0
            {
                // XYTS v2 predates Scene's explicit Band topology. Preserve
                // its native Scene SVG/raster contract: a visible authored
                // area stroke is the complete closed perimeter.
                BandOutline::Perimeter as u8
            } else {
                BandOutline::None as u8
            });
            diameter.push(if kind == KIND_SCATTER {
                diameters.as_ref().map(|values| values[index]).unwrap_or(
                    if scalar_diameter.is_nan() {
                        8.0
                    } else {
                        scalar_diameter
                    },
                )
            } else {
                0.0
            });
            match kind {
                KIND_SCATTER | KIND_LINE => {
                    x0.push(xs[index]);
                    y0.push(ys[index]);
                    x1.push(0.0);
                    y1.push(0.0);
                }
                KIND_BAR => {
                    let half_width = bar_half_width.ok_or(SceneError::Length)?;
                    x0.push(xs[index] - half_width);
                    x1.push(xs[index] + half_width);
                    y0.push(lower.as_ref().map(|v| v[index]).unwrap_or(0.0));
                    y1.push(upper.as_ref().map(|v| v[index]).unwrap_or(ys[index]));
                }
                KIND_AREA => {
                    x0.push(xs[index]);
                    x1.push(xs[index]);
                    y0.push(lower.as_ref().map(|v| v[index]).unwrap_or(0.0));
                    y1.push(upper.as_ref().map(|v| v[index]).unwrap_or(ys[index]));
                }
                _ => unreachable!(),
            }
        }
    }
    if kinds.len() != record_count || data_cursor != bytes.len() {
        return Err(SceneError::Length);
    }

    let packed_capacity = COMPILE_HEADER_BYTES
        .checked_add(record_count.checked_mul(56).ok_or(SceneError::Limit)?)
        .and_then(|value| value.checked_add(series_count.checked_mul(16)?))
        .and_then(|value| value.checked_add(text_bytes))
        .and_then(|value| value.checked_add(64))
        .ok_or(SceneError::Limit)?;
    let mut packed = Vec::new();
    packed
        .try_reserve_exact(packed_capacity)
        .map_err(|_| SceneError::Limit)?;
    packed.extend_from_slice(&bytes[..COMPILE_HEADER_BYTES]);
    packed[..4].copy_from_slice(COMPILE_MAGIC);
    packed[4..8].copy_from_slice(&COMPILE_VERSION.to_le_bytes());
    packed[16..20].copy_from_slice(&(record_count as u32).to_le_bytes());
    packed[20..24].copy_from_slice(&(series_count as u32).to_le_bytes());
    for offset in (168..COMPILE_HEADER_BYTES).step_by(4) {
        packed[offset..offset + 4].fill(0);
    }
    packed.extend_from_slice(&kinds);
    append_aligned_u64s(&mut packed, &stable_ids);
    append_aligned_u32s(&mut packed, &style_refs);
    append_aligned_f64s(&mut packed, &diameter);
    packed.extend_from_slice(&symbols);
    append_aligned_f64s(&mut packed, &x0);
    append_aligned_f64s(&mut packed, &y0);
    append_aligned_f64s(&mut packed, &x1);
    append_aligned_f64s(&mut packed, &y1);
    packed.extend_from_slice(&fill_rgba);
    packed.extend_from_slice(&stroke_rgba);
    append_aligned_f64s(&mut packed, &stroke_width);
    let text_start = descriptors_end;
    let text_end = text_start
        .checked_add(title_len + x_label_len + y_label_len)
        .ok_or(SceneError::Limit)?;
    packed.extend_from_slice(bytes.get(text_start..text_end).ok_or(SceneError::Length)?);
    compile_columns_request(&packed, true)
}

/// Decode either packed canonical columns (`XYCC`) or transferable typed
/// series (`XYTS`) and encode the canonical Scene batch.
pub fn compile_scene_request(
    bytes: &[u8],
    peak_budget: usize,
) -> Result<CompiledScene, SceneError> {
    if bytes.get(..4) == Some(SEMANTIC_GRAPH_MAGIC) {
        compile_semantic_graph_request(bytes, peak_budget)
    } else if bytes.get(..4) == Some(SERIES_MAGIC) {
        compile_series_request(bytes, peak_budget)
    } else {
        compile_columns_request(bytes, false)
    }
}

/// Return the declared record count for checkpoint scheduling after validating
/// the common magic/header/version envelope. Full decoding remains fail-closed
/// in `compile_scene_request`.
pub fn checkpoint_record_count(bytes: &[u8]) -> Result<usize, SceneError> {
    if bytes.get(..4) == Some(SEMANTIC_GRAPH_MAGIC) {
        let offsets = semantic_graph_offsets(bytes)?;
        return offsets
            .nodes
            .checked_add(offsets.edges)
            .ok_or(SceneError::Limit);
    }
    if bytes.len() < COMPILE_HEADER_BYTES {
        return Err(SceneError::Length);
    }
    match bytes.get(..4) {
        Some(magic) if magic == SERIES_MAGIC => {
            if u32_at(bytes, HEADER_VERSION)? != SERIES_VERSION {
                return Err(SceneError::Version);
            }
            Ok(u32_at(bytes, HEADER_RECORD_COUNT)? as usize)
        }
        Some(magic) if magic == COMPILE_MAGIC => {
            if u32_at(bytes, HEADER_VERSION)? != COMPILE_VERSION {
                return Err(SceneError::Version);
            }
            Ok(u32_at(bytes, HEADER_SERIES_COUNT)? as usize)
        }
        _ => Err(SceneError::Length),
    }
}

/// Perform real bounded record decoding before the canonical build phase.
/// This catches malformed/non-finite geometry at a deterministic checkpoint;
/// it intentionally does not create a host-side policy or alternate output.
pub fn checkpoint_validate_records(
    bytes: &[u8],
    first: usize,
    count: usize,
) -> Result<(), SceneError> {
    let total = checkpoint_record_count(bytes)?;
    let end = first
        .checked_add(count)
        .ok_or(SceneError::Limit)?
        .min(total);
    if first > end {
        return Err(SceneError::Length);
    }
    if bytes.get(..4) == Some(SEMANTIC_GRAPH_MAGIC) {
        let o = semantic_graph_offsets(bytes)?;
        for index in first..end.min(o.nodes) {
            let values = [
                f64_at(bytes, o.x + index * 8)?,
                f64_at(bytes, o.y + index * 8)?,
            ];
            let metric = f64_at(bytes, o.node_metric + index * 8)?;
            let flags = u32_at(bytes, o.node_flags + index * 4)?;
            let parent = u64_at(bytes, o.parents + index * 8)?;
            let parent_valid = bytes[o.parent_validity + index];
            let collapsed = bytes[o.collapsed + index];
            if values.iter().any(|v| !v.is_finite())
                || metric.is_infinite()
                || flags & !xyg_engine::graph_style::KNOWN_STATE_FLAGS != 0
                || parent_valid > 1
                || collapsed > 1
                || parent_valid == 1 && parent >= o.nodes as u64
                || [o.node_class, o.node_epistemic, o.node_status]
                    .iter()
                    .any(|base| bytes[*base + index] > xyg_engine::graph_style::MAX_SEMANTIC_CODE)
            {
                return Err(SceneError::NonFinite);
            }
        }
        let edge_first = first.saturating_sub(o.nodes).min(o.edges);
        let edge_end = end.saturating_sub(o.nodes).min(o.edges);
        for index in edge_first..edge_end {
            let source = u64_at(bytes, o.sources + index * 8)?;
            let target = u64_at(bytes, o.targets + index * 8)?;
            let metric = f64_at(bytes, o.edge_metric + index * 8)?;
            let flags = u32_at(bytes, o.edge_flags + index * 4)?;
            if source >= o.nodes as u64
                || target >= o.nodes as u64
                || metric.is_infinite()
                || flags & !xyg_engine::graph_style::KNOWN_STATE_FLAGS != 0
                || [o.edge_class, o.edge_epistemic, o.edge_status]
                    .iter()
                    .any(|base| bytes[*base + index] > xyg_engine::graph_style::MAX_SEMANTIC_CODE)
            {
                return Err(SceneError::Length);
            }
        }
        return Ok(());
    }
    if bytes.get(..4) == Some(SERIES_MAGIC) {
        let series_count = u32_at(bytes, HEADER_SERIES_COUNT)? as usize;
        let data_start = align8(
            COMPILE_HEADER_BYTES
                + series_count
                    .checked_mul(SERIES_DESCRIPTOR_BYTES)
                    .ok_or(SceneError::Limit)?
                + u32_at(bytes, HEADER_TITLE_BYTES)? as usize
                + u32_at(bytes, HEADER_X_LABEL_BYTES)? as usize
                + u32_at(bytes, HEADER_Y_LABEL_BYTES)? as usize,
        );
        let mut base_record = 0usize;
        for series_index in 0..series_count {
            let base = COMPILE_HEADER_BYTES + series_index * SERIES_DESCRIPTOR_BYTES;
            let records = u32_at(bytes, base + DESCRIPTOR_RECORD_COUNT)? as usize;
            let local_first = first.saturating_sub(base_record).min(records);
            let local_end = end.saturating_sub(base_record).min(records);
            if local_first < local_end {
                for descriptor_offset in [DESCRIPTOR_X, DESCRIPTOR_Y] {
                    let offset = u32_at(bytes, base + descriptor_offset)? as usize;
                    if offset < data_start || !offset.is_multiple_of(8) {
                        return Err(SceneError::Length);
                    }
                    for index in local_first..local_end {
                        let value = f64_at(bytes, offset + index * 8)?;
                        if !value.is_finite() {
                            return Err(SceneError::NonFinite);
                        }
                    }
                }
            }
            base_record = base_record.checked_add(records).ok_or(SceneError::Limit)?;
        }
        if base_record != total {
            return Err(SceneError::Length);
        }
        return Ok(());
    }

    let mut offset = COMPILE_HEADER_BYTES;
    let kinds = take(bytes, &mut offset, total)?;
    offset = align8(offset);
    let stable = offset;
    offset += total.checked_mul(8).ok_or(SceneError::Limit)?;
    offset = align8(offset);
    let styles = offset;
    offset += total.checked_mul(4).ok_or(SceneError::Limit)?;
    offset = align8(offset);
    let diameters = offset;
    offset += total.checked_mul(8).ok_or(SceneError::Limit)?;
    let symbols = offset;
    offset += total;
    offset = align8(offset);
    let x0 = offset;
    offset += total.checked_mul(8).ok_or(SceneError::Limit)?;
    let y0 = offset;
    offset += total.checked_mul(8).ok_or(SceneError::Limit)?;
    let x1 = offset;
    offset += total.checked_mul(8).ok_or(SceneError::Limit)?;
    let y1 = offset;
    for index in first..end {
        let kind = *kinds.get(index).ok_or(SceneError::Length)?;
        let _identity = u64_at(bytes, stable + index * 8)?;
        let _style = u32_at(bytes, styles + index * 4)?;
        let diameter = f64_at(bytes, diameters + index * 8)?;
        let _symbol = *bytes.get(symbols + index).ok_or(SceneError::Length)?;
        let coordinates = [
            f64_at(bytes, x0 + index * 8)?,
            f64_at(bytes, y0 + index * 8)?,
        ];
        if !diameter.is_finite() || diameter < 0.0 || coordinates.iter().any(|v| !v.is_finite()) {
            return Err(SceneError::NonFinite);
        }
        if matches!(kind as u32, KIND_BAR | KIND_AREA)
            && [
                f64_at(bytes, x1 + index * 8)?,
                f64_at(bytes, y1 + index * 8)?,
            ]
            .iter()
            .any(|v| !v.is_finite())
        {
            return Err(SceneError::NonFinite);
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pack_scatter() -> Vec<u8> {
        let mut out = vec![0u8; COMPILE_HEADER_BYTES];
        out[..4].copy_from_slice(COMPILE_MAGIC);
        out[4..8].copy_from_slice(&COMPILE_VERSION.to_le_bytes());
        out[8..12].copy_from_slice(&(COMPILE_HEADER_BYTES as u32).to_le_bytes());
        out[HEADER_FLAGS..HEADER_FLAGS + 4]
            .copy_from_slice(&HEADER_FLAG_AUTO_MARGINS.to_le_bytes());
        out[16..20].copy_from_slice(&1u32.to_le_bytes());
        out[20..24].copy_from_slice(&1u32.to_le_bytes());
        for (offset, value) in [
            (40, 320.0f64),
            (48, 240.0),
            (120, 0.0),
            (128, 1.0),
            (136, 1.0),
            (144, 0.0),
            (152, 1.0),
            (160, 1.0),
        ] {
            out[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
        }
        out[88..96].copy_from_slice(&1u64.to_le_bytes());
        out[96..104].copy_from_slice(&2u64.to_le_bytes());
        out.extend_from_slice(&[0]); // kind scatter
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        out.extend_from_slice(&7u64.to_le_bytes());
        out.extend_from_slice(&0u32.to_le_bytes());
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        out.extend_from_slice(&8.0f64.to_le_bytes());
        out.push(0);
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for value in [0.5f64, 0.5, 0.0, 0.0] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        out.extend_from_slice(&[37, 99, 235, 255, 0, 0, 0, 0]);
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        out.extend_from_slice(&0.0f64.to_le_bytes());
        out
    }

    fn pack_semantic_graph() -> Vec<u8> {
        let mut out = vec![0u8; SEMANTIC_GRAPH_HEADER_BYTES];
        out[..4].copy_from_slice(SEMANTIC_GRAPH_MAGIC);
        out[4..8].copy_from_slice(&SEMANTIC_GRAPH_REQUEST_VERSION.to_le_bytes());
        out[8..12].copy_from_slice(&(SEMANTIC_GRAPH_HEADER_BYTES as u32).to_le_bytes());
        out[16..20].copy_from_slice(&3u32.to_le_bytes());
        out[20..24].copy_from_slice(&2u32.to_le_bytes());
        out[24..28].copy_from_slice(&14u32.to_le_bytes());
        out[12..16].copy_from_slice(&1u32.to_le_bytes());
        out[32..40].copy_from_slice(&800.0f64.to_le_bytes());
        out[40..48].copy_from_slice(&600.0f64.to_le_bytes());
        out.extend_from_slice(b"Semantic graph");
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for values in [[0.0f64, 1.0, 0.5], [0.0f64, 0.0, 1.0]] {
            for value in values {
                out.extend_from_slice(&value.to_le_bytes());
            }
        }
        out.extend_from_slice(&[1, 2, 3]); // class
        out.extend_from_slice(&[1, 0, 2]); // epistemic
        out.extend_from_slice(&[0, 1, 2]); // status
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for value in [0.0f64, 0.5, 1.0] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        for value in [2u32, 64, 0] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        out.extend_from_slice(&0u64.to_le_bytes());
        out.extend_from_slice(&2u64.to_le_bytes());
        out.extend_from_slice(&2u64.to_le_bytes());
        out.extend_from_slice(&1u64.to_le_bytes());
        out.extend_from_slice(&[1, 2, 1, 3, 1, 0]);
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for value in [1.0f64, 2.0] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        for value in [0u32, 16] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for _ in 0..3 {
            out.extend_from_slice(&0u64.to_le_bytes());
        }
        out.extend_from_slice(&[0, 0, 0]); // parent validity
        out.extend_from_slice(&[0, 0, 0]); // collapsed
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        let labels = [
            "Selected node",
            "Disabled node",
            "Third node",
            "parallel edge",
            "pinned edge",
        ];
        for label in &labels[..3] {
            out.extend_from_slice(&(label.len() as u32).to_le_bytes());
        }
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        for label in &labels[3..] {
            out.extend_from_slice(&(label.len() as u32).to_le_bytes());
        }
        for label in labels {
            out.extend_from_slice(label.as_bytes());
        }
        while !out.len().is_multiple_of(8) {
            out.push(0);
        }
        out
    }

    #[test]
    fn semantic_graph_request_compiles_to_the_canonical_scene_and_legend() {
        let request = pack_semantic_graph();
        let first = compile_scene_request(&request, 1 << 20).unwrap();
        let second = compile_scene_request(&request, 1 << 20).unwrap();
        assert_eq!(first.bytes, second.bytes);
        assert_eq!(&first.bytes[..4], b"XYGS");
        assert!(first.records > 4);
        let document = scene::SceneDocument::decode(&first.bytes).unwrap();
        assert!(document.to_svg().contains("Graph semantics"));
        assert!(
            document
                .to_browser_painter(1 << 20)
                .unwrap()
                .windows(4)
                .any(|w| w == b"XYLG")
        );
        assert!(!document.to_raster_commands(1.0).unwrap().is_empty());
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn compound_semantic_graph_is_byte_exact_with_native_abi89() {
        let mut request = pack_semantic_graph();
        let offsets = semantic_graph_offsets(&request).unwrap();
        for (index, parent) in [0u64, 0, 0].into_iter().enumerate() {
            request[offsets.parents + index * 8..offsets.parents + (index + 1) * 8]
                .copy_from_slice(&parent.to_le_bytes());
        }
        request[offsets.parent_validity..offsets.parent_validity + 3].copy_from_slice(&[0, 1, 0]);
        request[offsets.collapsed..offsets.collapsed + 3].copy_from_slice(&[1, 0, 0]);

        let compiled = compile_scene_request(&request, 1 << 20).unwrap();
        let x = [0.0, 1.0, 0.5];
        let y = [0.0, 0.0, 1.0];
        let node_classes = [1, 2, 3];
        let node_epistemic = [1, 0, 2];
        let node_statuses = [0, 1, 2];
        let node_metric = [0.0, 0.5, 1.0];
        let node_flags = [2, 64, 0];
        let sources = [0, 2];
        let targets = [2, 1];
        let edge_classes = [1, 2];
        let edge_epistemic = [1, 3];
        let edge_statuses = [1, 0];
        let edge_metric = [1.0, 2.0];
        let edge_flags = [0, 16];
        let node_label_lengths = [13, 13, 10];
        let edge_label_lengths = [13, 11];
        let label_payload = b"Selected nodeDisabled nodeThird nodeparallel edgepinned edge";
        let parents = [0, 0, 0];
        let parent_validity = [0, 1, 0];
        let collapsed = [1, 0, 0];
        let title = b"Semantic graph";
        let descriptor = xyg_core::XygGraphCompoundSceneDescriptor {
            version: SEMANTIC_GRAPH_SCENE_VERSION,
            theme: 1,
            width: 800.0,
            height: 600.0,
            node_count: 3,
            edge_count: 2,
            title: title.as_ptr(),
            title_len: title.len() as u64,
            x: x.as_ptr(),
            y: y.as_ptr(),
            node_classes: node_classes.as_ptr(),
            node_epistemic: node_epistemic.as_ptr(),
            node_statuses: node_statuses.as_ptr(),
            node_metric: node_metric.as_ptr(),
            node_flags: node_flags.as_ptr(),
            node_label_lengths: node_label_lengths.as_ptr(),
            sources: sources.as_ptr(),
            targets: targets.as_ptr(),
            edge_classes: edge_classes.as_ptr(),
            edge_epistemic: edge_epistemic.as_ptr(),
            edge_statuses: edge_statuses.as_ptr(),
            edge_metric: edge_metric.as_ptr(),
            edge_flags: edge_flags.as_ptr(),
            edge_label_lengths: edge_label_lengths.as_ptr(),
            label_payload: label_payload.as_ptr(),
            label_payload_len: label_payload.len() as u64,
            parents: parents.as_ptr(),
            parent_validity: parent_validity.as_ptr(),
            collapsed: collapsed.as_ptr(),
            reserved: 0,
        };
        let needed =
            unsafe { xyg_core::xyg_graph_compound_scene(&descriptor, std::ptr::null_mut(), 0) };
        assert_ne!(needed, usize::MAX);
        let mut native = vec![0; needed];
        assert_eq!(
            unsafe {
                xyg_core::xyg_graph_compound_scene(&descriptor, native.as_mut_ptr(), native.len())
            },
            needed
        );
        assert_eq!(compiled.bytes, native);
        let document = scene::SceneDocument::decode(&native).unwrap();
        assert_eq!(
            document.to_browser_painter(1 << 20).unwrap(),
            scene::SceneDocument::decode(&compiled.bytes)
                .unwrap()
                .to_browser_painter(1 << 20)
                .unwrap()
        );
    }

    #[test]
    fn compound_semantic_graph_rejects_hostile_planes_and_utf8() {
        let request = pack_semantic_graph();
        let offsets = semantic_graph_offsets(&request).unwrap();
        for (offset, value) in [(offsets.parent_validity, 2), (offsets.collapsed, 2)] {
            let mut hostile = request.clone();
            hostile[offset] = value;
            assert_eq!(
                checkpoint_validate_records(&hostile, 0, 1),
                Err(SceneError::NonFinite)
            );
            assert!(compile_scene_request(&hostile, 1 << 20).is_err());
        }
        let mut bad_parent = request.clone();
        bad_parent[offsets.parent_validity] = 1;
        bad_parent[offsets.parents..offsets.parents + 8].copy_from_slice(&3u64.to_le_bytes());
        assert!(compile_scene_request(&bad_parent, 1 << 20).is_err());

        let mut bad_utf8 = request;
        bad_utf8[SEMANTIC_GRAPH_HEADER_BYTES] = 0xff;
        assert!(matches!(
            compile_scene_request(&bad_utf8, 1 << 20),
            Err(SceneError::Length)
        ));
    }

    #[test]
    fn semantic_graph_checkpoint_validates_node_edge_boundary_and_planes() {
        let request = pack_semantic_graph();
        assert_eq!(checkpoint_record_count(&request), Ok(5));
        assert_eq!(checkpoint_validate_records(&request, 2, 2), Ok(()));

        let offsets = semantic_graph_offsets(&request).unwrap();
        let mut bad_code = request.clone();
        bad_code[offsets.node_class] = xyg_engine::graph_style::MAX_SEMANTIC_CODE + 1;
        assert_eq!(
            checkpoint_validate_records(&bad_code, 0, 1),
            Err(SceneError::NonFinite)
        );

        let mut bad_endpoint = request;
        bad_endpoint[offsets.sources..offsets.sources + 8].copy_from_slice(&3u64.to_le_bytes());
        assert_eq!(
            checkpoint_validate_records(&bad_endpoint, offsets.nodes, 1),
            Err(SceneError::Length)
        );
    }

    #[test]
    fn semantic_graph_request_rejects_reserved_and_trailing_data() {
        let mut reserved = pack_semantic_graph();
        reserved[28] = 1;
        assert!(matches!(
            compile_scene_request(&reserved, 1 << 20),
            Err(SceneError::Length)
        ));
        let mut trailing = pack_semantic_graph();
        trailing.extend_from_slice(&[0; 8]);
        assert!(matches!(
            compile_scene_request(&trailing, 1 << 20),
            Err(SceneError::Length)
        ));
    }

    #[test]
    fn semantic_graph_rejects_huge_viewport_and_insufficient_peak_before_columns() {
        let request = pack_semantic_graph();
        assert!(matches!(
            compile_scene_request(&request, request.len()),
            Err(SceneError::Limit)
        ));
        let mut huge = request;
        huge[32..40].copy_from_slice(&f64::MAX.to_le_bytes());
        assert!(matches!(
            compile_scene_request(&huge, 1 << 20),
            Err(SceneError::Length)
        ));
    }

    fn pack_typed_series() -> Vec<u8> {
        let data_start = COMPILE_HEADER_BYTES + SERIES_DESCRIPTOR_BYTES;
        let mut out = vec![0u8; data_start];
        out[..4].copy_from_slice(SERIES_MAGIC);
        out[4..8].copy_from_slice(&SERIES_VERSION.to_le_bytes());
        out[8..12].copy_from_slice(&(COMPILE_HEADER_BYTES as u32).to_le_bytes());
        out[HEADER_FLAGS..HEADER_FLAGS + 4]
            .copy_from_slice(&(HEADER_FLAG_AUTO_MARGINS | HEADER_FLAG_AUTO_DOMAIN).to_le_bytes());
        out[16..20].copy_from_slice(&1u32.to_le_bytes());
        out[20..24].copy_from_slice(&2u32.to_le_bytes());
        for (offset, value) in [
            (40, 320.0f64),
            (48, 240.0),
            (120, 0.0),
            (128, 1.0),
            (136, 1.0),
            (144, 0.0),
            (152, 1.0),
            (160, 1.0),
        ] {
            out[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
        }
        out[88..96].copy_from_slice(&1u64.to_le_bytes());
        out[96..104].copy_from_slice(&2u64.to_le_bytes());
        let descriptor = COMPILE_HEADER_BYTES;
        out[descriptor..descriptor + 4].copy_from_slice(&0u32.to_le_bytes());
        out[descriptor + 8..descriptor + 12].copy_from_slice(&2u32.to_le_bytes());
        out[descriptor + 24..descriptor + 32].copy_from_slice(&f64::NAN.to_le_bytes());
        out[descriptor + 32..descriptor + 40].copy_from_slice(&f64::NAN.to_le_bytes());
        out[descriptor + 48..descriptor + 52].copy_from_slice(&(data_start as u32).to_le_bytes());
        out[descriptor + 52..descriptor + 56]
            .copy_from_slice(&((data_start + 16) as u32).to_le_bytes());
        for value in [0.25f64, 0.75, 0.5, 0.9] {
            out.extend_from_slice(&value.to_le_bytes());
        }
        out
    }

    #[test]
    fn packed_scatter_compiles_to_canonical_scene() {
        let compiled = compile_scene_request(&pack_scatter(), usize::MAX).unwrap();
        assert_eq!(compiled.records, 1);
        assert_eq!(compiled.styles, 1);
        assert_eq!(&compiled.bytes[..4], b"XYGS");
        assert_eq!(
            u32::from_le_bytes(compiled.bytes[4..8].try_into().unwrap()),
            scene::SCENE_VERSION
        );
        scene::validate_scene_batch(&compiled.bytes).unwrap();
    }

    #[test]
    fn unknown_flags_and_trailing_bytes_fail_closed() {
        let mut bad = pack_scatter();
        bad[12..16].copy_from_slice(&4u32.to_le_bytes()); // bit 2 is unknown
        assert!(compile_scene_request(&bad, usize::MAX).is_err());
        let mut trailing = pack_scatter();
        trailing.push(0);
        assert!(compile_scene_request(&trailing, usize::MAX).is_err());
    }

    #[test]
    fn auto_domain_overrides_header_lo_hi() {
        let mut packed = pack_scatter();
        packed[HEADER_FLAGS..HEADER_FLAGS + 4]
            .copy_from_slice(&(HEADER_FLAG_AUTO_MARGINS | HEADER_FLAG_AUTO_DOMAIN).to_le_bytes());
        // Header domains are deliberately wrong; geometry is at (0.5, 0.5).
        packed[120..128].copy_from_slice(&(-10.0f64).to_le_bytes());
        packed[128..136].copy_from_slice(&(-9.0f64).to_le_bytes());
        packed[144..152].copy_from_slice(&(-10.0f64).to_le_bytes());
        packed[152..160].copy_from_slice(&(-9.0f64).to_le_bytes());
        let compiled = compile_scene_request(&packed, usize::MAX).unwrap();
        scene::validate_scene_batch(&compiled.bytes).unwrap();
    }

    #[test]
    fn auto_domain_from_columns_uses_engine_pad() {
        let kinds = [0u8];
        let x0 = [0.5];
        let y0 = [0.5];
        let x1 = [0.0];
        let y1 = [0.0];
        let (lo, hi) = auto_domain(Some((0.5, 0.5)));
        assert_eq!(
            auto_domain_from_columns(&kinds, &x0, &y0, &x1, &y1),
            Some((lo, hi, lo, hi))
        );
    }

    #[test]
    fn typed_series_expands_defaults_and_stable_ids_in_rust() {
        let request = pack_typed_series();
        let required = series_peak_bytes(request.len(), 2, 1).unwrap();
        assert!(compile_scene_request(&request, required - 1).is_err());
        let compiled = compile_scene_request(&request, required).unwrap();
        assert_eq!((compiled.records, compiled.styles), (2, 1));
        scene::validate_scene_batch(&compiled.bytes).unwrap();
        let first_record = scene::SCENE_BATCH_HEADER_BYTES + 16;
        assert_eq!(
            u64::from_le_bytes(
                compiled.bytes[first_record + 8..first_record + 16]
                    .try_into()
                    .unwrap()
            ),
            1
        );
        assert_eq!(
            u64::from_le_bytes(
                compiled.bytes[first_record + scene::SCENE_BATCH_RECORD_BYTES + 8
                    ..first_record + scene::SCENE_BATCH_RECORD_BYTES + 16]
                    .try_into()
                    .unwrap()
            ),
            2
        );
        assert_eq!(
            f64::from_le_bytes(
                compiled.bytes[first_record + 48..first_record + 56]
                    .try_into()
                    .unwrap()
            ),
            8.0
        );
        let painter = scene::SceneDocument::decode(&compiled.bytes)
            .unwrap()
            .to_browser_painter(1024 * 1024)
            .unwrap();
        assert_eq!(&painter[..4], b"XYPB");
        assert!(painter.windows(4).any(|rgba| rgba == default_mark_rgba8()));

        let mut malformed = pack_typed_series();
        malformed[COMPILE_HEADER_BYTES + 48..COMPILE_HEADER_BYTES + 52]
            .copy_from_slice(&0u32.to_le_bytes());
        assert!(compile_scene_request(&malformed, usize::MAX).is_err());

        let mut aliased = pack_typed_series();
        let x_offset = aliased[COMPILE_HEADER_BYTES + 48..COMPILE_HEADER_BYTES + 52].to_vec();
        aliased[COMPILE_HEADER_BYTES + 52..COMPILE_HEADER_BYTES + 56].copy_from_slice(&x_offset);
        assert!(compile_scene_request(&aliased, usize::MAX).is_err());

        let mut trailing = pack_typed_series();
        trailing.extend_from_slice(&0f64.to_le_bytes());
        assert!(compile_scene_request(&trailing, usize::MAX).is_err());

        let mut wrong_version = pack_typed_series();
        wrong_version[4..8].copy_from_slice(&(SERIES_VERSION + 1).to_le_bytes());
        assert!(matches!(
            compile_scene_request(&wrong_version, usize::MAX),
            Err(SceneError::Version)
        ));
        let mut wrong_header = pack_typed_series();
        wrong_header[8..12].copy_from_slice(&0u32.to_le_bytes());
        assert!(matches!(
            compile_scene_request(&wrong_header, usize::MAX),
            Err(SceneError::Length)
        ));
    }

    #[test]
    fn typed_series_auto_margins_compile_on_the_wasm_foundation_tiny_viewport() {
        let mut request = pack_typed_series();
        request[HEADER_WIDTH..HEADER_WIDTH + 8].copy_from_slice(&64.0f64.to_le_bytes());
        request[HEADER_HEIGHT..HEADER_HEIGHT + 8].copy_from_slice(&48.0f64.to_le_bytes());
        let compiled = compile_scene_request(&request, usize::MAX).unwrap();
        scene::validate_scene_batch(&compiled.bytes).unwrap();
    }

    #[test]
    fn typed_series_preserves_transferred_per_record_stable_ids() {
        let mut request = pack_typed_series();
        let descriptor = COMPILE_HEADER_BYTES;
        let ids_offset = request.len();
        request[descriptor + DESCRIPTOR_FLAGS..descriptor + DESCRIPTOR_FLAGS + 4]
            .copy_from_slice(&DESCRIPTOR_FLAG_STABLE_IDS.to_le_bytes());
        request[descriptor + DESCRIPTOR_STABLE_IDS..descriptor + DESCRIPTOR_STABLE_IDS + 4]
            .copy_from_slice(&(ids_offset as u32).to_le_bytes());
        request.extend_from_slice(&91u64.to_le_bytes());
        request.extend_from_slice(&7u64.to_le_bytes());

        let compiled = compile_scene_request(&request, usize::MAX).unwrap();
        let first = scene::SCENE_BATCH_HEADER_BYTES + 16;
        let second = first + scene::SCENE_BATCH_RECORD_BYTES;
        assert_eq!(u64_at(&compiled.bytes, first + 8).unwrap(), 91);
        assert_eq!(u64_at(&compiled.bytes, second + 8).unwrap(), 7);

        let mut conflicting = request;
        let flags = DESCRIPTOR_FLAG_STABLE_IDS | DESCRIPTOR_FLAG_STABLE_ID_BASE;
        conflicting[descriptor + DESCRIPTOR_FLAGS..descriptor + DESCRIPTOR_FLAGS + 4]
            .copy_from_slice(&flags.to_le_bytes());
        assert!(matches!(
            compile_scene_request(&conflicting, usize::MAX),
            Err(SceneError::Length)
        ));
    }

    #[test]
    fn legacy_xycc_stable_ids_remain_run_boundaries() {
        let mut request = vec![0u8; COMPILE_HEADER_BYTES];
        request[..4].copy_from_slice(COMPILE_MAGIC);
        request[4..8].copy_from_slice(&COMPILE_VERSION.to_le_bytes());
        request[8..12].copy_from_slice(&(COMPILE_HEADER_BYTES as u32).to_le_bytes());
        request[16..20].copy_from_slice(&2u32.to_le_bytes());
        request[20..24].copy_from_slice(&1u32.to_le_bytes());
        for (offset, value) in [
            (40, 320.0f64),
            (48, 240.0),
            (120, 0.0),
            (128, 1.0),
            (136, 1.0),
            (144, 0.0),
            (152, 1.0),
            (160, 1.0),
        ] {
            request[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
        }
        request[88..96].copy_from_slice(&1u64.to_le_bytes());
        request[96..104].copy_from_slice(&2u64.to_le_bytes());
        request.extend_from_slice(&[KIND_LINE as u8, KIND_LINE as u8]);
        append_aligned_u64s(&mut request, &[10, 11]);
        append_aligned_u32s(&mut request, &[0, 0]);
        append_aligned_f64s(&mut request, &[0.0, 0.0]);
        request.extend_from_slice(&[0, 0]);
        append_aligned_f64s(&mut request, &[0.1, 0.9]);
        append_aligned_f64s(&mut request, &[0.2, 0.8]);
        append_aligned_f64s(&mut request, &[0.0, 0.0]);
        append_aligned_f64s(&mut request, &[0.0, 0.0]);
        request.extend_from_slice(&[0, 0, 0, 0]);
        request.extend_from_slice(&[37, 99, 235, 255]);
        append_aligned_f64s(&mut request, &[1.5]);
        let compiled = compile_columns_request(&request, false).unwrap();
        assert_eq!(compiled.bytes[scene::SCENE_BATCH_HEADER_BYTES + 16 + 3], 0);
        let painter = scene::SceneDocument::decode(&compiled.bytes)
            .unwrap()
            .to_browser_painter(1 << 20)
            .unwrap();
        assert_eq!(u32::from_le_bytes(painter[20..24].try_into().unwrap()), 2);
    }

    #[test]
    fn default_bar_width_tracks_spacing_and_domain() {
        assert!(
            (default_bar_half_width(&[0.1, 0.2, 0.4], 0.0, 1.0).unwrap() - 0.04).abs()
                < f64::EPSILON
        );
        assert_eq!(
            default_bar_half_width(&[0.0, 1_000_000.0], 0.0, 1_000_000.0).unwrap(),
            400_000.0
        );
        assert_eq!(default_bar_half_width(&[5.0], 10.0, 0.0).unwrap(), 4.0);
        assert_eq!(default_bar_half_width(&[2.0, 2.0], 0.0, 10.0).unwrap(), 4.0);
        assert!(matches!(
            default_bar_half_width(&[f64::NAN], 0.0, 1.0),
            Err(SceneError::NonFinite)
        ));

        let mut request = pack_typed_series();
        request[COMPILE_HEADER_BYTES..COMPILE_HEADER_BYTES + 4]
            .copy_from_slice(&2u32.to_le_bytes());
        let compiled = compile_scene_request(&request, usize::MAX).unwrap();
        let first_record = scene::SCENE_BATCH_HEADER_BYTES + scene::SCENE_STYLE_RECORD_BYTES;
        let x0 = f64::from_le_bytes(
            compiled.bytes[first_record + 16..first_record + 24]
                .try_into()
                .unwrap(),
        );
        let x1 = f64::from_le_bytes(
            compiled.bytes[first_record + 32..first_record + 40]
                .try_into()
                .unwrap(),
        );
        assert!(x0.is_finite() && x1.is_finite() && x1 > x0);
    }
}
