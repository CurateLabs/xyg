/// <reference lib="webworker" />

import {
  bindXygWasmExports,
  readXygWasmError,
  XYG_WASM_STATUS,
  XYG_WASM_ABI_VERSION,
  XYG_WASM_DEFAULT_PALETTE_ROWS,
  XYG_WASM_DEFAULT_PALETTE_VERSION,
  XYG_WASM_SCENE_VERSION,
  XYG_WASM_AGGREGATE_CHECKPOINT_POINTS,
  XYG_WASM_AGGREGATE_REQUEST_COPY_FACTOR,
  XYG_WASM_AGGREGATE_OUTPUT_HEADER_BYTES,
  XYG_WASM_AGGREGATE_OUTPUT_STRIDE_COUNT,
  XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES,
  XYG_WASM_AGGREGATE_STREAM_CHUNK_BYTES,
  XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS,
  XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS,
  XYG_WASM_GRAPH_FIRST_PAINT_STEPS,
  type XygWasmExports,
} from "./wasm_abi_generated";
import { decodeWasmGraphCheckpoint } from "./49_wasm_graph";

type WorkerScope = DedicatedWorkerGlobalScope;
const scope = self as unknown as WorkerScope;

let exports: XygWasmExports | null = null;
let handle = 0;
type Lifecycle = "idle" | "initializing" | "initialized" | "failed" | "disposed";
let lifecycle: Lifecycle = "idle";
let operationBudgetBytes = 0;
let retainedGeoMode=false;
let evidenceCapability: string | null = null;
let initializedModule: WebAssembly.Module | null = null;
let compileLeaf = false;
let operationSequenceWatermark = 0;
let tickSequenceWatermark = 0;
const queued = new Map<number, number>();
let activeAggregate: { requestId: number; sequence: number; timer: number } | null = null;
let activeAggregateStream: { requestId: number; sequence: number; pushes: number } | null = null;
let activeGraph: { requestId: number; sequence: number; revision: number; timer: number; chunkSteps: number; started: number; maxWallMs: number; first: boolean } | null = null;
let activeCompile: { requestId: number; sequence: number; timer: number; paint: boolean; leaf?: Worker; loweringAnnounced?: boolean } | null = null;
let activeTick: { requestId: number; sequence: number; timer: number; bytes: number } | null = null;
const tickQueue: any[] = [];
let retainedTickBytes = 0;
const MAX_RETAINED_TICK_REQUESTS = 64;
const COMPILE_CHECKPOINT_RECORDS = 4096;

function isDisposed(): boolean {
  return lifecycle === "disposed";
}

function reply(requestId: number, value: unknown, transfer: Transferable[] = []) {
  scope.postMessage({ requestId, ok: true, value }, transfer);
}

/** Capability-gated observational telemetry for hosted strict-CSP evidence. */
function streamObservation(phase: "begin" | "push" | "cancelled" | "finish", active: { requestId: number; sequence: number; pushes: number }) {
  if (evidenceCapability) scope.postMessage({ type: "aggregate.stream_observation", phase,
    requestId: active.requestId, sequence: active.sequence, pushes: active.pushes });
}

function error(requestId: number, code: string, message: string, status: number | null = null) {
  scope.postMessage({ requestId, ok: false, error: { code, message, status, diagnostics: null } });
}

function rustError(requestId: number, code: string, message: string, status: number) {
  let snapshot = null;
  try {
    if (exports && handle) snapshot = diagnostics();
  } catch {
    // A trapped instance may reject diagnostic reads; preserve the root error.
  }
  scope.postMessage({ requestId, ok: false, error: { code, message, status, diagnostics: snapshot } });
}

function statusCode(status: number): string {
  const entry = Object.entries(XYG_WASM_STATUS).find(([, value]) => value === status);
  return entry ? `XYG_WASM_${entry[0]}` : "XYG_WASM_UNKNOWN_STATUS";
}

function disposeRust() {
  try {
    if (exports && handle) exports.xyg_wasm_instance_dispose(handle);
  } catch {
    // A trapped instance may trap again during cleanup; preserve the original error.
  } finally {
    handle = 0;
    exports = null;
    if (lifecycle === "failed") {
      rejectTicks("XYG_WASM_TRAP", "WASM instance failed while tick work was pending");
    }
  }
}

function disposeAttempt(bound: XygWasmExports | null, created: number) {
  try {
    if (bound && created) bound.xyg_wasm_instance_dispose(created);
  } catch {
    // Best-effort cleanup for a partially initialized or trapped instance.
  }
}

async function loadModule(source: any): Promise<WebAssembly.Module> {
  if (source?.kind === "module" && source.value instanceof WebAssembly.Module) {
    return source.value;
  }
  if (source?.kind === "bytes" && source.value instanceof ArrayBuffer) {
    return WebAssembly.compile(source.value);
  }
  if (source?.kind === "url" && typeof source.value === "string") {
    // This is the only network-capable branch and the URL is supplied by the
    // caller. There is no default CDN, fallback URL, or path probing.
    const response = await fetch(source.value, {
      credentials: "same-origin",
      redirect: "error",
    });
    if (!response.ok) throw new Error(`WASM URL returned HTTP ${response.status}`);
    return WebAssembly.compile(await response.arrayBuffer());
  }
  throw new TypeError("unsupported explicit WASM source");
}

/** A coded initialization failure; `code` reaches `XygWasmError.code`. */
class WasmInitError extends Error {
  constructor(readonly code: string, message: string) { super(message); }
}

async function initialize(message: any) {
  if (lifecycle !== "idle") {
    error(message.requestId, "XYG_WASM_ALREADY_INITIALIZED", "worker cannot be reinitialized");
    return;
  }
  lifecycle = "initializing";
  let bound: XygWasmExports | null = null;
  let created = 0;
  try {
    evidenceCapability = typeof message.evidenceCapability === "string" && message.evidenceCapability.length >= 24
      ? message.evidenceCapability : null;
    const module = await loadModule(message.source);
    if (isDisposed()) return;
    if (WebAssembly.Module.imports(module).length !== 0) {
      throw new WasmInitError("XYG_WASM_IMPORTS_REJECTED", "XYG WASM module must not request ambient imports");
    }
    const instance = await WebAssembly.instantiate(module, {});
    if (isDisposed()) return;
    try {
      bound = bindXygWasmExports(instance);
    } catch (cause) {
      // The generated binder also rejects a version skew; name it as one.
      const raw = instance.exports as Record<string, unknown>;
      const abi = typeof raw.xyg_wasm_abi_version === "function" ? (raw.xyg_wasm_abi_version as () => number)() >>> 0 : null;
      if (abi !== null && abi !== message.expectedAbiVersion) {
        throw new WasmInitError("XYG_WASM_ABI_MISMATCH", `XYG WASM ABI ${abi} does not match the client's ${message.expectedAbiVersion}; deploy the Worker, WASM, and client from one @curatelabs/xyg release`);
      }
      const scene = typeof raw.xyg_wasm_scene_version === "function" ? (raw.xyg_wasm_scene_version as () => number)() >>> 0 : null;
      if (scene !== null && scene !== message.expectedSceneVersion) {
        throw new WasmInitError("XYG_WASM_SCENE_MISMATCH", `XYG WASM Scene version ${scene} does not match the client's ${message.expectedSceneVersion}`);
      }
      throw new WasmInitError("XYG_WASM_EXPORT_MISMATCH", cause instanceof Error ? cause.message : "XYG WASM exports are incompatible");
    }
    const abi = bound.xyg_wasm_abi_version() >>> 0;
    if (abi !== message.expectedAbiVersion) {
      throw new WasmInitError("XYG_WASM_ABI_MISMATCH", `XYG WASM ABI ${abi} does not match the client's ${message.expectedAbiVersion}; deploy the Worker, WASM, and client from one @curatelabs/xyg release`);
    }
    const scene = bound.xyg_wasm_scene_version() >>> 0;
    if (scene !== message.expectedSceneVersion) {
      throw new WasmInitError("XYG_WASM_SCENE_MISMATCH", `XYG WASM Scene version ${scene} does not match the client's ${message.expectedSceneVersion}`);
    }
    if (bound.xyg_wasm_default_palette_version() !== XYG_WASM_DEFAULT_PALETTE_VERSION
      || bound.xyg_wasm_default_palette_rows() !== XYG_WASM_DEFAULT_PALETTE_ROWS) {
      throw new WasmInitError("XYG_WASM_PALETTE_MISMATCH", "XYG WASM default palette contract is incompatible with the client");
    }
    const max = Number(message.maxArenaBytes);
    if (!Number.isInteger(max) || max <= 0 || max > bound.xyg_wasm_max_arena_bytes()) {
      throw new WasmInitError("XYG_WASM_BUDGET_EXCEEDED", "maxArenaBytes exceeds the Rust adapter bound");
    }
    created = bound.xyg_wasm_instance_new(max) >>> 0;
    if (!created) throw new WasmInitError("XYG_WASM_INSTANCE_EXHAUSTED", "XYG WASM instance budget is exhausted");
    if (isDisposed()) {
      disposeAttempt(bound, created);
      return;
    }
    exports = bound;
    initializedModule = module;
    compileLeaf = message.compileLeaf === true;
    handle = created;
    operationBudgetBytes = max;
    created = 0;
    lifecycle = "initialized";
    reply(message.requestId, diagnostics());
  } catch (cause) {
    disposeAttempt(bound, created);
    if (isDisposed()) return;
    lifecycle = "failed";
    disposeRust();
    error(
      message.requestId,
      cause instanceof WasmInitError ? cause.code : "XYG_WASM_INIT_FAILED",
      cause instanceof Error ? cause.message : "WASM initialization failed",
    );
  }
}

function diagnostics() {
  if (!exports || !handle) throw new Error("XYG WASM worker is not initialized");
  const memoryBytes = exports.memory.buffer.byteLength;
  return {
    abiVersion: exports.xyg_wasm_abi_version() >>> 0,
    sceneVersion: exports.xyg_wasm_scene_version() >>> 0,
    defaultPaletteVersion: exports.xyg_wasm_default_palette_version() >>> 0,
    defaultPaletteRows: exports.xyg_wasm_default_palette_rows() >>> 0,
    defaultPaletteFirstRgba8: exports.xyg_wasm_default_palette_rgba8(0) >>> 0,
    arenaBytes: exports.xyg_wasm_arena_len(handle) >>> 0,
    arenaHighWaterBytes: exports.xyg_wasm_arena_high_water(handle) >>> 0,
    memoryBytes,
    memoryHighWaterBytes: memoryBytes,
    copyCount: exports.xyg_wasm_copy_count(handle) >>> 0,
    copyBytesLo: exports.xyg_wasm_copy_bytes_lo(handle) >>> 0,
    copyBytesHi: exports.xyg_wasm_copy_bytes_hi(handle) >>> 0,
    records: exports.xyg_wasm_last_scene_records(handle) >>> 0,
    styles: exports.xyg_wasm_last_scene_styles(handle) >>> 0,
  };
}

function streamStage(bytes: ArrayBuffer, limit: number): number {
  if (!exports || !handle) throw new Error("worker is not initialized");
  if (bytes.byteLength <= 0 || bytes.byteLength > limit) throw new RangeError("aggregate stream frame exceeds its generated bound");
  const status = exports.xyg_wasm_arena_resize(handle, bytes.byteLength);
  if (status !== XYG_WASM_STATUS.OK) return status;
  const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
  if (!ptr || ptr + bytes.byteLength > exports.memory.buffer.byteLength) throw new Error("aggregate stream staging range is invalid");
  new Uint8Array(exports.memory.buffer, ptr, bytes.byteLength).set(new Uint8Array(bytes));
  return XYG_WASM_STATUS.OK;
}

function streamFailure(message: any, status: number) {
  activeAggregateStream = null;
  if (exports && handle) exports.xyg_wasm_arena_resize(handle, 0);
  rustError(message.requestId, statusCode(status), readXygWasmError(exports!, handle), status);
}

/** Capability-gated strict-CSP evidence of a real Rust `XYAS` refusal. */
function evidenceLifecycle(message: any) {
  if (!evidenceCapability || message.capability !== evidenceCapability) {
    error(message.requestId, "XYG_WASM_EVIDENCE_DISABLED", "lifecycle evidence is not enabled"); return;
  }
  if (message.action === "trap") {
    // Capability-gated evidence only: exercise the same terminal lifecycle
    // boundary a Rust/WASM trap takes, so the host must rebuild a Worker and
    // replay its retained split source.
    lifecycle = "failed";
    disposeRust();
    error(message.requestId, "XYG_WASM_TRAP", "evidence-injected Rust/WASM trap");
    return;
  }
  if (message.action !== "stream_resource") {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "unknown lifecycle evidence action", XYG_WASM_STATUS.INVALID_ARGUMENT); return;
  }
  if (!exports || !handle || lifecycle !== "initialized") {
    error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return;
  }
  const sequence = Number(message.sequence);
  if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "stream evidence sequence is malformed", XYG_WASM_STATUS.INVALID_ARGUMENT); return;
  }
  try {
    // Valid XYAS framing with a grid one cell beyond Rust's declared bound.
    // This executes the production stream begin/export in this Worker rather
    // than rejecting on the host validation path.
    const header = new ArrayBuffer(XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES);
    const bytes = new Uint8Array(header), view = new DataView(header);
    bytes.set([0x58, 0x59, 0x41, 0x53]);
    view.setUint32(4, 1, true); view.setUint32(8, XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES, true);
    view.setUint32(16, 1, true); view.setUint32(20, 4097, true); view.setUint32(24, 4097, true);
    view.setFloat64(32, 0, true); view.setFloat64(40, 1, true);
    view.setFloat64(48, 0, true); view.setFloat64(56, 1, true);
    const staged = streamStage(header, XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES);
    if (staged !== XYG_WASM_STATUS.OK) { streamFailure(message, staged); return; }
    const status = exports.xyg_wasm_aggregate_stream_begin(handle, sequence, 0, header.byteLength);
    if (status === XYG_WASM_STATUS.OK || status === XYG_WASM_STATUS.PENDING) {
      throw new Error("stream evidence unexpectedly accepted an over-limit grid");
    }
    streamFailure(message, status);
  } catch (cause) {
    error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "stream lifecycle evidence trapped");
  }
}

function beginAggregateStream(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!(message.header instanceof ArrayBuffer) || message.header.byteLength !== XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES) throw new TypeError("aggregate stream header is malformed");
    if (activeAggregate) throw new Error("an aggregate request is already active");
    if (activeAggregateStream) {
      const previous = activeAggregateStream;
      if (Number(message.sequence) <= previous.sequence) {
        error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "aggregate stream sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE);
        return;
      }
      exports.xyg_wasm_cancel(handle, previous.sequence);
      activeAggregateStream = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate stream was superseded by a newer request", XYG_WASM_STATUS.CANCELLED);
    }
    const staged = streamStage(message.header, XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES);
    if (staged !== XYG_WASM_STATUS.OK) { streamFailure(message, staged); return; }
    const status = exports.xyg_wasm_aggregate_stream_begin(handle, Number(message.sequence), 0, message.header.byteLength);
    if (status !== XYG_WASM_STATUS.PENDING) { streamFailure(message, status); return; }
    activeAggregateStream = { requestId: message.requestId, sequence: Number(message.sequence), pushes: 0 };
    streamObservation("begin", activeAggregateStream);
  } catch (cause) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "aggregate stream begin failed", XYG_WASM_STATUS.INVALID_ARGUMENT); }
}

function pushAggregateStream(message: any) {
  const active = activeAggregateStream;
  if (!active || active.requestId !== message.requestId || active.sequence !== Number(message.sequence)) return;
  try {
    if (!(message.chunk instanceof ArrayBuffer) || !message.chunk.byteLength || message.chunk.byteLength > XYG_WASM_AGGREGATE_STREAM_CHUNK_BYTES || message.chunk.byteLength % 16) throw new TypeError("aggregate stream chunk is malformed");
    const staged = streamStage(message.chunk, XYG_WASM_AGGREGATE_STREAM_CHUNK_BYTES);
    if (staged !== XYG_WASM_STATUS.OK) { streamFailure(message, staged); return; }
    const status = exports!.xyg_wasm_aggregate_stream_push(handle, active.sequence, 0, message.chunk.byteLength);
    if (status !== XYG_WASM_STATUS.PENDING) streamFailure(message, status);
    else { active.pushes++; streamObservation("push", active); }
  } catch (cause) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "aggregate stream push failed", XYG_WASM_STATUS.INVALID_ARGUMENT); activeAggregateStream = null; }
}

function finishAggregateStream(message: any) {
  const active = activeAggregateStream;
  if (!active || active.requestId !== message.requestId || active.sequence !== Number(message.sequence) || !exports || !handle) return;
  try {
    const status = exports.xyg_wasm_aggregate_stream_finish(handle, active.sequence);
    activeAggregateStream = null;
    if (status !== XYG_WASM_STATUS.OK) { streamFailure(message, status); return; }
    const ptr = exports.xyg_wasm_output_ptr(handle) >>> 0, len = exports.xyg_wasm_output_len(handle) >>> 0;
    if (!ptr || !len || ptr + len > exports.memory.buffer.byteLength) throw new Error("Rust stream aggregate output returned an invalid range");
    const aggregate = new Uint8Array(exports.memory.buffer, ptr, len).slice().buffer;
    streamObservation("finish", active);
    reply(message.requestId, { sequence: active.sequence, streamPushes: active.pushes,
      ...diagnostics(), arenaBytes: 0, aggregate }, [aggregate]);
  } catch (cause) { activeAggregateStream = null; lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM aggregate stream trapped"); }
}

function advanceAggregate(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") return;
  try {
    const status = exports.xyg_wasm_aggregate_step(handle, Number(message.sequence), XYG_WASM_AGGREGATE_CHECKPOINT_POINTS);
    if (status === XYG_WASM_STATUS.PENDING) {
      const timer = setTimeout(() => advanceAggregate(message), 0) as unknown as number;
      activeAggregate = { requestId: message.requestId, sequence: Number(message.sequence), timer };
      return;
    }
    if (activeAggregate?.requestId === message.requestId) activeAggregate = null;
    queued.delete(message.requestId);
    if (status !== XYG_WASM_STATUS.OK) {
      rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status);
      return;
    }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0;
    const outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    const end = outputPtr + outputLen;
    if (!outputPtr || !outputLen || !Number.isSafeInteger(end) || end > exports.memory.buffer.byteLength) throw new Error("Rust aggregate output returned an invalid range");
    const aggregate = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    const value = { sequence: Number(message.sequence), ...diagnostics(), arenaBytes: 0, aggregate };
    reply(message.requestId, value, [aggregate]);
  } catch (cause) {
    if (activeAggregate?.requestId === message.requestId) activeAggregate = null;
    queued.delete(message.requestId);
    lifecycle = "failed";
    disposeRust();
    error(
      message.requestId,
      "XYG_WASM_TRAP",
      cause instanceof Error ? cause.message : "WASM aggregate checkpoint trapped",
    );
  }
}

function graphOutput(): ArrayBuffer {
  if (!exports || !handle) throw new Error("worker is not initialized");
  const ptr = exports.xyg_wasm_output_ptr(handle) >>> 0, len = exports.xyg_wasm_output_len(handle) >>> 0;
  if (!ptr || !len || ptr + len > exports.memory.buffer.byteLength) throw new Error("Rust graph checkpoint returned an invalid range");
  return new Uint8Array(exports.memory.buffer, ptr, len).slice().buffer;
}

function finishCompile(message: any, status: number) {
  if (!exports || !handle) return;
  activeCompile = null;
  queued.delete(message.requestId);
  if (status !== XYG_WASM_STATUS.OK) {
    rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status);
    return;
  }
  const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0;
  const outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
  if (!outputPtr || !outputLen || outputPtr + outputLen > exports.memory.buffer.byteLength) {
    throw new Error("Rust compile output returned an invalid range");
  }
  const transferred = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
  exports.xyg_wasm_arena_resize(handle, 0);
  const value = { sequence: Number(message.sequence), ...diagnostics(), arenaBytes: 0 };
  if (activeCompile?.paint ?? (message.type === "series.compile_paint" || message.type === "scene.compile_paint")) {
    reply(message.requestId, { ...value, painter: transferred }, [transferred]);
  } else {
    reply(message.requestId, { ...value, scene: transferred }, [transferred]);
  }
}

function advanceCompile(message: any) {
  const active = activeCompile;
  if (!active || active.requestId !== message.requestId || !exports || !handle) return;
  try {
    if ((exports.xyg_wasm_scene_compile_phase(handle) >>> 0) === 2 && !active.loweringAnnounced) {
      // Publish immediately before entering the synchronous canonical
      // expansion/Scene encode/painter lower call. A parent lifecycle Worker
      // can terminate this isolated instance while that O(N) work is running.
      scope.postMessage({ requestId: active.requestId, ok: true, progress: true, value: {
        sequence: active.sequence,
        recordsProcessed: exports.xyg_wasm_scene_compile_records_processed(handle) >>> 0,
        phase: 3,
      } });
      active.loweringAnnounced = true;
      active.timer = setTimeout(() => advanceCompile(message), 0) as unknown as number;
      queued.set(active.requestId, active.timer);
      return;
    }
    const status = exports.xyg_wasm_scene_compile_step(handle, active.sequence, COMPILE_CHECKPOINT_RECORDS);
    if (status === XYG_WASM_STATUS.PENDING) {
      scope.postMessage({ requestId: active.requestId, ok: true, progress: true, value: {
        sequence: active.sequence,
        recordsProcessed: exports.xyg_wasm_scene_compile_records_processed(handle) >>> 0,
        phase: exports.xyg_wasm_scene_compile_phase(handle) >>> 0,
      } });
      active.timer = setTimeout(() => advanceCompile(message), 0) as unknown as number;
      queued.set(active.requestId, active.timer);
      return;
    }
    finishCompile(message, status);
  } catch (cause) {
    activeCompile = null; queued.delete(message.requestId); lifecycle = "failed"; disposeRust();
    error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM compile checkpoint trapped");
  }
}

function terminateActiveCompile(label: string, report = true) {
  if (!activeCompile || !exports || !handle) return;
  const active = activeCompile;
  clearTimeout(active.timer);
  operationSequenceWatermark = Math.max(operationSequenceWatermark, active.sequence);
  active.leaf?.terminate();
  if (!active.leaf) exports.xyg_wasm_cancel(handle, active.sequence);
  activeCompile = null;
  if (report) error(active.requestId, "XYG_WASM_CANCELLED", `compile was superseded by ${label}`, XYG_WASM_STATUS.CANCELLED);
}

function supersedeCompile(sequence: number, label: string): boolean {
  if (!activeCompile || !exports || !handle) return true;
  if (sequence <= activeCompile.sequence) return false;
  terminateActiveCompile(label);
  return true;
}

function runIsolatedCompile(message: any) {
  queued.delete(message.requestId);
  if (!admitOperationSequence(message, true)) return;
  if (!initializedModule || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  const sequence = Number(message.sequence);
  if (!supersedeCompile(sequence, "a newer request")) {
    error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return;
  }
  if (activeGraph) {
    if (sequence <= activeGraph.sequence) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
    clearTimeout(activeGraph.timer); exports?.xyg_wasm_cancel(handle, activeGraph.sequence);
    error(activeGraph.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by compile", XYG_WASM_STATUS.CANCELLED); activeGraph = null;
  }
  if (activeAggregate) {
    if (sequence <= activeAggregate.sequence) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
    clearTimeout(activeAggregate.timer); exports?.xyg_wasm_cancel(handle, activeAggregate.sequence);
    exports?.xyg_wasm_aggregate_step(handle, activeAggregate.sequence, 1);
    error(activeAggregate.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by compile", XYG_WASM_STATUS.CANCELLED); activeAggregate = null;
  }
  const leaf = new Worker(import.meta.url, { type: "module", name: "xyg-wasm-compile" });
  const paint = message.type === "series.compile_paint" || message.type === "scene.compile_paint";
  activeCompile = { requestId: message.requestId, sequence, timer: 0, paint, leaf };
  leaf.onerror = (event) => {
    if (activeCompile?.leaf !== leaf) return;
    activeCompile = null; leaf.terminate();
    error(message.requestId, "XYG_WASM_WORKER_TRAP", event.message || "isolated compile worker trapped");
  };
  leaf.onmessageerror = () => {
    if (activeCompile?.leaf !== leaf) return;
    activeCompile = null; leaf.terminate();
    error(message.requestId, "XYG_WASM_MESSAGE_ERROR", "isolated compile worker returned an unreadable message");
  };
  leaf.onmessage = (event) => {
    const response = event.data;
    if (response?.requestId === 1) {
      if (activeCompile?.leaf !== leaf) { leaf.terminate(); return; }
      if (!response.ok) {
        activeCompile = null; leaf.terminate();
        error(message.requestId, response.error?.code ?? "XYG_WASM_INIT_FAILED", response.error?.message ?? "isolated compile initialization failed", response.error?.status ?? null);
        return;
      }
      const transfer = message.type === "series.compile_paint"
        ? [message.prefix, ...message.columns]
        : [message.scene];
      leaf.postMessage(message, transfer);
      return;
    }
    if (response?.requestId !== message.requestId || activeCompile?.leaf !== leaf) return;
    if (response.progress) { scope.postMessage(response); return; }
    operationSequenceWatermark = Math.max(operationSequenceWatermark, sequence);
    activeCompile = null; leaf.terminate();
    const value = response.value;
    const transfer: Transferable[] = value?.painter instanceof ArrayBuffer ? [value.painter]
      : value?.scene instanceof ArrayBuffer ? [value.scene] : [];
    scope.postMessage(response, transfer);
  };
  leaf.postMessage({
    type: "init", requestId: 1, source: { kind: "module", value: initializedModule },
    maxArenaBytes: operationBudgetBytes, expectedAbiVersion: XYG_WASM_ABI_VERSION,
    expectedSceneVersion: XYG_WASM_SCENE_VERSION, compileLeaf: true,
  });
}

function advanceGraph(message: any) {
  const active = activeGraph;
  if (!active || active.requestId !== message.requestId || !exports || !handle) return;
  try {
    if (performance.now() - active.started > active.maxWallMs) {
      exports.xyg_wasm_cancel(handle, active.sequence); activeGraph = null;
      error(active.requestId, "XYG_WASM_TIMEOUT", "graph layout exceeded maxWallMs", XYG_WASM_STATUS.RESOURCE_LIMIT); return;
    }
    const steps = active.first ? XYG_WASM_GRAPH_FIRST_PAINT_STEPS : active.chunkSteps; active.first = false;
    const status = exports.xyg_wasm_graph_step(handle, active.sequence, active.revision, steps);
    if (status !== XYG_WASM_STATUS.OK && status !== XYG_WASM_STATUS.PENDING) {
      activeGraph = null; rustError(active.requestId, statusCode(status), readXygWasmError(exports, handle), status); return;
    }
    const checkpoint = decodeWasmGraphCheckpoint(graphOutput());
    if (status === XYG_WASM_STATUS.OK) { activeGraph = null; reply(active.requestId, checkpoint); return; }
    scope.postMessage({ requestId: active.requestId, ok: true, progress: true, value: checkpoint });
    active.timer = setTimeout(() => advanceGraph(message), 0) as unknown as number;
  } catch (cause) {
    activeGraph = null; lifecycle = "failed"; disposeRust();
    error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM graph checkpoint trapped");
  }
}

function runGraph(message: any) {
  queued.delete(message.requestId);
  if (!admitOperationSequence(message, true)) return;
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!supersedeCompile(Number(message.sequence), "graph layout")) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "graph request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
    if (!(message.request instanceof ArrayBuffer) || message.request.byteLength > operationBudgetBytes) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "graph request is malformed or over budget"); return; }
    if (activeGraph) {
      if (Number(message.sequence) <= activeGraph.sequence) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "graph request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
      clearTimeout(activeGraph.timer); exports.xyg_wasm_cancel(handle, activeGraph.sequence);
      error(activeGraph.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded", XYG_WASM_STATUS.CANCELLED); activeGraph = null;
    }
    if (activeAggregate) {
      if (Number(message.sequence) <= activeAggregate.sequence) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "graph request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
      clearTimeout(activeAggregate.timer); exports.xyg_wasm_cancel(handle, activeAggregate.sequence);
      exports.xyg_wasm_aggregate_step(handle, activeAggregate.sequence, 1);
      error(activeAggregate.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by graph layout", XYG_WASM_STATUS.CANCELLED); activeAggregate = null;
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength).set(new Uint8Array(message.request));
    status = exports.xyg_wasm_graph_begin(handle, Number(message.sequence), Number(message.revision), 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const chunkSteps = Number(message.chunkSteps ?? XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS), maxWallMs = Number(message.maxWallMs ?? XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS);
    if (!Number.isInteger(chunkSteps) || chunkSteps <= 0 || chunkSteps > 1000 || !Number.isFinite(maxWallMs) || maxWallMs <= 0 || maxWallMs > 300000) { exports.xyg_wasm_cancel(handle, Number(message.sequence)); error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "graph scheduler bounds are invalid"); return; }
    activeGraph = { requestId: message.requestId, sequence: Number(message.sequence), revision: Number(message.revision), timer: 0, chunkSteps, started: performance.now(), maxWallMs, first: true };
    advanceGraph(message);
  } catch (cause) { activeGraph = null; lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM graph start trapped"); }
}

function runSceneOp(message: any) {
  queued.delete(message.requestId);
  if (!admitOperationSequence(message, true)) return;
  if (!exports || !handle || lifecycle !== "initialized") {
    error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized");
    return;
  }
  let superseded: typeof activeAggregate = null;
  try {
    if (activeCompile && activeCompile.requestId !== message.requestId) {
      if (Number(message.sequence) <= activeCompile.sequence) {
        error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return;
      }
      terminateActiveCompile("a newer request");
    }
    if (activeGraph && activeGraph.requestId !== message.requestId) {
      if (Number(message.sequence) <= activeGraph.sequence) { error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return; }
      clearTimeout(activeGraph.timer); exports.xyg_wasm_cancel(handle, activeGraph.sequence);
      error(activeGraph.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded", XYG_WASM_STATUS.CANCELLED); activeGraph = null;
    }
    const series = message.type === "series.compile_paint";
    if (!series && !(message.scene instanceof ArrayBuffer)) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "scene must be an ArrayBuffer");
      return;
    }
    if (series && (!(message.prefix instanceof ArrayBuffer)
        || !Array.isArray(message.columns)
        || message.columns.some((column: unknown) => !(column instanceof ArrayBuffer)))) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "typed-series buffers are malformed");
      return;
    }
    const inputLength = series ? Number(message.byteLength) : message.scene.byteLength;
    if (!Number.isSafeInteger(inputLength) || inputLength <= 0) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "scene or typed-series byte length is invalid");
      return;
    }
    if (series) {
      const total = message.columns.reduce(
        (sum: number, column: ArrayBuffer) => sum + column.byteLength,
        message.prefix.byteLength,
      );
      if (!Number.isSafeInteger(total) || total !== inputLength) {
        exports.xyg_wasm_arena_resize(handle, 0);
        error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "typed-series buffers do not match byte length");
        return;
      }
    }
    if (activeAggregate && activeAggregate.requestId !== message.requestId) {
      if (Number(message.sequence) <= activeAggregate.sequence) {
        error(
          message.requestId,
          "XYG_WASM_STALE_SEQUENCE",
          "request sequence is stale",
          XYG_WASM_STATUS.STALE_SEQUENCE,
        );
        return;
      }
      superseded = activeAggregate;
      const previous = superseded;
      clearTimeout(previous.timer);
      queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      const cancelled = exports.xyg_wasm_aggregate_step(handle, previous.sequence, 1);
      if (cancelled !== XYG_WASM_STATUS.CANCELLED) {
        throw new Error("Rust aggregate cancellation cleanup returned an invalid status");
      }
      activeAggregate = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by a newer viewport", XYG_WASM_STATUS.CANCELLED);
      superseded = null;
    }
    if (!series && !(message.scene instanceof ArrayBuffer)) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "scene must be an ArrayBuffer");
      return;
    }
    if (message.type === "aggregate.bin2d"
        && inputLength * XYG_WASM_AGGREGATE_REQUEST_COPY_FACTOR > operationBudgetBytes) {
      error(
        message.requestId,
        "XYG_WASM_RESOURCE_LIMIT",
        "aggregate request copies exceed the instance operation budget",
        XYG_WASM_STATUS.RESOURCE_LIMIT,
      );
      return;
    }
    let status = exports.xyg_wasm_arena_resize(handle, inputLength);
    if (status !== XYG_WASM_STATUS.OK) {
      rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status);
      return;
    }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    const end = ptr + inputLength;
    if (!ptr || !Number.isSafeInteger(end) || end > exports.memory.buffer.byteLength) {
      throw new Error("Rust staging arena returned an invalid range");
    }
    // Ordinary ArrayBuffers cannot alias wasm32 linear memory. The canonical
    // source remains a JS-owned transferable; only this bounded staging slice
    // is copied into WASM. The logical arena is cleared after the operation.
    const destination = new Uint8Array(exports.memory.buffer, ptr, inputLength);
    if (series) {
      destination.set(new Uint8Array(message.prefix), 0);
      let offset = message.prefix.byteLength;
      for (const column of message.columns) {
        destination.set(new Uint8Array(column), offset);
        offset += column.byteLength;
      }
    } else {
      destination.set(new Uint8Array(message.scene));
    }
    const paint = series || message.type === "scene.paint" || message.type === "scene.paint_annotations" || message.type === "scene.compile_paint";
    const compile = series || message.type === "scene.compile" || message.type === "scene.compile_paint";
    const aggregate = message.type === "aggregate.bin2d";
    if (compile) {
      status = exports.xyg_wasm_scene_compile_begin(
        handle, Number(message.sequence), 0, inputLength, paint ? 1 : 0,
      );
      if (status === XYG_WASM_STATUS.PENDING) {
        const timer = setTimeout(() => advanceCompile(message), 0) as unknown as number;
        activeCompile = { requestId: message.requestId, sequence: Number(message.sequence), timer, paint };
        queued.set(message.requestId, timer);
        return;
      }
    } else status = aggregate
      ? exports.xyg_wasm_aggregate_bin2d(
        handle, Number(message.sequence), 0, inputLength,
      )
      : (paint
        ? (message.type === "scene.paint_annotations"
          ? exports.xyg_wasm_scene_prepare_annotations(handle, Number(message.sequence), 0, inputLength)
          : exports.xyg_wasm_scene_prepare(handle, Number(message.sequence), 0, inputLength))
        : exports.xyg_wasm_scene_validate(
          handle, Number(message.sequence), 0, inputLength,
        ));
    if (aggregate && status === XYG_WASM_STATUS.PENDING) {
      const timer = setTimeout(() => advanceAggregate(message), 0) as unknown as number;
      activeAggregate = { requestId: message.requestId, sequence: Number(message.sequence), timer };
      queued.set(message.requestId, timer);
      return;
    }
    const detail = status === XYG_WASM_STATUS.OK ? "" : readXygWasmError(exports, handle);
    const value = { sequence: Number(message.sequence), ...diagnostics() };
    if (status !== XYG_WASM_STATUS.OK) {
      exports.xyg_wasm_arena_resize(handle, 0);
      rustError(message.requestId, statusCode(status), detail, status);
      return;
    }
    if (paint || message.type === "scene.compile" || aggregate) {
      const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0;
      const outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
      const outputEnd = outputPtr + outputLen;
      if (!outputPtr || !outputLen || !Number.isSafeInteger(outputEnd)
          || outputEnd > exports.memory.buffer.byteLength) {
        throw new Error("Rust browser output returned an invalid range");
      }
      const transferred = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
      exports.xyg_wasm_arena_resize(handle, 0);
      value.arenaBytes = 0;
      if (paint) {
        reply(message.requestId, { ...value, painter: transferred }, [transferred]);
      } else if (aggregate) {
        reply(message.requestId, { ...value, aggregate: transferred }, [transferred]);
      } else {
        reply(message.requestId, { ...value, scene: transferred }, [transferred]);
      }
    } else {
      exports.xyg_wasm_arena_resize(handle, 0);
      value.arenaBytes = 0;
      reply(message.requestId, value);
    }
  } catch (cause) {
    // A Rust trap invalidates the instance. Fail closed and require a fresh
    // worker; never continue with partially mutated engine state.
    lifecycle = "failed";
    disposeRust();
    if (superseded) {
      queued.delete(superseded.requestId);
      activeAggregate = null;
      error(
        superseded.requestId,
        "XYG_WASM_TRAP",
        cause instanceof Error ? cause.message : "WASM aggregate cancellation trapped",
      );
    }
    error(
      message.requestId,
      "XYG_WASM_TRAP",
      cause instanceof Error ? cause.message : "WASM operation trapped",
    );
  }
}

function tickLaneBusy(): boolean {
  return activeCompile !== null || activeAggregate !== null
    || activeAggregateStream !== null || activeGraph !== null;
}

function startNextTick() {
  if (activeTick || lifecycle !== "initialized") return;
  const message = tickQueue.shift();
  if (!message) return;
  const timer = setTimeout(() => runTicks(message), 0) as unknown as number;
  activeTick = {
    requestId: message.requestId,
    sequence: Number(message.sequence),
    timer,
    bytes: message.request.byteLength,
  };
  queued.set(message.requestId, timer);
}

function finishTick() {
  if (activeTick) retainedTickBytes = Math.max(0, retainedTickBytes - activeTick.bytes);
  activeTick = null;
  startNextTick();
}

function rejectTicks(code: string, message: string, status: number | null = null) {
  const rejected: number[] = [];
  if (activeTick) {
    clearTimeout(activeTick.timer);
    queued.delete(activeTick.requestId);
    rejected.push(activeTick.requestId);
  }
  for (const pending of tickQueue) rejected.push(pending.requestId);
  activeTick = null;
  tickQueue.length = 0;
  retainedTickBytes = 0;
  for (const requestId of rejected) error(requestId, code, message, status);
}

/** Run a bounded synchronous tick batch without entering any other operation's
 * sequence/cancellation lane. A compile/aggregate owns the shared staging
 * arena across checkpoints, so tick work waits instead of cancelling it. */
function runTicks(message: any) {
  if (!activeTick || activeTick.requestId !== message.requestId) return;
  if (!exports || !handle || lifecycle !== "initialized") {
    queued.delete(message.requestId);
    finishTick();
    error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized");
    return;
  }
  if (tickLaneBusy()) {
    const timer = setTimeout(() => runTicks(message), 0) as unknown as number;
    activeTick.timer = timer;
    queued.set(message.requestId, timer);
    return;
  }
  queued.delete(message.requestId);
  try {
    if (!(message.request instanceof ArrayBuffer)
        || message.request.byteLength < 32
        || message.request.byteLength > operationBudgetBytes) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "tick request is not a bounded ArrayBuffer", XYG_WASM_STATUS.INVALID_ARGUMENT);
      finishTick();
      return;
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) {
      rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status);
      finishTick();
      return;
    }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    const end = ptr + message.request.byteLength;
    if (!ptr || !Number.isSafeInteger(end) || end > exports.memory.buffer.byteLength) {
      throw new Error("Rust tick staging range is invalid");
    }
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength)
      .set(new Uint8Array(message.request));
    status = exports.xyg_wasm_ticks_resolve(handle, 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) {
      const detail = readXygWasmError(exports, handle);
      exports.xyg_wasm_arena_resize(handle, 0);
      rustError(message.requestId, statusCode(status), detail, status);
      finishTick();
      return;
    }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0;
    const outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    const outputEnd = outputPtr + outputLen;
    if (!outputPtr || !outputLen || !Number.isSafeInteger(outputEnd)
        || outputEnd > exports.memory.buffer.byteLength) {
      throw new Error("Rust tick output range is invalid");
    }
    const output = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    exports.xyg_wasm_arena_resize(handle, 0);
    reply(message.requestId, output, [output]);
    finishTick();
  } catch (cause) {
    lifecycle = "failed";
    rejectTicks(
      "XYG_WASM_TRAP",
      cause instanceof Error ? cause.message : "WASM tick operation trapped",
    );
    disposeRust();
  }
}

function queueTicks(message: any) {
  const sequence = Number(message.sequence);
  if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffff_ffff) {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "tick sequence must be a nonzero u32", XYG_WASM_STATUS.INVALID_ARGUMENT);
    return;
  }
  if (lifecycle !== "initialized") {
    error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized");
    return;
  }
  if (!(message.request instanceof ArrayBuffer) || message.request.byteLength < 32) {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "tick request is not a bounded ArrayBuffer", XYG_WASM_STATUS.INVALID_ARGUMENT);
    return;
  }
  if (message.request.byteLength > operationBudgetBytes) {
    error(message.requestId, "XYG_WASM_RESOURCE_LIMIT", "tick request exceeds the worker byte budget", XYG_WASM_STATUS.RESOURCE_LIMIT);
    return;
  }
  if (new DataView(message.request).getUint32(12, true) !== sequence) {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "tick request header sequence does not match its envelope", XYG_WASM_STATUS.INVALID_ARGUMENT);
    return;
  }
  if (sequence <= tickSequenceWatermark) {
    error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "tick request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE);
    return;
  }
  if (tickQueue.length + (activeTick ? 1 : 0) >= MAX_RETAINED_TICK_REQUESTS
      || retainedTickBytes + message.request.byteLength > operationBudgetBytes) {
    error(message.requestId, "XYG_WASM_RESOURCE_LIMIT", "pending tick requests exceed the worker queue bound", XYG_WASM_STATUS.RESOURCE_LIMIT);
    return;
  }
  tickSequenceWatermark = sequence;
  retainedTickBytes += message.request.byteLength;
  tickQueue.push(message);
  startNextTick();
}

function runTemporalCommand(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") {
    error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized");
    return;
  }
  try {
    if (activeCompile) {
      terminateActiveCompile("temporal work");
    }
    // One WASM instance owns one staging/output arena. A temporal command is
    // newer work on that instance, so retire any progressive job before it
    // can publish another checkpoint into the shared output buffer.
    if (activeGraph) {
      clearTimeout(activeGraph.timer);
      exports.xyg_wasm_cancel(handle, activeGraph.sequence);
      error(activeGraph.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by temporal work", XYG_WASM_STATUS.CANCELLED);
      activeGraph = null;
    }
    if (activeAggregate) {
      clearTimeout(activeAggregate.timer);
      exports.xyg_wasm_cancel(handle, activeAggregate.sequence);
      exports.xyg_wasm_aggregate_step(handle, activeAggregate.sequence, 1);
      error(activeAggregate.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by temporal work", XYG_WASM_STATUS.CANCELLED);
      activeAggregate = null;
    }
    if (!(message.command instanceof ArrayBuffer) || message.command.byteLength < 16
        || message.command.byteLength > operationBudgetBytes) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "temporal command is malformed");
      return;
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.command.byteLength);
    if (status !== XYG_WASM_STATUS.OK) {
      rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status);
      return;
    }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    const end = ptr + message.command.byteLength;
    if (!ptr || end > exports.memory.buffer.byteLength) throw new Error("invalid temporal staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.command.byteLength)
      .set(new Uint8Array(message.command));
    status = exports.xyg_wasm_temporal_execute(handle, 0, message.command.byteLength);
    if (status !== XYG_WASM_STATUS.OK) {
      const detail = readXygWasmError(exports, handle);
      exports.xyg_wasm_arena_resize(handle, 0);
      rustError(message.requestId, statusCode(status), detail, status);
      return;
    }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0;
    const outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    const outputEnd = outputPtr + outputLen;
    if (!outputPtr || outputLen < 176 || outputLen > operationBudgetBytes
        || outputEnd > exports.memory.buffer.byteLength) {
      throw new Error("Rust temporal response returned an invalid range");
    }
    const selectionCount = new DataView(exports.memory.buffer, outputPtr, 16).getUint32(12, true);
    if (outputLen !== 176 + selectionCount * 8) {
      throw new Error("Rust temporal response returned an invalid selection range");
    }
    const response = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    exports.xyg_wasm_arena_resize(handle, 0);
    reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed";
    disposeRust();
    error(
      message.requestId,
      "XYG_WASM_TRAP",
      cause instanceof Error ? cause.message : "WASM temporal command trapped",
    );
  }
}

function runTemporalGraphCommand(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (activeCompile) terminateActiveCompile("a temporal graph frame");
    if (activeGraph) {
      clearTimeout(activeGraph.timer); exports.xyg_wasm_cancel(handle, activeGraph.sequence);
      error(activeGraph.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by a temporal graph frame", XYG_WASM_STATUS.CANCELLED); activeGraph = null;
    }
    if (!(message.command instanceof ArrayBuffer) || message.command.byteLength < 32 || message.command.byteLength > operationBudgetBytes) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "temporal graph command is malformed"); return;
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.command.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0; const end = ptr + message.command.byteLength;
    if (!ptr || end > exports.memory.buffer.byteLength) throw new Error("invalid temporal graph staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.command.byteLength).set(new Uint8Array(message.command));
    status = exports.xyg_wasm_temporal_graph_execute(handle, 0, message.command.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { const detail = readXygWasmError(exports, handle); exports.xyg_wasm_arena_resize(handle, 0); rustError(message.requestId, statusCode(status), detail, status); return; }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0; const outputLen = exports.xyg_wasm_output_len(handle) >>> 0; const outputEnd = outputPtr + outputLen;
    if (outputLen !== 0 && (!outputPtr || outputLen < 64 || outputLen > operationBudgetBytes || outputEnd > exports.memory.buffer.byteLength)) throw new Error("Rust temporal graph response returned an invalid range");
    const response = outputLen === 0 ? new ArrayBuffer(0) : new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    exports.xyg_wasm_arena_resize(handle, 0); reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM temporal graph command trapped");
  }
}

function runDashboardPlan(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!(message.request instanceof ArrayBuffer) || message.request.byteLength < 32 || message.request.byteLength > operationBudgetBytes) {
      error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "dashboard plan request is malformed"); return;
    }
    const sequence = Number(message.sequence);
    if (activeCompile) terminateActiveCompile("a dashboard plan");
    if (activeGraph) {
      const previous = activeGraph;
      clearTimeout(previous.timer);
      queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      activeGraph = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by a dashboard plan", XYG_WASM_STATUS.CANCELLED);
    }
    if (activeAggregate) {
      const previous = activeAggregate;
      clearTimeout(previous.timer);
      queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      const cancelled = exports.xyg_wasm_aggregate_step(handle, previous.sequence, 1);
      if (cancelled !== XYG_WASM_STATUS.CANCELLED) throw new Error("Rust aggregate cancellation cleanup returned an invalid status");
      activeAggregate = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by a dashboard plan", XYG_WASM_STATUS.CANCELLED);
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    if (!ptr || ptr + message.request.byteLength > exports.memory.buffer.byteLength) throw new Error("invalid dashboard staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength).set(new Uint8Array(message.request));
    status = exports.xyg_wasm_dashboard_plan(handle, sequence, 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0, outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    if (!outputPtr || outputLen < 24 || outputPtr + outputLen > exports.memory.buffer.byteLength) throw new Error("Rust dashboard planner returned an invalid range");
    const response = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM dashboard planner trapped");
  }
}

function runCompoundTransition(message: any) {
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!(message.request instanceof ArrayBuffer) || message.request.byteLength < 58 || message.request.byteLength > operationBudgetBytes) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "compound transition request is malformed"); return; }
    if (activeCompile) terminateActiveCompile("a compound transition");
    if (activeGraph) {
      const previous = activeGraph; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence); activeGraph = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by a compound transition", XYG_WASM_STATUS.CANCELLED);
    }
    if (activeAggregate) {
      const previous = activeAggregate; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      const cancelled = exports.xyg_wasm_aggregate_step(handle, previous.sequence, 1);
      if (cancelled !== XYG_WASM_STATUS.CANCELLED) throw new Error("Rust aggregate cancellation cleanup returned an invalid status");
      activeAggregate = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by a compound transition", XYG_WASM_STATUS.CANCELLED);
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    if (!ptr || ptr + message.request.byteLength > exports.memory.buffer.byteLength) throw new Error("invalid compound transition staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength).set(new Uint8Array(message.request));
    status = exports.xyg_wasm_compound_transition(handle, 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0, outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    if (!outputPtr || outputLen < 17 || outputPtr + outputLen > exports.memory.buffer.byteLength) throw new Error("Rust compound transition returned an invalid range");
    const response = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM compound transition trapped");
  }
}

function runGraphforgeCompose(message: any) {
  queued.delete(message.requestId);
  if (!admitOperationSequence(message, true)) return;
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!(message.request instanceof ArrayBuffer) || message.request.byteLength < 32 || message.request.byteLength > operationBudgetBytes) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "graphforge request is malformed"); return; }
    if (activeCompile) terminateActiveCompile("a graphforge composition");
    if (activeGraph) {
      const previous = activeGraph; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence); activeGraph = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by a graphforge composition", XYG_WASM_STATUS.CANCELLED);
    }
    if (activeAggregate) {
      const previous = activeAggregate; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      const cancelled = exports.xyg_wasm_aggregate_step(handle, previous.sequence, 1);
      if (cancelled !== XYG_WASM_STATUS.CANCELLED) throw new Error("Rust aggregate cancellation cleanup returned an invalid status");
      activeAggregate = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by a graphforge composition", XYG_WASM_STATUS.CANCELLED);
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    if (!ptr || ptr + message.request.byteLength > exports.memory.buffer.byteLength) throw new Error("invalid graphforge staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength).set(new Uint8Array(message.request));
    status = exports.xyg_wasm_graphforge_compose(handle, 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0, outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    if (!outputPtr || outputLen < 32 || outputPtr + outputLen > exports.memory.buffer.byteLength) throw new Error("Rust graphforge composition returned an invalid range");
    const response = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM graphforge composition trapped");
  }
}

// Admission at receipt and again before deferred execution protects every shared
// lane: an older queued timer must not cancel/stage over a newer stream/job.
function admitOperationSequence(message: any, deferred = false): boolean {
  const sequence = Number(message.sequence);
  if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) {
    error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "sequence must be a nonzero u32", XYG_WASM_STATUS.INVALID_ARGUMENT); return false;
  }
  if (deferred ? sequence !== operationSequenceWatermark : sequence <= operationSequenceWatermark) {
    error(message.requestId, "XYG_WASM_STALE_SEQUENCE", "request sequence is stale", XYG_WASM_STATUS.STALE_SEQUENCE); return false;
  }
  if (!deferred) operationSequenceWatermark = sequence;
  return true;
}

function runGeoIngest(message: any, owned = false) {
  queued.delete(message.requestId);
  if (!owned && !admitOperationSequence(message, true)) return;
  if (!exports || !handle || lifecycle !== "initialized") { error(message.requestId, "XYG_WASM_NOT_READY", "worker is not initialized"); return; }
  try {
    if (!(message.request instanceof ArrayBuffer) || message.request.byteLength < (message.type.startsWith("geo.scale.") || message.type.startsWith("geo.snapshot.") ? 256 : message.type.startsWith("geo.tile.") ? 128 : message.type === "geo.scene" ? 192 : (message.type === "geo.viewport" || message.type === "geo.catalog") ? 128 : 64) || message.request.byteLength > operationBudgetBytes) { error(message.requestId, "XYG_WASM_INVALID_ARGUMENT", "geographic descriptor is malformed"); return; }
    if (activeCompile) terminateActiveCompile("a geographic ingestion");
    if (activeGraph) {
      const previous = activeGraph; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence); activeGraph = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "graph layout was superseded by a geographic ingestion", XYG_WASM_STATUS.CANCELLED);
    }
    if (activeAggregate) {
      const previous = activeAggregate; clearTimeout(previous.timer); queued.delete(previous.requestId);
      exports.xyg_wasm_cancel(handle, previous.sequence);
      const cancelled = exports.xyg_wasm_aggregate_step(handle, previous.sequence, 1);
      if (cancelled !== XYG_WASM_STATUS.CANCELLED) throw new Error("Rust aggregate cancellation cleanup returned an invalid status");
      activeAggregate = null;
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate was superseded by a geographic ingestion", XYG_WASM_STATUS.CANCELLED);
    }
    if (activeAggregateStream) {
      const previous = activeAggregateStream;
      exports.xyg_wasm_cancel(handle, previous.sequence);
      activeAggregateStream = null;
      streamObservation("cancelled", previous);
      error(previous.requestId, "XYG_WASM_CANCELLED", "aggregate stream was superseded by geographic ingestion", XYG_WASM_STATUS.CANCELLED);
    }
    let status = exports.xyg_wasm_arena_resize(handle, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { rustError(message.requestId, statusCode(status), readXygWasmError(exports, handle), status); return; }
    const ptr = exports.xyg_wasm_arena_ptr(handle) >>> 0;
    if (!ptr || ptr + message.request.byteLength > exports.memory.buffer.byteLength) throw new Error("invalid geographic staging range");
    new Uint8Array(exports.memory.buffer, ptr, message.request.byteLength).set(new Uint8Array(message.request));
    status = message.type === "geo.scale.execute"
      ? exports.xyg_wasm_geo_scale_execute(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.scale.read"
      ? exports.xyg_wasm_geo_scale_read(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.tile.execute"
      ? exports.xyg_wasm_geo_tile_execute(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.tile.read"
      ? exports.xyg_wasm_geo_tile_read(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.snapshot.execute"
      ? exports.xyg_wasm_geo_snapshot_execute(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.snapshot.read"
      ? exports.xyg_wasm_geo_snapshot_read(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.catalog"
      ? exports.xyg_wasm_geo_catalog_compile(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.viewport"
      ? exports.xyg_wasm_geo_viewport_execute(handle, message.sequence, 0, message.request.byteLength)
      : message.type === "geo.scene"
      ? exports.xyg_wasm_geo_scene_compile(handle, message.sequence, 0, message.request.byteLength)
      : exports.xyg_wasm_geo_column_ingest(handle, message.sequence, 0, message.request.byteLength);
    if (status !== XYG_WASM_STATUS.OK) { const detail = readXygWasmError(exports, handle); rustError(message.requestId, detail.startsWith("XYG_GEO_") ? detail : statusCode(status), detail, status); return; }
    const outputPtr = exports.xyg_wasm_output_ptr(handle) >>> 0, outputLen = exports.xyg_wasm_output_len(handle) >>> 0;
    if (!outputPtr || outputLen < 64 || outputLen > operationBudgetBytes || outputPtr + outputLen > exports.memory.buffer.byteLength) throw new Error("Rust geographic ingestion returned an invalid range");
    const response = new Uint8Array(exports.memory.buffer, outputPtr, outputLen).slice().buffer;
    reply(message.requestId, response, [response]);
  } catch (cause) {
    lifecycle = "failed"; disposeRust(); error(message.requestId, "XYG_WASM_TRAP", cause instanceof Error ? cause.message : "WASM geographic ingestion trapped");
  }
}

scope.onmessage = (event: MessageEvent<any>) => {
  const message = event.data;
  if(retainedGeoMode&&!['dispose','cancel','evidence.lifecycle','geo.transport.acquire','geo.frame.prepare','geo.tile.frame.prepare','geo.scale.execute','geo.scale.read','geo.tile.execute','geo.tile.read','geo.snapshot.execute','geo.snapshot.read'].includes(message?.type)){
    error(message?.requestId,'XYG_WASM_INVALID_ARGUMENT','This retained geographic Worker requires a separate ordinary chart Worker for other product lanes',XYG_WASM_STATUS.INVALID_ARGUMENT);return;
  }
  if (message?.type === "init") {
    void initialize(message);
    return;
  }
  if(message?.type === 'geo.transport.acquire'){
    if(!exports||!handle||lifecycle!=='initialized'){error(message.requestId,'XYG_WASM_NOT_READY','Worker not initialized');return;}
    try{
      const status=exports.xyg_wasm_geo_transport_acquire(handle);
      if(status!==XYG_WASM_STATUS.OK){rustError(message.requestId,statusCode(status),readXygWasmError(exports,handle),status);return;}
      retainedGeoMode=true;operationBudgetBytes=Math.min(operationBudgetBytes,128*1024*1024);reply(message.requestId,diagnostics());
    }catch(cause){error(message.requestId,'XYG_WASM_TRAP',cause instanceof Error?cause.message:'geographic transport admission trapped');}
    return;
  }
  if(message?.type==='geo.frame.prepare'||message?.type==='geo.tile.frame.prepare'){
    if(!admitOperationSequence(message))return;
    if(!exports||!handle||lifecycle!=='initialized'){error(message.requestId,'XYG_WASM_NOT_READY','Worker not initialized');return;}
    try{
      const status=message.type==='geo.tile.frame.prepare'?exports.xyg_wasm_geo_tile_frame_prepare(handle,message.sequence,message.frameHandle,message.publicationSequence):exports.xyg_wasm_geo_frame_prepare(handle,message.sequence,message.frameHandle,message.publicationSequence);
      if(status!==XYG_WASM_STATUS.OK){rustError(message.requestId,statusCode(status),readXygWasmError(exports,handle),status);return;}
      const ptr=exports.xyg_wasm_output_ptr(handle)>>>0,length=exports.xyg_wasm_output_len(handle)>>>0;
      if(!ptr||length<64||length>operationBudgetBytes||ptr+length>exports.memory.buffer.byteLength)throw new Error('Invalid retained painter range');
      const painter=new Uint8Array(exports.memory.buffer,ptr,length).slice().buffer;
      reply(message.requestId,{...diagnostics(),sequence:message.sequence,painter},[painter]);
    }catch(cause){lifecycle='failed';disposeRust();error(message.requestId,'XYG_WASM_TRAP',cause instanceof Error?cause.message:'retained painter trapped');}
    return;
  }
  if (message?.type === "evidence.lifecycle") { evidenceLifecycle(message); return; }
  if (message?.type === "aggregate.stream_push") { pushAggregateStream(message); return; }
  if (message?.type === "aggregate.stream_finish") { finishAggregateStream(message); return; }
  if (message?.type === "ticks.resolve") { queueTicks(message); return; }
  if (message?.type === "ticks.cancel") {
    if (activeTick?.requestId === message.requestId
        && activeTick.sequence === Number(message.sequence)) {
      clearTimeout(activeTick.timer);
      queued.delete(activeTick.requestId);
      finishTick();
    } else {
      const index = tickQueue.findIndex((queuedTick) => queuedTick.requestId === message.requestId
        && Number(queuedTick.sequence) === Number(message.sequence));
      if (index >= 0) {
        const [cancelled] = tickQueue.splice(index, 1);
        retainedTickBytes = Math.max(0, retainedTickBytes - cancelled.request.byteLength);
      }
    }
    return;
  }
  const sequenced = message?.type === "aggregate.stream_begin" || message?.type === "scene.validate" || message?.type === "scene.paint" || message?.type === "scene.paint_annotations"
    || message?.type === "scene.compile" || message?.type === "scene.compile_paint"
    || message?.type === "series.compile_paint" || message?.type === "aggregate.bin2d"
    || message?.type === "graph.cose" || message?.type === "dashboard.plan"
    || message?.type === "compound.transition"
    || message?.type === "graphforge.compose" || message?.type === "geo.ingest" || message?.type === "geo.scene" || message?.type === "geo.viewport" || message?.type === "geo.catalog" || message?.type === "geo.scale.execute" || message?.type === "geo.scale.read" || ["geo.tile.execute","geo.tile.read","geo.snapshot.execute","geo.snapshot.read"].includes(message?.type);
  if (sequenced && !admitOperationSequence(message)) return;
  // Ownership mutations and immutable reads cannot be discarded by a later
  // request. Execute at receipt; the main-thread ownership FIFO sequences them.
  // Session cancellation remains the explicit Rust command9.
  if(["geo.scale.execute","geo.scale.read","geo.tile.execute","geo.tile.read","geo.snapshot.execute","geo.snapshot.read"].includes(message?.type)) {runGeoIngest(message,true);return;}
  if (message?.type === "aggregate.stream_begin") { beginAggregateStream(message); return; }
  if (
    message?.type === "scene.validate"
    || message?.type === "scene.paint"
    || message?.type === "scene.paint_annotations"
    || message?.type === "scene.compile"
    || message?.type === "scene.compile_paint"
    || message?.type === "series.compile_paint"
    || message?.type === "aggregate.bin2d"
  ) {
    const compile = message?.type === "scene.compile" || message?.type === "scene.compile_paint" || message?.type === "series.compile_paint";
    if (compile && !compileLeaf) {
      const timer = setTimeout(() => runIsolatedCompile(message), 0);
      queued.set(message.requestId, timer as unknown as number);
      return;
    }
    // Deferring one task turn gives a cancellation already queued by the main
    // thread a chance to suppress work before a synchronous WASM call starts.
    const timer = setTimeout(() => runSceneOp(message), 0);
    queued.set(message.requestId, timer as unknown as number);
    return;
  }
  if (message?.type === "temporal.command") {
    runTemporalCommand(message);
    return;
  }
  if (message?.type === "temporal_graph.command") { runTemporalGraphCommand(message); return; }
  if (message?.type === "dashboard.plan") { runDashboardPlan(message); return; }
  if (message?.type === "compound.transition") { runCompoundTransition(message); return; }
  if (message?.type === "geo.ingest" || message?.type === "geo.scene" || message?.type === "geo.viewport" || message?.type === "geo.catalog" || message?.type === "geo.scale.execute" || message?.type === "geo.scale.read") {
    const timer = setTimeout(() => runGeoIngest(message), 0);
    queued.set(message.requestId, timer as unknown as number);
    return;
  }
  if (message?.type === "graphforge.compose") {
    // Composition and layout run synchronously; one task turn lets a queued
    // cancellation clear the timer before any WASM work starts.
    const timer = setTimeout(() => runGraphforgeCompose(message), 0);
    queued.set(message.requestId, timer as unknown as number);
    return;
  }
  if (message?.type === "graph.cose") { const timer = setTimeout(() => runGraph(message), 0); queued.set(message.requestId, timer as unknown as number); return; }
  if (message?.type === "cancel") {
    const timer = queued.get(message.requestId);
    if (timer !== undefined) {
      clearTimeout(timer);
      queued.delete(message.requestId);
    }
    try {
      if (activeCompile?.requestId === message.requestId && activeCompile.leaf) {
        terminateActiveCompile("cancellation", false);
      } else if (exports && handle) exports.xyg_wasm_cancel(handle, Number(message.sequence));
      if (activeAggregate?.requestId === message.requestId && exports && handle) {
        clearTimeout(activeAggregate.timer);
        exports.xyg_wasm_aggregate_step(handle, Number(message.sequence), 1);
        activeAggregate = null;
      }
      if (activeAggregateStream?.requestId === message.requestId && exports && handle) {
        exports.xyg_wasm_cancel(handle, Number(message.sequence));
        streamObservation("cancelled", activeAggregateStream);
        activeAggregateStream = null;
      }
      if (activeGraph?.requestId === message.requestId) { clearTimeout(activeGraph.timer); activeGraph = null; }
      if (activeCompile?.requestId === message.requestId) terminateActiveCompile("cancellation", false);
    } catch (cause) {
      activeAggregate = null;
      lifecycle = "failed";
      disposeRust();
      error(
        message.requestId,
        "XYG_WASM_TRAP",
        cause instanceof Error ? cause.message : "WASM cancellation trapped",
      );
    }
    return;
  }
  if (message?.type === "dispose") {
    lifecycle = "disposed";
    rejectTicks("XYG_WASM_DISPOSED", "worker was disposed", XYG_WASM_STATUS.DISPOSED);
    for (const timer of queued.values()) clearTimeout(timer);
    if (activeGraph) clearTimeout(activeGraph.timer);
    if (activeCompile) terminateActiveCompile("disposal", false);
    activeGraph = null;
    activeAggregateStream = null;
    activeCompile = null;
    queued.clear();
    disposeRust();
    reply(message.requestId, undefined);
    scope.close();
    return;
  }
  if (Number.isInteger(message?.requestId)) {
    error(message.requestId, "XYG_WASM_UNSUPPORTED", "unsupported worker operation");
  }
};
