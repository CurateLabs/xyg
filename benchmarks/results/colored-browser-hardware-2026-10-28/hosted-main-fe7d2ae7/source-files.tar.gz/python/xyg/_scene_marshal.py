"""Figure observation marshaling for scene bulk packers (ABI 321-323)."""

from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from typing import Any

import numpy as np

from xyg import _native
from xyg.config import default_mark_color


def xych_from_xycf(xycf: bytes) -> bytes:
    """Extract the XYCH sidecar from packed XYCF v1 (ABI 319 wire layout)."""
    if len(xycf) < 288 or xycf[:4] != b"XYCF":
        raise ValueError("invalid scene chrome facts")
    title_len = struct.unpack_from("<I", xycf, 156)[0]
    x_label_len = struct.unpack_from("<I", xycf, 160)[0]
    y_label_len = struct.unpack_from("<I", xycf, 164)[0]
    x_format_len = struct.unpack_from("<I", xycf, 168)[0]
    y_format_len = struct.unpack_from("<I", xycf, 172)[0]
    x_major_len = struct.unpack_from("<I", xycf, 176)[0]
    x_minor_len = struct.unpack_from("<I", xycf, 180)[0]
    y_major_len = struct.unpack_from("<I", xycf, 184)[0]
    y_minor_len = struct.unpack_from("<I", xycf, 188)[0]
    x_label_count = struct.unpack_from("<I", xycf, 192)[0]
    y_label_count = struct.unpack_from("<I", xycf, 196)[0]
    chrome_len = struct.unpack_from("<I", xycf, 200)[0]
    at = 288
    at += title_len + x_label_len + y_label_len + x_format_len + y_format_len
    at += (x_major_len + x_minor_len + y_major_len + y_minor_len) * 8
    for _ in range(x_label_count):
        label_len = struct.unpack_from("<I", xycf, at)[0]
        at += 4 + label_len
    for _ in range(y_label_count):
        label_len = struct.unpack_from("<I", xycf, at)[0]
        at += 4 + label_len
    chrome = xycf[at : at + chrome_len]
    if len(chrome) != chrome_len or chrome[:4] != b"XYCH":
        raise ValueError("invalid scene chrome facts")
    return chrome


def scene_chrome_style(figure: Any) -> bytes:
    """Marshal chrome observations and resolve the 200-byte Scene style via Rust."""
    xycf = pack_chrome_facts(
        figure,
        width=int(figure.width),
        height=int(figure.height),
        margins=None,
        colorbar_ok=True,
    )
    return _native.scene_resolve_chrome_style(xych_from_xycf(xycf))


def pack_chrome_facts(
    figure: Any,
    *,
    width: int,
    height: int,
    margins: tuple[float, float, float, float] | None,
    colorbar_ok: bool,
    y2_chrome: Y2Chrome | None = None,
) -> bytes:
    """Marshal figure chrome observations and bulk-pack XYCF via Rust (ABI 321)."""
    from xyg._scene_observations import _SCENE_AXIS_STYLE_KEYS, UnsupportedSceneV3, _scene_side_mask

    xa = figure.axis_options["x"]
    ya = figure.axis_options["y"]
    kind_codes = {"linear": 0, "log": 1, "symlog": 2}
    tick_kind_code = {"linear": 0, "time": 1, "category": 2}
    x_lo, x_hi = (float(v) for v in figure._range("x"))
    y_lo, y_hi = (float(v) for v in figure._range("y"))
    pad = getattr(figure, "padding", None)
    has_padding = isinstance(pad, (list, tuple)) and len(pad) == 4
    figure_style = getattr(figure, "style", None) or {}
    legend_options = dict(getattr(figure, "legend_options", None) or {})
    legend_style = dict(legend_options.get("style") or {})
    allowed_legend = {"loc", "title", "ncols", "style", "highlight", "toggle"}
    unsupported_legend = set(legend_options) - allowed_legend
    if unsupported_legend or int(legend_options.get("ncols") or 1) != 1:
        raise UnsupportedSceneV3(
            "Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content"
        )
    if any(
        key in legend_options and legend_options[key] is not False
        for key in ("toggle", "highlight")
    ):
        raise UnsupportedSceneV3(
            "Scene v12 primary legends are static; toggle and highlight must be false"
        )
    authored_loc = legend_options.get("loc")
    if authored_loc is not None and not str(authored_loc):
        raise UnsupportedSceneV3(
            f"Scene v12 does not support legend location {str(authored_loc)!r}"
        )
    colorbar = getattr(figure, "colorbar_options", None) if colorbar_ok else None
    colorbar_payload = None
    if colorbar:
        from xyg._scene_annotations import colorbar_input

        packed = colorbar_input(figure)
        flags = packed[8]
        stop_count = int.from_bytes(packed[12:16], "little")
        tick_count = int.from_bytes(packed[16:20], "little")
        title_len = int.from_bytes(packed[20:24], "little")
        domain_lo, domain_hi = struct.unpack_from("<2d", packed, 24)
        stops_at = 56
        ticks_at = stops_at + stop_count * 12
        title_at = ticks_at + tick_count * 8
        stops = [
            (
                struct.unpack_from("<d", packed, stops_at + index * 12)[0],
                packed[stops_at + index * 12 + 8 : stops_at + index * 12 + 12],
            )
            for index in range(stop_count)
        ]
        colorbar_payload = {
            "domain_lo": domain_lo,
            "domain_hi": domain_hi,
            "stops": stops,
            "side_bottom": bool(flags & 1),
            "invalid_side": False,
            "minor_ticks": bool(flags & 4),
            "title": _optional_str(packed[title_at : title_at + title_len].decode("utf-8")),
            "text_rgba": bytes(packed[40:44]),
            "ticks": list(struct.unpack_from(f"<{tick_count}d", packed, ticks_at))
            if tick_count
            else None,
        }

    def marshal_axis_style(style: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key in (
            "grid_color",
            "grid_width",
            "grid_opacity",
            "axis_color",
            "axis_width",
            "tick_color",
            "tick_width",
            "tick_length",
            "tick_direction",
            "tick_label_color",
            "label_color",
        ):
            if key not in style:
                continue
            raw = style[key]
            if key in {"grid_width", "axis_width", "tick_width", "tick_length"}:
                out[f"{key}_present"] = True
                out[key] = float(raw)
            elif key == "grid_opacity":
                out["grid_opacity_present"] = True
                out["grid_opacity"] = float(raw)
            else:
                out[key] = str(raw)
        return out

    def marshal_chrome_axis(axis_id: str, options: dict[str, Any]) -> dict[str, Any]:
        style = dict(options.get("style") or {})
        minor = dict(options.get("minor_style") or {})
        for label, authored in (("style", style), ("minor_style", minor)):
            unsupported = set(authored) - _SCENE_AXIS_STYLE_KEYS
            if unsupported:
                raise UnsupportedSceneV3(
                    f"Scene v12 does not yet encode {axis_id} axis {label} keys {sorted(unsupported)!r}"
                )
        # An unauthored y2 side is passed through as absent (code 0 is ignored
        # without `side_authored`): Rust defaults the secondary axis to the right.
        side = (
            None
            if axis_id == "y2" and options.get("side") is None
            else options.get("side", "bottom" if axis_id == "x" else "left")
        )
        allowed = ("bottom", "top") if axis_id == "x" else ("left", "right")
        if side is not None and side not in allowed:
            raise UnsupportedSceneV3(
                f"Scene v12 {axis_id} axis side must be one of {list(allowed)!r}"
            )
        side_code = 0 if side in {None, "bottom", "left"} else 1
        return {
            "side_code": side_code,
            "tick_sides_mask": _scene_side_mask(
                options.get("tick_sides"), "tick_sides", axis_id, allowed, side_code
            ),
            "label_sides_mask": _scene_side_mask(
                options.get("tick_label_sides"), "tick_label_sides", axis_id, allowed, side_code
            ),
            "style": marshal_axis_style(style),
            "minor_style": marshal_axis_style(minor),
        }

    facts: dict[str, Any] = dict(
        width=float(width),
        height=float(height),
        show_legend=bool(getattr(figure, "show_legend", True)),
        colorbar_ok=bool(colorbar_ok and colorbar_payload is not None),
        polar=str(getattr(figure, "coords", "cartesian") or "cartesian") == "polar",
        has_margins=margins is not None,
        margins=tuple(float(v) for v in margins) if margins is not None else (0.0, 0.0, 0.0, 0.0),
        has_padding=has_padding,
        padding=tuple(float(v) for v in pad) if has_padding else (0.0, 0.0, 0.0, 0.0),
        title=str(figure.title or ""),
        x_label=str(figure.x_label or xa.get("label") or ""),
        y_label=str(figure.y_label or ya.get("label") or ""),
        x_format=_optional_str(xa.get("format")),
        y_format=_optional_str(ya.get("format")),
        x_scale_kind=kind_codes[figure._axis_scale("x")],
        y_scale_kind=kind_codes[figure._axis_scale("y")],
        x_lo=x_lo,
        x_hi=x_hi,
        x_constant=float(xa.get("constant") or 1.0),
        y_lo=y_lo,
        y_hi=y_hi,
        y_constant=float(ya.get("constant") or 1.0),
        x_nonpositive_mask=1 if xa.get("nonpositive", "clip") == "mask" else 0,
        y_nonpositive_mask=1 if ya.get("nonpositive", "clip") == "mask" else 0,
        x_tick_kind=tick_kind_code.get(figure._axis_kind("x"), 0),
        y_tick_kind=tick_kind_code.get(figure._axis_kind("y"), 0),
        x_axis=marshal_chrome_axis("x", xa),
        y_axis=marshal_chrome_axis("y", ya),
        x_major=None if xa.get("tick_values") is None else [float(v) for v in xa["tick_values"]],
        y_major=None if ya.get("tick_values") is None else [float(v) for v in ya["tick_values"]],
        x_minor=[float(v) for v in (xa.get("minor_tick_values") or ())],
        y_minor=[float(v) for v in (ya.get("minor_tick_values") or ())],
        x_tick_labels=None
        if xa.get("tick_labels") is None
        else [str(v) for v in xa["tick_labels"]],
        y_tick_labels=None
        if ya.get("tick_labels") is None
        else [str(v) for v in ya["tick_labels"]],
        x_collision={
            "strategy": _optional_str(xa.get("tick_label_strategy")),
            "collision": _optional_str(xa.get("collision")),
            "anchor": _optional_str(xa.get("tick_label_anchor")),
            "min_gap": None
            if xa.get("tick_label_min_gap") is None
            else float(xa["tick_label_min_gap"]),
            "angle": None if xa.get("tick_label_angle") is None else float(xa["tick_label_angle"]),
            "tick_kind_category": figure._axis_kind("x") == "category",
        },
        y_collision={
            "strategy": _optional_str(ya.get("tick_label_strategy")),
            "collision": _optional_str(ya.get("collision")),
            "anchor": _optional_str(ya.get("tick_label_anchor")),
            "min_gap": None
            if ya.get("tick_label_min_gap") is None
            else float(ya["tick_label_min_gap"]),
            "angle": None if ya.get("tick_label_angle") is None else float(ya["tick_label_angle"]),
            "tick_kind_category": figure._axis_kind("y") == "category",
        },
        chart_background=_optional_str(figure_style.get("background")),
        plot_background=_optional_str(figure_style.get("--chart-bg")),
        legend={
            "unsupported_keys": bool(set(legend_options) - allowed_legend),
            "toggle": "toggle" in legend_options and legend_options["toggle"] is not False,
            "highlight": "highlight" in legend_options and legend_options["highlight"] is not False,
            "loc": None if legend_options.get("loc") is None else str(legend_options.get("loc")),
            "title": _optional_str(
                str(legend_options.get("title")).lower()
                if isinstance(legend_options.get("title"), bool)
                else legend_options.get("title")
            ),
            "ncols": int(legend_options.get("ncols") or 1),
            "unsupported_style": bool(
                set(legend_style) - {"background", "color", "font_size", "title_font_size"}
            ),
            "font_size": legend_style.get("font_size"),
            "title_font_size": legend_style.get("title_font_size"),
            "color": _optional_str(legend_style.get("color")),
            "background": _optional_str(legend_style.get("background")),
        },
        colorbar=colorbar_payload,
    )
    if "y2" in figure.axis_options:
        facts["y2"] = _marshal_y2(
            figure, marshal_chrome_axis("y2", figure.axis_options["y2"]), y2_chrome
        )
    return _native.scene_chrome_pack(**facts)


@dataclass(frozen=True)
class Y2Chrome:
    """Rust-resolved XYCO facts for the secondary y axis (the ``XYY2`` metrics block)."""

    tick_size: float
    title_size: float
    padding: float
    # Two-bit italic/bold flags: bits 0..1 tick labels, bits 2..3 title.
    text_flags: int
    tick_rgba: tuple[int, int, int, int] | None
    title_rgba: tuple[int, int, int, int] | None


# XYFS / XYEF axis ids: Rust decides which secondary axes it admits.
_AXIS_CODES = {"x": 0, "y": 1, "y2": 2, "x2": 3}


def _marshal_y2(figure: Any, y2_axis: dict[str, Any], y2_chrome: Y2Chrome | None) -> dict[str, Any]:
    """Marshal the authored secondary y axis: presence and authored values only.

    Rust owns every default (scale constant, tick strategy and anchor, minimum
    label gap), the axis chrome record, validation and the ``XYY2`` layout.
    """
    options = figure.axis_options["y2"]
    lo, hi = (float(v) for v in figure._range("y2"))
    constant = options.get("constant")
    return {
        "scale_kind": {"linear": 0, "log": 1, "symlog": 2}[figure._axis_scale("y2")],
        "lo": lo,
        "hi": hi,
        "constant": None if constant is None else float(constant),
        "nonpositive_mask": 1 if options.get("nonpositive") == "mask" else 0,
        "axis": y2_axis,
        "side_authored": options.get("side") is not None,
        "tick_sides_authored": options.get("tick_sides") is not None,
        "label_sides_authored": options.get("tick_label_sides") is not None,
        "collision": {
            "strategy": _optional_str(options.get("tick_label_strategy")),
            "collision": _optional_str(options.get("collision")),
            "anchor": _optional_str(options.get("tick_label_anchor")),
            "min_gap": None
            if options.get("tick_label_min_gap") is None
            else float(options["tick_label_min_gap"]),
            "angle": None
            if options.get("tick_label_angle") is None
            else float(options["tick_label_angle"]),
            "tick_kind_category": figure._axis_kind("y2") == "category",
        },
        "major": None
        if options.get("tick_values") is None
        else [float(v) for v in options["tick_values"]],
        "minor": [float(v) for v in (options.get("minor_tick_values") or ())],
        "tick_labels": None
        if options.get("tick_labels") is None
        else [str(v) for v in options["tick_labels"]],
        "title": _optional_str(options.get("label")),
        "format": _optional_str(options.get("format")),
        "metrics": None
        if y2_chrome is None
        else {
            "tick_size": y2_chrome.tick_size,
            "title_size": y2_chrome.title_size,
            "padding": y2_chrome.padding,
            "text_flags": y2_chrome.text_flags,
            "tick_rgba": y2_chrome.tick_rgba,
            "title_rgba": y2_chrome.title_rgba,
        },
    }


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def _marshal_trace_obs(trace: Any, *, polar: bool) -> dict[str, Any]:
    from xyg._scene_observations import (
        _admitted_fill_gradient,
        _admitted_fill_gradient_from_fill,
        _classify_ribbon_color2,
        _density_aggregates_color,
        _hexbin_packs_paint_plane,
        _mesh_packs_paint_plane,
        _parse_scene_dash,
        _ribbon_packs_end_paints,
        _scatter_packs_paint_plane,
    )
    from xyg.marks import _validated_marker_path

    kind = str(getattr(trace, "kind", "") or "mark")
    style = getattr(trace, "style", None) or {}
    fill = style.get("fill")
    radius = style.get("corner_radius", 0.0)
    if isinstance(radius, (list, tuple)):
        radius_values = [float(v) for v in radius]
        radius_seq = True
    else:
        radius_values = [float(radius)]
        radius_seq = False
    marker_path = style.get("marker_path")
    marker_path_valid = False
    marker_path_filled_small = False
    if marker_path is not None and kind == "scatter":
        try:
            validated = _validated_marker_path(marker_path)
            marker_path_valid = True
            marker_path_filled_small = validated["filled"] and any(
                len(c) < 6 for c in validated["contours"]
            )
        except ValueError:
            marker_path_valid = False
    dash = style.get("dash")
    dash_present = dash is not None
    dash_text: str | None = None
    dash_is_array = False
    if dash_present:
        parsed = _parse_scene_dash(dash)
        if parsed is False:
            dash_text = ""
        elif parsed is None:
            dash_present = False
        elif isinstance(parsed, list):
            dash_text = ",".join(str(part) for part in parsed)
        else:
            dash_text = str(dash)
    return {
        "kind": kind,
        "x_axis": str(getattr(trace, "x_axis", "x") or "x"),
        "y_axis": str(getattr(trace, "y_axis", "y") or "y"),
        "hidden": bool(getattr(trace, "hidden", False)),
        "has_per_item_channels": trace.has_per_item_channels(),
        "density_aggregates_color": _density_aggregates_color(trace),
        "marker_glyph_present": style.get("marker_glyph") is not None,
        "marker_glyph": _optional_str(style.get("marker_glyph")),
        "marker_path_present": marker_path is not None,
        "marker_path_valid": marker_path_valid,
        "marker_path_filled_small": marker_path_filled_small,
        "curve_present": style.get("curve") is not None,
        "curve": _optional_str(style.get("curve")),
        "linecap_present": style.get("linecap") is not None,
        "linecap": _optional_str(style.get("linecap")),
        "dash_present": dash_present,
        "dash_text": dash_text,
        "dash_is_array": dash_is_array,
        "fill_present": "fill" in style,
        "fill_is_string": isinstance(fill, str),
        "fill_gradient_admitted": _admitted_fill_gradient(trace) is not None,
        "hexbin_reduce": _optional_str(style.get("reduce")),
        "heatmap_truecolor": bool(getattr(trace, "truecolor", False)),
        "heatmap_has_colormap": getattr(trace, "colormap", None) is not None,
        "heatmap_has_rgba_grid": getattr(trace, "rgba_grid", None) is not None,
        "heatmap_has_rgba": getattr(trace, "rgba", None) is not None,
        "rect_gradient_fail": isinstance(fill, dict)
        and _admitted_fill_gradient_from_fill(fill, default_mark_color()) is None,
        "corner_radius_values": radius_values,
        "corner_radius_seq": radius_seq,
        "wedge_gap": float(style.get("wedge_gap", 0.0) or 0.0),
        "ribbon_color2_fail": _classify_ribbon_color2(trace) == "fail",
        "color_channel_unsupported": (
            getattr(trace, "color_ch", None) is not None
            and not isinstance(trace.color_ch, str)
            and (trace.color_ch.mode != "constant" or trace.color_ch.constant is None)
            and not (kind == "scatter" and trace.use_density())
            and not _hexbin_packs_paint_plane(trace)
            and not _mesh_packs_paint_plane(trace)
            and not _scatter_packs_paint_plane(trace)
            and not (not polar and _ribbon_packs_end_paints(trace))
        ),
    }


def _contour_color_channel(trace: Any) -> Any:
    """The contour color channel, failing closed on a custom colormap (#1025).

    The Scene color channel carries built-in colormap names only, so a gradient,
    CSS-color list or RGB-stop contour colormap would silently paint as the
    default map. Live rendering keeps it; static/Scene export refuses it.
    """
    channel = getattr(trace, "color_ch", None)
    if getattr(trace, "kind", None) == "contour" and channel is not None:
        colormap = getattr(channel, "colormap", None)
        if colormap is not None and not isinstance(colormap, str):
            from xyg._scene_observations import UnsupportedSceneV3

            raise UnsupportedSceneV3(CONTOUR_CUSTOM_COLORMAP_REASON)
    return channel


CONTOUR_CUSTOM_COLORMAP_REASON = "XYG_SCENE_UNSUPPORTED_CONTOUR_CUSTOM_COLORMAP"


def _marshal_xyta_color_channel(channel: Any) -> dict[str, Any]:
    if channel is None or isinstance(channel, str):
        return {
            "present": False,
            "mode": "",
            "constant": None,
            "colormap": None,
            "has_domain": False,
            "domain_lo": 0.0,
            "domain_hi": 0.0,
            "values_f64": np.empty(0, dtype=np.float64),
            "rgba_u8": b"",
            "codes_u8": b"",
            "codes_i64": np.empty(0, dtype=np.int64),
            "palette": [],
            "n_categories": 0,
        }
    mode = str(getattr(channel, "mode", "") or "")
    domain = getattr(channel, "domain", None)
    has_domain = domain is not None and len(domain) == 2
    values_f64 = np.empty(0, dtype=np.float64)
    rgba_u8 = b""
    values = getattr(channel, "values", None)
    if values is not None:
        values_f64 = np.ascontiguousarray(np.asarray(values, dtype=np.float64).reshape(-1))
    elif getattr(channel, "rgba", None) is not None:
        rgba = channel.rgba
        if isinstance(rgba, (bytes, bytearray)):
            rgba_u8 = bytes(rgba)
        else:
            values_f64 = np.ascontiguousarray(np.asarray(rgba, dtype=np.float64).reshape(-1))
    codes_u8 = b""
    codes_i64 = np.empty(0, dtype=np.int64)
    codes = getattr(channel, "codes", None)
    if codes is not None:
        if isinstance(codes, np.ndarray) and codes.dtype == np.uint8:
            codes_u8 = np.ascontiguousarray(codes, dtype=np.uint8).tobytes()
        else:
            codes_i64 = np.ascontiguousarray(np.asarray(codes, dtype=np.int64).reshape(-1))
    palette = getattr(channel, "palette", None) or getattr(channel, "colors", None) or ()
    colormap = getattr(channel, "colormap", None)
    return {
        "present": True,
        "mode": mode,
        "constant": getattr(channel, "constant", None),
        "colormap": colormap if isinstance(colormap, str) else None,
        "has_domain": has_domain,
        "domain_lo": float(domain[0]) if has_domain else 0.0,
        "domain_hi": float(domain[1]) if has_domain else 0.0,
        "values_f64": values_f64,
        "rgba_u8": rgba_u8,
        "codes_u8": codes_u8,
        "codes_i64": codes_i64,
        "palette": [str(entry) for entry in palette],
        "n_categories": len(getattr(channel, "categories", None) or ()),
    }


def _marshal_xyta_style_channel(channel: Any) -> dict[str, Any]:
    if channel is None or getattr(channel, "values", None) is None:
        return {"present": False, "values_f64": np.empty(0, dtype=np.float64)}
    return {
        "present": True,
        "values_f64": np.ascontiguousarray(
            np.asarray(channel.values, dtype=np.float64).reshape(-1)
        ),
    }


def _marshal_xyta_size_channel(channel: Any) -> dict[str, Any]:
    """Raw continuous size values, domain, and ``range_px``; Rust maps diameters."""
    mode = getattr(channel, "mode", None)
    if channel is None or isinstance(channel, str) or mode == "constant":
        return {"present": False, "values_f64": np.empty(0, dtype=np.float64)}
    # Any other mode is marshaled as present: a non-continuous channel carries
    # no values, so Rust's length check fails it closed instead of silently
    # inheriting the trace diameter.
    values = getattr(channel, "values", None) if mode == "continuous" else None
    if values is None:
        return {"present": True, "values_f64": np.empty(0, dtype=np.float64)}
    domain = getattr(channel, "domain", None)
    lo, hi = channel.range_px
    return {
        "present": True,
        "has_domain": domain is not None,
        "domain_lo": float(domain[0]) if domain is not None else 0.0,
        "domain_hi": float(domain[1]) if domain is not None else 0.0,
        "range_lo": float(lo),
        "range_hi": float(hi),
        "values_f64": np.ascontiguousarray(np.asarray(values, dtype=np.float64).reshape(-1)),
    }


def marshal_xyta_trace_obs(trace: Any, figure: Any, *, polar: bool) -> dict[str, Any]:
    """Marshal XYTA trace observations for ABI 323 materialize."""
    from xyg._scene_observations import (
        _mesh_count,
        _mesh_packs_paint_plane,
        _ribbon_color2_class_code,
        _ribbon_count,
        _scatter_count,
        _scatter_packs_paint_plane,
        _trace_column,
        _xyta_hexbin_plane_observations,
    )

    style = getattr(trace, "style", None) or {}
    kind_name = str(trace.kind)
    hexbin_colormap, hexbin_rgba_ready = _xyta_hexbin_plane_observations(trace)
    dispatch = _native.scene_xyta_trace_dispatch_plan(
        kind=kind_name,
        polar=polar,
        use_density=kind_name == "scatter" and trace.use_density(),
        hexbin_colormap_plane=hexbin_colormap,
        hexbin_rgba_plane_ready=hexbin_rgba_ready,
        ribbon_color2_class=_ribbon_color2_class_code(trace),
        mesh_paint_plane=_mesh_packs_paint_plane(trace),
        scatter_paint_plane=_scatter_packs_paint_plane(trace),
    )
    nan = float("nan")
    domain_x0 = domain_x1 = domain_y0 = domain_y1 = nan
    if dispatch["pack_density"]:
        domain_x0, domain_x1 = (float(value) for value in figure._range("x"))
        domain_y0, domain_y1 = (float(value) for value in figure._range("y"))
    if kind_name == "hexbin":
        xv_hex = _trace_column(trace, "x")
        point_count = 0 if xv_hex is None else int(len(xv_hex))
    elif kind_name == "ribbon":
        point_count = _ribbon_count(trace)
    elif kind_name in {"triangle_mesh", "segments", "contour"}:
        point_count = _mesh_count(trace)
    elif kind_name == "scatter":
        point_count = _scatter_count(trace)
    else:
        point_count = 0
    colormap = style.get("colormap")
    if isinstance(colormap, str):
        style_colormap_mode = 1
        style_colormap_named = colormap
        style_colormap_stops = b""
    elif colormap is not None:
        style_colormap_mode = 2
        style_colormap_named = ""
        try:
            stops = np.ascontiguousarray(
                [(int(red), int(green), int(blue)) for red, green, blue in colormap],
                dtype=np.uint8,
            )
            style_colormap_stops = (
                stops.tobytes() if stops.ndim == 2 and stops.shape[1] == 3 else b""
            )
        except (TypeError, ValueError):
            style_colormap_stops = b""
    else:
        style_colormap_mode = 0
        style_colormap_named = ""
        style_colormap_stops = b""
    shape = getattr(trace, "grid_shape", None)
    has_grid_shape = shape is not None and len(shape) == 2
    grid_shape_rows = float(shape[0]) if has_grid_shape else 0.0
    grid_shape_cols = float(shape[1]) if has_grid_shape else 0.0
    raw_grid = getattr(trace, "grid", None)
    if raw_grid is None:
        grid_values = np.empty(0, dtype=np.float64)
    else:
        grid_values = np.ascontiguousarray(
            np.asarray(getattr(raw_grid, "values", raw_grid), dtype=np.float64).reshape(-1)
        )
    packed_rgba = getattr(trace, "rgba", None)
    rgba_u8 = (
        np.ascontiguousarray(np.asarray(packed_rgba, dtype=np.uint8).reshape(-1)).tobytes()
        if packed_rgba is not None
        else b""
    )
    planes = getattr(trace, "rgba_grid", None)
    if planes is None:
        rgba_grid_f64 = np.empty(0, dtype=np.float64)
    elif len(planes) == 4:
        channels_f64 = [
            np.asarray(getattr(plane, "values", plane), dtype=np.float64).reshape(-1)
            for plane in planes
        ]
        rgba_grid_f64 = np.ascontiguousarray(np.stack(channels_f64, axis=-1)).reshape(-1)
    else:
        rgba_grid_f64 = np.empty(0, dtype=np.float64)
    xv = _trace_column(trace, "x")
    yv = _trace_column(trace, "y")
    x_values = (
        np.ascontiguousarray(xv, dtype=np.float64)
        if xv is not None
        else np.empty(0, dtype=np.float64)
    )
    y_values = (
        np.ascontiguousarray(yv, dtype=np.float64)
        if yv is not None
        else np.empty(0, dtype=np.float64)
    )
    style_channels = getattr(trace, "style_channels", None) or {}
    fallback_color = str(style.get("color", default_mark_color()))
    return {
        "trace_id": int(getattr(trace, "id", 0)) & 0xFFFFFFFF,
        "dispatch": dispatch,
        "domain_x0": domain_x0,
        "domain_x1": domain_x1,
        "domain_y0": domain_y0,
        "domain_y1": domain_y1,
        "point_count": point_count,
        "fallback_color": fallback_color,
        "style_color": style.get("color"),
        "style_stroke": style.get("stroke"),
        "style_stroke_width": float(style.get("stroke_width", 0.0) or 0.0),
        "has_style_stroke_width": "stroke_width" in style,
        "style_opacity": float(style["opacity"]) if "opacity" in style else nan,
        "has_style_opacity": "opacity" in style,
        "style_fill_opacity": float(style["fill_opacity"]) if "fill_opacity" in style else nan,
        "has_style_fill_opacity": "fill_opacity" in style,
        "style_stroke_opacity": (
            float(style["stroke_opacity"]) if "stroke_opacity" in style else nan
        ),
        "has_style_stroke_opacity": "stroke_opacity" in style,
        "style_truecolor": bool(style.get("truecolor")),
        "style_domain": style.get("domain"),
        "style_colormap_mode": style_colormap_mode,
        "style_colormap_named": style_colormap_named,
        "style_colormap_stops": style_colormap_stops,
        "grid_shape_rows": grid_shape_rows,
        "grid_shape_cols": grid_shape_cols,
        "has_grid_shape": has_grid_shape,
        "grid_values": grid_values,
        "rgba_u8": rgba_u8,
        "rgba_grid_f64": rgba_grid_f64,
        "x_values": x_values,
        "y_values": y_values,
        "color_ch": _marshal_xyta_color_channel(_contour_color_channel(trace)),
        "stroke_ch": _marshal_xyta_color_channel(getattr(trace, "stroke_ch", None)),
        "color2_ch": _marshal_xyta_color_channel(getattr(trace, "color2_ch", None)),
        "opacity_ch": _marshal_xyta_style_channel(style_channels.get("opacity")),
        "artist_alpha_ch": _marshal_xyta_style_channel(style_channels.get("artist_alpha")),
        "stroke_width_ch": _marshal_xyta_style_channel(style_channels.get("stroke_width")),
        "size_ch": _marshal_xyta_size_channel(getattr(trace, "size_ch", None)),
    }


def marshal_xytc_trace_obs(trace: Any, *, show_legend: bool) -> dict[str, Any]:
    """Marshal XYTC trace observations for ABI 325 materialize."""
    from xyg._scene_observations import (
        _channel_constant_css,
        _ribbon_end_rgba_pair,
        _trace_source_color_css,
    )

    style = getattr(trace, "style", None) or {}
    kind_name = str(trace.kind)
    nan = float("nan")
    name = str(trace.name) if getattr(trace, "name", None) else ""
    symbol_raw = style.get("symbol", "circle")
    if isinstance(symbol_raw, (int, float)) and not isinstance(symbol_raw, bool):
        symbol_is_int, symbol_int, symbol_text = 1, int(symbol_raw), None
    else:
        symbol_is_int, symbol_int = 0, 0
        symbol_text = str(symbol_raw or "circle")
    size_ch = getattr(trace, "size_ch", None)
    size_ch_constant = getattr(size_ch, "constant", None) if size_ch is not None else None
    raw_dx = style.get("hex_dx", style.get("dx"))
    raw_dy = style.get("hex_dy", style.get("dy"))
    dash = style.get("dash")
    dash_text = None
    dash_values: list[float] = []
    dash_is_array = 0
    if isinstance(dash, str):
        dash_text = dash
    elif isinstance(dash, (list, tuple)):
        dash_is_array = 1
        try:
            dash_values = [float(part) for part in dash]
        except (TypeError, ValueError):
            dash_values = []
    perimeter_present = 1 if "stroke_perimeter" in style else 0
    if perimeter_present:
        perimeter = style["stroke_perimeter"]
        perimeter_is_bool = 1 if isinstance(perimeter, bool) else 0
        perimeter_true = 1 if perimeter_is_bool and perimeter else 0
    else:
        perimeter_is_bool = perimeter_true = 0
    radius = style.get("corner_radius", 0.0)
    if isinstance(radius, (list, tuple)) and len(radius) == 2:
        radius_seq, r0, r1 = 2, float(radius[0]), float(radius[1])
    else:
        radius_seq, r0, r1 = 1, float(radius or 0.0), 0.0
    channel = getattr(trace, "color_ch", None)
    color_ch_present = 1 if channel is not None and not isinstance(channel, str) else 0
    color_ch_has_constant = (
        1 if color_ch_present and getattr(channel, "constant", None) is not None else 0
    )
    color2 = getattr(trace, "color2_ch", None)
    has_color2 = color2 is not None
    kind_is_ribbon = kind_name == "ribbon"
    has_fill = "fill" in style
    color2_source_const = _channel_constant_css(getattr(trace, "color_ch", None))
    color2_target_const = _channel_constant_css(color2) if has_color2 else None
    has_end_pair = False
    if has_color2 and kind_is_ribbon:
        both_const = color2_target_const is not None and color2_source_const is not None
        if not both_const and not has_fill:
            has_end_pair = _ribbon_end_rgba_pair(trace) is not None
    return {
        "show_legend": show_legend,
        "kind": kind_name,
        "has_name": bool(name),
        "name": name,
        "marker_path_present": kind_name == "scatter" and style.get("marker_path") is not None,
        "use_density": kind_name == "scatter" and trace.use_density(),
        "joined_fill": kind_name == "triangle_mesh" and bool(style.get("joined_fill")),
        "symbol_is_int": symbol_is_int,
        "symbol_int": symbol_int,
        "symbol_text": symbol_text,
        "opacity": float(style.get("opacity", 1.0)),
        "fill_opacity": float(style.get("fill_opacity", 1.0)),
        "stroke_opacity": float(style.get("stroke_opacity", 1.0)),
        "line_opacity": float(style.get("line_opacity", 1.0)),
        "has_stroke": "stroke" in style,
        "stroke": style.get("stroke"),
        "has_line_color": "line_color" in style,
        "line_color": style.get("line_color"),
        "has_color": "color" in style,
        "color": style.get("color"),
        "has_size": "size" in style,
        "size": float(style["size"]) if "size" in style else nan,
        "has_size_ch": size_ch is not None,
        "has_size_ch_constant": size_ch_constant is not None,
        "size_ch_constant": float(size_ch_constant) if size_ch_constant is not None else nan,
        "has_stroke_width": "stroke_width" in style,
        "stroke_width": float(style["stroke_width"]) if "stroke_width" in style else 0.0,
        "has_width": "width" in style,
        "width": float(style["width"]) if "width" in style else 0.0,
        "has_line_width": "line_width" in style,
        "line_width": float(style["line_width"]) if "line_width" in style else 0.0,
        "has_hex_dx": raw_dx is not None,
        "hex_dx": float(raw_dx) if raw_dx is not None else nan,
        "has_hex_dy": raw_dy is not None,
        "hex_dy": float(raw_dy) if raw_dy is not None else nan,
        "has_stroke_perimeter": bool(perimeter_present),
        "stroke_perimeter_is_bool": perimeter_is_bool,
        "stroke_perimeter_true": perimeter_true,
        "wedge_gap_raw": float(style.get("wedge_gap", 0.0) or 0.0),
        "dash_is_array": dash_is_array,
        "dash_text": dash_text,
        "dash_values": dash_values,
        "has_fill": has_fill,
        "fill": style.get("fill") if has_fill else None,
        "marker_path": style.get("marker_path"),
        "marker_glyph": style.get("marker_glyph"),
        "has_color2": has_color2,
        "kind_is_ribbon": kind_is_ribbon,
        "color2_source_const": color2_source_const,
        "color2_target_const": color2_target_const,
        "source_paint": _trace_source_color_css(trace),
        "has_end_pair": has_end_pair,
        "corner_radius_seq": radius_seq,
        "corner_radius_r0": r0,
        "corner_radius_r1": r1,
        "color_ch_present": color_ch_present,
        "color_ch_has_constant": color_ch_has_constant,
        "color_ch_mode": None
        if channel is None or isinstance(channel, str)
        else getattr(channel, "mode", ""),
        "color_ch_constant": (
            None
            if not color_ch_has_constant or channel is None or isinstance(channel, str)
            else str(channel.constant)
        ),
        "linecap": style.get("linecap"),
        "step": style.get("step"),
        "curve": style.get("curve"),
    }


def pack_figure_support(
    figure: Any,
    annotations: list[Any],
    colorbar_unsupported: bool,
) -> bytes:
    """Marshal figure support observations and materialize XYFS via Rust (ABI 322)."""
    from xyg._scene_observations import (
        _annotation_has_custom_typography,
        _annotation_has_markup,
        _significant_scene_axis_keys,
    )

    polar = str(getattr(figure, "coords", "cartesian") or "cartesian") == "polar"
    chrome_styles = getattr(figure, "chrome_styles", None) or {}
    ann_rows = []
    for annotation in annotations:
        kind = annotation.get("kind")
        ann_rows.append(
            {
                "has_html": annotation.get("html") not in (None, ""),
                "has_collision": annotation.get("collision") not in (None, ""),
                "has_markup": _annotation_has_markup(annotation),
                "has_custom_typography": _annotation_has_custom_typography(annotation),
                "has_class_name": annotation.get("class_name") not in (None, ""),
                "kind_is_supported_text": kind in {"callout", "arrow", "text"},
                "has_text": annotation.get("text") not in (None, ""),
                "y2": annotation.get("y_axis") == "y2",
                "coordinate_space": _optional_str(
                    (annotation.get("style") or {}).get("coordinate_space")
                ),
            }
        )
    axes = []
    for axis_id, options in figure.axis_options.items():
        axis_code = _AXIS_CODES.get(axis_id, 255)
        axes.append(
            {
                "axis_code": axis_code,
                "side": {None: 0, "bottom": 1, "left": 2, "top": 3, "right": 4}.get(
                    options.get("side"), 255
                ),
                "keys": _significant_scene_axis_keys(options, polar=polar),
                "tick_label_strategy": _optional_str(options.get("tick_label_strategy")),
                "collision": _optional_str(options.get("collision")),
            }
        )
    traces = [
        _marshal_trace_obs(trace, polar=polar) for trace in getattr(figure, "traces", None) or []
    ]
    return _native.scene_figure_support_materialize(
        polar=polar,
        colorbar_unsupported=colorbar_unsupported,
        has_colorbar=bool(getattr(figure, "colorbar_options", None)),
        has_custom_font=any("font-family" in (style or {}) for style in chrome_styles.values())
        or any(_annotation_has_custom_typography(a) for a in annotations),
        has_browser_css=bool(
            getattr(figure, "class_name", None)
            or getattr(figure, "class_names", None)
            or chrome_styles
            or set(getattr(figure, "style", None) or {}) - {"background", "--chart-bg"}
            or any(a.get("class_name") not in (None, "") for a in annotations)
        ),
        has_extra_legends=bool(getattr(figure, "extra_legends", None)),
        annotations=ann_rows,
        axes=axes,
        traces=traces,
    )


def pack_polar_scene_input(figure: Any) -> bytes:
    """Marshal polar axis literals and pack XYPL via Rust (ABI 322)."""
    xa = figure.axis_options.get("x") or {}
    ya = figure.axis_options.get("y") or {}
    unit = str(xa.get("theta_unit", "radians"))
    turn = 360.0 if unit == "degrees" else 2.0 * math.pi
    sector = xa.get("sector") or (0.0, turn)
    r_lo, r_hi = figure._range("y")
    origin = ya.get("r_origin")
    scale_kind, constant, mask_nonpositive = _native._polar_r_scale(ya)
    grid = str(xa.get("grid_shape", "circular"))
    theta_zero = xa.get("theta_zero", "E")
    theta_zero_is_label = isinstance(theta_zero, str)
    return _native.scene_polar_input_pack(
        polar=str(getattr(figure, "coords", "cartesian") or "cartesian") == "polar",
        theta_unit=_native._polar_theta_unit(unit),
        theta_direction=_native._polar_theta_direction(xa.get("theta_direction")),
        n_categories=len(tuple(xa.get("categories") or ())),
        grid_shape=1 if grid == "linear" else 0,
        r_scale_kind=scale_kind,
        r_mask_nonpositive=mask_nonpositive,
        sector_start=float(sector[0]),
        sector_end=float(sector[1]),
        r_lo=float(r_lo),
        r_hi=float(r_hi),
        r_origin_is_nan=origin is None,
        r_origin=float("nan") if origin is None else float(origin),
        hole=float(ya.get("hole") or 0.0),
        r_constant=constant,
        theta_zero_is_label=theta_zero_is_label,
        theta_zero_label=str(theta_zero) if theta_zero_is_label else "",
        theta_zero_numeric=_native._polar_theta_zero(theta_zero),
    )


_XYEF_OBS_HAS_X = 1 << 0
_XYEF_OBS_HAS_Y = 1 << 1
_XYEF_OBS_X_FINITE = 1 << 2
_XYEF_OBS_Y_FINITE = 1 << 3
_XYEF_OBS_HAS_X0 = 1 << 4
_XYEF_OBS_HAS_Y0 = 1 << 5
_XYEF_OBS_HAS_X1 = 1 << 6
_XYEF_OBS_HAS_Y1 = 1 << 7
_XYEF_OBS_X0_FINITE = 1 << 8
_XYEF_OBS_Y0_FINITE = 1 << 9
_XYEF_OBS_X1_FINITE = 1 << 10
_XYEF_OBS_Y1_FINITE = 1 << 11
_XYEF_OBS_JOINED_FILL = 1 << 12
_XYEF_OBS_HEATMAP_TRUECOLOR = 1 << 13
_XYEF_OBS_HEATMAP_RGBA_GRID = 1 << 16
_XYEF_OBS_HEATMAP_SHAPE_OK = 1 << 17
_XYEF_OBS_HEATMAP_EXTENT_OK = 1 << 18
_XYEF_OBS_HEATMAP_FINITE = 1 << 19
_XYEF_OBS_STROKE_WIDTH_ONLY = 1 << 20
_XYEF_OBS_COMPANION_XY_MATCH = 1 << 21
_XYEF_OBS_COMPANION_AXES_MATCH = 1 << 22
_XYEF_OBS_SYMBOL_NON_STRING = 1 << 23
_XYEF_OBS_DENSITY_BLIT = 1 << 24
_XYEF_OBS_ITEM_PAINT_PLANE = 1 << 25


def _xyep_put_keys(buf: bytearray, keys: list[str]) -> None:
    for key in keys:
        encoded = str(key).encode("utf-8")
        if len(encoded) > 256:
            encoded = encoded[:256]
        buf.extend(len(encoded).to_bytes(2, "little"))
        buf.extend(encoded)


def _xyep_column(trace: Any, name: str) -> Any:
    return getattr(trace, name, None)


def _xyep_len(column: Any) -> int:
    return 0 if column is None else int(len(column.values))


def _xyep_finite(column: Any) -> bool:
    if column is None:
        return False
    return _native.scene_finite_all(column.values)


def _graph_marks_only(figure: Any) -> bool:
    """True when every trace belongs to a recorded graph mark (#33).

    Each graph mark owns an edge ``segments`` trace immediately followed by its
    node ``scatter`` trace; Rust re-verifies the kinds (XYEP ``FLAG_GRAPH_MARKS``).
    """
    metas = getattr(figure, "_graph_meta", None) or []
    traces = getattr(figure, "traces", None) or []
    owned = []
    for meta in metas:
        edge, node = meta.get("edge_trace"), meta.get("node_trace")
        if not isinstance(edge, int) or node != edge + 1:
            return False
        owned.extend((edge, node))
    return bool(owned) and sorted(owned) == list(range(len(traces)))


def pack_public_export_support(
    figure: Any,
    *,
    width: int | None = None,
    height: int | None = None,
) -> bytes:
    """Pack authored XYEF facts; Rust owns the XYEP envelope (ABI 152)."""
    from xyg._scene_observations import (
        UnsupportedSceneV3,
        _annotation_has_markup,
        _heatmap_extent,
        _heatmap_grid_values,
        _heatmap_shape,
        _hexbin_pitch,
        _mesh_packs_paint_plane,
        _scatter_packs_paint_plane,
    )

    export_plan = _native.scene_public_export_figure_plan(
        polar=getattr(figure, "coords", "cartesian") == "polar",
        has_chrome_styles=bool(getattr(figure, "chrome_styles", None)),
        has_title_options=bool(getattr(figure, "title_options", None)),
    )
    flags = 0
    if width is None and not isinstance(figure.width, int):
        flags |= 1 << 0
    if height is None and not isinstance(figure.height, int):
        flags |= 1 << 1
    if export_plan["has_chrome_styles"]:
        flags |= 1 << 2
    if export_plan["has_title_options"]:
        flags |= 1 << 3
    if export_plan["polar"]:
        flags |= 1 << 4
    if _graph_marks_only(figure):
        flags |= 1 << 5
    style_keys = [str(key) for key in (getattr(figure, "style", None) or {})]
    legend_keys = [str(key) for key in (getattr(figure, "legend_options", None) or {})]
    colorbar_keys = [str(key) for key in (getattr(figure, "colorbar_options", None) or {})]
    annotations = list(getattr(figure, "annotations", None) or [])
    traces = list(getattr(figure, "traces", None) or [])
    payload = bytearray(b"XYEF")
    payload.extend((1).to_bytes(4, "little"))
    payload.extend(flags.to_bytes(4, "little"))
    payload.extend(len(style_keys).to_bytes(4, "little"))
    payload.extend(len(legend_keys).to_bytes(4, "little"))
    payload.extend(len(colorbar_keys).to_bytes(4, "little"))
    payload.extend(len(figure.axis_options).to_bytes(4, "little"))
    payload.extend(len(annotations).to_bytes(4, "little"))
    payload.extend(len(traces).to_bytes(4, "little"))
    _xyep_put_keys(payload, style_keys)
    _xyep_put_keys(payload, legend_keys)
    _xyep_put_keys(payload, colorbar_keys)
    for axis_id, options in figure.axis_options.items():
        axis_code = _AXIS_CODES.get(axis_id, 255)
        resolved = figure._axis_kind(axis_id)
        resolved_code = {"linear": 0, "time": 1, "category": 2}.get(resolved, 255)
        authored = options.get("type")
        authored_code = {None: 0, "linear": 1, "log": 2, "symlog": 3}.get(authored, 255)
        side = options.get("side")
        side_code = {None: 0, "bottom": 1, "left": 2, "top": 3, "right": 4}.get(side, 255)
        keys = [str(key) for key, value in options.items() if value not in (None, False)]
        payload.extend(
            bytes(
                (
                    axis_code,
                    resolved_code,
                    authored_code,
                    int(options.get("domain") is not None),
                    side_code,
                    0,
                )
            )
        )
        payload.extend(len(keys).to_bytes(2, "little"))
        _xyep_put_keys(payload, keys)
    for annotation in annotations:
        if not isinstance(annotation, dict):
            payload.extend(struct.pack("<B3sHH", 1, b"", 0, 0))
            continue
        kind_b = str(annotation.get("kind") or "").encode("utf-8")[:256]
        fields = [str(key) for key in annotation]
        if _annotation_has_markup(annotation) and "markup" not in fields:
            fields.append("markup")
        payload.extend(struct.pack("<B3sHH", 0, b"", len(kind_b), len(fields)))
        payload.extend(kind_b)
        _xyep_put_keys(payload, fields)
    for trace_index, trace in enumerate(traces):
        style = getattr(trace, "style", None) or {}
        export_dispatch = _native.scene_public_export_trace_dispatch_plan(
            kind=str(trace.kind),
            polar=export_plan["polar"],
            use_density=str(trace.kind) == "scatter" and trace.use_density(),
        )
        opacity = float(style.get("opacity", 1.0))
        if not np.isfinite(opacity) or not 0.0 <= opacity <= 1.0:
            raise ValueError("trace opacity must be finite and in [0, 1]")
        prev = traces[trace_index - 1] if trace_index else None
        prev2 = traces[trace_index - 2] if trace_index >= 2 else None
        prev3 = traces[trace_index - 3] if trace_index >= 3 else None
        xv = _xyep_column(trace, "x")
        yv = _xyep_column(trace, "y")
        x0 = _xyep_column(trace, "x0")
        y0 = _xyep_column(trace, "y0")
        x1 = _xyep_column(trace, "x1")
        y1 = _xyep_column(trace, "y1")
        obs = 0
        if xv is not None:
            obs |= _XYEF_OBS_HAS_X
        if yv is not None:
            obs |= _XYEF_OBS_HAS_Y
        if _xyep_finite(xv):
            obs |= _XYEF_OBS_X_FINITE
        if _xyep_finite(yv):
            obs |= _XYEF_OBS_Y_FINITE
        if x0 is not None:
            obs |= _XYEF_OBS_HAS_X0
        if y0 is not None:
            obs |= _XYEF_OBS_HAS_Y0
        if x1 is not None:
            obs |= _XYEF_OBS_HAS_X1
        if y1 is not None:
            obs |= _XYEF_OBS_HAS_Y1
        if _xyep_finite(x0):
            obs |= _XYEF_OBS_X0_FINITE
        if _xyep_finite(y0):
            obs |= _XYEF_OBS_Y0_FINITE
        if _xyep_finite(x1):
            obs |= _XYEF_OBS_X1_FINITE
        if _xyep_finite(y1):
            obs |= _XYEF_OBS_Y1_FINITE
        if style.get("joined_fill"):
            obs |= _XYEF_OBS_JOINED_FILL
        heatmap_rows = heatmap_cols = heatmap_values = 0
        if trace.kind == "heatmap":
            style_truecolor = bool(style.get("truecolor"))
            if style_truecolor:
                obs |= _XYEF_OBS_HEATMAP_TRUECOLOR
            if getattr(trace, "rgba_grid", None) is not None:
                obs |= _XYEF_OBS_HEATMAP_RGBA_GRID
            try:
                heatmap_rows, heatmap_cols = _heatmap_shape(trace)
                values = _heatmap_grid_values(trace)
                _heatmap_extent(trace)
                obs |= _XYEF_OBS_HEATMAP_SHAPE_OK
                obs |= _XYEF_OBS_HEATMAP_EXTENT_OK
                heatmap_values = int(values.size)
                if _native.scene_finite_all(values):
                    obs |= _XYEF_OBS_HEATMAP_FINITE
            except (UnsupportedSceneV3, ValueError, TypeError):
                heatmap_rows = heatmap_cols = heatmap_values = 0
        if style.get("stroke_width") is not None and style.get("stroke") is None:
            obs |= _XYEF_OBS_STROKE_WIDTH_ONLY
        if (
            prev is not None
            and xv is not None
            and yv is not None
            and _xyep_column(prev, "x1") is not None
            and _xyep_column(prev, "y1") is not None
            and _native.scene_arrays_equal(xv.values, prev.x1.values)
            and _native.scene_arrays_equal(yv.values, prev.y1.values)
        ):
            obs |= _XYEF_OBS_COMPANION_XY_MATCH
        if prev is not None and trace.x_axis == prev.x_axis and trace.y_axis == prev.y_axis:
            obs |= _XYEF_OBS_COMPANION_AXES_MATCH
        symbol = style.get("symbol", "circle")
        if not isinstance(symbol, str):
            obs |= _XYEF_OBS_SYMBOL_NON_STRING
            symbol = ""
        if export_dispatch["pack_density_blit"]:
            obs |= _XYEF_OBS_DENSITY_BLIT
        # Same facts the XYTA dispatch plan receives; Rust bounds the plane (#1006).
        if _scatter_packs_paint_plane(trace) or _mesh_packs_paint_plane(trace):
            obs |= _XYEF_OBS_ITEM_PAINT_PLANE
        role = style.get("role")
        role_s = "" if role is None else str(role)
        reduce = style.get("reduce")
        reduce_s = "" if reduce is None else str(reduce)
        try:
            hex_dx, hex_dy = (
                _hexbin_pitch(style)
                if export_dispatch["pack_hexbin_pitch"]
                else (float("nan"), float("nan"))
            )
        except UnsupportedSceneV3:
            hex_dx = hex_dy = float("nan")
        style_keys_tr = [str(key) for key, value in style.items() if value is not None]
        kind_b = str(trace.kind).encode("utf-8")[:256]
        step_b = str(style.get("step") or "").encode("utf-8")[:256]
        role_b = role_s.encode("utf-8")[:256]
        symbol_b = (symbol.encode("utf-8") if isinstance(symbol, str) else b"")[:256]
        reduce_b = reduce_s.encode("utf-8")[:256]
        prev_b = (str(prev.kind).encode("utf-8") if prev is not None else b"")[:256]
        prev2_b = (str(prev2.kind).encode("utf-8") if prev2 is not None else b"")[:256]
        prev3_b = (str(prev3.kind).encode("utf-8") if prev3 is not None else b"")[:256]
        payload.extend(
            struct.pack(
                "<I6I3I10H4x2d",
                obs,
                _xyep_len(xv),
                _xyep_len(yv),
                _xyep_len(x0),
                _xyep_len(y0),
                _xyep_len(x1),
                _xyep_len(y1),
                heatmap_rows,
                heatmap_cols,
                heatmap_values,
                len(style_keys_tr),
                len(kind_b),
                len(step_b),
                len(role_b),
                len(symbol_b),
                len(reduce_b),
                len(prev_b),
                len(prev2_b),
                len(prev3_b),
                0,
                hex_dx,
                hex_dy,
            )
        )
        payload.extend(kind_b)
        payload.extend(step_b)
        payload.extend(role_b)
        payload.extend(symbol_b)
        payload.extend(reduce_b)
        payload.extend(prev_b)
        payload.extend(prev2_b)
        payload.extend(prev3_b)
        _xyep_put_keys(payload, style_keys_tr)
    return _native.scene_pack_public_export(bytes(payload))
