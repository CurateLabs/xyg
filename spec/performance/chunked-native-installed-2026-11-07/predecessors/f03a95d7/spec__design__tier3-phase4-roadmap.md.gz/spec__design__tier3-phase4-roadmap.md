# Tier-3 Phase 4 — disk-resident tile spill roadmap

**Status:** design **locked** (WP0 complete); WP1 Rust tile store **landed**
(ABI 73: `xyg_pyramid_spill` / `xyg_tile_store_*` in `crates/xyg-engine` +
`crates/xyg-core`). Host engagement is WP2. Phase-3 square pyramid is **productized**
on Python and Node ([lod-architecture.md](lod-architecture.md) §4 /
Phase 3; [tier3-testing.md](tier3-testing.md);
[xy-coverage.md](xy-coverage.md)). Note the shipped Phase-3 pyramid is
**not tiled** — `crates/xyg-engine/src/tiles.rs` stores one contiguous grid per level — so
Phase 4 is a storage-layout change, not a residency wrapper.

**Tracking issue:** [#5](https://github.com/CurateLabs/xyg/issues/5)
(“Phase 4: Tier-3 disk-resident 256² tile spill”); sub-issues
[#7](https://github.com/CurateLabs/xyg/issues/7) (WP0) ·
[#8](https://github.com/CurateLabs/xyg/issues/8) (WP1) ·
[#9](https://github.com/CurateLabs/xyg/issues/9) (WP2) ·
[#10](https://github.com/CurateLabs/xyg/issues/10) (WP3) ·
[#11](https://github.com/CurateLabs/xyg/issues/11) (WP4). In-repo
pointer: [`issues/phase4-tile-spill.md`](issues/phase4-tile-spill.md).

**Sequencing overlay:** WP1 (#8) re-landed in `crates/xyg-engine` after the
crate split ([#18](https://github.com/CurateLabs/xyg/issues/18)); draft PR #19
is superseded. Canonical f64 columns / `stream.rs` are
[#22](https://github.com/CurateLabs/xyg/issues/22), not this spill store.
Cross-cutting host/identity/client plan:
[host-neutral-architecture.md](host-neutral-architecture.md) / #24.

## Why Phase 4

Phase 3 keeps the **whole pyramid resident in kernel RAM** (≈1.33× finest
level). That is enough for interactive compose at tens–hundreds of millions
of points when rows are memmap’d and only the density grid ships. At
**~1B colored points** (or multi-trace apps sharing RAM), the pyramid itself
must spill:

| Concern | Phase 3 (shipped) | Phase 4 (this roadmap) |
| --- | --- | --- |
| Aggregate storage | Whole square pyramid in RAM | 256² **data-space tiles** under a byte budget |
| Pan | Re-compose from resident levels | Fetch only newly exposed tiles; reuse LRU |
| Zoom | Level pick + compose | Adjacent-level tile set + optional crossfade |
| Deep zoom | Spatial index / exact re-bin | Unchanged companion (`_spatial`) |
| Hosts | Python + Node bind `xyg_pyramid_*` | Same hosts; new spill/fetch ABI |

## Goals (MUST)

1. **Rust owns spill/load** — tile residency, LRU, and compose-from-tiles live
   in `libxyg_core` (extend `tiles.rs` / new `tile_store.rs`). Hosts stay thin.
2. **Screen-bounded replies** — at most ~ceil(w/256+1)×ceil(h/256+1) tiles
   contribute to a frame; client never holds more than screen-bounded textures.
3. **§28 recording** — every reply records `binning: "pyramid-L<l>-tiles"`
   (or equivalent) plus residency stats (tiles hit / miss / bytes).
4. **Dual-host parity** — Python and Node expose the same build/fetch/compose
   surface; browser remains paint-only.
5. **Append policy** — count-only pyramids may dirty-tile rebuild; colored
   pyramids continue to refuse incremental color append (invalidate + rebuild),
   or gain an explicit color-append ABI if designed.

## Non-goals

- Replacing Phase-3 compose for traces that fit in RAM (keep hot path).
- Browser-side layout/LOD/encode.
- Allocating 1B points in CI to “prove” spill (see testing below).
- Shipping Arrow/Parquet ingest as a hard dependency of the first spill MVP
  if a simpler mmap tile format lands first — document the format choice.

## Locked decisions (WP0 — [#7](https://github.com/CurateLabs/xyg/issues/7))

Every decision below is the authoritative record (§28 culture: recorded,
never silent). Dossier-level summary: design-dossier.md §32b. WP1–WP4 build
inside this frame; changing any of it means editing this section first.

### D1 — Tile key and on-disk layout: fixed mmap slabs

- **Key:** `(level, tx, ty)` — level 0 is the finest (`base_dim`), each higher level halves the dimension; level *l*
  has up to `ceil(dim_l/256)²` tiles over the pyramid’s square level grids.
- **Layout:** one spill file per pyramid. Fixed header (magic `XYTS`,
  format version u32, base dim, level count, plane flags), then a dense
  count region and — for colored pyramids — a dense color region, each
  ordered coarsest level first (highest level index first), row-major `(ty, tx)` within a level. Every
  slab is a fixed 256²-cell block (count: 256 KiB of u32; color: 512 KiB of
  `[u16; 4]`); levels smaller than 256² store one zero-padded slab. Fixed
  slabs make every offset closed-form arithmetic — no per-tile directory
  lookup on the read path — and 4 KiB pages divide the slab size, so mmap
  reads stay page-aligned. Values are native-endian: the file is a
  **per-process rebuildable cache** (§27), never an interchange format, with
  process-scoped temporary ownership, deleted on free/exit. User-owned
  canonical memmaps are retained; they have a different lifecycle.
- **Why not Arrow/Parquet (MVP):** the win Arrow buys (interchange,
  schema evolution, ecosystem readers) is worth nothing for a file that
  never leaves the process and can always be discarded and rebuilt; the
  costs are real — a large crate tree in a repo that must vendor every
  crate (rust-engine.md dependency policy; crates.io is unreachable from
  the dev sandbox), plus decode work on a path whose §29 culture is
  memcpy-shaped I/O. The roadmap non-goal above already permits this.
- **Migration note:** the header’s magic + version byte is the whole
  migration story — a future Arrow/Parquet store replaces the format at a
  version bump with zero compatibility work, because no spill file ever
  outlives its process. Revisit if measurements show a need (e.g. HTTP
  range-request serving of tiles, dossier §29, where an interchange format
  starts paying for itself).

### D2 — Byte-budget knob: `PYRAMID_RESIDENT_BYTES`

- **Name/default:** `PYRAMID_RESIDENT_BYTES = 512 * 2**20` (512 MiB) in
  `python/xyg/config.py`, mirrored in the Node constants
  (`packages/xy-node/src/pyramid.js` exports, like the four existing
  `PYRAMID_*` knobs). Scope is **process-wide across all pyramids** —
  the motivating cliff is multi-trace apps sharing RAM, so a per-pyramid
  budget would multiply exactly like the problem it solves.
- **Why 512 MiB:** a default-base (2048²) colored pyramid is ~67 MB
  resident, so ordinary traces — even several — never spill and the
  Phase-3 hot path is untouched; an adaptive 16 384² base (~1.4 GB counts
  + ~2.9 GB color) must spill, which is the point.
- **Accounting (dossier §27):** `pyramid_report_bytes` — the
  `memory_report()["pyramid_bytes"]` line — reports **all** RAM-resident
  tile bytes plus tile-directory/index metadata, whether or not the
  pyramid has spilled. On-disk bytes report separately as
  `pyramid_spilled_bytes` (disk-backed, reclaimable), mirroring the
  `canonical_bytes` / `canonical_mapped_bytes` split of §27 rule 5.

### D3 — Eviction: LRU with frame pinning

- **Unit:** whole tiles — a tile’s count and color slabs evict together
  (compose-color needs both; split residency would double bookkeeping to
  save at most the color plane of a tile about to be refetched).
- **Pinning:** the ≤ ceil(w/256+1) × ceil(h/256+1) tiles of the level
  serving the current compose are pinned for the duration of the call and
  left most-recently-used afterward, so an immediate pan re-fetches only
  newly exposed edge tiles. Nothing else is pinned; the previous frame’s
  set competes in LRU order like everything else.
- **Working set > budget:** a frame never fails and never livelocks. The
  effective budget floors at the pinned working set (compose proceeds),
  the reply records the condition (`over_budget: true` in the §28 tile
  stats, below), and eviction returns residency to the configured budget
  as soon as the pins release. Degrading to a coarser level is *not* done
  implicitly — the working set is screen-bounded (~12 tiles ≈ 3–9 MB), so
  exceeding the budget with pins alone means a pathological configuration,
  and silently changing the served level would be a §28 violation.
- **§28 recording:** every tile-served reply carries
  `binning: "pyramid-L<l>-tiles[-upsampled]"` plus
  `tiles: {hit, miss, resident_bytes, spilled_bytes, budget_bytes,
  over_budget}`.

### D4 — Append and domain-growth policy

- **Count-only pyramids:** an in-domain append marks the intersecting
  tiles dirty per level (a batch touching one region dirties ~1 tile per
  level) and rebuilds them lazily on next fetch/compose; the composed
  result must equal a from-scratch rebuild bit-for-bit (WP4 golden).
- **Colored pyramids:** refuse-and-rebuild stands, spilled or not — the
  Phase-3 rationale (append colors unknown to the count path; domain
  motion re-colors already-binned points) is unchanged by residency. No
  color-append ABI in Phase 4; designing one is out of scope and would
  re-enter through this section.
- **Domain growth:** an append outside the pyramid’s original x/y domain
  invalidates the **whole store** — RAM tiles, spill file, and tile index
  — because a grown domain re-keys every `(level, tx, ty)`; partial reuse
  is impossible by construction. Rebuild is lazy (next density view), as
  today.

### D5 — Zone-map-pruned tile index (companion, not replacement)

- **Bounded baseline shipped (ABI 396):** `canonical_drill.rs` queries existing
  f64 columns and paired chunk min/max maps without expanding candidate IDs or
  allocating N output rows. Rust returns ascending canonical u32 IDs only on
  `complete`; `overflow` / `scan-budget` return unknown exact count and no usable
  prefix. The 200k/1.15 drill policy and existing 80M candidate allowance own
  output/read bounds. Complete channel-bearing point replies and padded windows
  use the usual global-channel, canonical hover/selection and subset-history path,
  before legacy or XYDC spilled-density early returns. Predicates bypass this
  unfiltered route. See [LOD §4.2](lod-architecture.md#42-serving-a-viewport).
  **Remaining:** unordered massive chunk zones can all overlap, so this baseline
  may refuse even a sparse tiny view. Finer canonical-row localization plus
  actual massive-source scale/latency/memory evidence are still required; this
  finite implementation does not complete #11/#108 or prove a competitor win.
- Dirty-tile rebuilds (D4) and below-floor re-bins locate rows through the
  **existing** §22 chunk zone maps: `xy_zone_maps_pair` per-chunk x/y
  min/max prune the candidate ~64k-row chunks intersecting a tile’s
  data-space rect, and only those chunks are scanned. No new ingest-time
  sort or bucketing pass is added for the MVP — the index is O(chunks)
  metadata that already exists and is already counted.
- Where a trace carries `_spatial.SpatialIndex` (the shipped osm-sort cell
  grid, dossier §32b), it serves as the finer row locator for the same
  queries. It remains a **companion**: position-only, gated as today
  (constant-styled traces, deep-zoom regime) — the zone-map path is the
  always-available baseline.
- Rejected for the MVP: a mandatory per-row spatial sort at ingest —
  it duplicates `SpatialIndex`, taxes every ingest to benefit only the
  spilled minority, and zone-map pruning already bounds rebuild scans to
  O(chunks touching the tile).

### D6 — Filter/legend interaction (§34): staleness impossible by construction

- The tile store holds **unfiltered** aggregates only, exactly like the
  Phase-3 in-RAM pyramid. A trace with any active predicate (legend mask,
  filter) bypasses compose-from-tiles entirely and is served by the exact
  re-bin path (`binning` tagged `-masked`), and **filtered results are
  never written to the store**. There is therefore no filter-invalidation
  bookkeeping to get wrong: a spilled tile cannot serve stale filtered
  counts because filtered counts never reach disk. WP4 must still test
  the negative path (predicate change ⇒ no tile-served reply).
- Data changes invalidate per D4; predicate changes invalidate nothing
  because they never read the store.

### D7 — Nonlinear axes: excluded, recorded

- Traces on log/symlog axes skip pyramid build/compose (dossier §28
  nonlinear-axes rules — the record now names the tile store explicitly),
  so they never engage spill: no pyramid, nothing to spill. They keep the
  exact scan path at every scale, cost accepted and recorded in §28.

## Work packages

### WP0 — Spec lock ([#7](https://github.com/CurateLabs/xyg/issues/7))

- [x] Finalize tile key `(level, tx, ty)`, on-disk layout (fixed mmap slabs;
  Arrow/Parquet deferred with a migration note), and the
  `PYRAMID_RESIDENT_BYTES` byte-budget knob for `python/xyg/config.py` /
  Node constants → locked decisions D1–D2 above.
- [x] Eviction/pinning semantics, append + domain-growth policy, zone-map
  tile index, filter/legend rule, nonlinear-axes exclusion → D3–D7 above.
- [x] Update [lod-architecture.md](lod-architecture.md) Phase 4 checklist
  items 10–12 with acceptance numbers.
- [x] Link the tracking GitHub issue and sub-issues from this doc and
  `dual-host-parity.json` `lod_tiers[2].notes`.
- [x] Fix the spec debt found in review: phantom “§32b” citations (dossier
  §32b now exists), dossier §32 “Python-only” framing, lod-architecture
  §4.1 tiled-vs-shipped ambiguity, parity-JSON Phase-4 scoping.

### WP1 — Rust tile store ABI ([#8](https://github.com/CurateLabs/xyg/issues/8))

- [x] `xyg_pyramid_spill` / `xyg_tile_store_fetch` / `xyg_tile_store_compose` /
  `_compose_color` / `_append` / `_stats` / `xyg_tile_budget_set` /
  `xyg_tile_store_free` — ABI 73 in `crates/xyg-core`; regenerate via
  `python3 scripts/gen_abi_manifest.py --write`; `scripts/abi_smoke.py` covers
  spill→fetch→compose goldens.
- [x] LRU under process-wide `PYRAMID_RESIDENT_BYTES` default (512 MiB) per D2–D3;
  frame pinning + `over_budget` recording; spill file is `XYTS` fixed slabs
  (pread/pwrite realization of D1 mmap layout — no mmap crate vendored).
  Registered operations use a bounded kernel operation lock and process-wide
  recency clock, choosing the deterministic oldest unpinned `(tick, store
  handle, tile key)` across siblings. The lock order prevents cross-store
  eviction deadlocks and an idle figure cannot make a fitting active frame
  report a false over-budget condition.
- [x] Compose-from-tiles shares `LevelView` / `compose_level` with in-RAM compose
  (bit-identical). Count-only dirty-tile append; colored refuse; domain growth
  refused atomically.
- [ ] Zone-map-pruned tile index for unordered scatter (D5) — companion path;
  MVP uses closed-form slab offsets; zone-map rebuild wiring remains available
  via existing `xyg_zone_maps_*` for WP2/WP4 dirty rebuilds.

### WP2 — Hosts ([#9](https://github.com/CurateLabs/xyg/issues/9))

- [x] Python: wire spill behind `no_rescan` / memmap / `n > PYRAMID_NO_RESCAN_ROWS`
  or the public scatter option `pyramid_spill=True`; `None` retains automatic
  policy and invalid non-booleans fail before ingest.
- [x] Node: mirror the option as `pyramidSpill` (with `pyramid_spill` accepted
  at the host boundary) in `packages/xy-node/src/pyramid.js`; both spellings
  require an actual boolean and composed marks preserve the option unchanged.
- [x] An explicit spill request fails with an actionable temporary-directory
  error when the store cannot be created; only automatic spill may retain the
  RAM pyramid as a safe fallback.
- [x] First paint + `density_view` prefer spilled tiles when the resident pyramid
  would exceed budget.

### WP3 — Client (implemented, [#10](https://github.com/CurateLabs/xyg/issues/10))

- Tile-keyed density cache in `js/src/45_lod.ts` (Phase-3 item 8) reuses
  Rust-served `(generation, level, tx, ty)` textures. Binary XYDC inventory
  observations and XYDT painter frames keep level, encoding and retention
  policy in Rust. See [density-tile-painter.md](density-tile-painter.md) for
  the exact format, unchanged eight-screen-texture ceiling, explicit GPU
  resource coarsening exception to adjacent changes, and cached/fetch-all
  pixel/upload proofs. D3 CPU pinning behavior is unchanged.

### WP4 — Evidence ([#11](https://github.com/CurateLabs/xyg/issues/11))

- [x] MB-scale spill fixtures, hit/miss counters, screen-bounded compose,
  count/mean-color golden parity, dirty append/rebuild, colored refusal,
  predicate bypass, process-wide budget pressure and failed-I/O cleanup.
  The [testing contract](tier3-testing.md) maps these to Rust/Python/Node
  tests and explicitly forbids 1B-row CI fixtures.
- [x] Independently pinned structural report verification for both bounded
  host harnesses; raw samples and native/source hashes accompany results.
- [x] Bounded count/color spill/fetch/compose benchmark definitions in the
  existing scheduled/manual main CodSpeed suite. Actual main run 40055566017
  passed all 131 Python benchmarks, including these eight cases, and uploaded
  simulation data. Its [retained execution receipt](../../benchmarks/results/codspeed-spill-2026-10-24/hosted-main/README.md)
  binds source, full job log and metadata; no numerical CPU-work export or
  before/after speedup is inferred from that log.
- [x] Dedicated colored-spill 100M memmap **host/kernel** pan/zoom latency,
  independently pinned budgets and raw results: clean-main run 40055564684,
  [retained evidence](../../benchmarks/results/colored-spill-2026-10-24/hosted-main/README.md).
  Pan p95 0.37907085 ms, slowest zoom 8.125563 ms; sampled tile residency fits
  16 MiB. This does not establish browser continuity or larger-than-RAM behavior.
- [x] Same colored-spill source scripted real-browser continuity and pixels:
  clean-main run 40063864999 passed 33 framebuffer matches, eight adjacent
  fades and zero seam error at 100M with production base 4096. The
  [raw host/companion receipt](../../benchmarks/results/colored-spill-browser-2026-10-24/hosted-main/README.md)
  records SwiftShader and deterministic presentation, with complete cleanup.
- [ ] Accelerated owned-allocation/normal-cadence 100M evidence: the retained
  schema-1 software receipt excludes pre-hook initial textures. The implemented
  [schema-3 companion](density-spill-browser-evidence.md) accounts all owned
  texture/buffer storage and deletion and adds a separate normal product-RAF
  journey. Its optional existing-M4 manual mode fails closed on software or
  missing renderer/observer before source allocation. Actual accepted-main
  run 40639793475 on `fe7d2ae7` failed the unchanged Apple-M4 renderer guard:
  Chromium identified an Apple Paravirtual Metal device. Its
  [failed preflight receipt](../../benchmarks/results/colored-browser-hardware-2026-10-28/hosted-main-fe7d2ae7/README.md)
  retains successful WebGL2 readback and browser/profile cleanup, but no control,
  100M worker, chart resource trace or verifier pair ran. Actual accelerated
  100M owned-allocation/normal-RAF acceptance remains open. Total driver VRAM
  stays unqueryable. No universal
  FPS gate or new runner/capacity is introduced; broader headline gaps remain.
- [ ] Comparable live competitive evidence and explicit scale limitations.
  Actual-main run 40618320164 now passes the structural contract for all
  1M/100M/1B × three arms × two repetitions; the
  [raw receipt](../../benchmarks/results/live-aggregation-2026-10-28/hosted-main-d005b006/README.md)
  preserves 576 warm windows, 18 empty controls and numerical source/grid
  proofs. Programmatic clocks and unequal grid/shading/validation work do not
  establish a normalized winner; colored competitive and natural-gesture
  parity, cold-disk and larger-than-RAM evidence remain outstanding.

## Exit criteria

- [ ] Colored 100M–class scatter pans without blanking; mean-color tiles match
      oracle within recorded u16 quantization. The scripted 100M companion
      and native oracle now pass; broader headline behavior remains open.
- [x] Resident tile bytes stay under configured budget while canonical rows
      remain memmap’d: the 100M run retained three f64 mappings totaling 2.4 GB and
      maximum sampled tile residency 16,517,088 bytes under 16 MiB, with
      `over_budget: false`; fixtures enforce the policy beyond these samples.
- [x] Python ↔ Node count and mean-color goldens for the same spilled inputs
      (`test_phase4_tile_spill_hosts.py` / `pyramid.test.mjs`). This bounded
      seam proof does not substitute for the 100M or final-host matrix.
- [x] Specs + `dual-host-parity.json` distinguish implemented WP1–WP3 bounded
      capabilities from the outstanding #11/#5 scale and Phase-4 exit evidence.

## References

- [lod-architecture.md](lod-architecture.md) §4.1–4.4, Phase 3–4
- [tier3-testing.md](tier3-testing.md)
- [xy-coverage.md](xy-coverage.md)
- [host-parity.md](host-parity.md) — three runtime surfaces
- Dossier §27 (rebuildable caches), §28 (recorded decisions), §32 / §32b


## Canonical-column continuation (#110)

The local ordered XYGC path now validates fetched detail slabs against admitted
zone-map extrema and ordering and cancels stale empty nonpaged reads. The
bounded failure proof is described in [tier3-testing.md](tier3-testing.md).
This advances #110 independently while #11/#5 still require successful
accelerated 100M browser evidence and normalized competitive/remaining headline
proof. At that failure-repair checkpoint, chunk reuse, full cross-host/WASM
orchestration, larger-than-RAM journeys,
shared-context dashboards (#111) and indexed linked views (#112) remained open;
that change added no completion claim or revised resource/performance budget.


The next bounded continuation implements local canonical chunk reuse in both
read modes, with exact row identity, shared per-open deterministic LRU, actual
positioned-fetch counters and generation-safe serialized residency accounting.
See [rust-engine.md §5.1a](rust-engine.md#51a-bounded-local-canonical-chunk-reuse-110)
and [the focused proof](tier3-testing.md#bounded-canonical-chunk-reuse-proof-110).
This fulfills the local resident-overlap read contract only. #110 still needs
larger-than-RAM first paint/navigation and latency/RSS evidence, chart-lifecycle
overview/detail integration, complete host orchestration and direct browser/WASM
support, unordered spatial localization, and remote range artifacts if supported.
#109/#113 remain gated by those journeys plus #5/#11 accepted-main accelerated
100M proof, #111 shared-GPU dashboards and #112 Filter Tier C. No hardware gate,
WASM limit, quality tolerance, benchmark workflow or milestone closure changes.


## Bounded local chart snapshots (#110 continuation)

Python `ChunkedColumns.chart()` and Node `ChunkedColumns.chart()` now compose
precomputed overview points without detail reads. An explicit x range, with an
optional y predicate, asks Rust to admit the complete selected canonical byte
count under the declared scene budget before any page I/O. Rust reuses its
existing page selector and per-open LRU, applies the exact predicate, and returns
canonical physical row IDs with generation and I/O provenance. The adapters
compose the ordinary scatter renderer, with no alternative overview sampler.
Python uses `source_row_ids` / `source_provenance`; Node uses `sourceRowIds` /
`sourceProvenance`. Row IDs are source metadata alongside the snapshot; browser
pick indices remain snapshot-local and require mapping through these arrays.

These are programmatic viewport snapshots, not an automatic widget/app gesture
bridge. Hosts retain the open source while requesting successive viewports;
`close()` deterministically releases native source residency. Previously returned
charts remain independent snapshots. Overview charts use the same monotonic generation watermark as detail charts, with admission and final native output-publication checks; stale overview requests never receive host-stamped success provenance. The explicit static `overview()` metadata API remains generation-independent. Caller retention of many snapshots is not
bounded by the source cache. Scene budget defaults to 4 MiB canonical input;
page budget defaults to 1 MiB and may not exceed scene budget. Scratch, returned
vectors, IDs, composition copies, metadata and renderer allocations are additional;
these are not a total RSS guarantee. Requests exceeding either declared budget
fail closed, without truncated output or a new tier decision. A viewport snapshot
may contain many pages, but cannot admit unbounded detail across those pages.

Bounded native correctness and Python/Node composition tests run through existing
cargo/pytest/npm commands. The headless Python test compares overview, viewport,
programmatic pan and deep-zoom pixels exactly with a full-scan oracle; it requires
`XYG_TEST_CHROMIUM`. The normal native Python CI step aliases its installed Playwright Chromium into that variable and requires browser execution; absent configuration fails instead of skipping when `XY_REQUIRE_BROWSER=1`. Workflow negative controls forbid removal of either binding. The retained
receipt is `spec/performance/chunked-chart-snapshots-2026-11-07/README.md`.
No larger-than-RAM, automatic live refinement, browser/WASM orchestration,
competitive performance, remote-source or full #110/#109/#113 acceptance claim
follows from this bounded snapshot integration.

Native chunked-chart viewport continuation and its remaining acceptance are specified
in [the local native viewport contract](chunked-native-viewport.md).
