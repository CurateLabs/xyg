import os,subprocess as S,json,pathlib as P
root=P.Path.cwd();out=P.Path('/var/tmp/xyg-pr1114-ci');env=dict(os.environ,PATH='/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin:'+os.environ['PATH'],TMPDIR='/var/tmp',XYG_NATIVE_LIB=str(root/'target/release/libxyg_core.so'),PYTHONPATH=str(root/'python'),XYG_TEST_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome',XYG_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome');sha=S.check_output(['git','rev-parse','HEAD'],text=True).strip();env.update(GITHUB_SHA=sha,GITHUB_WORKSPACE=str(root));results={}
def run(name,args,**kwargs):
 with (out/(name+'.log')).open('w') as f:
  try:exit=S.run(args,env=kwargs.get('env',env),stdout=f,stderr=S.STDOUT,timeout=300).returncode
  except S.TimeoutExpired:exit=124
 results[name]={'command':args,'exit':exit};(out/'validation.json').write_text(json.dumps(results,indent=2)+'\n');print(name,exit,flush=True);return exit
for version,py in [('312','/var/tmp/xyg-pr1114-ci/venv312/bin/python'),('311',str(root/'.venv/bin/python'))]:
 if version=='312':
  host=out/'after312-host.json';browser=out/'after312-browser.json'
  run('after312',[py,'benchmarks/bench_density_e2e.py','--workload','colored-spill','--points','16384','--chunk-points','4096','--chrome',env['XYG_CHROMIUM'],'--timeout','180','--max-rss-gib','4','--max-disk-gib','1','--output',str(host),'--colored-browser-report',str(browser)])
 else:host=out/'after311-host.json';browser=out/'after311-browser.json'
 run('host-verify'+version,[py,'scripts/verify_density_spill_report.py',str(host),'--artifact-root',str(root)])
 run('browser-verify'+version,[py,'scripts/verify_density_spill_browser_report.py',str(browser),'--host-report',str(host),'--sha',sha,'--artifact-root',str(root)])
 run('report-tests'+version,[py,'-m','pytest','tests/test_density_spill_browser_report.py','-q','--basetemp',str(out/('pytest-'+version))],env=dict(env,GITHUB_REF='refs/heads/main'))
 # All direct negatives use real native paint and browser controls, including
 # blank/gutter, late replies, malformed frames, owned deletion and normal RAF.
 run('browser-tests'+version,[py,'-m','pytest','tests/test_density_spill_browser.py','-q','--basetemp',str(out/('pytest-browser-'+version))])
