export { attachFilterDashboard } from "./49_filter_dashboard";
import { renderGraphHost } from "./66_graph_host";
import { renderGeoHost } from "./65_geo_host";
export { XygGeoHostView } from "./65_geo_host";
export type { XygGeoHostComm } from "./65_geo_host";
import { bytesToSpan, decodeFrame, payloadBuffers, payloadCoherent, PROTOCOL } from "./00_header";
import { ChartView } from "./50_chartview";
import { MARK_KINDS, markOf } from "./55_marks";
import { createXygWasmWorker, XygWasmError, XygWasmWorker } from "./47_wasm";
export { encodeWasmDashboardPlan, decodeWasmDashboardPlan, planWasmDashboardResources, applyWasmDashboardResourceBudget, watchWasmDashboardResourceBudget } from "./49_wasm_dashboard";
export type { XygWasmDashboardResource, XygWasmDashboardAdmissionController } from "./49_wasm_dashboard";
import {
  attachWasmTicks,
  decodeWasmTickBatch,
  encodeWasmTickBatch,
  resolveWasmTicks,
  XygWasmTicksHandle,
} from "./49_wasm_ticks";
export type {
  XygWasmTickAxisRequest,
  XygWasmTickAxisResult,
  XygWasmTickBatchRequest,
  XygWasmTickBatchResult,
  XygWasmTickFamily,
  XygWasmTickProvenance,
  XygWasmTicksDiagnostics,
  XygWasmTicksOptions,
} from "./49_wasm_ticks";
import { hydrateWasmPainter, renderWasmScene } from "./48_wasm_scene";
import {
  compilePrepareWasmScene,
  compileWasmScene,
  encodeWasmColumns,
  renderWasmColumns,
} from "./49_wasm_columns";
import { frameWasmChart, renderWasmChart } from "./49_wasm_chart";
import {
  aggregateWasmBin2d,
  decodeWasmAggregateOutput,
  encodeWasmAggregate,
} from "./49_wasm_aggregate";
import { attachInlineStandaloneWasmDensity, attachStandaloneWasmDensity, attachWasmDensity, provisionKernelWasmDensity, XygWasmDensityHandle } from "./49_wasm_density";
import { XygWasmTemporalController } from "./49_wasm_temporal";
import { XygWasmTemporalGraph, decodeWasmTemporalGraphFrame, encodeWasmTemporalGraphCreate, encodeWasmTemporalGraphFrame } from "./49_wasm_temporal_graph";
import { decodeWasmGraphCheckpoint, encodeWasmCose, layoutWasmCose } from "./49_wasm_graph";
import {
  XygGraphForgeComposition,
  composeWasmGraphForge,
  decodeWasmGraphForgeDocument,
  encodeWasmGraphForgeRequest,
  graphforgeTableElement,
  renderWasmGraphForge,
} from "./49_wasm_graphforge";
import {
  compilePrepareWasmSemanticGraph,
  compileWasmSemanticGraph,
  encodeWasmSemanticGraph,
  renderWasmSemanticGraph,
} from "./49_wasm_semantic_graph";
import { decodeWasmCompoundTransition, encodeWasmCompoundTransition, transitionWasmCompound } from "./49_wasm_compound";
// Prototype-augmentation modules: imported for their side effect of attaching
// methods to ChartView.prototype. Every entry point must load them before the
// first ChartView is constructed.
import "./51_annotations";
import "./52_tooltip";
import "./53_interaction";
import "./54_kernel";
import "./56_animation";
import "./57_viewstate";
// Optional graph enhancement (CSR neighborhood dim on node hover). Geometry
// for graph charts is ordinary segments + scatter via MARK_KINDS; omitting
// this import still paints every mark including graph wire traces.
import "./58_graph";

// ---------------------------------------------------------------------------
// Entry points
// ---------------------------------------------------------------------------

function attachHostWasmTicks(view: ChartView & { _dispatchChartEvent?: Function }, spec: { wasm_ticks?: unknown }) {
  const assets = spec?.wasm_ticks as
    | { workerUrl?: unknown; worker_url?: unknown; wasm?: unknown }
    | null
    | undefined;
  if (assets == null) {
    view._publishTickFailure?.();
    return;
  }
  const workerUrl = assets.workerUrl ?? assets.worker_url;
  const wasm = assets.wasm;
  const observer = (globalThis as { __xygStandaloneObserver?: (event: object) => void }).__xygStandaloneObserver;
  const fail = (code: string, message: string, diagnostics: unknown = null) => {
    view._recordTickFailure?.(code, message);
    view._dispatchChartEvent?.("wasm_ticks_error", { code, message, diagnostics });
    if (typeof observer === "function") observer({ phase: "ticks_error", code, message });
  };
  if (typeof workerUrl !== "string" || !workerUrl || typeof wasm !== "string" || !wasm) {
    fail("XYG_WASM_UNAVAILABLE", "wasm_ticks requires explicit workerUrl and wasm");
    return;
  }
  const blocked = /^(blob:|data:|javascript:)/i;
  if (blocked.test(workerUrl) || blocked.test(wasm) || workerUrl.startsWith("//") || wasm.startsWith("//")) {
    fail("XYG_WASM_UNAVAILABLE", "wasm_ticks URLs must be explicit same-origin paths, not blob/data/CDN");
    return;
  }
  try {
    const worker = createXygWasmWorker({ workerUrl, wasm });
    void attachWasmTicks(view, { worker, workerOwnership: "own" }).then((handle) => {
      (globalThis as { __xygWasmTicks?: unknown }).__xygWasmTicks = handle;
      if (typeof observer === "function") observer({ phase: "ticks_ready", diagnostics: handle.diagnostics() });
    }).catch((cause) => {
      const code = cause instanceof XygWasmError ? cause.code : "XYG_WASM_UNAVAILABLE";
      const message = cause instanceof Error ? cause.message : "wasm tick provisioning failed";
      if (typeof observer === "function") observer({ phase: "ticks_error", code, message });
    });
  } catch (cause) {
    const code = cause instanceof XygWasmError ? cause.code : "XYG_WASM_UNAVAILABLE";
    const message = cause instanceof Error ? cause.message : "wasm tick provisioning failed";
    fail(code, message, cause instanceof XygWasmError ? cause.diagnostics ?? null : null);
  }
}

export function render({ model, el }) {
  const spec = model._xygChunkedPacket?.spec || model.get("spec");
  if (spec?.graph_host === true) return renderGraphHost({model,el,attachTicks:attachHostWasmTicks});
  if (spec?.geo_host === true) return renderGeoHost({model,el});
  const buffer = payloadBuffers(spec, model._xygChunkedPacket?.buffers || model.get("buffers"));
  if (spec.chunked && model._xygChunkedActiveView) {
    const old = model._xygChunkedActiveView;
    model._xygChunkedSavedState = {state: old.root.xy.state(), past: old._historyPast, future: old._historyFuture};
  }
  const epochKey = Symbol.for("xyg.chunked.mount.epoch");
  const epochOwner: any = el.ownerDocument.defaultView || globalThis;
  const epoch = BigInt(spec.chunked?.mount_epoch || "0") > (epochOwner[epochKey] || 0n)
    ? BigInt(spec.chunked.mount_epoch) : (epochOwner[epochKey] || 0n);
  const chunkedEpoch = String(epochOwner[epochKey] = epoch + 1n);
  const chunkedMount = spec.chunked ? Array.from(crypto.getRandomValues(new Uint32Array(4))).join("-") : null;
  let chunkedIntent = 0n;
  let chunkedFrame = spec.chunked?.frame;
  const comm = {
    send: (msg, buffers = []) => {
      if (chunkedMount) {
        msg = {...msg, mount: chunkedMount, chunked_frame: chunkedFrame};
        if (msg.type === "view_change") msg.chunked_intent = String(++chunkedIntent);
      }
      model.send(msg, {}, buffers);
    },
    // Read the live spec: appends re-sync it, and the transport flag must
    // survive them (it is re-applied kernel-side on every append).
    wantsViewChange: () => model.get("spec")?.interaction?._transport_view_change === true,
    onMessage: (cb) => {
      const handler = (content, buffers) => cb(content, buffers);
      model.on("msg:custom", handler);
      return () => model.off?.("msg:custom", handler);
    },
  };
  const view = new ChartView(el, spec, buffer, comm);
  if (chunkedMount) {
    model._xygChunkedActiveView = view;
    model.send({type: "chunked_mount", mount: chunkedMount, mount_epoch: chunkedEpoch, chunked_frame: chunkedFrame}, {}, []);
    const saved = model._xygChunkedSavedState || (spec.chunked.state ? {state: spec.chunked.state, past: [], future: []} : null);
    if (saved) {
      view.root.xy.applyState(saved.state, {animate: false, history: false});
      view._historyPast = saved.past; view._historyFuture = saved.future;
    }
    const onChunkedFrame = (msg, buffers) => {
      if (msg?.type === "chunked_error" && msg.mount === chunkedMount && msg.intent === String(chunkedIntent)) {
        view._dispatchChartEvent("chunked_error", {error: msg.error, view: view.root.xy.state()});
        return;
      }
      if (msg?.type !== "chunked_frame" || msg.mount !== chunkedMount) return;
      const reject = () => model.send({type: "chunked_rejected", mount: chunkedMount,
        intent: msg.intent, frame: msg.spec?.chunked?.frame}, {}, []);
      if (model._xygChunkedActiveView !== view || msg.intent !== String(chunkedIntent)) { reject(); return; }
      if (view._applyChunkedFrame(msg, buffers)) {
        chunkedFrame = msg.spec.chunked.frame;
        model._xygChunkedPacket = {spec: view.spec, buffers};
        model.send({type: "chunked_painted", mount: chunkedMount,
          intent: msg.intent, frame: chunkedFrame}, {}, []);
        // Expose the frame only after the comm's pick/selection token advanced
        // and its genuine paint acknowledgement was queued first.
        view._dispatchChartEvent("chunked_frame", {frame: chunkedFrame, view: view._eventView("refine"), memory: view._chunkedMemoryReport()});
        if (view._stateSelection && !view._stateSelection.rows) {
          view.root.xy.applyState({selection: view._stateSelection}, {animate: false, history: false});
        }
      } else reject();
    };
    model.on("msg:custom", onChunkedFrame);
    view._chunkedCleanup = () => {
      model.off?.("msg:custom", onChunkedFrame);
      if (model._xygChunkedActiveView === view) {
        model._xygChunkedSavedState = {state: view.root.xy.state(), past: view._historyPast, future: view._historyFuture};
        model._xygChunkedActiveView = null;
      }
      model.send({type: "chunked_unmount", mount: chunkedMount}, {}, []);
    };
  }
  attachHostWasmTicks(view, spec);
  // Streaming append rides the spec+buffers trait update itself (§29): one
  // comm message per tick that doubles as notebook-reopen state. A fresh
  // render above already painted the streamed state, so only a *subsequent*
  // advance of `spec.append.seq` applies as an incremental append.
  //
  // Hosts are not guaranteed to set the two traits atomically: one change
  // event may fire between the spec write and the buffers write (in either
  // order). Both events funnel here, a torn pair (a column that no longer
  // fits its buffer) defers without consuming the seq, and applied state is
  // keyed on (seq, buffers identity) — so if a same-length torn pair slips
  // past the fit check, the buffers' own change event re-applies and repairs.
  const applied = { seq: spec.append?.seq ?? null, buffers: model.get("buffers") };
  const onAppendState = () => {
    const nextSpec = model.get("spec");
    const tag = nextSpec?.append;
    if (!tag) return;
    const nextBuffers = model.get("buffers");
    if (tag.seq === applied.seq && nextBuffers === applied.buffers) return;
    if (!payloadCoherent(nextSpec, nextBuffers)) return; // torn: wait for the pair
    applied.seq = tag.seq;
    applied.buffers = nextBuffers;
    view._applyAppend({ type: "append", affected: tag.affected, spec: nextSpec }, nextBuffers);
  };
  model.on("change:spec", onAppendState);
  model.on("change:buffers", onAppendState);
  return () => {
    model.off?.("change:spec", onAppendState);
    model.off?.("change:buffers", onAppendState);
    view._chunkedCleanup?.();
    view.destroy();
  };
}

/** Standalone (static HTML export — no kernel). Retains typed CPU views of
 * shipped channels so hover can read approximate values without a kernel (§37). */
export function renderStandalone(el, spec, arrayBuffer) {
  const buffer = bytesToSpan(arrayBuffer);
  const view = new ChartView(el, spec, buffer, null);
  const column = (idx) => view._columnView(buffer, spec.columns[idx]);
  for (const g of view.gpuTraces) {
    if (markOf(g.trace.kind).retainCpu && g.tier !== "density") {
      // Ribbon build retains its six specialized geometry columns directly in
      // `_cpuRibbon`; it has no generic trace.x/trace.y wire fields. Trying to
      // load those nonexistent fields aborts standalone hydration after the
      // first paint and leaves hover without a usable ChartView.
      if (g._cpuRibbon) continue;
      if (!Number.isInteger(g.trace.x) || !Number.isInteger(g.trace.y)) continue;
      g._cpu = {
        x: column(g.trace.x),
        y: column(g.trace.y),
        xMeta: g.xMeta,
        yMeta: g.yMeta,
      };
      if (g.trace.color && Number.isInteger(g.trace.color.buf)) {
        g._cpu.color = column(g.trace.color.buf);
      }
      if (g.trace.size && Number.isInteger(g.trace.size.buf)) {
        g._cpu.size = column(g.trace.size.buf);
      }
    }
  }
  // `to_html()` embeds the checked bytes plus a classic IIFE only for density
  // documents. This establishes the Rust-owned path without a module URL or
  // network fetch. An unavailable/invalid artifact deliberately leaves the
  // existing Rust-authored overview in place; it never starts a JavaScript
  // aggregation fallback.
  const inline = (globalThis as any).__xygInlineWasm;
  const observer = (globalThis as any).__xygStandaloneObserver;
  // This opaque capability exists only when CDP has installed the evidence
  // observer. Normal self-contained exports do not expose failure controls.
  const evidenceCapability = typeof observer === "function"
    ? `xyg-evidence-${crypto.getRandomValues(new Uint32Array(6)).join("-")}` : undefined;
  let densityHandle: XygWasmDensityHandle | null = null;
  const attachInline = async () => {
    if (!inline) return null;
    const handle = await attachInlineStandaloneWasmDensity(view, { inline, delay: 0, evidenceCapability });
    densityHandle = handle;
    return handle;
  };
  const densityTraces = view.gpuTraces.filter((g: any) => g.tier === "density");
  const retainedDensity = densityTraces.some((g: any) => g.sampleOverlay?._cpu);
  if (densityTraces.length && !inline) {
    view._reportDensityNoRefinement?.("XYG_WASM_UNAVAILABLE", "self-contained Rust/WASM density artifact is unavailable");
  } else if (densityTraces.length && !retainedDensity) {
    view._reportDensityNoRefinement?.("XYG_WASM_SOURCE_UNAVAILABLE", "density refinement requires a retained typed source");
  } else if (inline && retainedDensity) {
    void attachInline().then((handle) => {
      if (!handle) return;
      // The exported document has no kernel viewport message to trigger the
      // first refinement. Start the initial Rust-owned grid explicitly.
      handle.schedule(view.view, { delay: 0, force: true });
      if (typeof observer === "function") observer({ phase: "density_ready", diagnostics: handle.diagnostics() });
    }).catch((cause) => {
      const code = cause instanceof XygWasmError ? cause.code : "XYG_WASM_UNAVAILABLE";
      const message = cause instanceof Error ? cause.message : "inline WASM density provisioning failed";
      view._reportDensityNoRefinement?.(code, message);
      if (typeof observer === "function") observer({ phase: "density_no_refinement", code, message });
    });
  }
  // Test/host observability only: no runtime policy is selected from this
  // hook. It lets strict-CSP file evidence distinguish successful attachment
  // from a later density worker failure.
  attachHostWasmTicks(view, spec);
  if (typeof observer === "function") observer({ phase: "attached", inline: !!inline, view });
  if (typeof observer === "function") (globalThis as any).__xygStandaloneDensityControl = {
    home: () => {
      const revision = densityHandle?.schedule(view.view0, { delay: 0, force: true });
      observer({ phase: "home", revision: revision || null }); return revision;
    },
    zoom: () => {
      const revision = densityHandle?.schedule({ ...view.view, x0: view.view.x0 + 1, x1: view.view.x1 - 1 }, { delay: 0, force: true });
      observer({ phase: "zoom", revision: revision || null });
      if (revision) observer({ phase: "revision", revision }); return revision;
    },
    supersede: () => {
      const oldRevision = densityHandle?.schedule(
        { ...view.view, x0: view.view.x0 + 0.5, x1: view.view.x1 - 0.5 },
        { delay: 0, force: true },
      );
      const revision = densityHandle?.schedule(
        { ...view.view, x0: view.view.x0 + 1, x1: view.view.x1 - 1 },
        { delay: 0, force: true },
      );
      observer({ phase: "superseded", oldRevision: oldRevision || null, revision: revision || null });
      return { oldRevision, revision };
    },
    diagnostics: () => densityHandle?.diagnostics() || null,
    payload: () => {
      const density = densityTraces[0]?.density;
      const bytes = (density?.grid?.byteLength || 0) + (density?.rgba?.byteLength || 0);
      return { bytes, xRange: density?.xRange || null, yRange: density?.yRange || null };
    },
    cancel: () => {
      densityHandle?.schedule({ ...view.view, x0: view.view.x0 + 1, x1: view.view.x1 - 1 }, { delay: 100 });
      densityHandle?.cancel(); observer({ phase: "cancelled" });
    },
    malformed: async () => {
      try { await densityHandle?.evidenceLifecycle("malformed"); }
      catch (cause) { observer({ phase: "malformed", code: cause instanceof XygWasmError ? cause.code : "XYG_WASM_WORKER_ERROR" }); return; }
      throw new Error("malformed lifecycle evidence unexpectedly succeeded");
    },
    resource: async () => {
      try { await densityHandle?.evidenceLifecycle("resource"); }
      catch (cause) { observer({ phase: "resource", code: cause instanceof XygWasmError ? cause.code : "XYG_WASM_WORKER_ERROR" }); return; }
      throw new Error("resource lifecycle evidence unexpectedly succeeded");
    },
    trap: async () => {
      try { await densityHandle?.evidenceLifecycle("trap"); }
      catch (cause) {
        observer({ phase: "trap", code: cause instanceof XygWasmError ? cause.code : "XYG_WASM_WORKER_ERROR" });
        await densityHandle?.dispose(); densityHandle = null;
        const recovered = await attachInline();
        recovered?.schedule(view.view, { delay: 0, force: true });
        observer({ phase: "recovered", diagnostics: recovered?.diagnostics() || null }); return;
      }
      throw new Error("trap lifecycle evidence unexpectedly succeeded");
    },
    dispose: async () => { await densityHandle?.dispose(); densityHandle = null; observer({ phase: "disposed" }); },
  };
  return view;
}

// Public API. The ESM bundle (static/index.js, anywidget's `_esm`) re-exports
// these directly; the IIFE bundle (static/standalone.js) exposes the same
// namespace as `window.xy`.
export {
  decodeFrame,
  PROTOCOL,
  ChartView,
  MARK_KINDS,
  markOf,
  createXygWasmWorker,
  XygWasmError,
  XygWasmWorker,
  attachWasmTicks,
  attachHostWasmTicks,
  decodeWasmTickBatch,
  encodeWasmTickBatch,
  resolveWasmTicks,
  XygWasmTicksHandle,
  renderWasmScene,
  hydrateWasmPainter,
  encodeWasmColumns,
  compileWasmScene,
  compilePrepareWasmScene,
  renderWasmColumns,
  frameWasmChart,
  renderWasmChart,
  encodeWasmAggregate,
  decodeWasmAggregateOutput,
  aggregateWasmBin2d,
  attachWasmDensity,
  attachInlineStandaloneWasmDensity,
  attachStandaloneWasmDensity,
  provisionKernelWasmDensity,
  XygWasmDensityHandle,
  XygWasmTemporalController,
  XygWasmTemporalGraph,
  decodeWasmTemporalGraphFrame,
  encodeWasmTemporalGraphCreate,
  encodeWasmTemporalGraphFrame,
  encodeWasmCose,
  decodeWasmGraphCheckpoint,
  layoutWasmCose,
  encodeWasmSemanticGraph,
  compileWasmSemanticGraph,
  compilePrepareWasmSemanticGraph,
  renderWasmSemanticGraph,
  encodeWasmCompoundTransition,
  decodeWasmCompoundTransition,
  transitionWasmCompound,
  XygGraphForgeComposition,
  composeWasmGraphForge,
  decodeWasmGraphForgeDocument,
  encodeWasmGraphForgeRequest,
  graphforgeTableElement,
  renderWasmGraphForge,
};
export type { XygWasmAggregateTaskOptions } from "./47_wasm";
export type {
  XygStandaloneWasmDensityOptions,
  XygWasmDensityInput,
  XygWasmDensityOptions,
  XygWasmDensityDiagnostics,
} from "./49_wasm_density";
export type {
  XygTemporalControllerOptions,
  XygTemporalEvent,
  XygTemporalResult,
  XygTemporalState,
} from "./49_wasm_temporal";
export type { XygWasmCoseOptions, XygWasmGraphCheckpoint, XygWasmGraphRequest } from "./49_wasm_graph";
export type { XygTemporalPlane, XygWasmTemporalGraphBinding, XygWasmTemporalGraphFrame, XygTemporalGraphControllerBinding } from "./49_wasm_temporal_graph";
export type { XygWasmSemanticGraphInput } from "./49_wasm_semantic_graph";
export type { XygCompoundAction, XygWasmCompoundTransitionInput, XygWasmCompoundTransitionResult } from "./49_wasm_compound";
export type { XygGraphForgeInput, XygGraphForgeLayerInput, XygGraphForgeIdentity, XygGraphForgeIntent, XygWasmGraphForgeView } from "./49_wasm_graphforge";
export default { render, decodeFrame };

export { encodeWasmGeoDescriptor, encodeWasmGeoSceneRequest } from "./49_wasm_geo";
export type { XygGeoDescriptor, XygFrozenGeoScene } from "./49_wasm_geo";

export { GEO_VIEWPORT_OPERATIONS, encodeGeoViewportRequest, encodeGeoViewportColumnRequest, decodeGeoViewportResponse } from "./49_wasm_geoviewport";
export type { XygGeoCamera } from "./49_wasm_geoviewport";

export { encodeGeoCatalogRequest, decodeGeoCatalogResponse } from "./61_geo_catalog";
export type { XygGeoCatalogRequest, XygGeoCatalogLayer, XygGeoStylePatch } from "./61_geo_catalog";
export { createMapLibreGeoLayer } from "./59_maplibre_geo";
export type { GeoMapShell, MapLibreGeoLayerOptions } from "./59_maplibre_geo";

export { XygGeographicChart } from "./62_geographic_controller";
export type { GeographicChartOptions } from "./62_geographic_controller";
export type { RetainedGeographicChartOptions, RetainedGeoFrameSummary } from './64_geo_retained_controller';
export type { OverviewGeographicChartOptions, OverviewGeoFrameSummary } from './71_geo_overview_controller';
export { GeoOverviewIndex, GeoOverviewFrame, GeoOverviewQuery, GeoOverviewUncertainAllocation, GeoOverviewUnsupportedDomain } from './71_geo_overview_owner';
export type { GeoOverviewBuildInput } from './71_geo_overview_owner';
export { encodeGeoScaleRequest, encodeGeoScaleStyle, encodeGeoChunkRequest, decodeGeoScaleReply, driveGeoSession, prepareGeoSceneData } from './63_geo_source';
export type { XygGeoScaleBridge, XygGeoScaleQuery, XygGeoQueryBudget, XygGeoTime, XygGeoReadTicket } from './63_geo_source';
export type { XygGeoInteractionEvent } from "./61_geo_catalog";

export type { GeoOverviewFrozenBinary, OverviewBinaryFreezeOptions } from './74_geo_overview_snapshot';

export { attachWasmGraphSession } from "./63_graph_controller";
export type { XygWasmGraphSession, XygWasmGraphSessionOptions, XygWasmGraphSnapshot, XygWasmGraphCamera, XygWasmGraphLoad } from "./63_graph_controller";

export { createWasmFilterSession, filterRequest, decodeFilterReply, FilterTierCError } from "./49_filter_session";
export { encodeTemporalScene } from "./75_temporal_scene";
export type { TemporalSceneInput } from "./75_temporal_scene";
export {XygFrozenTemporalGraph} from './67_frozen_graph';
