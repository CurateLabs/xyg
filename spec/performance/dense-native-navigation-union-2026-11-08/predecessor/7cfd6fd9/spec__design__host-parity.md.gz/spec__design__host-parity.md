# Host parity — Python and Node

The browser WASM host retains packed `XYAG` for the compatibility seam and now
exposes `XYAS` v1 for the product-path successor: a header/domain/grid plus
bounded canonical f64 x/y chunks, all binned count-only by Rust and finished as
the existing packed `XYAO`. Hosts may frame and transfer chunks, but cannot
scan, bin, or select a grid/domain policy. Exact mean-color accumulation stays
on the legacy seam until its separately bounded stream contract exists.
Cancellation cleanup and the aggregate peak model remain Rust-owned. Native
hosts continue to use the same `xyg-engine` binning kernels. Wiring streamed
`XYAO` into aggregate production beyond the current density/Scene vertical is
tracked by the post-M2 follow-up **Expand direct-browser aggregate production beyond the density/Scene vertical** (related to [#54](https://github.com/CurateLabs/xyg/issues/54)).

**Status:** requirements locked and **ready for review** with
[graph-fork-requirements.md](graph-fork-requirements.md); implementation design
in [graph-mark.md](graph-mark.md). Runtime taxonomy and machine-readable twin:
[dual-host-parity-matrix.md](dual-host-parity-matrix.md) /
[`dual-host-parity.json`](dual-host-parity.json).

**Scope:** the **entire product** — every chart type and mark family, not
graph-only. Graph is the core dual-host feature, but the three runtime surfaces
and the placement rule below apply to scatter, line, hist, area, bar, box,
heatmap, hexbin, violin, sankey, polar, and every other shipped kind.

**Priority:** **graph visualization** is the core feature. **MVP includes all
chart / visualization features** on Python and Node with equal feel and speed —
no degraded non-graph path, and **no Python host-only layout/encode leftovers**.

**Architecture principle — Rust owns decisions:** implement chart behavior in
the shared Rust C ABI so Python and Node stay thin loaders over identical
behavior. **Rust owns decisions** that affect buffers, layout, encodings, LOD,
and recorded §28 outcomes — not only O(N) loops. Hosts own ergonomics and
idiomatic I/O only; the browser client owns screen-bounded draw and gestures
only. [rust-engine.md](rust-engine.md) §1 states this rule directly for XYG
(upstream XY's "Python owns decisions" is recorded there as historical).

**Host-neutral packaging:** Python exists only when the user is using
Python. Public npm names are `@curatelabs/xyg` (paint client) and
`@curatelabs/xyg-node` (Node host) — never `@xy/node`. Plan:
[host-neutral-architecture.md](host-neutral-architecture.md) / GitHub #24.
The paint-client artifact is in-repo as `@curatelabs/xyg` (#23); registry
publish waits on the `@curatelabs` npm org (#13).

---

## 0. Three runtime surfaces (product-wide)

XYG has exactly **three** runtime surfaces. They cover all chart types. Do not
treat VS Code, notebooks, or Streamlit as separate engine stacks.

| Surface | Location | Role |
|---|---|---|
| **1. Python host** | `python/xyg/` | Primary authoring host for notebooks and Python apps. Loads the Rust cdylib via **ctypes**. Surfaces: **anywidget** notebooks (`show()`), **HTML export** (`to_html()` / standalone), and **Streamlit HTML embedding**. Embeds a **copy** of the paint client plus the packaged `wasm-worker.js` / `xyg-wasm.wasm` tick assets in the wheel (`python/xyg/static/`) so Python users need no Node. The public import is `xyg`; no framework adapter namespace ships. |
| **2. Node host** | `packages/xy-node` (`@curatelabs/xyg-node`) | Thin Node bindings (koffi) over the **same** Rust C ABI. Covers **server-side Node** and **VS Code extensions**: VS Code is a **consumer of the Node bindings**, not a fourth stack. Never publish `@xy/node`. Native loading uses the exact optional platform package (`@curatelabs/xyg-node-<platform>-<arch>`, #52), with only an explicit absolute-path `XYG_NATIVE_LIB` development override; it never searches a checkout, working directory, system path, or Python. Windows arm64 is an explicit unsupported error. Every loading failure is an `XygNativeError` with a stable `code` (`NATIVE_ERROR_CODES`): `XYG_NATIVE_UNSUPPORTED_PLATFORM` (`platform`, `arch`, `supported`), `XYG_NATIVE_LIBRARY_MISSING` (`packageName`, `searched`), `XYG_NATIVE_LIBRARY_PATH_INVALID` (relative `XYG_NATIVE_LIB`), `XYG_NATIVE_LOAD_FAILED` (the library exists but cannot be loaded), and `XYG_NATIVE_ABI_MISMATCH` (`expected`, `actual`; also a matching version that lacks a declared symbol). `@curatelabs/xyg-node/load` exports `loadXygNode()`, which imports no native code itself and resolves to `{ok: true, xyg}` or `{ok: false, code, message}` instead of throwing, so hosts such as VS Code extensions can degrade with a stable diagnostic; its `LOAD_ERROR_CODES` add `XYG_NODE_DEPENDENCY_MISSING` (a JavaScript dependency such as koffi is absent) and `XYG_NODE_IMPORT_FAILED` (any other import failure) so packaging problems never masquerade as native ones. A loadable library without `xyg_abi_version` is `XYG_NATIVE_ABI_MISMATCH` (`actual: null`). Host-facing loading messages carry no filesystem paths or loader text; `libraryPath`, `searched`, and `cause` stay on the thrown error for local debugging. `toHtml()` inlines the host-neutral standalone client, not the Python tree. Root `npm ci` does **not** install this package; CI Test and Python 3.11 jobs run `npm ci --prefix packages/xy-node` so koffi is present for Node host tests. |
| **3. Browser surface** | `js/src/*.ts` + Rust/WASM → `@curatelabs/xyg` (`packages/xy-client/dist/{index,standalone}.js`) | Shared WebGL2 painter and browser lifecycle. It draws §29 buffers uploaded by Python/Node and uses the #59 foundation for direct browser execution by the same Rust engine compiled to WebAssembly in a Worker. TypeScript keeps paint, pick, gestures, accessibility, DOM chrome, transitions, caches, and request scheduling; Rust owns canonical layout/LOD/encode decisions. |

Node/VS Code live GraphForge payloads use a per-view
`GraphForgeLayoutController`: composition and preset packing run in a bridge
Worker, while the existing dedicated force Worker owns native ticks and cleanup.
For non-force layouts, the bridge obtains the complete source layout from the
existing native authority before preset packing. Full source snapshots and
Rust-derived render membership have distinct indexing, including Aggregate.
The [Node scheduling contract](graphforge-node-scheduling.md) defines the async
API and explicit synchronous export route. This adds no engine runtime or
host-owned layout, LOD or style policy. Native loading at module import,
structured cloning and callbacks still cost caller CPU. The local four-node
paint proof establishes neither zero-copy delivery nor large-scale response.

The #59 foundation adds `crates/xyg-wasm`, a generated raw-export adapter,
and an explicit static module Worker. It proves bounded JS→WASM staging,
version/status/lifecycle behavior, exact Scene validation/paint lowering, and
packed typed-column compile into the same canonical Scene batch native hosts
encode. Public `frameWasmChart` / `renderWasmChart` transfer typed series while
Rust assigns identities and expands canonical mark/default geometry. The
current density/Scene vertical is delivered; broader aggregate production is
tracked by the post-M2 follow-up **Expand direct-browser aggregate production beyond the density/Scene vertical** (related to [#54](https://github.com/CurateLabs/xyg/issues/54)). See [browser-wasm.md](browser-wasm.md).

Those typed series use versioned `XYTS` canonical compile ingress: exact raw
f64 source columns move JS → Worker and undergo one bounded copy into WASM.
They are not the live paint wire and are not `XYBF`. Rust alone validates and
lowers them to the shared offset-f32/u8 painter buffer consumed by WebGL; the
browser host has no per-record conversion or policy fallback.
Rust also owns staging-copy and resource accounting. The Worker returns those
counters unchanged on success and attaches them to public `XygWasmError`
failures after initialization; TypeScript neither reconstructs byte counts nor
estimates retained Rust resources.

Dynamic tick resolution is likewise one shared implementation. Packed `XYTK`
parsing, linear/log/symlog/category/time/angular generation, modular authored
filtering, minor subdivision, formatting, and packed `XYTO` output live in
`xyg-engine::packed_ticks`. The seam was introduced in WASM ABI 23 and native
ABI 360; current WASM ABI 27 re-exports that module and current native ABI 361
provides the capacity-aware `xyg_tick_resolve_packed` twin used by Python and
Node. `tests/fixtures/packed_ticks_cross_host.json` is byte-exact across those
two native hosts and the real-browser Worker proof. TypeScript owns viewport
framing/admission and DOM paint only; absent or invalid Rust output fails
closed.

`tests/fixtures/xyts_cross_host.json` is generated from the Rust XYTS decoder,
never authored by a host. Direct WASM recompiles every request and matches the
exact Scene v23 output under a local-only strict CSP. Native Python and Node
load those Scene bytes through the shared `xyg_scene_browser_painter` C ABI and
byte-compare Rust's painter-v13 lowering; the Pyodide wheel executes that same
native ABI inside an actual Pyodide runtime with network access disabled for
the conformance operation. This is intentionally asymmetric: adding an XYTS
decoder to Python or Node would duplicate browser-ingress policy rather than
prove host parity.
Browser-painter admission is the same contract on every host (#1007;
[browser-wasm.md](browser-wasm.md) "Painter admission"). Rust's
`scene::PainterRejection` table is the only classifier: native Python, Node,
and Pyodide read its stable `CODE: detail` diagnostic from the
`xyg_scene_browser_painter` output buffer (Python `ScenePainterError.code`,
Node `RangeError.code`), and the WASM Worker reports the identical text with
its `RESOURCE_LIMIT` / `SCENE_VERSION` / `MALFORMED_SCENE` status.
`tests/fixtures/painter_admission_cross_host.json` is generated by a Rust test
that runs the native seam and the Worker ABI on the same bytes. Its cases are
compact recipes, not stored Scenes: each host rebuilds them through the
Rust-backed `scene_batch_encode` and must match the recorded Scene SHA-256
before comparing painter SHA-256 or diagnostics, so no host re-derives the
1,024-trace or byte-budget policy.
Filesystem-backed XYGC chunk reads and tile-store spills are intentionally
unavailable in Pyodide. The Emscripten library exports the shared ABI symbols
as fail-closed stubs so supported in-memory kernels and Scene consumers still
load. The Pyodide gate calls every stub and checks its documented sentinel and
signature; it never emulates filesystem policy in Python or JavaScript. These
stubs are Emscripten-specific, not a blanket policy for every WASM target.
The capacity-aware `xyg_tile_store_compose_color` stub takes both declared
output capacities even though it returns `-1` without touching output.
Tile paint capacity/paint also remain unavailable (both return zero).

All five ABI 396 additions are supported in-memory operations on the native
wheel targets **and** `wasm32-unknown-emscripten`: `xyg_tile_paint_control_valid`
and `xyg_canonical_drill_limits`, `_estimate`, `_admit`, `_query`. XYDC decoding
lives in the store-independent `xyg-engine::tile_paint_control`; native painting
and validation use that one decoder with unchanged bounds and empty-inventory
semantics. Emscripten validation must not depend on the file-backed store or
return an unavailable-operation sentinel for valid controls. Canonical drill
uses the same f64/zone-map engine and capped output on Pyodide, not a stub.
The exact-wheel Pyodide gate binds every generated ABI declaration and exercises
all five additions, including valid/malformed XYDC and a finite canonical query
with NaNs and pruned chunks. It also calls all 17 filesystem stubs. Native ABI
396 and its 529 declared symbols/signatures are unchanged; this availability
repair does not change the standalone `wasm32-unknown-unknown` compute ABI.

The #58 scene migration is active: scene schema version 25 provides one
backend-neutral Rust-owned typed batch with fixed caller-provided plot bounds, axes,
scatter, polyline, rectangle, and versioned bounded decoration records through both host bindings. The v1
scatter SVG wrapper remains temporarily for scatter-only compatibility. Python
and Node now compile the same representative constant-style scatter/line/bar
figure fixture to identical Scene bytes; explicit host APIs feed those bytes to
Rust SVG and native-raster consumers. Public Python SVG/PNG/PDF select the Rust
Scene consumers only for the proven bounded literal Cartesian geometry subset:
all 19 constant built-in scatter symbols either without authored stroke or with
an authored constant CSS stroke and optional finite non-negative scalar width
(default 1px), and constant-style
polylines, ordinary area/error-band
Bands, bar/column/histogram Rects, disconnected segment/error-bar/stem endpoint
pairs with bounded stem markers, unjoined triangle-mesh faces (constant or
interned per-face fill/stroke/width, ABI 195; the static mesh tiers below),
interned per-item scatter fill/stroke/width/opacity (ABI 196),
constant-style Cartesian hexbin PolyFill cells (one
6-vertex group per cell, up to a separate 50,000-cell aggregate ceiling, #887), constant-style
Cartesian heatmap Rects (one regular cell per Rect, sharing the 10,000-bin
histogram ceiling), and finite
literal solid ribbons. Each accepted mesh face
is one three-vertex Triangle group in the Scene; the browser painter keeps its
1,024-group run budget, while static export keeps every face (#1006);
`joined_fill` plus per-face paint, polar meshes, and alternate axes remain
compatibility behavior; a non-joined mesh above the 1,024-group budget keeps
every face in static export, with SVG/PDF writing one Rust-painted raster per
mesh above 50,000 faces (#1006), identically in both hosts. For ribbons,
Python and Node pack two adjacent endpoint rows and ABI 97 makes Rust apply the
axis transforms and expand the fixed 96-interval cubic into 97 paired Scene
Band samples. Two-ended gradients, polar projection, LOD/density, and
direct-browser ribbon authoring remain explicit boundaries; broader
direct-browser production paths are tracked by the post-M2 follow-up **Expand direct-browser aggregate production beyond the density/Scene vertical** (related to [#54](https://github.com/CurateLabs/xyg/issues/54)). Every
unmodeled output contract remains an explicit compatibility route.

### Exhaustive admitted-shape static proof (#875)

The public static differential is enumerated by the Rust-owned registry in
`crates/xyg-engine/src/static_export_registry.rs`, not by independent Python
and Node case lists. `PUBLIC_EXPORT_KINDS` is also the kind membership authority
used by `scene_public_export_reason`; a Rust unit test requires the fixture
shapes' trace-kind union to equal that admitted set. The generated, reviewed
projection is `tests/fixtures/static_export_support_registry.json`; adding an
admitted kind or shape without regenerating the projection and implementing
both host builders fails `make check-host-parity`.

The current registry has all 19 admitted trace kinds represented by 21 public
shapes: scatter, line, step, stairs, ECDF, bar, column/bar host alias,
histogram, area, errorbar, box/whisker/median, violin, hexbin, segments,
stem/marker, error band, ribbon, triangle mesh, heatmap, and contour; violin
has separate vertical and horizontal rows. Every admitted case compares exact
Scene bytes, SVG bytes, raster-command bytes, and PNG bytes across Python and
Node. PNG is additionally decoded and checked for `(320, 240)` RGB metadata
and an exact RGBA pixel hash, keeping the encoded-format and visible-pixel
contracts separate.

Node `contour` carries the same authoring facts as Python `contour` (#1025):
`colormap` (a built-in name, a `linear-gradient(...)` string, a sequence of
2-256 CSS colors or `[position, color]` pairs, or canonical RGB stops; default
`viridis`) drives a continuous per-segment color channel over the segment
levels, a string `color` is one constant stroke, and a color array is one RGB(A)
row per level. The host only admits the input through the shared Rust colormap
resolvers (ABI 349) and forwards the facts; Rust lowers level to stroke.
`tests/test_static_export_noop_paint_cross_host.py` pins Python/Node
byte identity (and the painted stroke colors) for the default, named,
constant-color, and per-level-color cases. The Scene color channel carries only
built-in colormap names, so a custom (gradient, CSS-color list, or RGB-stop)
contour colormap is rejected by static/Scene export on both hosts with the one
stable reason `XYG_SCENE_UNSUPPORTED_CONTOUR_CUSTOM_COLORMAP` (fail closed,
`static-document.md`); live rendering keeps it. The same gap exists for
`segments` color channels and is left as is. `filled`, `dash_negative`, `extend`, and per-level widths remain
Python-only on Node.

The Rust-registry-driven bounded pairwise rows cross authored/autorange domains,
empty/single/NaN inputs, categorical/time axes, style, linear/log scale, and
static LOD tiers. Issue #889 adds hidden tick labels paired with empty authored
tick lists, on an authored-domain line and an autoranged scatter. Rust pins that exact
concern vocabulary and requires each concern's two rows to use distinct public
shapes and distinct axis-mode configurations. Admitted rows use
the same byte-exact matrix; deliberately unsupported rows require identical
fail-close reasons. The fail-close registry separately pins fluid
viewport, browser CSS/classes, custom font, title options, extra legend layout,
alternate axes, unsupported symbol/mark, user-authored violin orientation
metadata, layered autorange, annotation HTML/collision/markup/schema and the
#889 per-kind unadmitted annotation styles, colorbar
schema, LOD, malformed band/segment geometry, and triangle-mesh budget. This
is designed to grow by appending Rust registry rows when #873 expands
`StaticDocument`; the corpus runner and CI wiring do not need another
hand-maintained allowlist.

The landed #873 integration extends this **same Rust registry** with a
`document` subtree in the generated projection. It records XYST header/panel
flag bits, text/anchor/alignment enum values, document decoration and placement
families, explicit case-to-vocabulary links, all five static formats, malformed
envelope mutations, and six independent public-authoring witness links. The
header vocabulary includes Rust-resolved title centering (bit 3), including an
odd-width positive witness and rejection of a nonzero inactive title-x slot. The
panel vocabulary includes the #873 colorbar log-scale, minimum/maximum extend,
pyplot label-placement bits (10 through 13), the grid-dash fact (bit 14),
the Rust-resolved chrome-text fact (bit 15, #1004), and the per-label
annotation table (bit 3, #1006, with typography/padding entry facts and the
vertical-alignment codes) and the explicit-`cax` fill-plot fact (bit 24, with
the `document_colorbar_fill_plot` positive witness in both hosts) and the
discrete-colorbar region (bit 25, #1035, `document_colorbar_discrete` in both
hosts). XYST v3 retires the v2 uniform annotation bits 6, 7 and 9, so the full
panel mask is `0x0300fd3f` (a Rust test pins the registry masks to the decoder's admitted
`PANEL_FLAGS`/`FLAGS`) and rejection mutations pin the retired bits (`panel_retired_annotation_*`) together with the explicitly empty present
table (`panel_label_table_empty_present`); minimum, maximum, and combined extension
have distinct runtime case rows, and `document_grid_dash` drives both hosts'
dashed-grid output through the shared Rust pattern table. Rust tests require
complete vocabulary coverage, unique rows, all-format case coverage, valid
witness references, and masks matching their registered bits. The integrated
decoder validates every registered mask, the runtime Python/Node builders match
every case/mutation name exactly, and each output is compared through the
actual native consumer — 42 cases, 26 rejection mutations, and all five formats
run green under `tests/test_static_document_registry_cross_host.py`.

Chrome style (#1004, ABI 384): `xyg_static_chrome_style` is the one Rust
projection for title / axis-title / tick-label size, paint, bold, and italic.
Both hosts marshal the authored slot styles, the root theme, and the axis
`style`/`minor_style` entries into an XYCS frame and apply the XYCO result —
the resolved panel metrics and title style, the XYST chrome-text fact, and the
axis keys to drop. The Python `project_figure`, pyplot `_grid`, and Node
`figureStaticDocument` copies of the admission tables, defaults, and root-theme
`setdefault` are deleted; `tests/test_static_chrome_style_cross_host.py` pins
byte-identical SVG/PNG/PDF/JPEG/WebP, identical stable reasons, identical raw
frame results, and that the hosts carry no policy tables. Contract:
[static-chrome-style.md](static-chrome-style.md).

The six public-authoring witnesses are styled line, outlined scatter, text
annotation, anchored legend, continuous colorbar, and titled two-panel facets.
They author their own data in each host and compare Scene, XYST, and
SVG/PNG/PDF/JPEG/WebP outputs. Node additionally has the automatic
Figure→XYST projection (`figureStaticDocument`, mirrored from the Python
adapter), so `Figure.toSvg/toPng/toImage` produce byte-identical output to the
Python public route for every admitted registry shape.

The `title_options`, `extra_legend`, and `colorbar_option` Scene fail-close
fixtures flagged for post-rebase rechecking were resolved against the
integrated product: all three remain exact cross-host fail-closes with their
registered reasons. Existing trace cases remain intact.
Format-option witnesses include half/double scale and JPEG quality 1/100;
PNG optimization and tight cropping remain explicit document facts whose
effect is checked according to each format's documented consumer contract.

The exhaustive run exposed redundant Node-only metadata on public step, stairs,
ECDF, area, and violin traces. Node no longer emits the geometry-neutral roles;
it also omits violin `orientation` after that value has been validated and
resolved into bounded rectangle coordinates. XYEF v1 carries style keys but not
the orientation value, so broadly admitting that ignored key would be
unverifiable. User-authored unknown role/orientation style remains fail-closed.

Reproduce with `python3 scripts/static_export_support_registry.py`,
`uv run pytest tests/test_static_export_cross_host.py -q`, and
`uv run pytest tests/test_static_document_registry_cross_host.py -q`. The
first command is an explicit `make check-host-parity` step and the other two
are included by that gate's `test_*cross_host*.py` discovery. None invokes
hosted CodSpeed.

ABI 98 additionally gives both composition hosts one compact grouped violin
ingress. Hosts pack values, group offsets/centers, bins, width, orientation,
and literal style; Rust owns finite filtering, density normalization,
width/orientation, the 10,000-Rect bound, and final geometry. Vertical and
horizontal exact-byte fixtures feed the same SVG, raster, and browser Scene
consumers. Pyplot KDE bodies and advanced/polar variants remain compatibility.
Exact composition ECDFs in both hosts use the existing synchronous
`xyg_weighted_ecdf` kernel for total-order sorting, duplicate coalescing, and
normalized cumulative mass. Python passes its raw f64 column so Rust also
filters nonfinite observations; Node's existing coercion seam removes them
before the same kernel. After those validation/coercion seams, hosts prepend
the right-continuous zero anchor and author literal line style before the existing
Rust-expanded Step Scene path. Exact unsorted/repeated/nonfinite and singleton
fixtures are byte-identical through SVG, raster, and browser consumers. Binned
ECDFs use ABI 100 `xyg_binned_ecdf` in both hosts. Rust filters nonfinite
samples; applies the shared automatic-domain rule (constant nonzero values
widen by 5% of their absolute value, falling back to plus/minus 0.5 at zero or
when that pad is not useful) or Node's optional finite increasing authored range; enforces
the 10,000-bin bound; counts, normalizes, and omits empty bins; and returns the
zero anchor plus occupied-bin right edges. An authored Node range normalizes
in-range mass over every finite source sample, so excluded samples remain
visible in the final probability. Python deliberately adds no public range
option. The compact result remains an ordinary `post` Step and exact mode
remains `xyg_weighted_ecdf`.
An omitted composition-histogram bin count now resolves through the existing
Rust `xyg_histogram_edges(..., auto)` policy in both Python and Node. Explicit
positive integer bins and the empty-finite ten-bin compatibility case use
`xyg_histogram_mark_edges`; all-nonfinite input retains
the documented ten-bin `[0, 1]` (or authored-range) compatibility result.
ABI 101 `xyg_histogram_bins` then counts those resolved or authored edges in
Rust, applying density and left-to-right cumulative assembly. Rust caps
automatic or authored resolution at 10,000 bins (10,001 edges); invalid ranges,
non-increasing edges, or larger results fail through the hosts' existing
histogram argument errors. Unsorted, repeated, nonfinite, constant, ranged,
authored-edge, density, and cumulative fixtures produce identical Rect Scenes
for SVG, raster, and browser consumers.
ABI 102 makes composition hexbin ingress Rust-owned without a Scene-version
change. Both hosts pass raw f64 x/y (and optional C) plus either a scalar
grid width or an explicit pair; `grid_h == 0` selects matplotlib
`int(width / √3)` floored at 2, and `use_range == 0` applies the shared
automatic-domain pad. Finite-pair filtering ignores nonfinite x, y, or C.
Python custom reducers keep host group reduction after `xyg_hexbin_groups`
resolves the same domain, aspect, and lattice membership. The compact wire result remains the
existing centers-only hexbin trace. Constant-style Cartesian native
count/mean/sum lattices now compile those centers plus `hex_dx`/`hex_dy`
onto existing Scene v25 PolyFill records (one 6-vertex group per cell).
Python and Node fixtures are byte-identical through SVG, raster, and
browser consumers. Constant-style mean and sum share Scene bytes when they
occupy the same lattice, because paint ignores the metric. ABI 103 moves that
hex-cell ring and the regular heatmap lattice reconstruction into Rust
`expansion_modes` (`HexCell=5`, `HeatmapLattice=6`); hosts pack compact
center+pitch rows and a two-row extent+shape lattice. ABI 134 adds
`HeatmapPainted=9` plus an XYHP paint sidecar (or XYEX wrapping XYPL+XYHP on
the existing extras pointer): hosts pack the same two-row lattice plus RGBA8 or
scalar+stops payload; Rust tessellates cells and interns unique fills. ABI 135
adds `xyg_colormap_stops` and XYHP paint kind 2 so named tables live in Rust;
hosts pack a name or a custom RGB ramp. ABI 136 adds
`xyg_scene_resolve_pack_kind` / `xyg_scene_pack_product` so product-kind
dispatch and column remapping live in Rust. ABI 147 adds
`xyg_scene_pack_product_facts` so flags, `step_mode`, and extras resolve from
packed XYPK v1. ABI 148 adds `xyg_scene_pack_annotation_facts` so wrap vs
text vs arrow vs callout vs rule/band/marker routing resolves from packed
XYAF v1. ABI 149 adds `xyg_scene_pack_heatmap_facts` so heatmap/density
XYHP kind routing resolves from packed XYHF v1. ABI 150 adds
`xyg_scene_pack_scene_extras` so XYDS/XYLC/XYMP/XYGR/XYMG layout, concat order,
omit-empty, and XYEX wrapping resolve from packed XYSS v1 plus framed
XYPL/XYHP. ABI 151 adds
`xyg_scene_pack_density_grid` so Scene density `bin_2d` / `density_log_u8` /
optional mean-color resolve from packed columns. ABI 152 adds
`xyg_scene_pack_public_export` so XYEP layout, kind/step/annotation codes,
and flag derivation resolve from packed XYEF v1. ABI 153 adds
`xyg_scene_pack_figure_chrome` so plot layout, chrome-style resolve, legend
loc default/allowlists (empty authored loc is fail-closed, not the
upper-right default), colorbar flags/framing, XYTL tick-label framing, and
the 200-tick axis bound resolve from packed XYCF v1. Layout errors stay
plot-layout diagnostics so the public-export predicate can remap them to
`XYG_SCENE_UNSUPPORTED_VIEWPORT`. ABI 154 adds
`xyg_scene_pack_trace_compile` so opacity, symbol, color, dash, linecap,
marker-path, diameter, legend kind, step, curve-smooth, stroke-perimeter,
hex pitch, fill-gradient admission, and XYMS resolve from packed XYTC v1.
ABI 155 adds
`xyg_scene_pack_trace_attach` so heatmap/density attach policy
(shape/finite fail-closed checks, XYHF remainder order, density skip,
density XYHF flags, fact bits, density zeroing, and domain rewrite)
resolves from packed XYTO plus XYTA v1.
ABI 156 adds
`xyg_scene_pack_trace_rows` so XYPK construction, scatter-only
symbol/diameter, density domain-endpoint column rewrite, and
`pack_product_facts` resolve from packed XYTT plus XYCL v1.
ABI 157 adds
`xyg_scene_pack_trace_sidecars` so legend-name gating, heatmap-vs-density
plane selection, and per-trace style/dash/marker/gradient/plane extraction
resolve from packed XYTT plus XYNM v1.
ABI 158 adds
`xyg_scene_pack_style_sidecars` so XYSS dash/linecap/marker/gradient
records resolve from packed XYSD plus XYAO v1.
ABI 159 adds
`xyg_scene_splice_annotations` so annotation style/row splice and XYAD
extract resolve from packed product rows plus XYSD plus XYAO v1.
ABI 160 adds
`xyg_scene_encode_assembled` so assembled Scene encode resolves from packed
XYAS plus XYCC plus extras.
ABI 161 adds
`xyg_scene_pack_figure_chrome_from_sidecars` and
`xyg_scene_pack_scene_extras_from_sidecars` so legend paints and XYHP
wrapping resolve from packed XYSD.
ABI 162 adds
`xyg_scene_encode_assembled_from_sidecars` so XYCC packing, extras packing,
and viewport/axis scalars resolve from packed XYAS plus XYCF plus XYSD plus
polar plus XYSS.
ABI 163 adds
`xyg_scene_encode_product` so product-path compile, attach, sidecar, row,
annotation, style-sidecar, splice, and assembled encode resolve from packed
XYTC plus XYTA plus XYNM plus XYCL plus XYAF plus XYCF plus polar.
ABI 164 adds
`xyg_scene_static_export` so public SVG/PNG/PDF/JPEG/WebP consumers resolve
from one encoded Scene.
ABI 165 extends
`xyg_scene_encode_product` so the figure-compile support probe resolves from
packed XYFS on the same product call.
ABI 166 tessellates cartesian bar/column/histogram `corner_radius` after pixel
mapping through `geom::rounded_rect_poly`; ABI 167 applies polar
bar/column/histogram `wedge_gap` as a constant pixel inset. ABI 168
tessellates polar bar/column/histogram `corner_radius` when the inner radius
is positive. ABI 169 admits polar `curve="smooth"` plus `step` as polar step
expansion (identity chords). ABI 170 admits constant scatter `marker_glyph`
via an XYMG extras sidecar kept on the encoded Scene. ABI 171 admits
width-only scatter `stroke_width` as match-fill. ABI 172 admits cartesian
line `curve="smooth"` plus `step` as authored step expansion. ABI 181 admits
cartesian area/error_band `curve="smooth"` plus `step` as authored band step
expansion. ABI 182 admits triangle_mesh `joined_fill` as one identity PolyFill
ring. ABI 183 admits constant ribbon `color2_ch` as XYGR mark-space `dir=right`.
ABI 184 admits cartesian unwrapped text `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 185 admits labelled cartesian marker `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 186 admits cartesian colormap hexbin as a 1×N XYHP plane interned onto HexCell PolyFills.
ABI 187 admits cartesian unwrapped text `rotation` as XYAW `wrap=0` (XYAW v2 / XYLB v6).
ABI 188 admits labelled cartesian marker `rotation` as XYAW `wrap=0` (nums[8]).
ABI 189 owns heatmap/hexbin cell-fill tessellation eligibility from packed XYTA.
ABI 190 intern cartesian per-item two-ended ribbon `color2_ch` from packed XYHP kind 5.
ABI 191 admits constant multi-character scatter `marker_glyph` via XYMG v2.
ABI 192 admits polar painted heatmap inverse-raster as one Scene Image blit.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7.
ABI 173 tessellates
heatmap `corner_radius`. ABI 174 tessellates violin/box `corner_radius`.
ABI 175 admits violin/box `fill_opacity` / `stroke_opacity`.
ABI 176 admits bar/column/histogram `fill_opacity` / `stroke_opacity`.
ABI 177 admits heatmap `fill_opacity`.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7.
ABI 178 admits scatter `fill_opacity` / `stroke_opacity`.
ABI 179 admits hexbin `fill_opacity`.
ABI 180 admits triangle_mesh `fill_opacity` / constant stroke paint.
ABI 181 admits cartesian area/error_band `curve="smooth"` plus `step` as
authored band step expansion.
ABI 182 admits triangle_mesh `joined_fill` as one identity PolyFill ring.
ABI 183 admits constant ribbon `color2_ch` as XYGR mark-space `dir=right`.
ABI 184 admits cartesian unwrapped text `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 185 admits labelled cartesian marker `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 186 admits cartesian colormap hexbin as a 1×N XYHP plane interned onto HexCell PolyFills.
ABI 187 admits cartesian unwrapped text `rotation` as XYAW `wrap=0` (XYAW v2 / XYLB v6).
ABI 188 admits labelled cartesian marker `rotation` as XYAW `wrap=0` (nums[8]).
ABI 189 owns heatmap/hexbin cell-fill tessellation eligibility from packed XYTA.
ABI 190 intern cartesian per-item two-ended ribbon `color2_ch` from packed XYHP kind 5.
ABI 191 admits constant multi-character scatter `marker_glyph` via XYMG v2.
ABI 192 admits polar painted heatmap inverse-raster as one Scene Image blit.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7.
ABI 137 / Scene v27 adds
`DensityBlit=10` and `SceneRecordKind::Image=5`: hosts pack the heatmap
extent lattice plus an XYHP kind-3 log-u8 plane, and Rust emits one Image
record plus XYIM. ABI 138 / Scene v28
adds XYDS constant dash on the same extras pointer (raw XYDS or XYEX v2)
and an XYDS sidecar after XYIM. ABI 139 / Scene v29 adds XYLC constant
linecap on that same extras pointer (raw XYLC, XYDS+XYLC concat, or XYEX v2)
and an XYLC sidecar after XYDS. ABI 140 / Scene v30 adds `CurveFlatten=11`
so cartesian `curve="smooth"` polylines flatten in Rust from compact knots
(pack `step_mode=4`); ABI 141 / Scene v31 adds `BandFlatten=12` so cartesian
`area(curve="smooth")` bands flatten the same way. ABI 142 admits cartesian
mean-color density as XYHP kind 4 on the existing `DensityBlit` Image blit.
ABI 143 polar density tessellates occupied `DensityBlit` cells to PolyFill
wedges. ABI 144 admits cartesian `error_band(curve="smooth")` on existing
`BandFlatten=12` and polar `curve="smooth"` line/area/error_band as identity
chords (polar-axes.md §5). ABI 145 admits constant scatter `marker_path`
via an XYMP extras sidecar tessellated after pixel mapping. ABI 146 admits
constant mark `fill` linear-gradients via an XYGR extras sidecar kept on the
encoded Scene. ABI 147 owns product packing facts from XYPK v1. ABI 148 owns
annotation family routing from XYAF v1. ABI 149 owns heatmap/density XYHP
kind routing from XYHF v1. ABI 150 owns style-sidecar layout and extras wrapping
from XYSS v1. ABI 151 owns Scene density binning and log-u8 encoding from
packed columns. ABI 152 owns XYEP layout, kind/step/annotation codes, and
flag derivation from packed XYEF v1. ABI 153 owns plot layout, chrome-style
resolve, legend loc default/allowlists (empty authored loc is fail-closed),
colorbar flags/framing, XYTL tick-label framing, and the 200-tick axis bound
from packed XYCF v1. ABI 154 owns per-trace Scene compile policy
(opacity, symbol, color, dash, linecap, marker path, diameter, legend kind,
step, curve-smooth, stroke-perimeter, hex pitch, fill-gradient admission,
and XYMS resolve) from packed XYTC v1. ABI 155 owns heatmap/density attach
policy from packed XYTO plus XYTA v1. ABI 156 owns XYPK construction,
scatter-only symbol/diameter, density domain-endpoint column rewrite, and
`pack_product_facts` from packed XYTT plus XYCL v1. ABI 157 owns
legend-name gating, heatmap-vs-density plane selection, and per-trace
style/dash/marker/gradient/plane extraction from packed XYTT plus XYNM v1.
ABI 158 owns XYSS dash/linecap/marker/gradient record construction from
packed XYSD plus XYAO v1.
ABI 159 owns annotation style/row splice and XYAD extract from packed
product rows plus XYSD plus XYAO v1.
ABI 160 owns assembled Scene encode from packed XYAS plus XYCC plus extras.
ABI 161 owns legend paints and XYHP wrapping from packed XYSD.
ABI 162 owns XYCC packing, extras packing, and viewport/axis scalars from
packed XYAS plus XYCF plus XYSD plus polar plus XYSS.
ABI 163 owns product-path compile, attach, sidecar, row, annotation,
style-sidecar, splice, and assembled encode from packed XYTC plus XYTA plus
XYNM plus XYCL plus XYAF plus XYCF plus polar.
ABI 164 owns public SVG/PNG/PDF/JPEG/WebP consumers from one encoded Scene.
ABI 165 owns the figure-compile support probe from packed XYFS on product encode.
ABI 169 admits polar `curve="smooth"` plus `step` as polar step expansion
(identity chords). ABI 170 admits constant scatter `marker_glyph` via XYMG.
ABI 171 admits width-only scatter `stroke_width` as match-fill.
ABI 172 admits cartesian line `curve="smooth"` plus `step` as authored
step expansion.
ABI 173 tessellates heatmap `corner_radius`.
ABI 174 tessellates violin/box `corner_radius`.
ABI 175 admits violin/box `fill_opacity` / `stroke_opacity`.
ABI 176 admits bar/column/histogram `fill_opacity` / `stroke_opacity`.
ABI 177 admits heatmap `fill_opacity`.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7.
ABI 178 admits scatter `fill_opacity` / `stroke_opacity`.
ABI 179 admits hexbin `fill_opacity`.
ABI 180 admits triangle_mesh `fill_opacity` / constant stroke paint.
ABI 181 admits cartesian area/error_band `curve="smooth"` plus `step` as
authored band step expansion.
ABI 182 admits triangle_mesh `joined_fill` as one identity PolyFill ring.
ABI 183 admits constant ribbon `color2_ch` as XYGR mark-space `dir=right`.
ABI 184 admits cartesian unwrapped text `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 185 admits labelled cartesian marker `dx`/`dy`/`anchor` as XYAW `wrap=0`.
ABI 186 admits cartesian colormap hexbin as a 1×N XYHP plane interned onto HexCell PolyFills.
ABI 187 admits cartesian unwrapped text `rotation` as XYAW `wrap=0` (XYAW v2 / XYLB v6).
ABI 188 admits labelled cartesian marker `rotation` as XYAW `wrap=0` (nums[8]).
ABI 189 owns heatmap/hexbin cell-fill tessellation eligibility from packed XYTA.
ABI 190 intern cartesian per-item two-ended ribbon `color2_ch` from packed XYHP kind 5.
ABI 191 admits constant multi-character scatter `marker_glyph` via XYMG v2.
ABI 192 admits polar painted heatmap inverse-raster as one Scene Image blit.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7.
ABI 104 likewise moves
disconnected endpoint pairs (`SegmentPair=7`) and unjoined triangle faces
(`TriangleFace=8`) into that compact expansion; hosts pack one four-coordinate
row per segment and two PolyFill rows per face. ABI 105 makes the public
static-export support predicate Rust-owned: Python and Node pack the same
`XYEP` v1 envelope and surface `xyg_scene_public_export_reason` verbatim.
ABI 152 makes that envelope Rust-owned: Python and Node pack `XYEF` v1 facts
and call `xyg_scene_pack_public_export`.
ABI 153 makes figure chrome Rust-owned: Python and Node pack `XYCF` v1 facts
and call `xyg_scene_pack_figure_chrome`.
ABI 154 makes per-trace Scene compile Rust-owned: Python and Node pack `XYTC`
v1 facts and call `xyg_scene_pack_trace_compile`.
ABI 155 makes heatmap/density attach Rust-owned: Python and Node pack `XYTA`
v1 facts against compiled `XYTO` and call `xyg_scene_pack_trace_attach`.
ABI 156 makes product-row packing Rust-owned: Python and Node pack `XYCL`
v1 kind/coords/id/columns against attached `XYTT` and call
`xyg_scene_pack_trace_rows`.
ABI 157 makes trace-sidecar packing Rust-owned: Python and Node pack `XYNM`
v1 names against attached `XYTT` and call `xyg_scene_pack_trace_sidecars`.
ABI 158 makes XYSS packing Rust-owned: Python and Node pass `XYSD` plus
`XYAO` and call `xyg_scene_pack_style_sidecars`.
ABI 159 makes annotation splice Rust-owned: Python and Node pass product
rows plus `XYSD` plus `XYAO` and call `xyg_scene_splice_annotations`.
ABI 160 makes assembled Scene encode Rust-owned: Python and Node pass
`XYAS` plus `XYCC` plus extras plus axis scalars and call
`xyg_scene_encode_assembled`.
ABI 161 makes XYSD chrome/extras packing Rust-owned: Python and Node pass
`XYCF` legend options plus `XYSD` to `xyg_scene_pack_figure_chrome_from_sidecars`
and polar plus `XYSD` plus `XYSS` to `xyg_scene_pack_scene_extras_from_sidecars`.
ABI 162 makes product-path assembled encode Rust-owned from sidecars: Python
and Node pass `XYAS` plus `XYCF` plus `XYSD` plus polar plus `XYSS` and call
`xyg_scene_encode_assembled_from_sidecars`.
ABI 163 makes product-path Scene encode Rust-owned from packed facts: Python
and Node pass `XYTC` plus `XYTA` plus `XYNM` plus `XYCL` plus `XYAF` plus
`XYCF` plus polar and call `xyg_scene_encode_product`.
ABI 164 makes public static-export consumers Rust-owned: Python and Node pass
one encoded Scene plus format/scale/size/quality and call
`xyg_scene_static_export`.
ABI 165 folds figure-compile support into that product call: Python and Node
pass packed `XYFS` on `xyg_scene_encode_product` instead of probing
`xyg_scene_figure_support_reason` separately. Empty `XYFS` skips the probe.
ABI 166 tessellates cartesian bar/column/histogram `corner_radius` on that
same product Scene so public `to_svg` / PNG do not fall back to `_svg.py` /
`_raster.py` for constant radii. ABI 167 applies polar
bar/column/histogram `wedge_gap` on that same product Scene. ABI 168
tessellates polar bar/column/histogram `corner_radius` on that same product
Scene when the inner radius is positive. ABI 169 admits polar `curve="smooth"`
plus `step` on that same product Scene as polar step expansion. ABI 170 admits
constant scatter `marker_glyph` on that same product Scene. ABI 171 admits
width-only scatter `stroke_width` as match-fill on that same product Scene.
ABI 172 admits cartesian line `curve="smooth"` plus `step` as authored
step expansion on that same product Scene. ABI 173 tessellates heatmap
`corner_radius` on that same product Scene. ABI 174 tessellates violin/box
`corner_radius` on that same product Scene. ABI 175 admits violin/box
`fill_opacity` / `stroke_opacity` on that same product Scene. ABI 176 admits
bar/column/histogram `fill_opacity` / `stroke_opacity` on that same product Scene.
ABI 177 admits heatmap `fill_opacity` on that same product Scene.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity` on that same product Scene.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin on that same product Scene.
ABI 178 admits scatter `fill_opacity` / `stroke_opacity` on that same product Scene.
ABI 179 admits hexbin `fill_opacity` on that same product Scene.
ABI 180 admits triangle_mesh `fill_opacity` / constant stroke paint on that same product Scene.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6 on that same product Scene.
ABI 181 admits cartesian area/error_band `curve="smooth"` plus `step` as authored
band step expansion on that same product Scene.
ABI 182 admits triangle_mesh `joined_fill` as one identity PolyFill ring on that
same product Scene.
ABI 183 admits constant ribbon `color2_ch` as XYGR mark-space `dir=right` on that
same product Scene.
ABI 184 admits cartesian unwrapped text `dx`/`dy`/`anchor` as XYAW `wrap=0` on that
same product Scene.
ABI 185 admits labelled cartesian marker `dx`/`dy`/`anchor` as XYAW `wrap=0` on that
same product Scene.
ABI 186 admits cartesian colormap hexbin as a 1×N XYHP plane interned onto
HexCell PolyFills on that same product Scene.
ABI 187 admits cartesian unwrapped text `rotation` as XYAW `wrap=0` (XYAW v2 /
XYLB v6) on that same product Scene.
ABI 188 admits labelled cartesian marker `rotation` as XYAW `wrap=0` on that
same product Scene.
ABI 189 owns heatmap/hexbin cell-fill tessellation eligibility from packed XYTA on that
same product Scene.
ABI 190 intern cartesian per-item two-ended ribbon `color2_ch` from packed XYHP kind 5 on that
same product Scene.
ABI 191 admits constant multi-character scatter `marker_glyph` via XYMG v2 on that
same product Scene.
ABI 192 admits polar painted heatmap inverse-raster as one Scene Image blit on that
same product Scene.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity` on that
same product Scene.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba`
hexbin on that same product Scene.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6 on that same product Scene.
The explicit `xyg_scene_figure_support_reason` ABI remains for tests.
ABI 106 makes Figure autorange/domain the same way: Python and Node pack
`XYAR` v1 extents and zero-baseline predicates, then call
`xyg_figure_autorange` / `xyg_auto_domain`. Direct-browser WASM compile uses
the same `auto_domain` degenerate pad instead of a host-local ±0.5 fork.
Browser-painter LOD beyond its 1,024-group budget, and rich style
exceptions remain compatibility routes (static mesh export above that budget
is native since #1006: scene-ir.md "Mesh tiers and dense-fill rule"). ABI 107 makes Scene CSS→RGBA8 and
per-kind mark style defaults the same way: Python and Node pack `XYMS` v1
kind/opacity/CSS/width literals, then call `xyg_scene_resolve_mark_styles` /
`xyg_css_color_rgba`. ABI 108 makes Scene chrome defaults the same way:
Python and Node pack `XYCH` v1 background/axis CSS, sides, opacities, and
widths, then call `xyg_scene_resolve_chrome_style`. ABI 109 makes
Figure→Scene row packing the same way: Python and Node call
`xyg_scene_pack_trace` with kind/flags/columns and append the returned
56-byte rows. ABI 136 makes product-kind packing the same way: Python and
Node call `xyg_scene_pack_product` with the authored kind plus a canonical
`x`/`y`/`x0`/`y0`/`x1`/`y1`/`base` envelope; Rust maps kind/flags onto
pack-kind and column order. ABI 116 expands primary rule/band/marker annotations the same
way: Python and Node call `xyg_scene_pack_annotation_marks` with packed
scalars plus axis domains. ABI 117 makes figure-compile support the same way:
Python and Node pack `XYFS` observations plus axis ids/keys, then call
`xyg_scene_figure_support_reason`. ABI 118 extends that envelope to v2
per-trace allowlist flags so kind, hidden/per-item, density, dash, rect
extras, joined fill, hex reducer, heatmap colormap, and non-CSS fill
diagnostics cannot drift. ABI 119 moves composition mark ingress into Rust:
Python and Node call `xyg_argsort_stable`, `xyg_histogram_mark_edges`,
`xyg_contour_levels`, and `xyg_hexbin_groups` so line/area/error-band sort,
integer/empty-auto histogram edges, contour isoline spacing, and custom-hex
lattice membership cannot drift. Custom `reduce_C_function` callables stay
host-side over those groups. ABI 120 moves composition `loc="best"` scoring into
Rust: Python and Node call `xyg_legend_normalize` and `xyg_legend_best_loc` so
display-space occupancy, the 4096/512 sample, and the 0.02 tie band cannot drift.
ABI 197 Scene product encode settles authored `loc="best"` from packed XYCL/XYNM
plus XYCF domains; hosts pack the token and encoded XYLG still stores 0..=8.
Compatibility `_legendfit.py` / `resolveLegendBestLoc` still pack ChartView specs.
ABI 121 moves ribbon/curve/rounded-rect tessellation into Rust: Python and Node
call `xyg_ribbon_edge`, `xyg_ribbon_polygon`, `xyg_monotone_tangents`,
`xyg_curve_flatten`, and `xyg_rounded_rect_poly` so bump-X flattening,
Fritsch–Carlson tangents, Hermite polylines, and independent tip/base radii
cannot drift. Hosts still map affine scales.
ABI 122 moves compile-time payload LOD into Rust: Python and Node
call `xyg_payload_tier`, `xyg_payload_visible_needed`, and
`xyg_payload_visible_mask` so M4 vs density vs direct, polar skip,
the strict `>` scatter thresholds, and the log/null keep mask cannot
drift. ABI 204 `xyg_payload_m4_indices` owns remaining line M4 emit
(closed-window ulp, optional nonlinear buckets, polar skip) so Python
and Node cannot drift on first paint or `decimate_view`. Node `_emitLine`
and `_emitArea` pass `_binningCoords` into M4 like Python `_m4_decimate`;
cross-host proof: `tests/fixtures/payload_cross_host.json` case
`line_log_m4_bin_x`. Node `_emitRibbon` ships `color2_ch` on registry key
`color_target` like Python `_emit_ribbon`; cross-host proof:
`tests/fixtures/payload_cross_host.json` case `ribbon_color2_ch`. Node
`_emitHexbin` ships `color_ch` via payload channel attach like Python
`_emit_hexbin`; cross-host proof: `hexbin_colormap` (no metric column).
Hosts still gather extra columns and ship the chosen rows.
ABI 205 moves remaining `_emit_*` sampling into Rust: Python and Node
call `xyg_payload_visible_indices`, `xyg_payload_even_indices`, and
`xyg_payload_sample_target_indices` so fused finite/log keep indices,
NumPy int64 linspace stem/errorbar sampling, and density-overlay
`min(1, target/n)` selection cannot drift. ABI 214
`xyg_payload_segment_budget` owns the stem/errorbar count budget
(`max(1024, floor(px_width)*4)`). ABI 215 `xyg_payload_errorbar_indices`
owns even-index expansion across concatenated role groups. Hosts still
gather extra columns and ship the chosen rows.
ABI 123 moves tick-label collision thinning into Rust: Python and Node
call `xyg_scene_tick_label_layout` so auto / hide / rotate / stagger,
the edge-anchor rotate gap, and stride downsampling cannot drift.
Hosts still format label strings and map tick values to pixels.
ABI 124 moves static legend box packing into Rust: Python and Node
call `xyg_legend_box_layout` so column fit, measured ellipsis, and loc /
bbox-to-anchor placement cannot drift. Hosts still resolve CSS font-size
/ em paddings and pack entry strings. Polar `legend_box_*` remapping
stays host-side.
ABI 125 moves text-block measure and cartesian axis rooms into Rust:
Python and Node call `xyg_text_block_measure`,
`xyg_text_block_rotated_extent`, `xyg_y_tick_label_extent`,
`xyg_y_axis_left_room`, `xyg_x_axis_title_room`,
`xyg_x_tick_label_room`, and `xyg_x_tick_label_edge_rooms` so wrap,
rotated extent, and title/tick gutter formulas cannot drift. Hosts still
format `_tick_text`, resolve CSS visibility / tick offsets, and iterate
axes.
ABI 126 moves compatibility static-export padding, title-band, colorbar
extra, right-y, and polar recut into Rust: Python and Node call
`xyg_compat_is_compact`, `xyg_compat_default_padding`,
`xyg_compat_title_wrap_width`, `xyg_compat_title_room`,
`xyg_compat_x_axis_side_room`, `xyg_compat_colorbar_extra`,
`xyg_compat_right_y_room`, `xyg_polar_legend_room`,
`xyg_polar_legend_reserve`, `xyg_polar_label_room`, and
`xyg_recut_polar_plot` so compact gutters, colorbar extras, and polar
disc recut cannot drift. Hosts still iterate axes, format ticks, measure
rooms, resolve CSS visibility, and decide polar legend reservation.
ABI 127 moves the pyplot tight-layout grid solve into Rust: Python and
Node call `xyg_tight_layout_solve` so edge maxima, neighbor gaps, pad
multiples, and `subplots_adjust` fractions cannot drift. Hosts still
measure per-panel chrome, suptitle, figure labels, and outside legends.
ABI 198 moves the remaining static-export combination and tight-layout
figure-edge extras into Rust: Python and Node call
`xyg_compat_combine_plot` and `xyg_tight_layout_figure_extra` so padding,
title-band, colorbar extra, right-y, floors, polar recut, and
suptitle/label/legend extras cannot drift. Hosts still iterate axes,
format ticks, measure rooms, resolve CSS visibility, and decide polar
legend reservation.
ABI 128 moves authored tick-window resolve and filter into Rust: Python
and Node call `xyg_tick_window` and `xyg_tick_window_filter` so linear
vs modular angular containment cannot drift. ABI 199 Scene product encode
filters authored cartesian majors through that window and pairs
`tick_labels` during chrome pack. ABI 200 filters authored cartesian
minors through that same window (`require_finite`). ABI 201 filters polar
theta majors/minors through the modular sector and formats Scene polar
theta labels with `format_angular_tick`. ABI 202 materializes ABI 130
time strftime and polar angular numeric formats onto `XYTL`. Hosts pack
domain tick-kind in XYCF 154–155. ABI 203 runs ABI 123 cartesian collision
at Scene SVG/raster emit. Collision rooms clamp only when compact/authored
pads already fit; overflowing compact pads stay
`XYG_SCENE_UNSUPPORTED_VIEWPORT`. Polar rim auto/hide/rotate/stagger/preserve stay
fail-closed. Invalid ABI 96 grammar still falls
back. Only the right-hand secondary y axis (Scene v33) is admitted, and only by
Rust's XYFS admission; `x2`, left y2, extra axes and tick-only secondary axes stay
fail-closed. Python and Node marshal that axis identically (twinx PRs 2+3,
`spec/design/twinx-secondary-y-axis.md`): the `XYY2` sidecar, XYCO y2 outputs,
`XYFS` axis codes (`y2` = 2, `x2` = 3) and the `XYCL` y2 column flag (ABI 391);
`tests/test_static_dual_axis_cross_host.py` pins byte-identical XYST/SVG/PNG/PDF
and identical Rust reasons. The live wire matches (twinx round 4, protocol 14):
both hosts emit the y2 axis spec, its view range, per-trace bound ranges and
y2-bound annotation bindings — or the same fail-closed message when a binding
names an undeclared axis; `tests/test_live_dual_axis_cross_host.py` pins
identical axes/ranges/annotations and packed-blob bytes across hosts.
Hosts still choose tick families and
map values to pixels on the compatibility `_svg` path. ChartView JS
`_polarAngularTurn` / `_axisTicks` seam filter stays until WASM.
ABI 130 moves Cartesian compatibility tick-label formatting into Rust:
Python and Node call `xyg_tick_format` so linear/log/time/number-spec,
category, and angular defaults cannot drift. Polar tick drawing stays
host-side. Scene product-path authored `tick_labels` pair during chrome
pack (ABI 199). Authored cartesian minors filter during chrome pack (ABI 200).
Scene product encode applies ABI 130 time/angular formats (ABI 202).
Scene cartesian `tick_label_strategy` uses ABI 123 at emit (ABI 203);
polar rim collision stays refused.
ABI 131 moves static polar (theta, r) → screen-pixel projection into Rust:
Python and Node call `xyg_polar_layout`, `xyg_polar_project`, and the polar
visibility-mask helpers so disc layout, projection, and cull predicates cannot
drift on static export. ChartView GLSL `xyPolarPos` stays until WASM; hosts
still own ring/polygon helpers that call native projection. ABI 209 owns
compatibility wedge flatten (`xyg_polar_wedge_points`).
ABI 133 compiles polar Scene v26 line/scatter/area/bar/column/errorbar/heatmap/contour: Python and Node pack
XYPL v1 authoring (`_pack_polar_scene_input` / `packPolarSceneInput`); Rust
owns layout, `polar_project`, `polar_wedge_points` (annular-sector PolyFill),
clip, rings/spokes, and rim tick labels.
Polar encode applies ABI 126 `recut_polar_plot` before `polar_layout` so the
inscribed disc and polar legend gutter match compatibility static export.
Cartesian Scene bytes change only the version u32 at offset 4. Polar
density stays `XYG_SCENE_UNSUPPORTED_POLAR`. Polar heatmap constant-style
lattices tessellate Rects; ABI 192 polar painted heatmap inverse-rasters to
one plot-covering Image. Authored heatmap/hexbin stroke (ABI 193) tessellates
polar painted cells instead of Image blit so cell outlines are representable.
Polar contour
reuses SegmentPair polylines through `polar_project`.
ABI 132 moves first-paint density scatter emit policy into Rust: Python and
Node call `xyg_density_emit_meta`, `xyg_density_grid_path`,
`xyg_density_format_binning`, `xyg_density_pyramid_preflight`, and
`xyg_density_wasm_eligible` so path/binning/WASM/overlay decisions cannot
drift. Hosts still transform axis-scale coordinates, invoke `bin_2d` /
pyramid compose kernels, ship buffers, and assemble the wire spec.
WASM ABI 24 calls the same `payload_density_trace_emit_plan` body through
`xyg_wasm_density_first_paint_plan`; its packed allocation-free result records
tier, bounded mark count, pyramid/WASM eligibility, sample attachment, and
canonical-source shipment. The direct-browser foundation asserts the same
1M/100M decisions as the live Python/Node cross-host fixture.
ABI 316 `xyg_payload_density_grid_materialize` owns the execution half of
that grid body (bin2d / pyramid compose, log-u8 encode, optional mean-color
RGBA, overlay sample selection) after emit-plan policy is resolved. Hosts
marshal observations and ship returned buffers; Python ABI proof lives in
`tests/test_density_grid_materialize_abi.py`; Node density cross-host grid-buffer
SHA in `density_emit_cross_host.json`.
ABI 317 `xyg_scene_xytc_trace_pack`, ABI 318 `xyg_scene_xyta_trace_pack`, ABI
323 `xyg_scene_xyta_trace_observations_materialize`, and ABI 325
`xyg_scene_xytc_trace_observations_materialize` (M2 Push 2) retired host-side
XYTC/XYTA field-byte walks: `_scene_v3.py` and `packages/xy-node/src/scene.js`
marshal figure/trace inputs via `_scene_marshal.py` / bulk packers and ship
returned compile/attach fact buffers. Cross-host proof is the checked-in
`trace_pack_sha256` matrix in `tests/fixtures/figure_scene_v3.json` exercised
by `tests/test_scene_trace_pack_abi.py` and
`packages/xy-node/scripts/scene_trace_pack_cross_host.mjs`.
ABI 323 observation blobs remain bounded to 4 MiB. Rust budgets the complete
ABI 318 XYTA record (including its fixed prefix and every non-source sidecar),
then admits density f64 x/y only when that whole record fits. Python and Node
marshal identical observations without duplicating a row cutoff; when Rust
omits the planes, the explicit static direct-geometry fallback remains. The
four-tier authored-Scene evidence
explicitly sets the shared density tri-state false (`density=False` /
`force_density: false`) so its intended 1M direct workload cannot be changed
by Node's automatic interactive tier heuristic. The Python and Node generators
must remain byte-identical at 100, 10k, 100k, and 1M records.
ABI 321 `xyg_payload_trace_emit_materialize` (M2 payload writer ship) retired
host-side emit row gathers and channel materialization in `_payload.py`; Python
`_payload_trace_materialize.py` and Node `payloadTraceMaterialize.js` marshal
trace observations and ship returned geometry/channel blobs.
ABI 129 moves Cartesian static-export grid colormap into Rust: Python
and Node call `xyg_colormap_rgba`, `xyg_colormap_rgba_canonical`, and
`xyg_density_rgba` (log-u8 density) so `_lut` stop interpolation cannot
drift on heatmap/density grid export. ABI 206 adds `xyg_colormap_lut`,
`xyg_density_rgba_linear`, and `xyg_paint_effective_rgba` so remaining
compatibility 1D LUT samples, legacy count-grid density, and artist-alpha
compositing cannot drift (#313). ABI 207 `xyg_polar_heatmap_inverse_map`
owns the compatibility polar heatmap gather-after-inverse map so SVG/raster
exporters no longer invert pixels in Python or Node (#283). ABI 208
`xyg_geometry_offset` / `xyg_f32_safe_scale` owns §4/§16 encode offset and
the §19 f32-safe scale so Python `lod.py` and Node `encode.js` cannot drift.
ABI 216 `xyg_scale_pins_offset` owns log-family `pin_zero` admission
(`log`/`symlog`, case-sensitive). ABI 255 `xyg_encoded_column_meta` owns
`EncodedColumn` offset/scale/kind-presence packing. Hosts still copy the
original kind string. ABI 209
`xyg_polar_wedge_points` owns compatibility annular-sector flatten so
Python `_svg.polar_wedge_points` and Node `polarWedgePoints` cannot drift;
SVG still emits exact `A` arcs for unrounded wedges. ABI 210
`xyg_hexbin_ring` owns the pointy-top hexagon vertex offsets scaled by cell
pitch so Python `_svg.hexbin_ring` and Node `hexbinRing` cannot drift. ABI 211
`xyg_step_arrays` owns compatibility step/stairs expand so Python
`_svg._step_arrays` and Node `stepArrays` cannot drift. ABI 212
`xyg_marker_path_scale` owns authored-marker pixel vertices
(`out_x = cx + scale * unit_x`, `out_y = cy - scale * unit_y`) so Python
`_svg._authored_marker_path_d` / `_raster` and Node `markerPathScale` cannot
drift; SVG `d=` assembly stays host. ABI 213 `xyg_css_is_functional` /
`xyg_continuous_domain` / `xyg_direct_rgba_admit` owns the `resolve_color`
CSS/numeric split, equal-bound domain pad, and Nx3/Nx4 admit so Python
`channels.resolve_color` and Node `resolveColorChannel` cannot drift; named
colors stay categories. `xyg_heatmap_rgba` keeps its
distinct normalized-scalar remap for other consumers. Hosts still
resolve stop tables, CSS paints, and truecolor RGBA buffers.
ABI 214 `xyg_payload_segment_budget` owns the stem/errorbar count budget
(`max(1024, floor(px_width)*4)`) so Python `_payload._emit_segments` and Node
`_emitSegments` cannot drift. ABI 215 `xyg_payload_errorbar_indices` owns
even-index expansion across concatenated role groups. Hosts still
gather extra columns, and ship the chosen rows.
ABI 216 `xyg_scale_pins_offset` owns log-family `pin_zero` admission
(`log`/`symlog`, case-sensitive) so Python `lod.pins_offset_to_zero` and
Node `pinsOffsetToZero` cannot drift. ABI 255 `xyg_encoded_column_meta` owns
`EncodedColumn` offset/scale/kind-presence packing so Python
`lod.encode_f32_values` and Node `encodeF32Values` cannot drift. Hosts still
copy the original kind string.
ABI 217 `xyg_arrow_geometry` / `xyg_arrow_shaft_points` /
`xyg_arrow_end_decoration` / `xyg_arrow_taper_polygon` /
`xyg_arrow_trim_polyline_end` owns annotation-arrow connectionstyle geometry
so Python `_arrowgeom.py` and Node `arrowGeometry` cannot drift. ChartView
`51_annotations.ts` keeps the same formula until WASM.
ABI 254 `xyg_arrow_style_pack` owns comma-separated `start_offset` /
`label_clear` packing (empty tokens and non-finite parts fail the CSV;
exact 2 parts for offset, exact 4 non-negative parts for clear) so Python
`_pack_style` and Node `packArrowStyle` cannot drift. ChartView still parses
those strings until WASM. Hosts still coerce style keys and elbow truthiness.
ABI 218 `xyg_scene_dash_admit` owns Scene dash presets and 2–8 finite length
patterns so Python `_parse_scene_dash` and Node `parseSceneDash` cannot drift.
Invalid comma tokens reject the whole string. Hosts still coerce list vs
string and fail-close empty strings.
ABI 219 `xyg_scene_linecap_admit` owns Scene linecap names so Python
`_parse_scene_linecap` and Node `parseSceneLinecap` cannot drift. Unknown
names and whitespace-only strings reject. Hosts still fail-close empty
strings without calling the kernel.
ABI 220 `xyg_density_overlay_opacity` owns density overlay sample opacity
(`min(authored, 0.55)`; non-finite → `0.55`) so Python `_payload` and Node
`figure.js` cannot drift. Hosts still default omitted opacity to `0.8`.
ABI 221 `xyg_scene_marker_path_admit` owns Scene marker-path contour bounds
(1–32 contours, x/y pairs, `|v| ≤ 0.500001`, ≤ 96 vertices) so Python
`_validated_marker_path` and Node `validateMarkerPath` cannot drift. Hosts
still coerce mappings and fail-close non-numeric contours. Filled contours
shorter than 6 values stay a compile-path extra.
ABI 222 `xyg_scene_annotation_style_admit` owns Scene annotation style-key
allowlists so Python `_annotation_allowed_style` and Node
`annotationAllowedStyle` cannot drift. Hosts still skip markup/typography/
rotation and raise error text.
ABI 223 `xyg_scene_ribbon_color2_classify` owns ribbon two-ended paint class
(absent/solid/gradient/ends/fail) so Python `_classify_ribbon_color2` and
Node `classifyRibbonColor2` cannot drift. Hosts still coerce channels and
pack end RGBA8.
ABI 224 `xyg_scene_tick_label_strategy` owns Scene tick-label strategy names
so Python `_scene_tick_label_strategy` and Node `sceneTickStrategy` cannot
drift. Hyphens become underscores. Unknown names, including empty text, map
to `auto`. Hosts still pick `tick_label_strategy` vs `collision` vs camelCase
keys.
ABI 225 `xyg_scene_tick_anchor` owns Scene tick-label anchor names so Python
`_scene_tick_anchor_code` and Node `anchorCode` cannot drift. `middle` aliases
`center`. Unknown names, including empty text, reject. Hosts still pick
`tick_label_anchor` vs camelCase keys. ABI 123 layout enums stay a separate
throw-on-unknown table.
ABI 226 `xyg_scene_fill_gradient_admit` owns Scene fill-gradient stop admit
(space/dir, 2–8 monotone `t` in `[0, 1]`, `var(` reject, empty/`currentcolor`
→ mark color, RGBA8) so Python `_admitted_fill_gradient_from_fill` and Node
`admitFillGradient` cannot drift. Hosts still coerce fill mappings.
ABI 227 `xyg_scene_parse_linear_gradient` owns CSS `linear-gradient(...)`
parse (cardinal `to` directions, 2–8 resolved stops, nested function commas)
so Python `mark_fill` / `_admitted_fill_gradient_from_fill` and Node
`parseLinearGradient` cannot drift. Hosts still coerce fill mappings, wrap
authoring error text, and run `css_color` on authoring stops. Compile-path
skip-empty split stays extra.
ABI 228 `xyg_scene_rect_extra_flags` owns Scene rect extra-flag pack
(unusable-gradient bit, admitted corner-radius kinds, polar wedge-gap
exception) so Python `_rect_extra_flags` and Node `rectExtraFlags` cannot
drift. Hosts still coerce fill mappings, radius lists, and `wedge_gap`.
ABI 229 `xyg_scene_gradient_dir` owns Scene fill-gradient direction codes
(`down`/`up`/`right`/`left`; unknown/empty → 255; no lowercasing) so Python
`_pack_gradient_spec` / XYSS pack and Node `packGradientSpec` cannot drift.
Hosts still pick `dir` vs missing keys. Compile-path `to bottom` aliases stay extra.
ABI 231 `xyg_scene_gradient_space` owns Scene fill-gradient space codes
(`mark`/`plot`; unknown/empty → 255; no lowercasing) so Python
`_pack_gradient_spec` / XYSS pack and Node `packGradientSpec` cannot drift.
Hosts still pick `space` vs missing keys. XYSS plot-space is `code == 1`.
ABI 230 `xyg_scene_linear_gradient_prefix` owns the CSS `linear-gradient(`
prefix check (trim, lowercase) so Python `_fill_is_gradient_authoring` and
Node `fillIsGradientAuthoring` cannot drift. Hosts still treat dict/object
fills as authoring. Compile-path flag bits stay extra.
ABI 232 `xyg_scene_hexbin_reduce_admit` owns Scene hexbin reduce names
(`count`/`mean`/`sum`/`custom`; unknown/empty reject; no lowercasing) so
Python `_figure_trace_support_flags` and Node `figureTraceSupport` cannot
drift. Hosts still check hexbin kind. Compile-path `HEXBIN_REDUCES` in
`scene_export.rs` stays extra.
ABI 233 `xyg_scene_curve_classify` owns Scene curve names (`linear` → 0,
`smooth` → 1; unknown/empty → 255; trim then lowercase) so Python
`_figure_trace_support_flags` and Node `figureTraceSupport` cannot drift.
Hosts still check kind for `smooth`. Compile-path `curve_smooth` in
`scene_trace_compile.rs` stays extra.
ABI 234 `xyg_scene_marker_glyph_admit` owns Scene marker-glyph UTF-8 admit
(nonempty, no NUL/CR/LF, at most 64 bytes) so Python `_admitted_marker_glyph`
and Node `admittedMarkerGlyph` cannot drift. Hosts still coerce non-strings
and check scatter kind / combined `marker_path`. Compile-path `admit_glyph`
stays extra.
ABI 235 `xyg_scene_kind_admit` owns Scene product-kind names (exact
`scatter`/`line`/`bar`/`column`/`histogram`/`violin`/`box`/`segments`/
`errorbar`/`stem`/`contour`/`box_whisker`/`box_median`/`area`/`error_band`/
`ribbon`/`triangle_mesh`/`hexbin`/`heatmap`; unknown/empty reject; no
lowercasing) so Python `_figure_trace_support_flags` and Node
`figureTraceSupport` cannot drift. Packing-family bits are ABI 236.
ABI 236 `xyg_scene_kind_class` owns Scene packing-family bits (rect/segment/
band/ribbon/polyfill/hexbin/heatmap/stroke/scatter/line; unknown/empty → 0;
no lowercasing) so Python `_scene_v3` pack and Node `scene.js` pack cannot
drift. Hosts still pick channels and pack rows. Smooth-kind eligibility
uses the existing LINE|BAND bits (no new ABI).
ABI 237 `xyg_scene_hexbin_pitch_admit` owns Scene hexbin cell-pitch admit
(finite strictly-positive `dx`/`dy`) so Python `_hexbin_pitch` and Node
XYEP pack cannot drift. Field picking (`hex_dx` vs `dx`) stays host.
Compile-path `hex_pitch` in `scene_trace_compile.rs` stays extra.
ABI 238 `xyg_scene_heatmap_extent_admit` owns Scene heatmap cell-extent
admit (all four finite and `x0 < x1 && y0 < y1`) so Python `_heatmap_extent`
and Node XYEP pack cannot drift. Length==2 and field picking stay host.
Compile-path `heatmap_extent_columns` in `scene_pack.rs` stays extra.
ABI 239 `xyg_scene_heatmap_colormap_admit` owns Scene heatmap colormap
eligibility (OR of already-coerced truecolor / colormap / rgba_grid / rgba
flags) so Python `_heatmap_uses_colormap` and Node `figureTraceSupport`
cannot drift. Field picking and truthy coercion stay host. Kind checks
stay host.
ABI 240 `xyg_scene_heatmap_shape_admit` owns Scene heatmap lattice-shape
admit (finite integer-valued `rows`/`cols` `>= 1`) so Python `_heatmap_shape`
and Node XYEP pack cannot drift. Length==2 stays host. XYTA integer coerce
uses the same kernel (no new ABI). Closes Python `int()` truncation vs Node `Number.isInteger`.
ABI 241 `xyg_scene_scatter_paint_channel_admit` owns Scene scatter paint-plane
channel names (exact `color`/`stroke`/`stroke_width`/`opacity`/`artist_alpha`;
unknown/empty → 0; no lowercasing) so Python `_scatter_packs_paint_plane` and
Node `scatterPacksPaintPlane` cannot drift. Kind, density, and name gathering
stay host.
ABI 242 `xyg_scene_hexbin_colormap_plane_admit` owns Scene hexbin colormap-plane
packing (exact `continuous` plus a values-present flag; unknown/empty → 0; no
lowercasing) so Python `_hexbin_packs_colormap_plane` and Node
`hexbinPacksColormapPlane` cannot drift. Kind checks and field picking
(`color_ch` vs `colorChannel`, `values` vs `metric`) stay host.
ABI 243 `xyg_scene_hexbin_rgba_plane_admit` owns Scene hexbin RGBA-plane
modes (exact `categorical`/`direct_rgba`; unknown/empty → 0; no lowercasing)
so Python `_hexbin_packs_rgba_plane` and Node `hexbinPacksRgbaPlane` cannot
drift. Kind checks, field picking, and RGBA8 packing stay host.
ABI 244 `xyg_scene_mesh_paint_plane_admit` owns Scene mesh paint-plane packing
(exact `triangle_mesh` plus `joined_fill == 0` plus a per-item flag;
unknown/empty → 0; no lowercasing) so Python `_mesh_packs_paint_plane` and
Node `meshPacksPaintPlane` cannot drift. `joined_fill` field picking and
`has_per_item` gathering stay host.
ABI 245 `xyg_scene_item_apply_opacity` owns Scene per-item RGBA8 artist-alpha
replace then opacity multiply (ties-to-even u8 quantize) so Python
`_item_apply_opacity` and Node `itemApplyOpacity` cannot drift. Field picking
stays host.
ABI 246 `xyg_scene_item_widths_admit` owns Scene per-item stroke-width
admit (present values: `len == n` and every value finite `>= 0`; absent:
finite scalar `>= 0`) so Python `_item_widths` and Node `itemWidths` cannot
drift. Field picking and f64 packing stay host.
ABI 247 `xyg_scene_item_fill_t` owns Scene continuous per-item fill unit-t
(domain pair as-is, else finite min/max; zero/non-finite span → zeros;
clip to `[0, 1]`) so Python `_item_fill_rgba8` and Node `itemFillRgba8`
cannot drift. Field picking and colormap lookup stay host.
ABI 248 `xyg_scene_finite_all` owns Scene finite-all admit (empty → `1`)
so Python `_xyep_finite` / heatmap XYEP and Node `exportColumnFinite`
cannot drift. Field picking stays host.
ABI 249 `xyg_scene_gradient_solid_css` owns Scene gradient solid CSS
(first packed RGBA8 stop with alpha `> 0` → `rgb(r,g,b)`; else
`rgb(0,0,0)`) so Python `_gradient_solid_css` and Node `gradientSolidCss`
cannot drift. Field picking stays host.
ABI 250 `xyg_scene_arrays_equal` owns Scene f64 arrays-equal (lengths
match and every pair is IEEE `==`; empty equal; NaN never equals) so
Python companion x1/y1 match and Node `exportArraysEqual` cannot drift.
Field picking and null checks stay host.
ABI 251 `xyg_clip_quantize_u8` owns unit-f64 clip-to-`[0, 1]` × 255
ties-to-even u8 quantize (NaN → 0) so Python `_quantized_rgba8` /
`channels.ship_color_channel` and Node `clipQuantizeU8` /
`resolveColorChannel` / `channelEndRgba8` cannot drift. Field picking
stays host.
ABI 252 `xyg_scene_constant_color_admit` owns Scene constant-color admit
(`0` fail, `1` style fallback, `2` channel constant) so Python
`_constant_color` and Node `constantMarkColor` cannot drift. Ribbon-fail
and field picking stay host.
ABI 253 `xyg_scene_hidden_or_per_item_admit` owns Scene hidden-or-per-item
admit (`hidden || (has_per_item && !density_aggregates)`) so Python
`_figure_trace_support_flags` and Node `figureTraceSupport` cannot drift.
Field picking stays host.

ABI 254 `xyg_arrow_style_pack` owns annotation-arrow `start_offset` /
`label_clear` CSV pack (12 f64s, NaN = absent) so Python `_pack_style` and
Node `packArrowStyle` cannot drift. ChartView still parses those strings
until WASM. Hosts still coerce style keys and elbow truthiness.
ABI 255 `xyg_encoded_column_meta` owns EncodedColumn offset/scale/kind-presence
packing so Python `lod.encode_f32_values` and Node `encodeF32Values` cannot
drift. Hosts still copy the original kind string.
ABI 256 `xyg_scene_channel_constant_css` owns Scene channel-constant CSS
(`mode == "constant"` and `has_constant`) so Python `_channel_constant_css`
and Node `channelConstantCss` cannot drift. Hosts still pick `.mode` /
`.constant` vs `.color` and skip null channels.
Python `colormap_lut_rgba8` and Node `colormapLutRgba8` pack 256-texel LUTs
through ABI 343 `xyg_colormap_lut_rgba8` (named or custom RGB stops).
Python `quantize_unit_u8` / `_quantized_lut_idx` and Node
`quantizeUnitU8` / `resolveDensityBinColors` normalize and quantize through
ABI 341 `xyg_quantize_unit_u8`.
Equal or non-finite domain stays a host zero-span short-circuit.
Python `palette_rows_rgba8` and Node `paletteRowsRgba8` pack indexed palette
rows through ABI 342 `xyg_palette_rows_rgba8`. ABI 346 adds per-entry
unresolved flags so browser-only warnings stay host without a second CSS parse.
Python `categorical_palette` and Node `categoricalPalette` repeat base palette
colors through ABI 347 `xyg_categorical_palette`. Python `resolve_color`
palette-map resolution and Node `categoricalPaletteMapResolve` share ABI 347
`xyg_categorical_palette_map_resolve`; browser-only warnings stay host-side.
ABI 360 removes the last host-owned built-in palette copy.
`xyg_default_palette_version`, `xyg_default_palette_rows`,
`xyg_default_palette_utf8`, and `xyg_default_palette_rgba8` expose query-first,
capacity-aware fixed-width text and RGBA8 rows from the sole
`xyg-engine::kernels::DEFAULT_PALETTE` definition. Short buffers return the
required byte count without mutation; nonzero capacity with a null destination
returns `usize::MAX`. Python's `config.DEFAULT_PALETTE` is a lazy immutable
sequence over that contract, while Node's exported frozen palette is populated
from it during native module initialization. WASM ABI 25 exposes the same
engine version/rows, fails worker initialization on a version or row-count mismatch, and
uses the shared first RGBA8 row for omitted XYTS series paint.
Python `resolve_direct_rgba` and Node `colorChannelDirectRgbaF64*` sample LUT
channels through ABI 348 `xyg_color_channel_direct_rgba_f64_*`.
Python `is_colormap`, `_is_resolved_stops`, and `_validate.colormap_stops` /
Node `colormapIsBuiltin`, `colormapResolvedStopsAdmit`, and
`colormapCustomStopsResolve*` share ABI 349 colormap custom-stop resolve;
pair-shape validation and authoring error text stay host-side.
Python `channels._size_range` and Node `resolveSizeChannel` / `sizeRangeAdmit`
validate scatter size pixel endpoints through ABI 350 `xyg_size_range_admit`;
Node continuous size domains use ABI 213 `continuousDomain` like Python
`_continuous_domain`. Python `channels._is_categorical` and Node
`arrayIsCategorical` classify dtype/object columns through ABI 351
`xyg_array_is_categorical`; object-row tag loops stay host-side.
Python `channels._as_real_array`, `_figure._real_float_array`, and `columns`
numeric ingest plus Node `realNumericDtypeAdmit` reject boolean/complex dtype
kinds through ABI 352 `xyg_real_numeric_dtype_admit`; object-row real-numeric
probes stay host-side.
Python `channels._object_row_*_tag` and Node `objectRow*TagFromProbe` map host
value probes through ABI 353 `xyg_object_row_*_tag_from_probe`; per-row Python/
JS type inspection stays host-side.
Python `channels._category_label_kind_and_bytes` and Node `categoryLabelKindAndBytes`
select label kinds through ABI 354 `xyg_category_label_kind_from_probe`; UTF-8
payload encoding stays host-side.
Python `palette_rgba8` and Node `categoryCodeWidth` / `categoryPaletteRows` share
ABI 355 `xyg_category_code_width` and `xyg_category_palette_rows` for the 256
category u8/u32 boundary and indexed palette row cap.
Python `channels._object_column_is_*` and Node `objectColumnIs*` batch map host
value probes through ABI 356 `xyg_object_row_*_tags_from_probes`; per-row Python/
JS type inspection stays host-side.
Python `channels._category_labels` and Node `categoryLabels` batch map host value
probes through ABI 357 `xyg_category_label_kinds_from_probes`; UTF-8 payload
encoding stays host-side.
Python optimized Scene PNG export consumes ABI 358 `xyg_rasterize_rgb`, the
same opaque-white Rust display-list painter as the fused PNG consumer, before
calling Rust's indexed encoder. ABI 359 adds explicit output capacity to it and
the RGBA, data-arena, and multi-span framebuffer entries. ABI 359 applies the
same contract to every other caller-owned 2-D RGBA product output: mean-color
binning, normalized/canonical colormaps, heatmap, log/linear density, and both
colored compose backends (whose f32 count planes are capacity-aware too). Each
validates checked `w*h*channels`, the Rust `isize::MAX` slice ceiling, and the
actual allocation capacity before constructing a mutable slice. Python and
Node pass their NumPy/TypedArray element or byte counts; generated declarations
record each unit explicitly. `optimize=True` therefore
changes encoding without reintroducing Python geometry or paint policy. The
three fused PNG consumers also reject encoded-output capacities above
`isize::MAX` before constructing their caller-owned destination slice.
Python `_literal_color_rgba` and Node `resolveColorChannel` literal CSS columns
pack through ABI 344 `xyg_literal_color_rgba_f64`. The first-entry functional
syntax probe stays host-side so categorical columns are rejected without
materializing the whole column.
Node `channelEndRgba8` categorical paints index ABI 342 `paletteRowsRgba8`
rows like Python `palette_rows_rgba8`, not per-point CSS reparsing.
Python `lod._stratified_sample_range_plan` and Node `stratifiedSampleRangePlan`
size categorical sampling buffers through ABI 345
`xyg_stratified_sample_range_plan`. Hosts still validate group codes and exact
per-code counts before calling.
Python `_svg._paint_rgba8` resolves CSS paints through `xyg_css_color_rgba`,
matching `_raster._parse_color` and Node `cssColorRgba8`.
Python `resolved_hex_paint` / `_resolved_rgb` quantize `css_check` 0-1
channels through ABI 251 `xyg_clip_quantize_u8`. Browser-only rejection stays host.
Python `resolve_style_channel` admits finite arrays through ABI 248
`xyg_scene_finite_all`. Bounds checks stay host.
SVG `_rgb_css` formats 0-1 RGB through ABI 251 `xyg_clip_quantize_u8`.
SVG authored-scatter marker RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster scatter RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster mesh/hexbin fill RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster rectangle style RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster segment stroke RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster mesh stroke RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster ribbon fill RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Raster ribbon match-fill edge RGBA8 uses ABI 251 `xyg_clip_quantize_u8`.
Node `meshHasPerItem` uses `perItemChannelNames` (same as Python `has_per_item_channels`) for ABI 244.
Node `scatterPaintChannelNames` uses `perItemChannelNames` (same as Python `per_item_channel_names`) for ABI 241.
Node hexbin colormap-plane packing uses `channel.values` (same as Python); `trace.metric` is not a values fallback.
Node empty kind uses `|| "mark"` (same as Python `or "mark"`).
Node `figureTraceSupport` does not fail-close `style.smooth`; curve names stay ABI 233.
Node `itemWidths` fail-closes a present `stroke_width` channel without values (same as Python).
Node `itemApplyOpacity` fail-closes a present opacity/artist_alpha channel without values (same as Python).
Node missing scatter kind uses `|| ""` (same as Python); it is not defaulted to `"scatter"`.
Node `fillIsGradientAuthoring` rejects arrays (same as Python dict-only).
Node `rectExtraFlags` treats only mapping fills as gradient-fail (same as Python dict-only).
Node `admittedMarkerGlyph` rejects non-strings (same as Python `isinstance(..., str)`).
Node `packXyTaColormap` uses `style.colormap` only (same as Python); `trace.colormap` / `colormapStops` are not fallbacks.
Node hexbin XYTA colormap uses `channel.colormap` only (same as Python); `style.colormap` is not a fallback.
Node XYHF heatmap/density colormap uses `style.colormap` only (same as Python); `trace.colormap` / `colormapStops` are not fallbacks.
Node `constantMarkColor` uses `color_ch.constant` only (same as Python); string channels, `channel.color`, and `trace.color` are not fallbacks.
Node `channelConstantCss` uses `channel.constant` only (same as Python); string channels and `channel.color` are not fallbacks. Mode/has_constant admit is ABI 254.
Node `channelEndRgba8` constant paint uses `channel.constant` only (same as Python); string channels and `channel.color` are not fallbacks.
Node `sourceColorCss` uses `color_ch` only (same as Python); `trace.color` is not a source-channel fallback.
Node `resolveColorChannel` constant CSS uses `.constant` (same as Python `ColorChannel`); `composeRibbon` writes `color_ch` / `color2_ch`.
Node `color2Channel` uses `color2_ch` only (same as Python); `color_target` / `colorTarget` are not Scene-pack fallbacks.
Node `itemFillRgba8` uses `color_ch` only (same as Python); `trace.color` is not a fill-channel fallback.
Node `scatterPaintChannelNames` uses `color_ch` only (same as Python); `trace.color` is not a per-item color channel.
Node `scatterHasNonConstantColor` uses `color_ch` only (same as Python); `trace.color` is not a non-constant-color fallback.
Node `resolveDensityBinColors` uses `color_ch` only (same as Python); `trace.color` is not a density-bin color channel.
Node `scatterHasNonConstantColor` ignores `style.color_channel` (same as Python); only `color_ch` is a non-constant-color channel.
Node `scatterPaintChannelNames` ignores `style.color_channel` / `stroke_channel` / `size_channel` (same as Python); per-item extras come from `style_channels`.
Node `_emitScatterDensity` constant_color attach uses `color_ch.constant` like Python `_density_trace_spec`; `style.color` is not a density-color fallback. Node `resolveDensityBinColors` ignores `style.color_channel` (same as Python); only `color_ch` is a density-bin color channel.
Node XYMS mark color uses `style.color` only (same as Python `_constant_color` style fallback); `trace.color` is not a mark-color fallback.
Node XYTC style color uses `style.color` only (same as Python); `trace.color` is not a packed-color fallback.
Node XYTC constant paint uses `channel.constant` only (same as Python); `channel.color` is not a packed-constant fallback.
Node density-blit observation uses `scatterUsesDensity` (same as Python `use_density`); `style.color_channel` is not a per-item density extra.
Node XYTC color_ch packing ignores string channels (same as Python object-only); only a channel object packs COLOR_CH.
Node `scatterHasNonConstantColor` uses `channel.constant` only (same as Python); `channel.color` is not a packed-constant stand-in.
Node XYTC `COLOR_CH_CONSTANT` packs whenever `channel.constant` is set (same as Python); `mode === "constant"` is not a gate.
Node XYMS mark color uses `constantMarkColor` / ABI 252 (same as Python `_constant_color`); `style.color` is the code-1 fallback only.
Node `scatterPerItemChannels` ignores `style.color_channel` / `size_channel` / `stroke_channel` (same as Python `has_per_item_channels`); only `*_ch` presence counts.
Node `scatterPerItemChannels` is mode-based like Python `has_per_item_channels`; a constant `color_ch` is not per-item.
Node `channelEndRgba8` ignores array and typed-array channels (same as Python object-only); only `null` and mode objects pack.
Node `channelEndRgba8` categorical paint uses `DEFAULT_PALETTE` when palette is empty (same as Python); fallback CSS is not a missing-slot stand-in.
Node `packXyTaColormap` stop bytes require RGB rows like Python `_colormap_stop_bytes`; a flat or RGBA list packs empty stops.
Node `xyHfColormap` stop bytes require RGB rows like Python `_colormap_stop_bytes`; a flat or RGBA list packs empty stops.
Node `packXyTaRgbaGrid` stacks flattened planes like Python `_pack_xyta` `rgba_grid`; nested 2D index fallback is not a plane layout.
Node heatmap `trace.rgba` stores a flat uint8 buffer; `packXyTaRgba` packs that buffer like Python `_pack_xyta` and does not unwrap nested `.rgba`.
Node heatmap and density Scene packing is XYTA-only like Python `_pack_xyta`; unused XYHF paint-plane helpers are not a second plane layout.
Node `packXyTaGrid` flattens heatmap `grid` like Python `_pack_xyta` (`plane.values` or plane); nested length indexing is not a grid layout.
Node `rectFiniteSel` drops nonfinite rectangle rows through `validIndicesF64` like Python `_rect_finite_sel`; NaN never reaches vertex buffers (§19).
Node `packXyTa` density fill opacity uses `style.fill_opacity` only like Python `_pack_xyta`; `fillOpacity` is not a fill-opacity key.
Node XYTC fill opacity uses `style.fill_opacity` only like Python `_pack_xytc`; `fillOpacity` is not a fill-opacity key.
Node XYTC stroke opacity uses `style.stroke_opacity` only like Python `_pack_xytc`; `strokeOpacity` is not a stroke-opacity key.
Node XYTC line opacity uses `style.line_opacity` only like Python `_pack_xytc`; `lineOpacity` is not a line-opacity key.
Node XYTC stroke width uses `style.stroke_width` only like Python `_pack_xytc`; `strokeWidth` is not a stroke-width key.
Node XYTC line width uses `style.line_width` only like Python `_pack_xytc`; `lineWidth` is not a line-width key.
Node XYTC size uses `style.size` only like Python `_pack_xytc`; `diameter` is not a size key.
Node XYTC line color uses `style.line_color` only like Python `_pack_xytc`; `lineColor` is not a line-color key.
Node XYTC joined fill uses `style.joined_fill` only like Python `_pack_xytc`; `joinedFill` is not a joined-fill key.
Node XYTC stroke perimeter uses `style.stroke_perimeter` only like Python `_pack_xytc`; `strokePerimeter` is not a stroke-perimeter key.
Node XYTC COLOR_CH packing uses `color_ch` only like Python `_pack_xytc`; `colorChannel` is not a packed-channel fallback.
Node XYTC size_ch packing uses `size_ch` only like Python `_pack_xytc`; `sizeChannel` is not a packed-channel fallback.
Node XYEF stroke-width-only observation uses `style.stroke_width` only like Python; `strokeWidth` is not an observation key.
Node `meshJoinedFill` uses `style.joined_fill` only like Python `_mesh_joined_fill`; `joinedFill` is not a joined-fill key.
Node XYEF joined-fill observation uses `style.joined_fill` only like Python; `joinedFill` is not an observation key.
Node `constantMarkColor` uses `color_ch` only like Python `_constant_color`; `colorChannel` is not a source-channel fallback.
Node `sourceColorCss` uses `color_ch` only like Python `_trace_source_color_css`; `colorChannel` is not a source-css fallback.
Node `scatterHasNonConstantColor` uses `color_ch` only like Python; `colorChannel` is not a non-constant-color fallback.
Node `classifyRibbonColor2` source-constant CSS uses `color_ch` only like Python `_classify_ribbon_color2`; `colorChannel` is not a source-constant fallback.
Node `itemFillRgba8` uses `color_ch` only like Python `_item_fill_rgba8`; `colorChannel` is not a fill-channel fallback.
Node `resolveDensityBinColors` uses `color_ch` only like Python; `colorChannel` is not a density-bin color channel.
Node `hexbinPacksColormapPlane` uses `color_ch` only like Python `_hexbin_packs_colormap_plane`; `colorChannel` is not a colormap-plane fallback.
Node `ribbonEndRgbaPair` uses `color_ch` only like Python `_ribbon_end_rgba_pair`; `colorChannel` is not a ribbon-end source fallback.
Node `hexbinXyTaColormap` uses `color_ch` only like Python `_pack_xyta` hexbin colormap; `colorChannel` is not a colormap fallback.
Node `hexbinPacksRgbaPlane` uses `color_ch` only like Python `_hexbin_packs_rgba_plane`; `colorChannel` is not an RGBA-plane fallback.
Node `hexbinCellRgba8` uses `color_ch` only like Python `_hexbin_cell_rgba8`; `colorChannel` is not a cell-paint fallback.
Node XYTA density color_ch packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a packed-constant fallback.
Node `itemStrokeRgba8` uses `stroke_ch` only like Python `_item_stroke_rgba8`; `strokeChannel` is not a stroke-channel fallback.
Node `scatterPointStrokeRgba8` uses `stroke_ch` only like Python `_scatter_point_stroke_rgba8`; `strokeChannel` is not a match-fill opacity skip.
Node `perItemChannelNames` uses `color_ch` / `stroke_ch` / `size_ch` / `style_channels` only like Python `per_item_channel_names`; camelCase channel fields are not per-item name fallbacks.
Node `itemApplyOpacity` uses `style_channels` only like Python `_item_apply_opacity`; `styleChannels` is not an opacity-channel fallback.
Node `itemWidths` uses `style_channels` only like Python `_item_widths`; `styleChannels` is not a width-channel fallback.
Node `scatterUsesDensity` uses `force_density` only like Python `use_density`; `forceDensity` is not a density-force fallback.
Node `figureTraceSupport` uses `style.linecap` only like Python `_figure_trace_support_flags`; `lineCap` is not a dashed-marker linecap fallback.
Node `packXyTcLinecap` uses `style.linecap` only like Python `_pack_xytc`; `lineCap` is not a packed-linecap fallback.
Node `packXyAfLinecap` uses `style.linecap` only like Python `_pack_xyaf`; `lineCap` is not an annotation-linecap fallback.
Node `scatterUsesDensity` does not pass `force_direct` like Python `use_density`; `forceDirect` / `force_direct` are not density-direct overrides.
Node hexbin XYTA values packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a hexbin-grid values fallback.
Node `legendStyleFontSizes` uses `style.font_size` / `style.title_font_size` only like Python `_legend_input`; `fontSize` / `titleFontSize` are not legend-font fallbacks.
Node `heatmapGridShape` uses `grid_shape` only like Python `_heatmap_shape`; `gridShape` is not a heatmap-lattice fallback.
Node `hexbinStylePitch` uses `style.hex_dx` then `style.dx` like Python `_hexbin_pitch`; `hexDx` / `hexDy` are not hexbin-pitch fallbacks.
Node `polarGridShape` uses axis `grid_shape` only like Python `_pack_polar_scene_input`; `gridShape` is not a polar-grid fallback.
Node `polarAxisThetaUnit` uses axis `theta_unit` only like Python `_pack_polar_scene_input`; `thetaUnit` is not a polar-unit fallback.
Node `polarAxisThetaZero` uses axis `theta_zero` only like Python `_pack_polar_scene_input`; `thetaZero` is not a polar-zero fallback.
Node `polarAxisThetaDirection` uses axis `theta_direction` only like Python `_pack_polar_scene_input`; `thetaDirection` is not a polar-direction fallback. Node `polarAxisROrigin` uses axis `r_origin` only like Python `_pack_polar_scene_input`; `rOrigin` is not a polar-origin fallback. Node `axisTickValues` uses axis `tick_values` only like Python `_pack_figure_chrome`; `tickValues` is not a chrome-major-tick fallback. Node `axisMinorTickValues` uses axis `minor_tick_values` only like Python `_pack_figure_chrome`; `minorTickValues` is not a chrome-minor-tick fallback. Node `axisTickLabels` uses axis `tick_labels` only like Python `_pack_figure_chrome`; `tickLabels` is not a chrome-tick-label fallback. Node `figureXLabel` uses `x_label` then axis `label` like Python `_pack_figure_chrome`; `xLabel` is not a chrome-xlabel fallback. Node `figureYLabel` uses `y_label` then axis `label` like Python `_pack_figure_chrome`; `yLabel` is not a chrome-ylabel fallback. Node `plotTopAxisRoom` uses plot `top_axis_room` only like Python `recut_polar_plot`; `topAxisRoom` is not a polar-recut-room fallback. Node `axisTickLabelAnchor` uses axis `tick_label_anchor` only like Python `_scene_tick_anchor_code`; `tickLabelAnchor` is not a chrome-tick-anchor fallback. Node `axisTickLabelMinGap` uses axis `tick_label_min_gap` only like Python `_pack_tick_collision`; `tickLabelMinGap` is not a chrome-tick-gap fallback. Node `axisTickLabelAngle` uses axis `tick_label_angle` only like Python `_pack_tick_collision`; `tickLabelAngle` is not a chrome-tick-angle fallback. Node `axisTickLabelStrategy` uses `tick_label_strategy` then `collision` like Python `_scene_tick_label_strategy`; `tickLabelStrategy` is not a chrome-tick-strategy fallback. Node `polarCollisionKeys` uses snake-case keys only like Python `_POLAR_COLLISION_KEYS`; camelCase tick-label keys are not polar-collision-key extras. Node `figureChromeStyles` uses `chrome_styles` only like Python `_pack_figure_support`; `chromeStyles` is not a chrome-styles fallback. Node `chromeStyleHasFontFamily` uses `font-family` only like Python `_pack_figure_support`; `fontFamily` is not a chrome-font-family fallback. Node `figureClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not a figure-class-name fallback. Node `figureClassNames` uses `class_names` only like Python `_pack_figure_support`; `classNames` is not a figure-class-names fallback. Node `annotationClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not an annotation-class-name fallback. Node `figureExtraLegends` uses `extra_legends` only like Python `_pack_figure_support`; `extraLegends` is not an extra-legends fallback. Node `figureTitleOptions` uses `title_options` only like Python `_pack_public_export_support`; `titleOptions` is not a title-options fallback. Node `figureLegendOptions` uses `legend_options` only like Python `_legend_input`; `legend` is not a legend-options fallback. Node `figureColorbarOptions` uses `colorbar_options` only like Python `_colorbar_input`; `colorbarOptions` is not a colorbar-options fallback. Node `figureShowLegend` uses `show_legend` only like Python `_legend_input`; `showLegend` is not a show-legend fallback. Node `figureAxisOptions` uses `axis_options` only like Python `_pack_figure_chrome`; `xAxis` / `x_axis` are not axis-options fallbacks. Node `axisScaleName` uses axis `type` only like Python `_axis_scale`; `kind` is not an axis-scale fallback. Node `figureAutorangeAxisOptions` uses `axis_options` only like Python `_axis_scale`; `xAxis` is not an autorange-axis fallback. Node `_emitScatter` uses `force_density` only like Python `payload_force_density`; `style.force_density` is not a payload-density fallback. Node `_emitScatter` does not read `style.force_direct` like Python `_emit_scatter`; `style.force_direct` is not a payload-direct fallback. Node `_emitScatter` does not read `style.force_pyramid` like Python `_emit_scatter`; `style.force_pyramid` is not a payload-pyramid fallback. Node `chromeAxisMinorStyle` uses `minor_style` only like Python `_pack_chrome_axis`; `minorStyle` is not a chrome-minor-style fallback. Node `chromeAxisTickSides` uses `tick_sides` only like Python `_pack_chrome_axis`; `tickSides` is not a chrome-tick-sides fallback. Node `chromeAxisTickLabelSides` uses `tick_label_sides` only like Python `_pack_chrome_axis`; `tickLabelSides` is not a chrome-tick-label-sides fallback. Node `chromeAxisStyleKeys` admits snake-case keys only like Python `_SCENE_AXIS_STYLE_KEYS`; camelCase axis style keys are not a chrome-axis-style-keys fallback. Node `chromeAxisStyleHas` / `chromeAxisStyleValue` read snake-case keys only like Python `_pack_chrome_axis`; camelCase fields are not a chrome-axis-style-read fallback. Node `legendAxisScale` uses axis `type` only like Python `_axis_scale`; `scale` / `kind` are not a legend-axis-scale fallback. Node `figureAutorangeAxisScale` uses axis `type` only like Python `_axis_scale`; `kind` is not an autorange-axis-scale fallback. Node `figureAxisKind` matches Python `_axis_kind` (forced `type` time, then category labels, then `time_ms` columns); axis `kind` is not an autorange-axis-kind fallback. Node `chromeAxisTickKind` uses `Figure._axisKind` like Python `_pack_figure_chrome` / `_pack_tick_collision`; axis `kind` is not a chrome-tick-kind fallback. Node `xyEfResolvedKind` uses `Figure._axisKind` like Python `_pack_public_export_support`; axis `kind` is not an xyef-axis-kind fallback. Node `figureAutorangeThetaUnit` uses axis `theta_unit` only like Python `_pack_autorange`; `thetaUnit` is not an autorange-theta-unit fallback. Node `figureAxisIsLog` uses axis `type` only like Python `_axis_scale` log; `scale` is not an axis-is-log fallback. Node `figureAutorangeCategories` uses `_axis_categories` only like Python `_pack_autorange`; `options.categories` is not an autorange-categories fallback. Node `figureAutorangeDomain` uses axis `domain` only like Python `_pack_autorange`; `_axisRange` is not an autorange-domain fallback. Node `setPolarMeta` writes axis `theta_unit` like Python `set_axis`; `_polarMeta.thetaUnit` is not a polar-meta-unit fallback. Node `setPolarMeta` writes axis `theta_zero` like Python `set_axis`; `_polarMeta.thetaZero` is not a polar-meta-zero fallback. Node `setPolarMeta` writes axis `theta_direction` like Python `set_axis`; `_polarMeta.thetaDirection` is not a polar-meta-direction fallback. Node `setPolarMeta` writes axis `grid_shape` like Python `set_axis`; `_polarMeta.gridShape` is not a polar-meta-grid fallback. Node `setPolarMeta` writes axis `hole` like Python `set_axis`; `_polarMeta.hole` is not a polar-meta-hole fallback. Node `setPolarMeta` writes axis `sector` like Python `set_axis`; `_polarMeta.sector` is not a polar-meta-sector fallback. Node `polarAxisHole` uses axis `hole` only like Python `_pack_polar_scene_input`; `Hole` is not a polar-hole fallback. Node `polarAxisSector` uses axis `sector` only like Python `_pack_polar_scene_input`; `Sector` is not a polar-sector fallback. Node `_polarAxisSpecs` uses axis `theta_unit` like Python `_axis_spec`; `_polarMeta.thetaUnit` is not a polar-spec-unit fallback. Node `_polarAxisSpecs` uses axis `theta_zero` like Python `_axis_spec`; `_polarMeta.thetaZero` is not a polar-spec-zero fallback. Node `_polarAxisSpecs` uses axis `theta_direction` like Python `_axis_spec`; `_polarMeta.thetaDirection` is not a polar-spec-direction fallback. Node `_polarAxisSpecs` uses axis `grid_shape` like Python `_axis_spec`; `_polarMeta.gridShape` is not a polar-spec-grid fallback. Node `_polarAxisSpecs` uses axis `sector` like Python `_axis_spec`; `_polarMeta.sector` is not a polar-spec-sector fallback. Node `_polarAxisSpecs` uses axis `hole` like Python `_axis_spec`; `_polarMeta.hole` is not a polar-spec-hole fallback. Node `_polarAxisSpecs` uses axis `r_origin` like Python `_axis_spec`; `_polarMeta.rOrigin` is not a polar-spec-origin fallback. Node `packPolarSceneInput` uses figure `_range("y")` like Python `_pack_polar_scene_input`; `rAxis.range` is not a polar-range fallback. Node `_emitTriangleMesh` ships x2/y2 via `payloadColumnShipPlan` / `shipRegistryColumns` like Python `_emit_triangle_mesh`. Node `_emitScatterDensity` ships wasm_source via `payloadColumnShipPlan` / `shipRegistryColumns` like Python `_density_trace_spec`; cross-host proof: `tests/fixtures/density_emit_cross_host.json` case `scatter_density_wasm_source_split`. Node `buildPayload` ships `show_legend` like Python `build_payload` via ABI 303 `attach_show_legend`. Node `buildPayload` ships `padding` like Python `build_payload` via ABI 303 `attach_padding`. Node `buildPayload` ships `dom` via `domSpec` like Python `_dom_spec` via ABI 303 `attach_dom`; `domSpec` maps `chrome_styles` to `dom.styles` via `styleMapping`. Node `buildPayload` ships `wasm_density` like Python `build_payload` via ABI 303 `attach_wasm_density`; automatic and unsupported wire kinds follow `density_wasm_density_wire_kind`. Node `buildPayload` ships `frame_sides`, `show_modebar`, `export`, `show_tooltip`, `tooltip`, `mark_style`, `interaction`, `animation`, `graph`, and `palette` like Python `build_payload` via the corresponding ABI 303 attach flags; mapped palettes ship `palette_cycle` values not category labels. Node `buildPayload` computes one range per declared axis (reused across traces like Python's `axis_range` cache), passes each trace the ranges of its own bound `x_axis`/`y_axis`, emits an axis spec for every `axis_options` key, and derives `view.ranges` from those specs like Python `_payload_spec`; the primary x/y range is not a y2-trace range fallback (twinx round 4; the tier-2 density grid is the byte-visible proof). Node `setAxis("y2")` preserves an omitted `side` (stored absent, like Python `set_axis`; primary x/y defaults unchanged) and syncs the authored x/y `label` into `x_label`/`y_label` like Python `set_axis`; an omitted y2 side reaches Rust unobserved and resolves to the right edge, and a left y2 stays Rust-refused on the static path. The live axis spec `side` is resolved by the same Rust function through ABI 392 `xyg_payload_axis_side_resolve` (Python `kernels.payload_axis_side_resolve`, Node `payloadAxisSideResolve`); neither host keeps a y2 side constant (#1044), and the cross-host proof is `tests/test_live_dual_axis_cross_host.py::test_live_y2_side_is_resolved_by_rust_not_a_host_constant`. Node `annotationCommon` carries a bound `y_axis: "y2"` onto the live wire and refuses the binding (or an unknown id) exactly like Python `_annotation_common` — including requiring a declared y2 axis like the mark admission rule — and both hosts resolve a bound annotation's y coordinates (and category lookups) on the y2 ladder; the primary y axis is not a bound-annotation fallback.
The `wasm_source` parity sentence above describes only the explicit
`wasm_source=True` / `wasmSource: true` replay journey. Ordinary Python and
Node split payloads omit canonical f64 and ship only the screen-bounded grid
plus sampled offset-f32 geometry.

ABI 110 makes primary legend framing the same way: Python
and Node call `xyg_scene_pack_legend` with loc/flags/paints/labels.
ABI 111 makes primary colorbar framing the same way: Python and Node call
`xyg_scene_pack_colorbar` with domain/stops/ticks/title.
ABI 112 makes primary annotation framing the same way: Python and Node call
`xyg_scene_pack_annotations` with typed row meta plus concatenated labels.
ABI 113 makes closed-subset SVG→PDF the same way: Python `_pdf.svg_to_pdf` /
`_native.svg_to_pdf` and Node `svgToPdf` call `xyg_svg_to_pdf`; Rust owns
path lowering, Helvetica metrics, ExtGState/shading/image embedding, and
deterministic object numbering. ABI 114 makes static JPEG/WebP the same way:
Python `_jpeg.encode` / `_webp.encode` / `_native.encode_jpeg` /
`_native.encode_webp` and Node `encodeJpeg` / `encodeWebp` call
`xyg_encode_jpeg` / `xyg_encode_webp`; Rust owns YCbCr 4:4:4, Annex K
tables, the libjpeg quality curve, and VP8L simple-lossless packing.
ABI 115 makes static PNG the same way: Python `_png.encode` /
`_png.png_truecolor` / `_native.encode_png` and Node `encodePng` call
`xyg_encode_png`; Rust owns filter-0 scanlines, indexed-palette
selection, `tRNS`, and zlib IDAT. Polar painted heatmap inverse-raster is
Scene-owned (ABI 192). ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` /
`stroke_opacity` on XYMS. ABI 194 admits polar hexbin, custom host reducers, and
categorical / `direct_rgba` hexbin on HexCell PolyFills. ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7. LOD beyond 10,000 tessellated cells, and rich style
exceptions remain compatibility routes.
Scalar colormap and truecolor heatmaps compile through `HeatmapPainted` on Python and Node.
ABI 99 gives both composition hosts one compact grouped box ingress. Hosts pack
the same f64 values/offsets/centers and literal options; Rust returns typed
active-group IDs, fixed 25-f64 group records, monotone outlier offsets, and
fixed 3-f64 outlier records. Vertical and horizontal fixtures compile to
identical Python/Node Scene bytes and feed SVG, raster, and browser consumers.
Host grouping/coercion and literal styles remain seams; Tukey policy, geometry,
stable ordering, deterministic outlier placement, and bounds do not.
Scene v13 covers solid chart/plot backgrounds, authored
  Cartesian side/visibility/major-minor geometry and paint, and a bounded
  single-column primary static legend for named constant-style traces, plus a
  bounded literal RGBA banded colorbar (right/bottom). Scene v19 evolves that
  colorbar to `XYCB` v2: hosts may frame bounded major values and a minor-tick
  request, while Rust resolves labels and geometry in `XYCT` v1 for all three
  consumers, and
  rule, band, marker annotations, bounded Rust-anchored attached labels, and
  bounded Rust-projected literal straight arrows, and bounded Rust-resolved
  Cartesian callouts. Scene v20--v23 add fixed Rust-resolved literal label
backgrounds and bounded literal label-box borders; padding, radius, wrapping,
rich markup, custom typography, and advanced text layout remain unsupported.
Extra legends, named/advanced colorbars, other deferred
  annotation forms, custom
  tick strings, and advanced text layout remain loud unsupported boundaries.
  ABI 84's versioned support predicate makes the
  ordered `XYG_SCENE_UNSUPPORTED_*` reason Rust-owned and byte-identical across
  Python and Node instead of allowing host-specific fallback policy. Both host
  compilers route real polar, custom-font, CSS/class, and normalized gradient
  representations through it and reject non-u32 request versions before FFI
  coercion. See
[scene-ir.md](scene-ir.md).
Per-item scatter symbol stays fail-closed (per-item size rides the Rust-mapped scatter paint plane, ABI 386, #1006); density/LOD remain explicit compatibility exceptions. Python custom glyph/path markers and other
not-yet-migrated customization remain explicit compatibility exceptions until
bounded path, text, and chrome records land.

ABI 96 additionally admits the bounded primary Cartesian numeric format
grammar `<prefix>(,).N[f|%]<suffix>` with precision `N` from 0 through 100 on
linear, log, and symlog axes without a Scene-version change. Python and Node
frame the authored strings in the same
versioned `XYAF` authoring envelope; Rust alone parses the grammar, resolves
labels and gutters, and emits existing explicit-major plus `XYTL` bytes. Shared
fixtures pin exact Python/Node formatted Scene bytes and the Node forwarding of
scale kind, symlog constant, and log nonpositive policy. Explicit authored
labels win, invalid grammar retains default labels, and legacy raw `XYAD`
annotation input remains accepted. The bounded, atomic Worker seam introduced
in WASM ABI 23 is carried by current WASM ABI 27 for Rust-owned f64
linear/log/symlog/category/angular/UTC-time
values, steps, and formatting. M2 #869 generalizes `attachWasmTicks` to
primary/secondary Cartesian, polar angular/radial, authored minor, and eligible
colorbar slots. Hosted `to_html()`, notebook widgets, and application-host embeds
attach when they pass explicit Worker/WASM URLs; srcdoc and other unattached
paths fail closed instead of running a canonical TypeScript fallback.

For the migrated subset, public Python SVG and native PNG now use the Rust
Scene consumers and public PDF consumes their Rust SVG. The shared predicate
chooses the compatibility renderer only before Scene compilation for an
explicit unsupported feature, an export-only background override, or a valid
viewport too small for bounded Scene chrome. A malformed input or Rust
consumer failure remains an error rather than a fallback signal.
`public_static_export` is now the only optional Python product-route selector;
the older format-specific `try_public_*` adapters have been retired. The
support predicate itself is ABI 105 `xyg_scene_public_export_reason`; hosts
only pack literal figure metadata. The Python public router and facet SVG/
raster paths reuse the predicate's compiled Scene instead of compiling a second
batch for the Rust SVG/raster/PDF consumers. Format dispatch is ABI 164
`xyg_scene_static_export`. Explicit `figure_svg` /
`figure_raster_commands` callers still compile on demand. ABI 106 `xyg_figure_autorange` owns the
product domain/padding/polar/zero-baseline decisions from the same packed
extents both hosts already had. Consequently, ordinary autoranged line,
scatter, bar, and histogram figures now produce byte-identical Scene, SVG, and
raster-command output in Python and Node; the executable differential is
`tests/test_static_export_cross_host.py`. Unsupported browser CSS remains an
explicit preflight miss and only Python's documented compatibility renderer
handles it. ABI 107 `xyg_scene_resolve_mark_styles` /
`xyg_css_color_rgba` own per-kind fill/stroke defaults and CSS→RGBA8 so named
colors cannot drift. ABI 108 `xyg_scene_resolve_chrome_style` owns the 200-byte
Scene chrome style input so default axis/grid/tick/label RGBA, default widths,
and `grid_opacity` scaling of the default grid color cannot drift. ABI 109
`xyg_scene_pack_trace` owns Figure→Scene row packing so record kinds,
stable-id splitting, expansion modes, ribbon/triangle doubling, heatmap
lattice framing, and finite-coordinate rejection cannot drift. ABI 136
`xyg_scene_resolve_pack_kind` / `xyg_scene_pack_product` own product-kind
mapping and the canonical host column envelope so pack-kind dispatch cannot
drift. ABI 147 `xyg_scene_pack_product_facts` owns flags, `step_mode`, and
extra0/extra1 from packed XYPK v1 so cartesian-vs-polar smooth and painted
heatmap dispatch cannot drift. ABI 148
`xyg_scene_pack_annotation_facts` owns wrap vs text vs arrow vs callout vs
rule/band/marker routing from packed XYAF v1. ABI 149
`xyg_scene_pack_heatmap_facts` owns XYHP kind routing from packed XYHF v1.
ABI 150
`xyg_scene_pack_scene_extras` owns XYDS/XYLC/XYMP/XYGR/XYMG layout, concat order,
omit-empty, and XYEX wrapping from packed XYSS v1 plus framed XYPL/XYHP.
ABI 151
`xyg_scene_pack_density_grid` owns Scene density `bin_2d` / `density_log_u8`
/ optional mean-color from packed columns.
ABI 152
`xyg_scene_pack_public_export` owns XYEP layout, kind/step/annotation codes,
and flag derivation from packed XYEF v1. The public-export predicate also
owns the PolyFill group budget, including companion traces that share the
browser painter's 1,024-group ceiling; hexbin cells use their own 50,000-cell
aggregate ceiling (#887).
ABI 153
`xyg_scene_pack_figure_chrome` owns plot layout, chrome-style resolve, legend
loc default/allowlists (empty authored loc is fail-closed), colorbar
flags/framing, XYTL tick-label framing, and the 200-tick axis bound from
packed XYCF v1. Layout errors stay plot-layout diagnostics so the
public-export predicate can remap them to `XYG_SCENE_UNSUPPORTED_VIEWPORT`.
ABI 154
`xyg_scene_pack_trace_compile` owns per-trace Scene compile policy from
packed XYTC v1 so opacity, symbol, color, dash, linecap, marker path,
diameter, legend kind, step, curve-smooth, stroke-perimeter, hex pitch,
fill-gradient admission, and XYMS resolve cannot drift.
ABI 155
`xyg_scene_pack_trace_attach` owns heatmap/density attach policy from
packed XYTO plus XYTA v1 so shape/finite fail-closed checks, XYHF remainder
order, density skip, density XYHF flags, fact bits, density zeroing, and
domain rewrite cannot drift.
ABI 156
`xyg_scene_pack_trace_rows` owns XYPK construction, scatter-only
symbol/diameter, density domain-endpoint column rewrite, and
`pack_product_facts` from packed XYTT plus XYCL v1 so product rows cannot
drift.
ABI 157
`xyg_scene_pack_trace_sidecars` owns legend-name gating, heatmap-vs-density
plane selection, and per-trace style/dash/marker/gradient/plane extraction
from packed XYTT plus XYNM v1 so sidecars cannot drift.
ABI 158
`xyg_scene_pack_style_sidecars` owns XYSS dash/linecap/marker/gradient
record construction from packed XYSD plus XYAO v1 so style sidecars cannot
drift.
ABI 159
`xyg_scene_splice_annotations` owns annotation style/row splice and XYAD
extract from packed product rows plus XYSD plus XYAO v1 so batch-encode
arrays cannot drift.
ABI 160
`xyg_scene_encode_assembled` owns assembled Scene encode from packed XYAS
plus XYCC plus extras so XYAS/XYCC unpack, gutter widening, and SceneBatch
encode cannot drift.
ABI 161
`xyg_scene_pack_figure_chrome_from_sidecars` owns legend paints from packed
XYSD and `xyg_scene_pack_scene_extras_from_sidecars` owns XYHP wrapping from
XYSD planes so sidecar unpack cannot drift.
ABI 162
`xyg_scene_encode_assembled_from_sidecars` owns XYCC packing, extras packing,
and viewport/axis scalars from packed XYAS plus XYCF plus XYSD plus polar plus
XYSS so chrome/extras packing cannot drift.
ABI 163
`xyg_scene_encode_product` owns product-path compile, attach, sidecar, row,
annotation, style-sidecar, splice, and assembled encode from packed XYTC plus
XYTA plus XYNM plus XYCL plus XYAF plus XYCF plus polar so orchestration
cannot drift.
ABI 165 extends that same entry so packed XYFS figure-compile support cannot
drift either; empty XYFS skips the probe.
ABI 116
`xyg_scene_pack_annotation_marks` owns rule/band/marker domain expansion
so tags and opposite-axis spanning cannot drift. ABI 117
`xyg_scene_figure_support_reason` owns figure-compile support so feature
mapping, the primary x/y axis set, and the Scene axis-key allowlist cannot
drift. ABI 118 extends `XYFS` to v2 per-trace flags so kind and mark
allowlists cannot drift either. ABI 110
`xyg_scene_pack_legend` owns primary XYLG legend framing so header layout,
text offsets, and bounded-text rejection cannot drift. ABI 111
`xyg_scene_pack_colorbar` owns primary XYCB v2 framing so header layout,
stop/tick tables, domain-span checks, and bounded-text rejection cannot
drift. ABI 112
`xyg_scene_pack_annotations` owns primary XYAD framing so XYAT/XYAL/XYAR/
XYAC/XYAW table layout, version selection, the XYAD envelope, and
bounded-text rejection cannot drift. Explicit Scene diagnostics and consumers
remain available through `scene_export_support_reason` /
`sceneExportSupportReason`, `figure_scene`, `figure_svg`, and
`figure_raster_commands`. Python SVG/raster and pyplot automatic tick requests
also share one `_svg.axis_ticks` adapter that calls `xyg_scene_axis_ticks`
directly for every family; no per-family Python ladder adapter remains.

The public literal `x_axis`/`y_axis` `ticks=False` and `text=False` switches
are inside that migrated static subset: Rust preserves the independent
semantics in all three consumers (major-tick geometry versus tick-label/title
paint). This does not widen the boundary to rich tick strings, wrapping,
custom fonts, CSS/classes, theme-driven chrome, or arbitrary annotation text.
Scene static custom `font-family`, chart/theme CSS, and `class_name` are the
bounded fail-closed product contract (#288): `XYG_SCENE_UNSUPPORTED_CUSTOM_FONT`
and `XYG_SCENE_UNSUPPORTED_BROWSER_CSS`. Default-font figures without those
observations use Scene consumers, not `_svg.to_svg` / `_raster`. Live browser
widgets still apply CSS. CSS-room measurement of a second face stays #297.
Unresolved mark-fill `var()` / theme CSS gradients are the bounded fail-closed
Scene-static contract (#289): `XYG_SCENE_UNSUPPORTED_GRADIENT`. Literal
`linear-gradient(...)` with resolvable CSS colors stays ABI 146 Scene XYGR.
Live browser widgets still resolve `var()`.

### Contracts (MUST)

- **Rust owns decisions for all marks.** Hosts are thin: coerce inputs, schedule
  progressive work, attach transport, and assemble figure specs. They MUST NOT
  reimplement layout, LOD tiering, channel encode, or other buffer-affecting
  decisions in Python or TypeScript.
- **Browser TypeScript never reimplements layout / LOD / encode** for the
  product path. The client applies Rust-produced live §29 offset-f32/u8 buffers and runs screen-bounded
  interaction; force ticks and LOD plans stay off the browser main thread’s
  decision path (native Rust and the same Rust compiled to WASM by the #59
  foundation).
- **Isolation:** the Node package MUST NOT use browser-only APIs (`window`,
  `document`, WebGL, DOM). The browser client MUST NOT import `koffi`,
  `node:fs`, or other Node-only modules.
- **Same figure spec + §29** across Python and Node for the same inputs; the
  browser client is the **shared renderer** for both.
- **Notebooks stay first-class:** `show()` / anywidget / `to_html()` MUST NOT
  regress as Node or graph work lands. Python notebook UX remains a primary
  product surface, not a legacy path.

See [dual-host-parity-matrix.md](dual-host-parity-matrix.md) §0 and the
`runtimes` section of [`dual-host-parity.json`](dual-host-parity.json).
The exhaustive per-file application of these rules is
[ownership-audit.md](ownership-audit.md).

---

## 1. Goal

| Layer | Shared across Python and Node |
|---|---|
| Rust viz `cdylib` C ABI | All kernels (existing marks + `xyg_graph_*` + `xyg_temporal_*`); **u64** graph element indices; **i64** UTC micros for temporal columns |
| Wire / §29 buffers | Identical binary payloads for the same figure spec |
| JS render client | One bundled WebGL client (`@curatelabs/xyg`: `index.js` / `standalone.js`); Python copies into the wheel |
| Public chart semantics | Same mark kinds, options, defaults, layout/LOD decisions |
| Temporal foundation (#43) | Same `TemporalColumn` / interval visibility for identical Arrow-like fixtures ([temporal.md](temporal.md)) |
| GeoColumn ingest (#47) | Same typed descriptor, Rust validation (CRS, offsets, holes, null parts, budgets), retained f64 planes, and `XYGM` v1 canonical metadata bytes for identical GeoArrow inputs; host adapters only decode Arrow / typed arrays ([geospatial.md](geospatial.md)) |
| Temporal controller (#44) | Same `TemporalController` commands, exact u64 stable-ID replacement selection, revisions, atomic apply, and coordination reject rules ([temporal-controller.md](temporal-controller.md)) |

Host-only differences are idiomatic (NumPy/pandas/Arrow vs TypedArrays;
notebook/application-host vs Node embed / VS Code webview attach). Names and defaults
match.

The direct-browser `XygWasmTemporalController` submits packed raw i64/u64
commands to that same Rust state machine. TypeScript owns only the coalesced
clock, explicit event transport, keyboard/focus surface, and ARIA presentation.
Python lists, Node `BigUint64Array`s, and browser `BigInt[]` values all lower to
the same Rust-canonical sorted/deduplicated selection; no host truncates or
reorders the result.

---

The experimental explicit browser `attachWasmGraphSession` uses the same
retained Rust graph session and existing XYGI/XYGR exports. Complete XYGF ingress
and an explicit seven-f64 camera enter initially Owned, unlinked state.
TypeScript only frames commands, validates complete replies, paints raw GPU-v1
buffers through existing GL primitives, and presents keyboard/ARIA/companion
controls. Rust alone chooses focus, selection/provenance, companion candidates
and summary. u64 identity/provenance remains exact `bigint`; a projected selection
length is not the global selected count. The Worker lane is serialized and
non-cancellable; competing ownership is refused before mutation, and borrowed
Worker disposal follows async session CLOSE. This bounded path has no
canonicalScene/legacy-graph compile, CSR neighborhood, generic CPU hit-test or
selection-mask dependency. Ordinary `spec.graph` intentionally omits host-only
identity planes and still needs the S6 legacy attachment; its CSR path remains.
No native/Node session-controller parity, broad S5b/S6/S7, #36/M4/#108 acceptance
or performance claim follows from this vertical. See the
[attachment contract](graph-interaction.md#bounded-explicit-s5b-attachment) and
[proof receipt](../performance/graph-s5b-attachment-2026-11-04/README.md).

## 2. Placement rule (Rust owns decisions)

| Lives in | Examples |
|---|---|
| **XYG Rust (shared)** | Display layouts (including today’s Python-only ones such as Sankey), graph adjacency/position buffers, channel resolution, decimation, LOD aggregates, layout/LOD **decisions**, thresholds that change buffers, progressive layout ticks, canonical temporal columns, interval/event visibility, and UUID-stable temporal graph membership/interaction state |
| **Host (Python *or* Node)** | Public API shapes, idiomatic ingest coercion (list/NumPy/TypedArray → pointers), error message text, transport attach — **no** second layout/algorithm/encode/decision path |
| **Browser client** | WebGL draw, hit-test, pan/zoom/select/drag gestures applying uploaded buffers; playback clocks submit revisioned temporal commands to Rust (#44+) |

Temporal graph native hosts follow the same boundary: Python and Node accept
UUID/time buffers, expose lifecycle methods, and return Rust-produced
visibility plus frozen provenance. They do not calculate membership, endpoint
closure, interaction persistence, revision ordering, or work budgets. Node
retains revisions and timestamps as exact `bigint`; Python performs bounded
integer conversion before the C ABI call.

The direct browser uses the same engine through WASM ABI 9 `XYTG`/`XYTF`
frames. Rust emits visible UUID membership and remapped topology before layout;
the TypeScript coordinator only owns transfer, latest-wins cancellation,
stale-reply rejection, and disposal.

Graph **analysis algorithms** (paths, centrality, communities, Cypher, …) are
not owned here — they live in GraphForge (and similar peers). This charting
stack plots their outputs; it does not reimplement them.

Node must not reimplement layouts or mark geometry in TypeScript. The browser
client must not grow a parallel “JS layout/LOD” product path.

---

## 3. Requirements

- **REQ-HOSTPARITY-0 (MUST).** The product exposes exactly the three runtime
  surfaces in §0 (Python host, Node host, browser client). VS Code extensions
  consume `packages/xy-node` (`@curatelabs/xyg-node`); they are not a separate runtime stack.
- **REQ-HOSTPARITY-0b (MUST).** Notebook UX (`show()`, anywidget, `to_html()`)
  remains first-class on the Python host and MUST NOT regress.
- **REQ-HOSTPARITY-0c (MUST).** Node bindings MUST NOT depend on browser-only
  APIs; the browser client MUST NOT import Node-only modules (`koffi`,
  `node:fs`, …).
- **REQ-HOSTPARITY-1 (MUST).** One XYG Rust C ABI serves Python (ctypes) and
  Node (Koffi, which uses Node-API internally). Both low-level declaration sets
  are generated from the typed Rust contract; `ABI_VERSION` bumps apply to both
  loaders without making XYG a PyO3 or napi-rs extension.
- **REQ-HOSTPARITY-1b (MUST).** **Rust owns decisions:** chart/graph behavior
  that affects buffers, layout, encodings, or recorded LOD/layout decisions is
  implemented in Rust. Hosts MAY validate and coerce inputs but MUST NOT own a
  parallel implementation of that behavior.
- **REQ-HOSTPARITY-2 (MUST).** For every public chart type, Python and Node
  produce the same figure spec shape and §29 buffers for the same inputs.
  Graph is the core feature; **all** chart types ship in MVP on both hosts with
  the same feel/speed.
- **REQ-HOSTPARITY-2b (MUST).** Non-graph marks retain the same composition
  quality and performance bar (Rust kernels, binary transport, WebGL). Graph
  work MUST NOT regress them or leave them second-class.
- **REQ-HOSTPARITY-2c (MUST).** Graph ingest helpers (including any GraphForge
  primary path) MUST NOT be the only way to build a graph chart on either host.
  XYG-native column/sequence formats from
  [graph-fork-requirements.md](graph-fork-requirements.md) REQ-API-3 remain
  available with the same semantics on Python and Node.
- **REQ-HOSTPARITY-2d (MUST).** Python `from_graphforge_tables()` and Node
  `fromGraphForgeTables()` pass canonical UUID buffers through the same ABI
  `GraphProjection` handle. Hosts validate UUID representation before creation;
  Rust validates duplicate identities, topology, and dense endpoint/parent
  mapping to `u64`. Hosts retain typed attributes and provenance on
  `GraphData`. `graph()` / `composeGraph()` accept GraphForge tables or a ready
  `GraphData` and attach `tooltip_rows` / identity meta for hover, encodings,
  and export. The browser never imports Arrow or receives UUIDs as JSON
  numbers. Native-vs-WASM projection parity is covered by the #59 foundation.
- **REQ-HOSTPARITY-2e (MUST).** Graph node/edge `tooltip_rows` and continuous
  size/color channels ship with the same wire shape on Python and Node
  (`tooltip_rows` length-checked against geometry and encoded as byte-identical
  typed `tooltip_columns`, `tests/fixtures/tooltip_columns_cross_host.json`;
  `spec.graph` omits the same host-only identity planes; Node `shipScalar`
  mirrors Python `_ship_channels` continuous size). See
  [graph-mark.md](graph-mark.md) encodings table.
- **REQ-HOSTPARITY-2e2 (MUST).** GraphForge result compositions
  (`compose_graphforge` / `composeGraphForge` / `composeWasmGraphForge`) frame
  identical `XYGQ` requests and receive identical `XYGF` documents on Python,
  Node, and direct-browser WASM, pinned by
  `tests/fixtures/graphforge/cross_host.json` and the Node/WASM parity suite
  ([graphforge-compositions.md](graphforge-compositions.md) §6). Hover rows
  omit `provenance_row` where the provenance plane holds the u64::MAX "no
  source row" sentinel (derived edges) on both hosts.
- **REQ-HOSTPARITY-2f (MUST).** Graph edge identity follows the Rust
  render-edge membership CSR (graph-mark.md §6) on both hosts: per-segment
  edge rows, `edge_ids`, and the edge pick reply (Python `pick`/`click`, Node
  `Figure.graphEdgePick`) are identical for the same input, pinned by
  `tests/fixtures/graph_edge_identity_cross_host.json`. Membership stays
  host-side and is never serialized to the wire.
- **REQ-HOSTPARITY-2g (MUST).** Python `graph_chart` and Node `graphChart`
  author the same axes (the hidden default for each unauthored primary axis;
  an authored `x_axis` / `y_axis`, Node `xAxis` / `yAxis`, as given, #909)
  and export byte-identical SVG and PNG (equal
  scale) for identical input through the Rust Scene route
  (`FLAG_GRAPH_MARKS`, scene-ir.md), pinned by
  `tests/fixtures/graph_static_export_cross_host.json`. Both hosts route
  graph edges through `xyg_graph_edge_route_ends` with the same node radii
  and shapes, ship the same `edge_ends` channel, and set the same XYCL
  edge-ends flag, so border-aware arrowheads are byte-identical too (#33).
  Default graph colors are Rust-owned and identical (#898): edges paint
  `xyg_graph_default_edge_color_utf8` and take no palette slot, and nodes
  take the series palette color (the `default_colors` fixture case).
  Default series colors in general are host-parity (#918): Node `Figure`
  keeps a series cursor that advances once per logical series exactly like
  Python's `Figure.next_series_color`, over `palette=` or the Rust built-in
  palette, so graph nodes (one slot per graph) match with custom palettes
  too. Pinned by `tests/fixtures/series_palette_cross_host.json`.
- **REQ-HOSTPARITY-2h (MUST).** GeoArrow / GeoColumn ingest (#47) is a thin
  host adapter over the shared `xyg_geo_column_*` C ABI (ABI 379). Python
  (`xyg._geoarrow.ingest_geoarrow` and `_native.geo_column_*`) and Node
  (`geoDescriptorFromGeoArrow` in `packages/xy-node/src/geoarrow.js`, and
  `geoColumn*` in `abi.js`) decode GeoArrow-shaped buffers and extension
  metadata into the same typed descriptor, with the same CRS parsing and the
  same null-Point packing rule (a null point contributes no vertex), and
  forward feature IDs unchanged. Rust owns validation, CRS, source f64
  geometry, offsets, validity, identity, resource limits, and ring orientation
  (recorded, never rewritten); neither host reimplements geometry checks or
  carries a fallback. Both hosts MUST read back the same planes and the same
  `XYGM` canonical metadata bytes, pinned by
  `tests/fixtures/geo_cross_host.json` (`tests/test_geo_cross_host.py` and
  `packages/xy-node/test/geo-cross-host.test.mjs`). Node takes no Arrow
  dependency; parity runs through the Python-authored golden. Error *messages*
  may differ; the stable `XYG_GEO_*` codes (-1..-14) may not. Direct-browser
  WASM descriptor ingest is the follow-on slice of #47.
- **REQ-HOSTPARITY-3 (MUST).** The browser client is shared; hosts only differ
  in transport attachment. The same `js/src` → `@curatelabs/xyg`
  (`packages/xy-client/dist/{index,standalone}.js`) client serves Python
  notebooks (anywidget, via the wheel **copy**), HTML export on either host,
  Node-served pages, and VS Code webviews. `58_graph.ts` is an optional
  enhancement (neighborhood hover); all wire marks paint without it. The client draws uploaded §29 buffers and MUST NOT
  reimplement layout/LOD/encode for the product path.
- **REQ-HOSTPARITY-3b (MUST, #1024, ABI 393).** An authored text annotation that
  leaves `dx`/`dy` unset is placed at the one Rust-owned default offset
  `(6, -6)` pixels (`kernels::DEFAULT_TEXT_ANNOTATION_DX` / `_DY`); screen y is
  down, so a negative `dy` is up. "Unset" means the same on every path: the Rust
  XYAF packer lays out every text row (a bare row, an anchor-only row and an
  explicit-offset row differ only in the facts they carry), and the live payload
  specs (`_annotation_specs` / `annotationSpecs`) read the same value through
  `xyg_default_text_annotation_dx()` / `xyg_default_text_annotation_dy()`. Hosts
  carry no copy. An explicit `dx`/`dy`, including `0`, is never replaced. Callout,
  marker and other annotation kinds keep their per-kind defaults. Pinned by
  `tests/test_text_annotation_default_offset_cross_host.py` (static bytes
  identical across hosts; static and payload agree for raw unset text).

- **REQ-HOSTPARITY-4 (MUST).** Graph viz is the core dual-host feature surface
  ([graph-fork-requirements.md](graph-fork-requirements.md)); other marks are
  first-class in the same MVP.
- **REQ-HOSTPARITY-5 (MUST, done).** [rust-engine.md](rust-engine.md) and the
  dossier's identity preamble state “Rust owns decisions” directly as the XYG
  rule; no conflicting “Python owns decisions” guidance remains in force
  (upstream text survives only as clearly-marked provenance).
- **REQ-HOSTPARITY-6 (MUST, MVP).** Remove Python host-only layout/encode
  shenanigans for MVP: remaining twins are `_payload` emit orchestration and
  `_scene_v3` pack. M2 close tracker:
  [#731](https://github.com/CurateLabs/xyg/issues/731)
  ([`m2-close.md`](../process/m2-close.md)); children #732 / #733. Stay-host
  TAP extras are inventory, not an alternate close path. Sankey placement already lives in `xyg_sankey_layout`;
  encode offset/scale is ABI 208; polar wedge flatten is ABI 209; hexbin ring
  offsets are ABI 210; step/stairs expand is ABI 211; authored marker-path
  scale is ABI 212; color CSS/numeric split, domain pad, and direct RGBA admit
  are ABI 213; stem/errorbar count budget is ABI 214; errorbar role-block
  expand is ABI 215; log-family pin_zero admission is ABI 216;
  annotation-arrow geometry is ABI 217; annotation-arrow style CSV pack is ABI 254; Scene dash admit is ABI 218;
  Scene linecap admit is ABI 219; density overlay opacity is ABI 220;
  Scene marker-path admit is ABI 221;   Scene annotation style admit is ABI 222;
  Scene ribbon color2 classify is ABI 223;
  Scene tick-label strategy admit is ABI 224;
  Scene tick-label anchor admit is ABI 225;
  Scene fill-gradient admit is ABI 226;
  Scene linear-gradient CSS parse is ABI 227;
  Scene rect extra-flag pack is ABI 228;
  Scene fill-gradient direction pack is ABI 229;
  Scene linear-gradient CSS prefix is ABI 230;
  Scene fill-gradient space pack is ABI 231;
  Scene hexbin reduce admit is ABI 232.
  Scene curve-name classify is ABI 233.
  Scene marker-glyph admit is ABI 234.
  Scene product-kind admit is ABI 235.
  Scene packing-family classify is ABI 236.
  Scene hexbin cell-pitch admit is ABI 237.
  Scene heatmap cell-extent admit is ABI 238.
  Scene heatmap colormap eligibility is ABI 239.
  Scene heatmap lattice-shape admit is ABI 240.
  Scene scatter paint-channel admit is ABI 241.
  Scene hexbin colormap-plane admit is ABI 242.
  Scene hexbin RGBA-plane admit is ABI 243.
  Scene mesh paint-plane admit is ABI 244.
  Scene per-item RGBA8 artist-alpha/opacity is ABI 245.
  Scene per-item stroke-width admit is ABI 246.
  Scene continuous per-item fill unit-t is ABI 247.
  Scene finite-all admit is ABI 248.
  Scene gradient-solid CSS is ABI 249.
  Scene f64 arrays-equal is ABI 250.
  Unit-f64 clip-quantize u8 is ABI 251.
  Scene constant-color admit is ABI 252.

  Scene hidden-or-per-item admit is ABI 253;
  annotation-arrow style CSV pack is ABI 254.
  256-texel colormap RGBA8 LUT uses ABI 206.
  Unit-t LUT/size u8 quantize uses ABI 251.
  Node density-bin LUT idx uses the same composition.
  Categorical palette LUT u8 uses ABI 251.
  SVG `_paint_rgba8` uses `xyg_css_color_rgba`.
  Authoring hex / colormap-stop u8 uses ABI 251.
  Style-channel finite arrays use ABI 248.
  SVG `_rgb_css` uses ABI 251.
  SVG authored-scatter marker RGBA8 uses ABI 251.
  Raster scatter RGBA8 uses ABI 251.
  Raster mesh/hexbin fill RGBA8 uses ABI 251.
  Raster rectangle style RGBA8 uses ABI 251.
  Raster segment stroke RGBA8 uses ABI 251.
  Raster mesh stroke RGBA8 uses ABI 251.
  Raster ribbon fill RGBA8 uses ABI 251.
  Raster ribbon match-fill edge RGBA8 uses ABI 251.
  Node `meshHasPerItem` uses `perItemChannelNames` for ABI 244.
  Node `scatterPaintChannelNames` uses `perItemChannelNames` for ABI 241.
  Node hexbin colormap-plane packing uses `channel.values` for ABI 242.
  Node empty kind uses `|| "mark"`.
  Node `figureTraceSupport` does not fail-close `style.smooth`.
  Node `itemWidths` fail-closes a present `stroke_width` channel without values.
  Node `itemApplyOpacity` fail-closes a present opacity/artist_alpha channel without values.
  Node missing scatter kind uses `|| ""`.
  Node `fillIsGradientAuthoring` rejects arrays (same as Python dict-only).
  Node `rectExtraFlags` treats only mapping fills as gradient-fail (same as Python dict-only).
  Node `admittedMarkerGlyph` rejects non-strings (same as Python `isinstance(..., str)`).
  Node `packXyTaColormap` uses `style.colormap` only.
  Node hexbin XYTA colormap uses `channel.colormap` only.
  Node XYHF heatmap/density colormap uses `style.colormap` only.
  Node `constantMarkColor` uses `color_ch.constant` only.
  Node `channelConstantCss` uses `channel.constant` only. Mode/has_constant admit is ABI 254.
  Node `channelEndRgba8` constant paint uses `channel.constant` only.
  Node `sourceColorCss` uses `color_ch` only.
  Node `resolveColorChannel` constant CSS uses `.constant`.
  Node `color2Channel` uses `color2_ch` only.
  Node `itemFillRgba8` uses `color_ch` only.
  Node `scatterPaintChannelNames` uses `color_ch` only.
  Node `scatterHasNonConstantColor` uses `color_ch` only.
  Node `resolveDensityBinColors` uses `color_ch` only.
  Node `scatterHasNonConstantColor` ignores `style.color_channel`.
  Node `scatterPaintChannelNames` ignores `style.color_channel`.
  Node `resolveDensityBinColors` ignores `style.color_channel`.
  Node XYMS mark color uses `style.color` only.
  Node XYTC style color uses `style.color` only.
  Node XYTC constant paint uses `channel.constant` only.
  Node density-blit observation uses `scatterUsesDensity`.
  Node XYTC color_ch packing ignores string channels.
  Node `scatterHasNonConstantColor` uses `channel.constant` only.
  Node XYTC `COLOR_CH_CONSTANT` packs whenever `channel.constant` is set.
  Node XYMS mark color uses `constantMarkColor`.
  Node `scatterPerItemChannels` ignores `style.color_channel`.
  Node `scatterPerItemChannels` is mode-based.
  Node `channelEndRgba8` ignores array channels.
  Node `channelEndRgba8` categorical paint uses `DEFAULT_PALETTE`.
  Node `packXyTaColormap` stop bytes require RGB rows.
  Node `xyHfColormap` stop bytes require RGB rows.
  Node `packXyTaRgbaGrid` stacks flattened planes.
  Node heatmap `trace.rgba` is a flat uint8 buffer.
  Node heatmap and density Scene packing is XYTA-only.
  Node `packXyTaGrid` flattens heatmap `grid`.
  Node `rectFiniteSel` drops nonfinite rectangle rows.
  Node `packXyTa` density fill opacity uses `fill_opacity` only.
  Node XYTC fill opacity uses `fill_opacity` only.
  Node XYTC stroke opacity uses `stroke_opacity` only.
  Node XYTC line opacity uses `line_opacity` only.
  Node XYTC stroke width uses `stroke_width` only.
  Node XYTC line width uses `line_width` only.
  Node XYTC size uses `size` only.
  Node XYTC line color uses `line_color` only.
  Node XYTC joined fill uses `joined_fill` only.
  Node XYTC stroke perimeter uses `stroke_perimeter` only.
  Node XYTC COLOR_CH packing uses `color_ch` only.
  Node XYTC size_ch packing uses `size_ch` only.
  Node XYEF stroke-width-only observation uses `stroke_width` only.
  Node `meshJoinedFill` uses `joined_fill` only.
  Node XYEF joined-fill observation uses `joined_fill` only.
  Node `constantMarkColor` uses `color_ch` only.
  Node `classifyRibbonColor2` source-constant CSS uses `color_ch` only.
  Node `hexbinPacksColormapPlane` uses `color_ch` only.
  Node `ribbonEndRgbaPair` uses `color_ch` only.
  Node `hexbinXyTaColormap` uses `color_ch` only.
  Node `hexbinPacksRgbaPlane` uses `color_ch` only.
  Node `hexbinCellRgba8` uses `color_ch` only.
  Node XYTA density color_ch packing uses `color_ch` only.
  Node `itemStrokeRgba8` uses `stroke_ch` only.
  Node `scatterPointStrokeRgba8` uses `stroke_ch` only.
  Node `perItemChannelNames` uses snake-case channel fields only.
  Node `itemApplyOpacity` uses `style_channels` only.
  Node `itemWidths` uses `style_channels` only.
  Node `scatterUsesDensity` uses `force_density` only.
  Node `figureTraceSupport` uses `style.linecap` only.
  Node `packXyTcLinecap` uses `style.linecap` only.
  Node `packXyAfLinecap` uses `style.linecap` only.
  Node `scatterUsesDensity` does not pass `force_direct`.
  Node hexbin XYTA values packing uses `color_ch` only.
  Node `legendStyleFontSizes` uses `style.font_size` / `style.title_font_size` only.
  Node `heatmapGridShape` uses `grid_shape` only.
  Node `hexbinStylePitch` uses `hex_dx` then `dx`.
  Node `polarGridShape` uses axis `grid_shape` only.
  Node `polarAxisThetaUnit` uses axis `theta_unit` only.
  Node `polarAxisThetaZero` uses axis `theta_zero` only.
  Node `polarAxisThetaDirection` uses axis `theta_direction` only.
  Node `polarAxisROrigin` uses axis `r_origin` only.
  Node `axisTickValues` uses axis `tick_values` only.
  Node `axisMinorTickValues` uses axis `minor_tick_values` only.
  Node `axisTickLabels` uses axis `tick_labels` only.
  Node `figureXLabel` uses `x_label` then axis `label`.
  Node `figureYLabel` uses `y_label` then axis `label`.
  Node `plotTopAxisRoom` uses plot `top_axis_room` only.
  Node `axisTickLabelAnchor` uses axis `tick_label_anchor` only.
  Node `axisTickLabelMinGap` uses axis `tick_label_min_gap` only.
  Node `axisTickLabelAngle` uses axis `tick_label_angle` only.
  Node `axisTickLabelStrategy` uses `tick_label_strategy` then `collision`.
  Node `polarCollisionKeys` uses snake-case keys only.
  Node `figureChromeStyles` uses `chrome_styles` only.
  Node `chromeStyleHasFontFamily` uses `font-family` only.
  Node `figureClassName` uses `class_name` only.
  Node `figureClassNames` uses `class_names` only.
  Node `annotationClassName` uses `class_name` only.
  Node `figureExtraLegends` uses `extra_legends` only.
  Node `figureTitleOptions` uses `title_options` only.
  Node `figureLegendOptions` uses `legend_options` only.
  Node `figureColorbarOptions` uses `colorbar_options` only.
  Node `figureShowLegend` uses `show_legend` only.
  Node `figureAxisOptions` uses `axis_options` only.
  Node `axisScaleName` uses axis `type` only.
  Node `figureAutorangeAxisOptions` uses `axis_options` only.
  Node `_emitScatter` uses `force_density` only.
  Node `_emitScatter` does not read `style.force_direct`.
  Node `_emitScatter` does not read `style.force_pyramid`.
  Node `chromeAxisMinorStyle` uses `minor_style` only.
  Node `chromeAxisTickSides` uses `tick_sides` only.
  Node `chromeAxisTickLabelSides` uses `tick_label_sides` only.
  Node `chromeAxisStyleKeys` admits snake-case keys only.
  Node `chromeAxisStyleHas` / `chromeAxisStyleValue` read snake-case keys only.
  Node `legendAxisScale` uses axis `type` only.
  Node `figureAutorangeAxisScale` uses axis `type` only.
  Node `figureAxisKind` matches Python `_axis_kind`.
  Node `chromeAxisTickKind` uses `Figure._axisKind`.
  Node `xyEfResolvedKind` uses `Figure._axisKind`.
  Node `figureAutorangeThetaUnit` uses axis `theta_unit` only.
  Node `figureAxisIsLog` uses axis `type` only.
  Node `figureAutorangeCategories` uses `_axis_categories` only.
  Node `figureAutorangeDomain` uses axis `domain` only.
  Node `setPolarMeta` writes axis `theta_unit`.
  Node `setPolarMeta` writes axis `theta_zero`.
  Node `setPolarMeta` writes axis `theta_direction`.
  Node `setPolarMeta` writes axis `grid_shape`.
  Node `setPolarMeta` writes axis `hole`.
  Node `setPolarMeta` writes axis `sector`.
  Node `polarAxisHole` uses axis `hole` only.
  Node `polarAxisSector` uses axis `sector` only.
  Node `_polarAxisSpecs` uses axis `theta_unit`.
  Node `_polarAxisSpecs` uses axis `theta_zero`.
  Node `_polarAxisSpecs` uses axis `theta_direction`.
  Node `_polarAxisSpecs` uses axis `grid_shape`.
  Node `_polarAxisSpecs` uses axis `sector`.
  Node `_polarAxisSpecs` uses axis `hole`.
  Node `_polarAxisSpecs` uses axis `r_origin`.
  Node `_polarAxisSpecs` uses axis `tick_values`.
  Node `_polarAxisSpecs` uses axis `minor_tick_values`.
  Node `_polarAxisSpecs` uses axis `tick_labels`.
  Node `_polarAxisSpecs` uses axis `tick_count`.
  Node `_axisSpec` uses axis `nonpositive` on log axes.
  Node `_axisSpec` uses axis `constant` on symlog axes.
  Node `_axisSpec` uses `_axis_categories` on category axes.
  Node `_axisSpec` ships non-linear `scale` on polar y when authored.
  Node `packPolarSceneInput` uses figure `_range` only.
  Node `shouldUseDensity` Boolean false stays auto.
  Node `_emitScatter` still passes `forceDirect`.
  Node `_emitScatter` still ORs `forcePyramid` into density.
  Node `buildPayload` cartesian axes stay linear.
---

## 4. Delivery order

1. Amend placement docs; extend C ABI (**u64** graph indices; Rust-owned
   decisions); lock the three-runtime taxonomy (§0).
2. Promote host-only layouts into Rust; Node loader over the same ABI.
3. Graph mark + interactive client (core feature); tick architecture at scale.
4. All chart types on Python and Node; golden parity; scatter-class scale
   evidence for graphs on both bindings. Keep notebook `show()` / anywidget /
   `to_html()` green throughout.

---

## 5. Non-goals

- Separate Node-only or VS Code-only renderers, or host-side reimplementations
  of Rust kernels.
- Reimplementing layout/LOD/encode inside the browser client for the product
  path.
- Mixing Node-only modules into `js/src` or browser-only APIs into
  `packages/xy-node`.
- Reimplementing GraphForge (or peer) analysis algorithms inside XYG.
- Leaving layout/encode/LOD **decisions** in one host language.
- Requiring Node for Python users or vice versa.
- A heavy GraphForge extension framework in this pass (thin helper only;
  independent charting first).
- Treating notebooks as secondary once Node lands.

---

## 6. Graph LOD / interaction parity notes (MVP)

- **Render-graph ABI:** `xyg_graph_build_render` emits centroids/`member_of` +
  cluster-space edges within node/edge budgets (optional viewport) and records
  §28; `xyg_graph_cluster_aggregate` remains the node-only helper. Hosts ship
  only the reduced buffers — no second edge-sample for draw.
- **Force at scale:** exact pairwise repulsion for `n ≤ 500`
  (`FORCE_EXACT_REPULSION_MAX_N`); spatial-grid Barnes–Hut-style approx above.
- **Configured CoSE:** Python and Node normalize ergonomic option spelling and
  shape host buffers for `xyg_graph_force_create_cose`; Rust validates semantic
  numeric constraints, bounds, pins, and compound parents and applies every
  force/layout decision.
  Browser callers use `encodeWasmCose` and `XygWasmWorker.layoutCose`; the
  static Worker transports packed columns into the same Rust `ForceState` and
  emits revision-tagged f64 checkpoints. Python's per-graph
  `GraphLayoutController` likewise schedules bounded native ticks on its own
  worker thread and restarts Rust CoSE from drag coordinates plus the current
  pin mask. Cross-host parity is bitwise (no ε): Python/Node native and WASM
  agree on every f64 checkpoint of the committed 12-fixture golden because the CoSE path uses
  only `+ − × ÷ √` and `portable_sin_cos`. Checkpoint-delivery latency and cadence
  evidence is historical (`cb78c1f4`, 1k–1M nodes, three hosts), predating
  #1078's Node checkpoint acceptance/cleanup contract. It is not current-main
  timing or first-paint evidence. The default Node live payload route now uses
  `GraphForgeLayoutController` and bridge/force Workers; synchronous
  `composeGraphForge` remains explicit metadata/static/batch composition
  ([Node contract](graphforge-node-scheduling.md)). The issue's literal async
  `composeGraphForge` wording still needs an explicit acceptance clarification.
  The bounded 1k [render receipt](../performance/graph-node-first-paint-1k-review-repair-2026-11-04/README.md)
  supersedes the frozen historical runners, directly observes the selected
  native path/hash/ABI in fixture and bridge/force Workers, and separates byte
  identity from unknown/declared origin. Earlier conventional-path hashes do
  not retroactively attest selection. Held update ACKs are drained and reset
  is checked on the first replacement. It records actual initial/final paint
  and GPU node-hit readiness, with trusted
  UUID/pan inspection separated from unheld presentation. Intermediate steps
  coalesced away; one initial-to-final interval is not sustained progress
  cadence. These captures predate the Node Buffer numeric-copy repair; the
  integrated Node package tree differs. Only individually verified producer
  sources and artifact bytes are reused, as scoped in the
  [Node contract](graphforge-node-scheduling.md#evidence-and-remaining-boundary).
  Remaining for #35 are the rendered size ladder and unheld initial
  trusted interaction, public browser progressive attachment/scheduling, and
  Python widget/notebook progressive integration (#1015). Retained opcode 15
  alone does not attach a public scheduler. The historical receipt is committed
  under
  `spec/performance/cose-progressive-ladder-2026-10-20/`. Policy and results:
  `graph-mark.md` §4 "CoSE cross-host parity".
- **Box-select:** reuses the existing scatter/segments selection path — no
  graph-specific selection ABI for MVP.
- **Node shapes:** via scatter `symbol=` (same mark as other scatter charts).
- **`edge_curve`:** recorded in graph meta (`straight` default) for client
- **`xyg_graph_edge_route_segments`:** Python/Node call the same Rust router after `build_render` so Direct-tier parallels, self-loops, and arrowheads stay host-neutral (`render_edge_index` on graph meta).
- **Graph style foundation:** Node utilities and private Python `_native`
  utilities call `xyg_graph_label_accept`, `xyg_graph_visual_state_resolve`,
  and `xyg_graph_compound_bounds`. Python and Node graph composition serialize
  those Rust results into the same `spec.graph` fields. Canonical Scene v12 now
  carries Rust-resolved label text/placement, theme chrome, semantic paint,
  legends, and compound bounds to browser, HTML/SVG, and raster consumers;
  TypeScript must not derive them.
  Compound validity governs ingress, so zero-filled invalid projection slots
  pass directly without host rewrite or copy.
  ABI 89 `xyg_graph_compound_scene` is the native canonical-Scene compound
  seam used by thin Python and Node helpers. It requires each compound plane
  to equal node count and additionally validates the complete
  parent forest in linear traversal, derives transitive descendant bounds, and
  resolves collapse visibility plus boundary-edge representatives before any
  painter/export allocation. Browser painter, SVG, and raster consume those
  identical Rect/Polyline/Scatter records and the same accepted-label plane;
  no host walks ancestors or recomputes collapsed endpoints. Direct-WASM XYGG
  v3 frames exact parent, parent-validity, and collapse planes into that same
  compiler without overloading a semantic plane or adding a TypeScript fallback.
  `tests/fixtures/graphforge/semantic_compound.json` anchors exact native Scene,
  painter, SVG, raster-command, and PNG bytes for both themes. The strict-CSP
  browser worker smoke consumes the same semantic and compound fields on XYGG v3 and proves
  real WebGL paint plus deterministic label/legend accessibility and stable
  IDs plus collapsed descendant omission.
  ABI 90 and WASM ABI 14 expose the same Rust-owned atomic stable-ID
  expand/collapse/toggle transaction. Native, Python, Node, and WASM only
  frame exact planes; aggregate LOD, malformed forests, duplicate IDs, and
  leaf or missing targets are refused before output changes.
  The packaged browser entry exposes the same transition through
  `transitionWasmCompound`; browser lifecycle evidence verifies one current
  label layer across expand and recollapse without duplicating hierarchy
  traversal in TypeScript.
  follow-up; curved edge rendering is not MVP-blocking.
- **Shared dashboard admission:** the browser-only
  `ChartView.applyDashboardResourceBudget(worker, budgetBytes)` surface and
  its `applyWasmDashboardResourceBudget` boundary
  snapshots logical bytes and lifecycle signals from one document-scoped
  `GLHost`, obtains retain bits from Rust `XYDP`, and applies them only if the
  exact snapshot is still current. Object-identity accounting and synchronous
  capacity reservations now cover shared-host buffer and texture storage, with
  whole-chart loss/rebuild eviction, per-chart caps through the same Rust planner,
  and separately charged host quad/canvas backing. Canonical Scene data and
  source identity stay intact; stale GPU state cannot serve picks. Python and Node HTML
  inherit this browser compositor when they use the packaged client; none owns
  a parallel admission policy. The same `GLHost` coalesces registered charts'
  color paints into one animation-frame batch without ranking them in the host;
  this browser execution mechanism therefore preserves the Rust-owned
  admission decision across Python, Node HTML, and direct-browser use.
  `ChartView.watchDashboardResourceBudget(worker, budgetBytes)` adds opt-in
  continuous enforcement: shared-host lifecycle and measured-resource changes
  coalesce into serialized calls through that same Rust boundary. The watcher
  performs no ranking, and its controller can be disposed without destroying
  any chart or canonical state.

### Direct-browser GeoColumn ingress

WASM ABI 29 `XYGD` → `XYGM` shares Rust validation and canonical metadata with
Python/Node ABI 379. The browser's `encodeWasmGeoDescriptor` and
`XygWasmWorker.geoColumnIngest` frame/transfer typed planes only. Source
geometry, CRS, null topology, identity and limit policy remain Rust-owned.
The committed six-kind goldens and stable failures run against the actual
wasm32 module in `packages/xy-node/test/geo-wasm-parity.test.mjs`.

The frozen zero-pitch `XYGP` processor also lowers that geometry through
`GeoViewport` to ordinary `XYGS` point/outline records. The native conformance
executable and actual wasm32 module run the same engine processor; their
scene parity, full u64 identities, finite run separators and deep-zoom geometry
are pinned by `packages/xy-node/test/geo-scene-wasm-parity.test.mjs`.
`scripts/geo_wasm_smoke.mjs` additionally proves packaged strict-CSP hydration,
paint and GPU picking. This is the #47 derived-scene parity proof, not a
Python/Node geographic chart-building API. Live camera transitions, pitched
projection and geographic fills/layers remain #48/#49.


### Geographic camera transport (#48)

Native C ABI 380 and WASM ABI 30 execute the same `XYVC` → `XYVR` Rust camera
processor. Python `xyg._geoviewport.geo_viewport` and Node `geoViewport` only
pack/unpack typed values; browser `geoViewportExecute` uses the same byte
contract. Camera transitions, projection/inverse, normalized rebuild keys,
visible identities/bounds and polygon ring topology are Rust-owned. See
[the exact protocol](geo-viewport-protocol.md) and the executable actual-wasm32
parity proof `packages/xy-node/test/geo-viewport-wasm-parity.test.mjs`.

## Native retained geographic presentation

The immutable notebook and VS Code webview adapters
are specified in [geographic-hosts.md](geographic-hosts.md), including public
composition wiring, one-mount admission, release acknowledgment, actual host
journey evidence and the remaining native live-update/orphan-recovery gates.
This checkpoint is pending follow-up PR integration.

Issue #889 extends the same registry with all-format witnesses for exact authored
frames, colormapped scatter alpha, explicit relabelled/frameless legend items,
annular polar documents, and two opposite paint orders of wide overlapping
translucent panels. The overlap witnesses also pin exact source-over RGBA pixels.
Every retained pyplot #889 future-rendering xfail has an active exact original-
program rejection check; the family matrix and receipts live in
`spec/matplotlib/issue-889-evidence.md`.

### Null locator/formatter observations (#889 review correction)

Bulk chrome empty major arrays retain their existing automatic-ticks contract,
including secondary axes. The pyplot NullLocator adapter authors zero major
tick length/grid width and uses Rust's existing off label strategy. Separately
authored minor positions and their style use the existing authored-major slot
with labels off when no majors exist. This preserves minor marks coincident
with Rust's automatic major positions without altering the empty-array contract.
The redundant minor slot is disabled. A null minor locator, or an absent minor
locator on a non-log axis, authors zero minor length/grid width; implicit log
subdivisions retain their normal minor style. NullFormatter uses off to hide labels while
retaining tick marks. A pre-existing hidden-axis `none` strategy takes precedence
for either null ticker. Python and Node annotation numeric admission uses the
same `XYG_SCENE_UNSUPPORTED_ANNOTATION_COORDINATE` diagnostic, including the
coordinate name, for nonnumeric/nonfinite values. Four registry rejection cases
check exact x/y messages across both hosts. This changes no ABI struct,
signature or wire format.

### Python public notebook progressive scheduling (R2, 2026-11-06)

All public GraphForge graph widgets now feed retained native force checkpoints
through the original Figure compiler, ChartView and widget channel. Layered and
configured graphs share that route; there is no theme/style routing fork. The
initial native checkpoint precedes terminal layout, and paint acknowledgements
bound delivery to one pending picture. Static/batch routes remain synchronous.
[The transport contract](graph-session-python-transport.md#public-notebook-scheduling-through-the-existing-figure-channel-r2-2026-11-06)
records exact snapshot/epoch ownership, cross-loop dispatch, cancellation,
selection-mask validity, preserved generic presentation and event semantics.
The private GraphSession wrapper is unchanged. The later notebook identity
projection subsection below records the bounded UUID integration; full public
GraphSession interaction remains future work. The real five-node/two-widget notebook
smoke runs within the existing Release surfaces `test` job. It does not prove
required rendered ladder budgets, every notebook frontend, UUID box/lasso/export
parity, competitor leadership or #35/#36/#1015 closure. The R1 geometry-only
candidate is superseded; its receipt remains historical evidence.


### Authentic Core rc.7 composition qualification

The [Core rc.7 receipt](../releases/core-rc7-compatibility-2026-11-06/README.md)
records real published-addon IPC for 96 algorithms plus find, native/Python/Node
composition, and exact native/WASM document parity. The supported-Core
declaration adds exact `0.6.0-rc.7`; it declares no interval or final `0.6.0`.
This Linux x64 GNU qualification is not an installed XYG release cohort, complete
platform matrix, or notebook/frontend acceptance. #936/#884/#108 remain open.

## Native automatic temporal/geographic snapshots

Python `GeoChart.bind_temporal` and Node `GeoChart.bindTemporal` schedule the
same native retained-point composition from exact temporal snapshots. Both
retain independently leased public chart/frame pairs, coalesce desired snapshots,
suppress stale camera/time results, skip selection-only requery and retain the
last accepted frame after failed reads. The complete ownership, synchronous batch
compatibility and remaining mounted-view/indexed/mixed-source limitations are
normative in [geo-retained-hosts.md](geo-retained-hosts.md). This bounded slice
advances M6; #50/#39/M6 and broader M5/#108 remain open.


### Python notebook identity projection (2026-11-06)

The [bounded identity slice](graph-session-python-transport.md#notebook-typed-identity-slice-2026-11-06)
adds Rust SelectRefs/SelectUuids projection to existing FigureWidget callbacks
and binary row highlights. Exact typed callback records preserve kind, UUID and
per-layer result_id/row without replacing the original graph renderer. The
[receipt](../performance/graph-notebook-identity-2026-11-06/README.md) separates
unit proofs for loops/parallel edges/layered provenance from actual small
JupyterLab node-callback/UUID-selection delivery. Prior receipts remain historical.
Full notebook frontend, exact geometric UUID sets, export and rendered size
ladder acceptance for #1015/#36/#35 remains open.

## Ordinary linked filtering checkpoint (#112)

Native ABI 405 and WASM ABI 38 share XYFC/XYFR v1 through the Rust
`FilterTierCSession`; Python `Chart.filter_session`, Node chart `filterSession`,
and browser `createWasmFilterSession` frame that same protocol. Full packets,
exact counts, refusal paths, and canonical u64 membership pages are compared
across hosts, including passive 2D exact count planes, base range/mask
composition and edit transactions. `attachFilterDashboard` reuses existing
composed browser views and the ordinary density painter; bounded Chromium
five-view pointer/keyboard parity and context/append/rebuild/publication failures
are exercised. Automatic notebook/native-host transport, assistive hardware,
nonlinear/large-offset compatibility and massive performance remain open. The [normative subset and remaining work](filter-tier-c.md)
include synchronous Worker cancellation limits and logical memory accounting.
## Temporal catalog candidate (#46)

[Temporal catalog](temporal-catalog.md) records the exact XYTM framing and
bounded Python/Node Figure and browser WASM entry points. Package size, full
parity and accessible controller journeys remain release blockers.
### Immutable temporal graph snapshots and retained exports

Python/Node and the actual browser Worker use Rust-owned XYFG snapshots and
retained paint-to-canonical-Scene lowering. Hosts marshal typed scalars, capture
computed CSS presentation and frame HTML with the shipped client; Rust owns
validation, membership, styles, geometry, dash phase, stable-ID mapping,
provenance and full-artifact consistency. Native SVG/PNG/HTML and browser
Scene/XYPB/SVG/HTML/PNG share these paths under the unchanged single-module
package caps. PNG is byte-identical through the shared Rust raster/encoder. See [the versioned frozen contract](temporal-graph-frozen.md).
Historical ABI402/403 acquisition/native receipts remain immutable.

Native local chunked charts now refine committed viewport gestures through the
existing renderer, with exact accepted-frame source identity and cancellation.
The installed Jupyter/anywidget and public Node binary HTTP journeys, lifecycle
contract, required CI discovery and remaining issue-wide acceptance are specified
in [the local native viewport contract](chunked-native-viewport.md).
