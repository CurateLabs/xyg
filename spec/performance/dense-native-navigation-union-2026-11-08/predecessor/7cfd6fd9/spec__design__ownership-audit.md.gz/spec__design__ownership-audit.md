# Source ownership audit

<!-- xyg-ownership-schema: 1 -->

**Status:** enforced architecture contract. Machine-readable twin: [`ownership-audit.json`](ownership-audit.json). Tracking issue: [#56](https://github.com/CurateLabs/xyg/issues/56).

This ledger answers ownership file by file without treating language percentages as a quality target. Rust owns row scans and every parity-affecting decision. Python and Node own host ergonomics. TypeScript owns browser painting and interaction. Files marked for migration remain supported, but must not gain new canonical policy while their named issue is open.

ABI 396's [capped canonical drill](canonical-drill.md) keeps admission, point and
candidate caps, paired zone pruning, row membership and exact/refusal status in
Rust. `_native.py` and Node `encode.js` borrow typed inputs and pack that same
ABI. `interaction.py` orders the existing predicate, drill and tile lifecycles;
it does not certify an estimate or expand candidate rows. TypeScript recognizes
the existing keyed RGBA representation for opacity handoff and retains its
texture/cache ownership. Finite seams prove these boundaries; finer unordered
row localization and massive-source evidence remain open.

The keep-host inventory is an advisory source map, not behavioral evidence.
`scripts/audit_python_host_core.py` parses Python imports/calls and Node ESM
imports/calls to report syntactic call expressions and referenced entries on the generated
native boundary, plus references per KLOC. Imports alone do not count, but dead
calls do; host policy can also run before a counted call. The
`python-host` and `node-host` manifest policies also reject hand-authored ABI
signatures and known host-local aggregation/domain/tick implementations. These
checks are structural tripwires rather than semantic ownership proof.

The executable layer is `scripts/host_delegation_corpus.py`, whose versioned
contract is [`host-delegation-corpus.json`](host-delegation-corpus.json). It
runs the versioned default-palette byte contract, all 27 admitted public mark
kinds, and the payload, Scene/static export, LOD, density, append, and failure
controls through generated ctypes/Koffi test hooks.
Hooks record canonical ABI symbol names, pointer presence, size/capacity
metadata, outcomes, and returned lengths, never pointer addresses or user
values. The gate requires both hosts to execute the reviewed product-level Rust
entries while existing differential assertions remain the output oracle. It
writes `target/host-delegation-report.json`, keyed by ABI signature/version and
commit; CI uploads that exact-SHA artifact. The report also carries the
versioned uncovered-route/module inventory, with #869/#873/#875 as current
owners rather than silently converting missing coverage to zero. Dead calls produce no events,
injected native faults propagate before output, and a host-local fallback event
fails the verifier. Dynamic traces prove execution, not absence of every
possible duplicate algorithm, so the structural tripwires remain complementary.

The verifier inventories tracked source under its listed roots. Top-level tests, examples, benchmarks, generated bundles, dependencies, vendor trees, and untracked local files are outside this ledger. Internal Rust test modules under `crates/*/src/` remain in scope and require exact file entries; a `tests` directory name does not waive ownership classification.

Migration status: Scene v25 now moves canonical viewport/plot bounds, numeric
axis transforms, chart/plot backgrounds, authored axis side and visibility,
explicit major/minor tick geometry and paint, bounded primary static legend
entry order/placement/frame/text/swatch policy, bounded semantic graph label
collision/truncation/final screen geometry and source identity, default numeric
tick/label/grid/spine chrome, clipping visibility, and scatter/polyline/rectangle record
encoding plus Band `None`/`Top`/`Perimeter` outline topology into
`crates/xyg-engine/src/scene.rs`. `python/xyg/_native.py` and
`packages/xy-node/src/scene.js` only coerce typed arrays and call the generated
batch ABI. Their remaining migration classification covers figure-to-record
assembly, additional mark families, and legacy static-export consumers. ABI 84
also makes Rust authoritative for the ordered, stable failure reason attached
to deferred authored Scene features; hosts only pack the versioned presence mask.
Rust also owns bounded multiline/wrapped annotation line breaking, line count,
and screen-space box/leader bounds; public hosts only pack literal inputs and
reject markup, CSS/classes, custom fonts, and collision policy. Rust also owns
whether resolved Cartesian Scene chrome produces SVG/raster
primitives. Host paint alpha is data, not an implicit polar-mode signal; polar
Scene compile is explicit XYPL v1. Scene v26 owns polar line/scatter/area/bar/column
projection and annular-sector tessellation, polar errorbar and contour polylines, polar heatmap
lattice tessellation, ABI 192 polar painted heatmap Image blit, ABI 193 heatmap/hexbin stroke_opacity, ABI 194 polar hexbin / custom reducers / categorical direct_rgba, ABI 195 triangle-mesh custom role / per-item face intern, ABI 196 scatter per-item fill/stroke/width/opacity intern, clip, rings/spokes, and rim tick labels in `scene.rs` + `polar.rs`.
Python `_PolarProjection` remains a thin packer plus wedge/ring/polygon helpers
for the compatibility exporters. ABI 143 polar density tessellates occupied
`DensityBlit` cells to PolyFill wedges. ABI 97 also makes Rust authoritative for bounded solid-ribbon Scene geometry:
Python and Node pack two adjacent compact endpoint rows, while Rust transforms
the endpoints through the selected Cartesian axes and expands the fixed
96-interval cubic into ordinary Scene v25 Band samples. Host-local ribbon
polygon helpers remain compatibility-renderer code, not canonical Scene policy.
The public constant built-in marker slice admits all 19 fixed symbol codes and
an optional literal constant CSS stroke with a finite non-negative scalar
width. Python and Node preserve the constant fill and stroke paint in the Scene
style table and normalize stroke-only authoring to 1px. Rust owns implicit 1px line-only width,
symbol paths, stroke-inclusive extent clipping, legend swatches, and
SVG/raster/browser lowering. Width-only match-fill, per-item stroke/width,
custom paths/glyphs, and density/LOD scatter remain compatibility routes.
The public literal triangle-mesh slice admits at most 1,024 unjoined faces with
constant or interned per-face fill/stroke/width (ABI 195; custom `role` is
identity metadata). Public scatter admits interned per-item fill/stroke/width/
opacity (ABI 196) and, from ABI 386, Rust-mapped per-item size (#1006); per-item symbol stays fail-closed. Python and Node pack six authored
vertex columns as three-row PolyFill runs; Rust owns their stable-run grouping,
plot clipping, legend swatch, SVG/raster/browser lowering, and the public
PolyFill group budget (companion traces share the 1,024-group ceiling; hexbin
cells use a separate 50,000-cell aggregate ceiling, #887).
A non-joined mesh above that budget keeps every face in static export; Rust
bounds its overdraw and writes one raster image per mesh in SVG/PDF above
50,000 faces (#1006; scene-ir.md "Mesh tiers and dense-fill rule").
`joined_fill` plus per-face paint, alternate axes, and polar meshes remain
compatibility behavior.

ABI 98 removes composition-violin geometry policy from both hosts. They retain
coercion, group/category factorization, rollback, and literal style authoring,
then pack flat f64 samples, monotone offsets, centers, bins, width, and
orientation. Rust alone filters samples, skips empty groups, computes and
normalizes density, applies width/orientation, validates the 10,000-Rect bound,
and emits final coordinates. Public constant-style primary Cartesian violins
use the existing Scene consumers; pyplot KDE bodies and advanced variants stay
on their explicit compatibility paths.

Exact composition ECDF sorting, duplicate coalescing, and cumulative
normalization now use `xyg_weighted_ecdf` in both Python and Node. Python also
passes raw f64 values through Rust's finite filtering, while Node retains its
equivalent finite-value coercion seam.
The hosts retain validation/error wording, the right-continuous zero anchor,
and literal Step style packing; Rust expands that Step for the shared Scene
consumers. ABI 100 also moves binned ECDF finite filtering, automatic domain
(including 5% absolute-value widening for nonzero constants and a 0.5 fallback
at zero or for a non-useful pad), the 10,000-bin ceiling, uniform
counting, cumulative normalization, empty-bin compaction, right-edge placement,
and zero anchor into `xyg_binned_ecdf`. Node retains its optional authored
range and denominator contract; Python adds no public range option. Hosts keep
coercion, stable validation wording, literal style/axis/id packing, and the
existing Step Scene route.

Omitted-bin composition histogram edges now use Rust's NumPy-compatible auto
estimator in both Python and Node instead of Node silently selecting ten bins.
ABI 101 `xyg_histogram_bins` then owns authored-edge validation, closed-last-bin
assignment, density normalization, and cumulative assembly for every composition
histogram path. Hosts retain coercion, explicit integer-bin validation, literal
style packing, and the historical all-nonfinite ten-bin compatibility case;
Rust owns the ordinary adaptive edge count, irregular counting, density, and
cumulative heights. The resulting bounded Histogram Rects already route public
SVG/PNG/PDF and browser paint through the canonical Scene. Rust rejects
automatic or authored results above 10,000 bins, and each thin binding uses one
10,001-edge ABI scratch plane.
ABI 102 moves composition-hexbin finite-pair filtering, automatic domain
(including the shared 5% absolute-value widening for nonzero constants and a
0.5 fallback at zero or for a non-useful pad), and the matplotlib
`int(width / √3)` default grid height into `xyg_hexbin` /
`xyg_hexbin_ingress`. Python and Node pack raw f64 columns, an optional
authored rectangle, and either a scalar width or an explicit `(width, height)`;
they no longer scan finite pairs, pad degenerate extents, or choose the
default height (`Math.round` on Node was the host drift). Custom Python
`reduce_C_function` paths still reduce groups on the host after Rust resolves
the lattice. Public traces remain centers-only on the wire. ABI 103 moves
constant-style Cartesian hex-cell ring expansion and regular heatmap lattice
reconstruction into `expand_scene_records` (`HexCell=5`, `HeatmapLattice=6`).
Python and Node pack one compact center+pitch row per hex cell and a two-row
extent+shape heatmap lattice; Rust emits the same Scene v25 PolyFill rings and
Rects the retired host packers produced. ABI 134 adds `HeatmapPainted=9` and
XYHP paint planes (RGBA8 image-top-first or scalar values + RGB stops + domain)
on the Scene extras pointer (XYEX when polar XYPL is also present). Hosts pack
the compact lattice plus paint; Rust tessellates cells and interns unique fills.
ABI 104 moves disconnected endpoint
pairs and unjoined triangle faces into the same compact expansion
(`SegmentPair=7`, `TriangleFace=8`): hosts pack one four-coordinate Polyline
row per segment and two PolyFill rows per face. ABI 105 moves
`scene_export_support_reason` allowlists, check order, and diagnostic wording
into `crates/xyg-engine/src/scene_export.rs`. Python and Node pack `XYEF` v1
facts; ABI 152 owns `XYEP` layout and flag derivation, then the predicate
allowlists run over that envelope. They still compile the Scene
so encoder and router cannot disagree. ABI 106 moves Figure autorange, default
3% margin, log-positive extents, polar theta/radial defaults, reverse,
degenerate widening, `_auto_domain`, and zero-baseline pinning into
`crates/xyg-engine/src/autorange.rs`. Python and Node pack an `XYAR` v1 envelope
of axis options, zone extents, and rectangle zero-baseline predicates; they no
longer apply host-local padding (Node's former 5% pad). Direct-browser WASM
compile uses the same `auto_domain` degenerate pad. ABI 107 moves Scene
CSS→RGBA8 conversion and per-kind mark fill/stroke/width defaults into
`crates/xyg-engine/src/scene_style.rs` (plus `css::color_rgba8`). Python and
Node pack an `XYMS` v1 envelope of kind, opacities, authored CSS strings, and
width fields; named colors, `none`, line-only scatter stroke, band `line_color`,
and the never-invisible fallback cannot drift. ABI 108 moves the 200-byte
Scene chrome style input into the same module: Python and Node pack an
`XYCH` v1 envelope of background CSS, per-axis sides, paint flags, opacities,
widths, and CSS strings; default RGBA/widths and `grid_opacity` scaling of
the default grid color cannot drift. ABI 109 moves Figure→Scene row
packing into `crates/xyg-engine/src/scene_pack.rs`. Python and Node pass
kind, flags, step mode, style ref, trace id, diameter/symbol, extras, and
literal f64 columns; record kinds, stable-id splitting, expansion-mode
assignment, ribbon/triangle doubling, heatmap lattice framing, and
finite-coordinate rejection cannot drift. ABI 116 expands primary
rule/band/marker annotations into ordinary Scene polyline/rect/scatter
rows from packed scalars plus axis domains; hosts only coerce kind, axis,
style ref, index, and authored numbers. ABI 117 moves figure-compile
support into `crates/xyg-engine/src/scene_export.rs`. Python and Node pack
an `XYFS` v1 envelope of observations plus axis ids/keys; feature mapping,
the primary x/y axis set, and the Scene axis-key allowlist cannot drift.
ABI 118 extends that envelope to `XYFS` v2 per-trace allowlist flags so
unsupported kinds, hidden/per-item styles, density, dash/curve/markers,
rect extras, joined fills, custom hex reducers, heatmap colormaps, and
non-CSS fills cannot drift either. v1 envelopes remain accepted.
ABI 110 moves primary XYLG
legend framing into `crates/xyg-engine/src/scene_legend.rs`. Python and
Node pass loc/flags, font sizes, paints, title, and per-entry meta plus
labels; header layout, text offsets, and bounded-text rejection cannot
drift. ABI 111 moves primary XYCB colorbar framing into
`crates/xyg-engine/src/scene_colorbar.rs`. Python and Node pass domain,
stops, ticks, title, and text RGBA; header layout, stop/tick tables,
domain-span checks, and bounded-text rejection cannot drift. ABI 112
moves primary XYAD annotation framing into
`crates/xyg-engine/src/scene_annotations.rs`. Python and Node pass typed
row meta plus concatenated labels; XYAT/XYAL/XYAR/XYAC/XYAW table layout,
version selection, the XYAD envelope, and bounded-text rejection cannot
drift. ABI 113 moves closed-subset SVG→PDF into
`crates/xyg-engine/src/pdf.rs`. Python and Node pass UTF-8 SVG; path
lowering, Helvetica metrics, ExtGState/shading/image embedding, and
deterministic object numbering cannot drift. ABI 114 moves baseline JPEG
and lossless WebP encode into `crates/xyg-engine/src/jpeg.rs` and
`crates/xyg-engine/src/webp.rs`. Hosts coerce packed RGB/RGBA8 pixels;
YCbCr 4:4:4 / VP8L simple-lossless packing cannot drift. ABI 115 moves
filter-0 PNG encode into `crates/xyg-engine/src/png_encode.rs`. Hosts
coerce packed RGB/RGBA8 pixels and a compression level; indexed-palette
selection, `tRNS`, and zlib IDAT cannot drift. ABI 194 admits polar hexbin,
custom `reduce_C_function` (host-reduced after `xyg_hexbin_groups`), and
categorical / `direct_rgba` 1×N XYHP RGBA onto HexCell PolyFills. ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6. ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7. LOD over the 1,024-group painter
budget, and rich style exceptions stay on the compatibility exporters.
Scene 25 is unchanged. Polar density tessellates on Scene (ABI 143). LOD over the 10,000-Rect histogram ceiling,
and rich style exceptions stay on the compatibility exporters. Polar heatmap
Scene tessellates constant-style lattice Rects to PolyFill wedges; ABI 192
polar painted heatmap inverse-rasters to one plot-covering Image blit.
ABI 193 admits heatmap/hexbin `stroke` / `stroke_width` / `stroke_opacity`; polar
painted Image blit tessellates when stroke is visible.
ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba`
hexbin as interned HexCell PolyFills.
ABI 195 admits triangle-mesh custom `role` and per-item fill/stroke/width interned
from packed XYHP kind 6 (`joined_fill` plus per-face paint stays fail-closed).
ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7
(ABI 386 adds the Rust-mapped per-point size diameter, stride 12 -> 20; per-item symbol stays fail-closed).
Polar contour compiles as SegmentPair polylines. ABI 134
`HeatmapPainted` moves Cartesian/polar scalar colormap and truecolor intern into
Rust: hosts pack XYHP, Rust emits per-cell Rect fills.
ABI 99 likewise removes grouped composition-box statistics and geometry policy
from both hosts. Python and Node pack canonical values, offsets, centers,
orientation, width, visibility, and literal styles; Rust owns finite filtering,
Tukey statistics, stable group ordering, body/whisker/cap/median geometry,
deterministic bounded outlier placement, and the 10,000-record cap. Supported
constant-style primary-Cartesian boxes now use the existing Rect, Polyline, and
Scatter Scene consumers for public SVG/PNG/PDF; alternate-axis, polar,
gradient, and per-item-style cases remain explicit compatibility paths.

The post-M2 retirement pass removes two obsolete Python adapter layers without
widening that compatibility boundary. `_svg.axis_ticks` now maps every
automatic linear/log/category/angular/time/symlog family directly to
`_native.scene_axis_ticks`; the former per-family wrappers are gone. Rust
`scene::{linear_ticks, log_ticks, category_ticks, angular_ticks, time_ticks}`
remains the only ladder implementation, exposed to Node by `axisTicks` and to
Python/pyplot/SVG/raster by the generated C ABI. The duplicate
`try_public_svg` / `try_public_png` / `try_public_pdf` selectors are also gone:
`public_static_export` is the only optional product-route selector, while
`figure_scene`, `figure_svg`, and `figure_raster_commands` remain explicit
Scene consumers. `_svg.py`, `_raster.py`, and `_scene_v3.py` stay in the
migration class because the compatibility and figure-to-record assembly debt
listed below still exists.

### Post-M2 Python retirement inventory

| Candidate | Rust replacement and product call path | Coverage | Disposition |
| --- | --- | --- | --- |
| `_svg._linear_ticks`, `_log_ticks`, `_category_ticks`, `_angular_ticks`, `_time_ticks` | `crates/xyg-engine/src/scene.rs` owns all ladders; `xyg_scene_axis_ticks` exposes them through `crates/xyg-core/src/lib.rs`; Python SVG/raster/pyplot call `_native.scene_axis_ticks` through `_svg.axis_ticks`, and Node calls `axisTicks` in `packages/xy-node/src/scene.js` | Rust Scene tick unit tests, `tests/test_scene_ir.py`, and `packages/xy-node/test/scene.test.mjs` | **removed** |
| `_scene_v3.try_public_svg`, `try_public_png`, `try_public_pdf` | Rust `SceneDocument` owns SVG/raster/painter lowering; `Figure.to_svg` and `export._native_image` use the one `public_static_export` selector, while Node uses `sceneSvg` / `sceneRasterCommands` | `tests/test_figure_scene_v3.py`, `tests/test_scene_export_support.py`, and `scripts/bench_public_scene_routes.py` exercise the product selector and exact Rust consumers | **removed** |
| `_svg.py`, `_raster.py`, `_scene.py` compatibility rendering | Scene static custom fonts/CSS/classes are the bounded fail-closed contract `XYG_SCENE_UNSUPPORTED_CUSTOM_FONT` / `XYG_SCENE_UNSUPPORTED_BROWSER_CSS` (#288; DejaVu Sans only; default-font figures must not fall back to `_svg.to_svg` / `_raster`). Remaining compatibility debt is unresolved/browser-only gradients (`var()` / theme CSS are the bounded fail-closed contract `XYG_SCENE_UNSUPPORTED_GRADIENT` (#289)), and the rich style/text exceptions below. ABI 137 owns Cartesian constant-style density as one Scene Image blit (`DensityBlit` + XYHP kind 3 + XYIM); ABI 142 owns cartesian mean-color density on that same blit (XYHP kind 4, LOD doc §2 physical alpha); ABI 143 polar density tessellates occupied `DensityBlit` cells to PolyFill wedges (no XYIM). ABI 138 owns constant dash polylines (XYDS extras + sidecar); ABI 139 owns constant non-round linecaps (XYLC extras + sidecar); ABI 140 owns cartesian `curve="smooth"` polyline flatten (`CurveFlatten=11`); ABI 141 owns cartesian `area(curve="smooth")` Band flatten (`BandFlatten=12`); ABI 144 owns cartesian `error_band(curve="smooth")` on that same `BandFlatten` mapping and polar `curve="smooth"` line/area/error_band as identity chords (polar-axes.md §5); ABI 145 owns constant scatter `marker_path` (XYMP extras tessellated to PolyFill/Polyline after pixel mapping); ABI 146 owns constant mark `fill` linear-gradients (XYGR extras kept on encoded Scene; SVG `<linearGradient>` / raster `OP_FILL_POLY_GRAD`); ABI 166 owns cartesian bar/column/histogram `corner_radius` tessellation (`rounded_rect_poly` after pixel mapping); ABI 167 owns polar bar/column/histogram `wedge_gap` (`polar_wedge_points` constant-px inset); ABI 168 owns polar bar/column/histogram `corner_radius` (rounded-wedge tessellation when inner > 0); ABI 169 owns polar `curve="smooth"` plus `step` as polar step expansion (identity chords); ABI 170 owns constant scatter `marker_glyph` (XYMG extras kept on encoded Scene; SVG `<text>` / raster `OP_TEXT`); ABI 191 admits multi-character UTF-8 (XYMG v2, max 64 bytes); combined `marker_path` + `marker_glyph` stays fail-closed. ABI 192 owns polar painted heatmap inverse-raster as one Scene Image blit (Image+XYPL); constant-style polar lattices still tessellate. ABI 171 owns width-only scatter `stroke_width` as match-fill (mark color at the authored width); ABI 172 owns cartesian line `curve="smooth"` plus `step` as authored step expansion; ABI 173 owns heatmap `corner_radius` tessellation (cartesian rounded Rects / polar wedges); ABI 174 owns violin/box `corner_radius` tessellation on that same Rect path; ABI 175 owns violin/box `fill_opacity` / `stroke_opacity` on XYMS; ABI 176 owns bar/column/histogram `fill_opacity` / `stroke_opacity` on that same XYMS path; ABI 177 owns heatmap `fill_opacity` on that same XYMS fill alpha; ABI 178 owns scatter `fill_opacity` / `stroke_opacity` on that same XYMS path; ABI 179 owns hexbin `fill_opacity` on that same XYMS fill alpha; ABI 180 owns triangle_mesh `fill_opacity` / constant stroke paint on that same XYMS path; ABI 181 owns cartesian area/error_band `curve="smooth"` plus `step` as authored band step expansion; ABI 182 owns triangle_mesh `joined_fill` as one identity PolyFill ring; ABI 183 owns constant ribbon `color2_ch` as XYGR mark-space `dir=right`; ABI 190 owns cartesian per-item two-ended ribbon `color2_ch` intern from packed XYHP kind 5; ABI 184 owns cartesian unwrapped text `dx`/`dy`/`anchor` as XYAW `wrap=0`; ABI 185 owns labelled cartesian marker `dx`/`dy`/`anchor` as XYAW `wrap=0`; ABI 186 owns cartesian colormap hexbin as a 1×N XYHP plane interned onto HexCell PolyFills; ABI 194 owns polar hexbin, custom host reducers, and categorical / `direct_rgba` hexbin on that same intern; ABI 187 owns cartesian unwrapped text `rotation` as XYAW `wrap=0` ABI 195 owns triangle-mesh custom `role` and per-item fill/stroke/width interned from packed XYHP kind 6; ABI 196 intern scatter per-item fill/stroke/width/opacity from packed XYHP kind 7;; ABI 188 owns labelled cartesian marker `rotation` as XYAW `wrap=0`; per-item radius channels stay compatibility. ABI 121 owns ribbon/curve/rounded-rect tessellation; ABI 123 owns tick-label collision thinning (`_axis_tick_label_layout` is a thin packer); ABI 124 owns static legend box packing (`_legend_layout` is a thin packer plus CSS/polar remap); ABI 125 owns text-block measure and cartesian axis rooms (`_textblock.measure` / `_svg._*room` are thin packers plus CSS/tick formatting); ABI 126 owns static-export padding, title-band, colorbar extra, right-y, and polar-recut formulas (`layout()` / `_recut_polar_plot` are thin packers plus CSS/tick formatting/legend reservation); ABI 127 owns the pyplot tight-layout grid solve (`Figure._apply_tight_layout` is a thin packer plus chrome/suptitle/legend measurement); ABI 128 owns authored tick-window resolve/filter (`_tick_window` / `_tick_window_filter` are thin packers); ABI 199 owns Scene product-path authored filter/pairing during chrome pack; ABI 130 owns Cartesian compatibility tick-label formatting (`xyg_tick_format`; `_tick_text` / `_fmt_axis` are thin packers plus compatibility authored `tick_labels`); ABI 131 owns polar (theta, r) → screen-pixel projection (`xyg_polar_*`; `_PolarProjection` layout/project/masks are thin packers; wedge/ring/polygon helpers remain Python for compatibility except ABI 209 `xyg_polar_wedge_points` flatten); ABI 133 owns polar Scene compile for line/scatter/area/bar/column/errorbar/heatmap/contour (XYPL + `polar_project` + `polar_wedge_points` PolyFill + polar chrome; `_PolarProjection` remains for compatibility emitters; polar heatmap tessellates lattice Rects; polar contour reuses SegmentPair polylines); ABI 134 owns painted heatmap intern (`HeatmapPainted` + XYHP; `_heatmap_paint_plane` is a thin packer); ABI 135 owns named colormap tables (`xyg_colormap_stops`, XYHP paint kind 2); ABI 132 owns first-paint density scatter emit policy (`xyg_density_*`; `_density_trace_spec` is a thin packer plus kernel invocation/shipping); ABI 129 owns Cartesian static-export grid colormap (`xyg_colormap_rgba` / `xyg_colormap_rgba_canonical` plus log-u8 `xyg_density_rgba`; `_scene.grid_rgba`, `_svg._heatmap_rgba_grid`, `_svg._heatmap_rgba_samples`, and `_svg._density_image` are thin packers) | Existing polar, SVG, raster, style, export, and pyplot suites | **keep loudly** |
| `_scene_v3.py` figure-to-record assembly | Rust owns record validation, mapping, expansion modes, layout, consumers, the ABI 105 public-export allowlists (heatmap/contour lattices autorange without an authored axis domain), ABI 107 mark fill/stroke defaults plus CSS→RGBA8, ABI 108 chrome style defaults, ABI 109 column packing, ABI 136 product-kind packing, ABI 137 Cartesian density Image blit, ABI 138 constant dash XYDS, ABI 139 constant linecap XYLC, ABI 140 cartesian smooth-polyline flatten, ABI 141 cartesian smooth-area Band flatten, ABI 142 cartesian mean-color density XYHP kind 4, ABI 143 polar density PolyFill tessellation, ABI 144 cartesian error_band BandFlatten plus polar identity-chord smooth, ABI 145 constant marker_path XYMP tessellation, ABI 146 constant mark-fill linear-gradient XYGR, ABI 147 XYPK product packing facts, ABI 148 XYAF annotation packing facts, ABI 149 XYHF heatmap/density paint-fact packing, ABI 150 XYSS extras packing, ABI 151 Scene density grid packing, ABI 152 XYEP packing from XYEF, ABI 153 XYCF figure-chrome packing, ABI 154 XYTC per-trace compile packing, ABI 155 XYTA heatmap/density attach packing, ABI 156 XYCL product-row packing, ABI 157 XYSD trace-sidecar packing, ABI 158 XYSS style-sidecar packing, ABI 159 XYAS annotation splice packing, ABI 160 XYAS/XYCC assembled encode, ABI 161 XYSD chrome/extras packing, ABI 162 XYAS/XYCF assembled encode from sidecars, ABI 163 product encode from packed facts, ABI 164 public static-export consumers, ABI 165 product-path XYFS support, ABI 166 cartesian bar/column/histogram corner_radius tessellation, ABI 167 polar bar/column/histogram wedge_gap tessellation, ABI 168 polar bar/column/histogram corner_radius tessellation, ABI 169 polar curve=smooth plus step, ABI 170 constant marker_glyph XYMG, ABI 171 width-only scatter match-fill, ABI 172 cartesian line step+smooth, ABI 173 heatmap corner_radius tessellation, ABI 174 violin/box corner_radius tessellation, ABI 175 violin/box fill/stroke opacity, ABI 176 bar/column/histogram fill/stroke opacity, ABI 177 heatmap fill_opacity, ABI 178 scatter fill/stroke opacity, ABI 179 hexbin fill_opacity, ABI 180 triangle_mesh fill/stroke opacity, ABI 181 cartesian area/error_band step+smooth, ABI 182 triangle_mesh joined_fill, ABI 183 constant ribbon color2_ch XYGR, ABI 184 cartesian unwrapped text dx/dy/anchor XYAW, ABI 185 labelled cartesian marker dx/dy/anchor XYAW, ABI 186 cartesian colormap hexbin XYHP, ABI 187 cartesian unwrapped text rotation XYAW, ABI 188 labelled cartesian marker rotation XYAW, ABI 189 heatmap/hexbin cell-fill tessellation eligibility from packed XYTA, ABI 190 cartesian per-item two-ended ribbon color2_ch intern from packed XYHP kind 5, ABI 191 constant multi-character scatter marker_glyph XYMG v2, ABI 192 polar painted heatmap inverse-raster Image blit, ABI 193 heatmap/hexbin stroke_opacity, ABI 194 polar hexbin / custom reducers / categorical direct_rgba, ABI 110 XYLG legend framing ABI 195 triangle-mesh custom role / per-item face intern, ABI 196 scatter per-item fill/stroke/width/opacity intern,, ABI 111 XYCB colorbar framing, ABI 112 XYAD annotation framing, ABI 117–118 XYFS figure-compile support including per-trace allowlists, and ABI 135 named colormap lookup; remaining host work is mark-row assembly, custom glyphs/fonts/CSS, and payload LOD | Cross-host Scene bytes, `tests/test_scene_export_support.py`, `tests/test_scene_style_native.py`, and Node `sceneExportSupportReason` pin current assembly | **keep as migration debt** |
| `_figure.py` / `marks.py` host code | Public composition, ingest coercion, validation text, category factorization, rollback, and explicit custom-reducer callables / empty-input compatibility are host responsibilities; ABI 119 owns sort, histogram/contour edge policy, and hex lattice groups; ABI 120 owns `loc="best"` occupancy; ABI 121 owns ribbon/curve/rounded-rect flattening; ABI 122 owns compile-time payload LOD/mask; ABI 204 owns line M4 emit indices; ABI 205 owns remaining emit visible/even/sample indices; ABI 123 owns tick-label collision thinning; ABI 124 owns static legend box packing; ABI 125 owns text-block measure and cartesian axis rooms; ABI 126 owns static-export padding/colorbar/polar recut combination; ABI 127 owns the pyplot tight-layout grid solve; ABI 198 owns `_svg.layout()` combination and tight-layout figure-edge extras; ABI 128 owns authored tick-window resolve/filter; ABI 199 owns Scene product-path authored filter/pairing; ABI 200 owns Scene product-path authored minor filter; ABI 201 owns Scene polar modular theta window / angular labels (secondary axes fail-closed); ABI 202 owns Scene product-path ABI 130 time/angular formats; ABI 130 owns Cartesian compatibility tick-label formatting; ABI 132 owns first-paint density scatter emit policy | Mark, composition, pyplot, and host-parity suites | **keep host seams** |
| `xyg_scene_scatter_svg` Python/Node adapters | Whole-Scene owns the bounded product route, but the version-1 Rust wrapper still serves compatibility scatter rendering and the explicit low-level Node surface | `tests/test_scene_ir.py` and `packages/xy-node/test/scene.test.mjs` | **keep compatibility ABI** |

Static-export routing status (#117): `Figure.to_svg`, native `to_png`, native
`to_image(..., "svg"|"png"|"pdf")`, `write_image`, and the native branch of
`write_images` now delegate the proven
literal Cartesian public geometry subset—constant-style built-in scatter symbols
with optional constant marker strokes and scalar widths
and polylines, bounded fill-only unjoined triangle meshes, constant-style
Cartesian hexbin PolyFill cells, constant-style Cartesian heatmap Rects, Cartesian
constant-style density Image blits, ordinary finite
fixed-domain area/error-band Bands,
ordinary bar/column/histogram Rects and Rust-expanded constant-style violins and boxes, bounded disconnected
segment/error-bar/stem endpoint pairs, and finite literal solid-color ribbons
expanded by Rust—plus the proven literal static
chrome contract (chart/plot backgrounds, title, authored axis
labels/sides/major-minor ticks, independent literal `ticks`/`text` visibility
switches, primary legend, literal colorbar), and the existing bounded primary
Cartesian annotation family: cartesian text with optional `dx`/`dy`/`anchor` (XYAW `wrap=0` when unwrapped), Rust-positioned labelled rules/bands/markers,
unlabelled straight arrows, ordinary callouts, and bounded wrapped text/callouts,
to the Rust Scene
SVG and raster consumers (PDF consumes Rust SVG). `FacetGrid.to_svg` and native grid
PDF independently route each supported panel through that same Rust SVG
consumer, namespacing its closed clip-id vocabulary only for nested-document
composition; native grid PNG/JPEG/WebP independently route each supported
no-background-override panel through the compiled Scene raster display list and
compose the RGBA frames. Panel backgrounds and unsupported panels deliberately
select compatibility before compilation. `python/xyg/_scene_v3.py` is the single
preflight/orchestration seam for that subset: `public_static_export` owns the
Scene-format selection and reuses the predicate's compiled batch, while Python
entry points only retain host options and the documented compatibility
exceptions. `FacetGrid.to_svg` and every native facet image format reuse the compiled
panel Scene. `_svg.py` and
`_raster.py` remain compatibility owners for rich text and legend variants, every
annotation outside that bounded primary Cartesian family (including
collision/layout directives, markup, CSS/classes, and custom typography), themes, custom fonts or CSS/classes,
nonliteral/custom chrome, combined marker_path+marker_glyph, data-driven symbol channels, unmodeled marks or
segment roles/styles, LOD inputs, export background overrides, and any other
unmodeled output contract; #58/#117 must
retire each exception only with cross-host differential and performance proof.
Two-ended ribbon gradients, polar ribbons, and LOD/density ribbon policy remain
explicit compatibility exceptions. Broader direct-browser production,
including ribbon authoring, is tracked by the post-M2 follow-up **Expand direct-browser aggregate production beyond the density/Scene vertical** (related to [#54](https://github.com/CurateLabs/xyg/issues/54)).

The ABI 96 primary numeric-format slice removes one more duplicated host
decision from that compatibility boundary. For Scene-eligible linear, log, and
symlog x/y axes, `crates/xyg-engine/src/scene.rs` exclusively parses
`<prefix>(,).N[f|%]<suffix>` with precision `N` from 0 through 100, resolves
final labels (including invalid-format
fallback, log sub-unit collapse protection, and explicit-label precedence),
and measures gutters. `python/xyg/_scene_v3.py` and
`packages/xy-node/src/scene.js` only retain authoring options and pack bounded
UTF-8 through the versioned ABI envelope. M2 #869 removes canonical axis
policy from `js/src/30_ticks.ts`; it retains only presentation-oriented tooltip
formatting. The tick seam introduced in WASM ABI 23, now WASM ABI 27, plus
`attachWasmTicks` cuts attached primary/secondary
Cartesian, polar angular/radial, authored minor, and eligible colorbar slots to
the Rust resolver and independent Worker lane. Native ABI 360 introduced the
packed proof seam; current native ABI 361 carries it for Python/Node parity.
Unattached, invalid, pending,
Blob-worker HTML, and srcdoc notebook paths fail closed instead of generating
ticks in TypeScript.
Hosted `to_html()`,
notebook widgets, and application embeds can attach when they serve the packaged
Worker/WASM files at explicit URLs; this is not the all-host ChartView cutover.

## Binding seam decision

XYG intentionally ships one versioned C ABI cdylib for all hosts. Python uses ctypes and Node uses Koffi; Koffi itself is built on Node-API, but XYG is not an N-API addon. PyO3/abi3 and napi-rs would create separate host-specific native artifacts, packaging paths, and version seams. They are not the default while the product requires one core artifact usable by CPython versions, Node, VS Code, and future adapters. Issue #57 generated both low-level bindings and the C header from one typed ABI contract; measured evidence may revisit the seam later.

## Final re-audit (ABI 315, post-#732/#733, 2026-08-31)

Leftover children [#287](https://github.com/CurateLabs/xyg/issues/287)–[#313](https://github.com/CurateLabs/xyg/issues/313) and parents [#271](https://github.com/CurateLabs/xyg/issues/271)–[#283](https://github.com/CurateLabs/xyg/issues/283) are closed. No `python-scene-migration` production files remain (2026-09-01 §302 hub split). No `node-scene-migration` production files remain (2026-09-02 §302 Node marshal parity). Do not delete `_svg.py`, `_raster.py`, `_scene.py`, `marks.py`, `_legendfit.py`, `_payload.py`, or `_textblock.py` until Rust owns the path **and** differentials are green. Do not delete `_scene_v3.py`. Do not route pyplot through Scene.

**M2 close tracker ([#731](https://github.com/CurateLabs/xyg/issues/731) — CLOSED 2026-08-31).** Kernel orchestration (ABI 218–315) and host materialization retirement (ABI 316–325, big pushes 1–3) landed on `main` via PR [#852](https://github.com/CurateLabs/xyg/pull/852) (`8752bd95a`). `_payload.py` (219 lines) and `_scene_v3.py` (396 lines) are marshal-only; keep-host coercion lives in `_payload_trace_materialize.py` and `_scene_marshal.py`. Post-landing host-parity follow-on: [#855](https://github.com/CurateLabs/xyg/issues/855). Reproduce the inventory with `python3 scripts/audit_python_host_core.py`; gate with `python3 scripts/verify_ownership.py` and `make check-host-parity`.

**Audit run (2026-08-31, main ABI 315).**

| Check | Result |
| --- | --- |
| `verify_ownership.py` | 341 tracked production files classified |
| `abi_smoke.py` | 557 ABI checks passed |
| `audit_python_host_core.py` | 0 `python-scene-migration` / 0 `node-scene-migration` files; keep-host policy inventories for Python + Node |

Top remaining line counts (static-export emitters, not §302 blockers): `_channels_labels.py` ~247, `_export_marks_raster.py` ~1430, `_export_marks_svg.py` ~890, `_export_raster_cmd.py` ~660, `_export_chrome_raster.py` ~340, `_export_baseline_raster.py` ~235, `_export_axis_grid_raster.py` ~85, `_paint.py` ~880, `_export_layout.py` ~800, `_export_legend_raster.py` ~500, `_export_colormap.py` ~400, `_export_axis_grid_svg.py` ~280, `_export_baseline_svg.py` ~225, `_export_colorbar_svg.py` ~330, `_export_polar_svg.py` ~350, `_export_polar_raster.py` ~140, `_export_chrome_svg.py` ~180, `_export_annotations_svg.py` ~240, `_export_path_svg.py` ~145, `_export_marker_svg.py` ~115, `_export_svg_util.py` ~235, `_export_svg_state.py` ~120, `_export_ticks.py` ~360, `_export_legend_svg.py` ~230, `_layout.py` ~470, `_export_legend.py` ~180, `_export_heatmap.py` ~130, `_export_chrome.py` ~190, `_export_annotations.py` ~230, `_columns.py` ~40 (shared static-export helpers). `_figure.py` is a ~416-line keep-host hub over `_figure_*.py`. `channels.py` is a ~99-line keep-host hub over `_channels_*.py`. `lod.py` is a ~123-line keep-host hub over `_lod_*.py`. `facets.py` (~14), `_annotations.py` (~17), `_svg.py` (~183), and `_raster.py` (~71) are keep-host re-export hubs over their `_facets_*`, `_annotations_*`, `_svg_*`, and `_raster_*` slices.

**M2 Node stay-host TAP (2026-08-31).** Payload emit diffs [#644](https://github.com/CurateLabs/xyg/pull/644)–[#693](https://github.com/CurateLabs/xyg/pull/693) and scene compose diffs [#694](https://github.com/CurateLabs/xyg/pull/694)–[#698](https://github.com/CurateLabs/xyg/pull/698) are **merged on main** (with [#630](https://github.com/CurateLabs/xyg/pull/630)–[#643](https://github.com/CurateLabs/xyg/pull/643) and replay helper [#699](https://github.com/CurateLabs/xyg/pull/699)). Staging branches (`cursor/m2-node-payload-rebase-staging-7ce1`, scene rebase tips) are fully absorbed (0 commits ahead of main). Stay-host TAP is inventory tied to #731 close, not an alternate close path.

**Merged kernel stacks on main (ABI 315, 2026-08-31).** Admit/encode slices (ABI 218–291), payload orchestration plans (ABI 292–304, [#746](https://github.com/CurateLabs/xyg/pull/746)–[#758](https://github.com/CurateLabs/xyg/pull/758)), scene orchestration plans (ABI 305–309, [#759](https://github.com/CurateLabs/xyg/pull/759)–[#763](https://github.com/CurateLabs/xyg/pull/763)), and payload gather/ship registry kernels (ABI 310–315, [#765](https://github.com/CurateLabs/xyg/pull/765)–[#769](https://github.com/CurateLabs/xyg/pull/769), [#732](https://github.com/CurateLabs/xyg/issues/732) closed) are landed. Do not open more single-field admit slices.

| Lane | PR range | ABI range | Rust owns (summary) |
| --- | --- | ---: | --- |
| Kernel stack | [#640](https://github.com/CurateLabs/xyg/pull/640)–[#642](https://github.com/CurateLabs/xyg/pull/642) | 254–256 | arrow style CSV pack, EncodedColumn meta, Scene constant CSS |
| Scene lane | [#703](https://github.com/CurateLabs/xyg/pull/703)–[#718](https://github.com/CurateLabs/xyg/pull/718) | 257–272 | arrow shapes orchestration; XYTA/XYHF colormap; gradient/marker blob; XYTC field packs |
| Payload stack | [#719](https://github.com/CurateLabs/xyg/pull/719)–[#741](https://github.com/CurateLabs/xyg/pull/741) | 273–291 | errorbar/bar/transition admit; density trace classify/bin/colormap/wire admit |
| Payload orchestration | [#746](https://github.com/CurateLabs/xyg/pull/746)–[#758](https://github.com/CurateLabs/xyg/pull/758) | 292–304 | segment gather; channel/transition attach; per-trace emit skeleton plans; density/build/axis attach orchestration |
| Payload gather/ship | [#765](https://github.com/CurateLabs/xyg/pull/765)–[#769](https://github.com/CurateLabs/xyg/pull/769), [#732](https://github.com/CurateLabs/xyg/issues/732) | 310–315 | column registry / gather policy (`xyg_payload_column_ship_plan`, orientation + bar-compact nested keys ABI 313, explicit replay-only density wasm_source f64 + ordinary density_sample registry ABI 314); density grid buffer registry + attach order (`xyg_payload_density_grid_ship_plan` ABI 315); channel attach-order registry (`xyg_payload_channel_ship_plan`) + `channels.ship_registry_attach` row materialization; channel wire encode policy (`xyg_payload_channel_wire_encode`) — [#732](https://github.com/CurateLabs/xyg/issues/732) **closed** |
| Scene orchestration | [#759](https://github.com/CurateLabs/xyg/pull/759)–[#763](https://github.com/CurateLabs/xyg/pull/763) | 305–309 | XYTC/XYTA/XYFS/XYCF/XYAF/XYEF pack dispatch; polar + encode-product attach ([#733](https://github.com/CurateLabs/xyg/issues/733) **closed**) |

Secondary §302 composition hubs are closed: marks, `_figure`, channels, lod, facets, `_annotations`, `_svg`, and `_raster` are keep-host re-export modules. `marks.py`, `_figure.py`, `channels.py`, and `lod.py` are keep-host re-export hubs over `_marks_*.py`, `_figure_*.py`, `_channels_*.py`, and `_lod_*.py`. Payload emit and Scene pack product paths are marshal-only on `main` after PR #852.

**Post-M2 host-only completion bar (2026-09-02).** Zero `python-scene-migration` and zero `node-scene-migration` tags means hosts are classified as marshal/coerce shells, not that compatibility debt is retired. `audit_python_host_core.py` reports two keep-host policy inventories:

| Host | Keep-host policy files | Role |
| --- | ---: | --- |
| Python | ~80 (~23.6k lines) | static-export emitters (`_export_*`), scene observation marshal (`_scene_marshal.py`, `_scene_observations.py`), payload materialize (`_payload_trace_materialize.py`) |
| Node | ~30 (~23.7k lines) | Koffi ABI wrappers (`encode.js`), figure/scene marshal (`figure.js`, `scene.js`, `payloadTraceMaterialize.js`), mark composition (`marks/*`) |

Practical parity is proven by the executable delegation corpus, cross-host
differential tests (`tests/test_*cross_host*.py`), and ABI smoke—not by
migration tags, source counts, or native-looking call expressions. Follow-up
[#869](https://github.com/CurateLabs/xyg/issues/869) removes the final browser
migration tag: `30_ticks.ts` is presentation-only, shared Rust owns XYTK/XYTO
resolution, and every uncovered ChartView tick slot fails closed. Historical
parent #59 closed the narrower Worker foundation.

The default eight-color categorical palette and first mark color are now one
versioned Rust-engine contract ([#868](https://github.com/CurateLabs/xyg/issues/868),
ABI 360 / WASM ABI 25). Python and Node production paths contain no palette
literal copy; direct XYTS omission consumes the same engine first row and the
WASM worker fails closed on a palette-version or row-count mismatch. Authored palettes stay
host input. `tests/fixtures/default_palette_contract.json` is test/raw evidence,
not a product-policy source, and source guards reject reintroducing host copies.
The executable `default-palette` delegation journey runs the dedicated Python
and Node fixture tests and requires both hosts to trace all four ABI 360 palette
symbols, so `make check-host-parity` fails if either host substitutes fixture
bytes or a host-local copy for the Rust contract.

**#731 close checklist.**

| Gate | Status |
| --- | --- |
| [#732](https://github.com/CurateLabs/xyg/issues/732) gather/ship + density grid ship (ABI 310–315) | **Closed** — kernel owns registry/attach policy |
| [#733](https://github.com/CurateLabs/xyg/issues/733) scene orchestration plans (ABI 305–309) | **Closed** — kernel owns pack dispatch |
| Host materialization retirement (ABI 316–325, big pushes 1–3) | **Closed on main via #852** — `_payload.py` / `_scene_v3.py` marshal-only |
| Node stay-host TAP [#644](https://github.com/CurateLabs/xyg/pull/644)–[#698](https://github.com/CurateLabs/xyg/pull/698) serial merge | **Closed** — merged on main (#630–#698) |
| Cross-host payload + Scene-byte differential proof | **Closed** — payload cross-host + hexbin colormap XYTA scene-byte goldens green |
| Secondary §302 (_svg/_raster, marks, channels labels, lod cache) | **Closed** — composition hubs split to keep-host modules (2026-09-01) |
| [#735](https://github.com/CurateLabs/xyg/pull/735) M2 close contract doc rebase onto main | **Closed** — merged at 8fa63e1f |

**Reclassified keep-host** (Rust already owns the decision; the Python file packs, coerces, or carries error text):

- `_arrowgeom.py` — ABI 217/254/257 marshal-only; compat SVG/raster unpacks kernel geometry
- `_fontmetrics.py` — generated DejaVu advance table mirrored from `crates/xyg-engine/src/font.rs`
- `_columns.py` — shared payload column decode (`column`, `column_ref`, `density_column`) for static export emitters
- `_export_svg_util.py` — shared static-export escape, text metrics, stroke attrs, and annotation text boxes
- `_export_svg_state.py` — shared static-export mutable SVG document state (`_Svg` gradient registry)
- `_export_axis_grid_svg.py` — shared static-export Cartesian/polar grid lines and tick labels
- `_export_axis_grid_raster.py` — shared static-export raster axis grid lines
- `_export_baseline_svg.py` — shared static-export axis frames and tick marks
- `_export_chrome_svg.py` — shared static-export titles, axis labels, legends, and colorbar chrome
- `_export_baseline_raster.py` — shared static-export raster axis frames and tick marks
- `_export_chrome_raster.py` — shared static-export raster tick labels, titles, legends, and colorbar chrome
- `_export_polar_raster.py` — shared static-export polar raster grid and tick labels
- `_export_raster_cmd.py` — shared static-export native display-list command buffer
- `_export_marks_raster.py` — shared static-export raster mark emit
- `_export_legend_raster.py` — shared static-export raster legend and colorbar emit
- `_export_polar_svg.py` — shared static-export polar SVG grid, wedge paths, and tick labels
- `_export_chrome.py` — shared static-export chrome slots, theme tokens, and CSS token resolution
- `_export_colormap.py` — shared static-export colormap stop tables for JS-sync tests
- `_export_annotations.py` — shared static-export annotation placement and axis-title geometry
- `_export_legend.py` — shared static-export legend row expansion and box layout (`legend_items`, `legend_clip_rect`, `_legend_layout`)
- `_export_layout.py` — shared static-export layout, gutter rooms, title bands, polar recut (`layout`, `scene_layout_rooms`, axis room helpers)
- `_export_ticks.py` — shared static-export tick ladders, label layout, and polar tick placement
- `_export_heatmap.py` — shared static-export polar heatmap inverse-raster sampling
- `_layout.py` — shared static-export scale/polar projection (`_Scale`, `_PolarProjection`, `_axis_scales`, `affine_fast_path`, `polar_wedge_points`, `warp_grid_rgba`)
- `_paint.py` — shared static-export paint/geometry layer (fill/stroke bundles, scatter/ribbon/rect helpers, grid RGBA decode, density alpha + linear-gradient helpers, box corner radius, ABI 121/210/211/212 curve/hexbin/step/marker/rounded-rect helpers, `polar_clip_line_segments`, CSS→RGBA8); ABI 206 `effective_rgba` marshal; `triangle_mesh_boundary` recorded stay-host joined-fill walk
- `_sankey.py` — name resolution and diagnostic wording over `xyg_sankey_layout`
- `_marks_distribution.py` — box/violin marks and shared multi-group helpers (Node `marks/distribution.js` parity)
- `_marks_style.py` — cross-cutting style coercion, symbol codes, segment trace assembly
- `_marks_bar.py` — bar/column rect marks and multi-series style helpers (Node `marks/bar.js` parity)
- `_marks_contour.py` — contour isolines and filled bands (Node `marks/contour.js` parity)
- `_marks_scatter.py` — scatter mark with density fallback (Node `marks/scatter.js` parity)
- `_marks_errorbar.py` — errorbar/error_band marks and cap geometry (Node `marks/errorbar.js` parity)
- `_marks_hexbin.py` — hexbin density mark (Node `marks/hexbin.js` parity)
- `_marks_heatmap.py` — heatmap grid mark (Node `marks/heatmap.js` parity)
- `_marks_line.py` — line and area marks (Node `marks/line.js` / `marks/area.js` parity)
- `_marks_histogram.py` — histogram/hist rect marks (Node `marks/histogram.js` parity)
- `_marks_ribbon.py` — ribbon flow-band mark (Node `marks/ribbon.js` parity)
- `_marks_segments.py` — segments line mark (Node `marks/segments.js` parity)
- `_marks_step.py` — step/stairs/ecdf/stem marks (Node `marks/step.js` / `ecdf.js` / `stem.js` parity)
- `_marks_graph.py` — graph mark (Node `graph.js` parity)
- `_marks_sankey.py` — sankey mark (Node `sankey.js` parity)
- `_marks_triangle_mesh.py` — triangle mesh mark (Node `marks/triangle_mesh.js` parity)
- `_figure.py` — Figure composition hub binding `_figure_*.py` modules and mark methods
- `_figure_ingest.py` — column ingest, array coercion, category-axis positions, heatmap cell edges
- `_figure_traces.py` — rectangle trace assembly and finite-row selection
- `_figure_autorange.py` — XYAR autorange packing and Rust figure_autorange dispatch
- `_figure_axis.py` — axis configuration, scale/kind resolution, and payload axis spec assembly
- `_figure_interaction.py` — interaction configuration, polar validation, interaction/mark-style payload specs
- `_figure_palette.py` — categorical palette cycle and series color selection
- `_figure_dom.py` — DOM class inventory and payload dom spec assembly
- `_figure_runtime.py` — runtime interaction delegates (widget comm path)
- `_figure_view_state.py` — durable view-state cache and state_patch wire messages
- `_figure_export.py` — display and static export entry points
- `channels.py` — scatter channel composition hub binding `_channels_*` modules
- `_channels_types.py` — ColorChannel/SizeChannel/StyleChannel dataclasses
- `_channels_colormap.py` — built-in colormap names and custom ramp resolution
- `_channels_labels.py` — categorical label factorization and native probe routing
- `_channels_lut.py` — palette/colormap LUT packing and bin color resolve
- `_channels_resolve.py` — color/size/style channel resolution
- `_channels_ship.py` — wire encode and payload ship registry
- `lod.py` — LOD composition hub binding `_lod_*` modules
- `_lod_types.py` — LodPlan/EncodedColumn dataclasses and sampling constants
- `_lod_viewport.py` — viewport validation, visible mask, aligned window
- `_lod_params.py` — shared LOD argument coercion helpers
- `_lod_plan.py` — tier planning, grid shape, local log density
- `_lod_sample.py` — deterministic sampling tiers for LOD overlays
- `_lod_drill.py` — drill-down subset bookkeeping on traces
- `_lod_encode.py` — offset-encoded geometry columns and wire buffer packing
- `_textblock.py` — ABI 125 packer plus a pass-scoped measurement cache
- `_scene.py` — ABI 121 tessellation wrappers; `grid_rgba` uses ABI 129/206
- `_graph.py` — ingest / id maps; layout is `xyg_graph_layout`
- `_framing.py` — XYBF transport, not chart policy
- `_legendfit.py` — already keep-host (ABI 120 occupancy; ABI 197 Scene `loc="best"`)
- `_paint.triangle_mesh_boundary` — recorded stay-host joined-fill walk
- `_trace_paint_rgba` — host channel dispatch onto ABI 206 `effective_rgba`

**#731 close bar** (orchestration + materialization retirement + cross-host proof) is met. Secondary §302 composition hubs are closed — static export compat paths delegate to `_export_*` emitters and Rust tessellation kernels.
4. ChartView `51_annotations.ts` still copies arrow math until WASM; ABI 254 owns host `start_offset`/`label_clear` CSV pack.

ABI 209 `xyg_polar_wedge_points` owns compatibility annular-sector flatten (optional `steps`, `0` = `polar_bar_segments`; finite `norm_lo`/`norm_hi` skip radial-range normalization). `_polar_wedge_path` still emits SVG `A` arcs for unrounded wedges. ABI 210 `xyg_hexbin_ring` owns pointy-top hexagon vertex offsets scaled by cell pitch. ChartView `_buildHexbinMark` keeps the same fractions until WASM. ABI 211 `xyg_step_arrays` owns compatibility step/stairs expand (`mode` 1/2/3 = pre/mid/post; `n < 2` identity). ChartView `_stepArrays` keeps the same vertices until WASM. ABI 212 `xyg_marker_path_scale` owns authored-marker pixel vertices (`out_x = cx + scale * unit_x`, `out_y = cy - scale * unit_y`). ChartView legend/annotation scale keeps the same formula until WASM. SVG `d=` assembly stays host. ABI 213 `xyg_css_is_functional` / `xyg_continuous_domain` / `xyg_direct_rgba_admit` owns the `resolve_color` CSS/numeric split, equal-bound domain pad, and Nx3/Nx4 admit so Python `channels.resolve_color` and Node `resolveColorChannel` cannot drift. Named colors stay categories. Hosts still factorize labels, pin palettes, and emit warning text. ABI 214 `xyg_payload_segment_budget` owns the stem/errorbar count budget (`max(1024, floor(px_width)*4)`). ABI 215 `xyg_payload_errorbar_indices` owns even-index expansion across concatenated role groups. Hosts still expand transition-key role maps, gather extra columns, and ship rows. ABI 216 `xyg_scale_pins_offset` owns log-family `pin_zero` admission (`log`/`symlog`, case-sensitive). Hosts still pack `EncodedColumn` metadata. ABI 217 `xyg_arrow_geometry` / `xyg_arrow_shaft_points` / `xyg_arrow_end_decoration` / `xyg_arrow_taper_polygon` / `xyg_arrow_trim_polyline_end` owns annotation-arrow connectionstyle geometry. ChartView `51_annotations.ts` keeps the same formula until WASM. ABI 254 `xyg_arrow_style_pack` owns `start_offset`/`label_clear` CSV pack. ChartView still parses those strings until WASM. Hosts still coerce style keys and elbow truthiness. ABI 255 `xyg_encoded_column_meta` owns EncodedColumn offset/scale/kind-presence packing. ABI 218 `xyg_scene_dash_admit` owns Scene dash presets and 2–8 finite length patterns. Invalid comma tokens reject the whole string. ABI 219 `xyg_scene_linecap_admit` owns Scene linecap names; unknown and whitespace-only reject. ABI 220 `xyg_density_overlay_opacity` owns density overlay sample opacity (non-finite → 0.55). ABI 221 `xyg_scene_marker_path_admit` owns Scene marker-path contour bounds. ABI 222 `xyg_scene_annotation_style_admit` owns Scene annotation style-key allowlists. ABI 223 `xyg_scene_ribbon_color2_classify` owns ribbon two-ended paint class. ABI 224 `xyg_scene_tick_label_strategy` owns Scene tick-label strategy names (hyphens become underscores; unknown/empty map to auto). Hosts still pick `tick_label_strategy` vs `collision` vs camelCase keys. ABI 225 `xyg_scene_tick_anchor` owns Scene tick-label anchor names (`middle` aliases `center`; unknown/empty reject). Hosts still pick `tick_label_anchor` vs camelCase keys. ABI 123 layout enums stay a separate throw-on-unknown table. ABI 226 `xyg_scene_fill_gradient_admit` owns Scene fill-gradient stop admit (`var(` reject; empty/`currentcolor` → mark color). ABI 227 `xyg_scene_parse_linear_gradient` owns CSS `linear-gradient(...)` parse. ABI 228 `xyg_scene_rect_extra_flags` owns Scene rect extra-flag pack. ABI 229 `xyg_scene_gradient_dir` owns Scene fill-gradient direction codes. ABI 230 `xyg_scene_linear_gradient_prefix` owns the CSS `linear-gradient(` prefix check. ABI 231 `xyg_scene_gradient_space` owns Scene fill-gradient space codes. ABI 232 `xyg_scene_hexbin_reduce_admit` owns Scene hexbin reduce names. ABI 233 `xyg_scene_curve_classify` owns Scene curve names (trim then lowercase; smooth-kind eligibility uses ABI 236 LINE|BAND). ABI 234 `xyg_scene_marker_glyph_admit` owns Scene marker-glyph UTF-8 admit. ABI 235 `xyg_scene_kind_admit` owns Scene product-kind names. ABI 236 `xyg_scene_kind_class` owns Scene packing-family bits. Smooth-kind
eligibility uses the existing LINE|BAND bits (no new ABI). ABI 237 `xyg_scene_hexbin_pitch_admit` owns Scene hexbin cell-pitch admit. ABI 238 `xyg_scene_heatmap_extent_admit` owns Scene heatmap cell-extent admit. ABI 239 `xyg_scene_heatmap_colormap_admit` owns Scene heatmap colormap eligibility. ABI 240 `xyg_scene_heatmap_shape_admit` owns Scene heatmap lattice-shape admit. XYTA integer coerce uses the same kernel. ABI 241 `xyg_scene_scatter_paint_channel_admit` owns Scene scatter paint-plane channel names. ABI 242 `xyg_scene_hexbin_colormap_plane_admit` owns Scene hexbin colormap-plane packing. ABI 243 `xyg_scene_hexbin_rgba_plane_admit` owns Scene hexbin RGBA-plane modes. ABI 244 `xyg_scene_mesh_paint_plane_admit` owns Scene mesh paint-plane packing. ABI 245 `xyg_scene_item_apply_opacity` owns Scene per-item RGBA8 artist-alpha/opacity. ABI 246 `xyg_scene_item_widths_admit` owns Scene per-item stroke-width admit. Field picking and f64 packing stay host. ABI 247 `xyg_scene_item_fill_t` owns Scene continuous per-item fill unit-t. Field picking and colormap lookup stay host. ABI 248 `xyg_scene_finite_all` owns Scene finite-all admit (empty → 1). Field picking stays host. ABI 249 `xyg_scene_gradient_solid_css` owns Scene gradient-solid CSS. Field picking stays host. ABI 250 `xyg_scene_arrays_equal` owns Scene f64 arrays-equal (empty equal; NaN never equals). Field picking and null checks stay host. ABI 251 `xyg_clip_quantize_u8` owns unit-f64 clip-quantize u8 (NaN → 0). Field picking stays host. ABI 252 `xyg_scene_constant_color_admit` owns Scene constant-color admit (`0` fail, `1` style fallback, `2` channel constant). Ribbon-fail and field picking stay host. ABI 253 `xyg_scene_hidden_or_per_item_admit` owns Scene hidden-or-per-item admit (`hidden || (has_per_item && !density_aggregates)`). Field picking stays host. Python `colormap_lut_rgba8` and Node `colormapLutRgba8` sample 256 unit-t texels through ABI 206 `xyg_colormap_lut` then host-pack alpha 255. Python `quantize_unit_u8` / `_quantized_lut_idx` normalize then ABI 251 `xyg_clip_quantize_u8`. Node `quantizeUnitU8` / `resolveDensityBinColors` use the same composition (nonfinite → 0; equal/non-finite domain is a host zero-span short-circuit). Python `palette_rows_rgba8` quantizes css_check 0-1 channels through ABI 251 `xyg_clip_quantize_u8`. Browser-only status stays host. Python `_svg._paint_rgba8` uses `xyg_css_color_rgba` (same as `_raster._parse_color` and Node `cssColorRgba8`). Python `resolved_hex_paint` / `_resolved_rgb` quantize css_check 0-1 channels through ABI 251 `xyg_clip_quantize_u8`. Browser-only rejection stays host. Python `resolve_style_channel` admits finite arrays through ABI 248 `xyg_scene_finite_all`. Bounds checks stay host. SVG `_rgb_css` formats 0-1 RGB through ABI 251 `xyg_clip_quantize_u8`. SVG authored-scatter marker RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster scatter RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster mesh/hexbin fill RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster rectangle style RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster segment stroke RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster mesh stroke RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster ribbon fill RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Raster ribbon match-fill edge RGBA8 uses ABI 251 `xyg_clip_quantize_u8`. Node `meshHasPerItem` uses `perItemChannelNames` (same as Python `has_per_item_channels`) for ABI 244. Node `scatterPaintChannelNames` uses `perItemChannelNames` (same as Python `per_item_channel_names`) for ABI 241. Node hexbin colormap-plane packing uses `channel.values` (same as Python); `trace.metric` is not a values fallback. Node empty kind uses `|| "mark"` (same as Python `or "mark"`). Node `figureTraceSupport` does not fail-close `style.smooth`; curve names stay ABI 233. Node `itemWidths` fail-closes a present `stroke_width` channel without values (same as Python). Node `itemApplyOpacity` fail-closes a present opacity/artist_alpha channel without values (same as Python). Node missing scatter kind uses `|| ""` (same as Python); it is not defaulted to `"scatter"`. Node `fillIsGradientAuthoring` rejects arrays (same as Python dict-only). Node `rectExtraFlags` treats only mapping fills as gradient-fail (same as Python dict-only). Node `admittedMarkerGlyph` rejects non-strings (same as Python `isinstance(..., str)`). Node `packXyTaColormap` uses `style.colormap` only (same as Python); `trace.colormap` / `colormapStops` are not fallbacks. Node hexbin XYTA colormap uses `channel.colormap` only (same as Python); `style.colormap` is not a fallback. Node XYHF heatmap/density colormap uses `style.colormap` only (same as Python); `trace.colormap` / `colormapStops` are not fallbacks. Node `constantMarkColor` uses `color_ch.constant` only (same as Python); string channels, `channel.color`, and `trace.color` are not fallbacks. Node `channelConstantCss` uses `channel.constant` only (same as Python); string channels and `channel.color` are not fallbacks. Node `channelEndRgba8` constant paint uses `channel.constant` only (same as Python); string channels and `channel.color` are not fallbacks. Node `sourceColorCss` uses `color_ch` only (same as Python); `trace.color` is not a source-channel fallback. Node `resolveColorChannel` constant CSS uses `.constant` (same as Python `ColorChannel`); `composeRibbon` writes `color_ch` / `color2_ch`. Node `color2Channel` uses `color2_ch` only (same as Python); `color_target` / `colorTarget` are not Scene-pack fallbacks. Node `itemFillRgba8` uses `color_ch` only (same as Python); `trace.color` is not a fill-channel fallback. Node `scatterPaintChannelNames` uses `color_ch` only (same as Python); `trace.color` is not a per-item color channel. Node `scatterHasNonConstantColor` uses `color_ch` only (same as Python); `trace.color` is not a non-constant-color fallback. Node `resolveDensityBinColors` uses `color_ch` only (same as Python); `trace.color` is not a density-bin color channel. Node `scatterHasNonConstantColor` ignores `style.color_channel` (same as Python); only `color_ch` is a non-constant-color channel. Node `scatterPaintChannelNames` ignores `style.color_channel` / `stroke_channel` / `size_channel` (same as Python); per-item extras come from `style_channels`. Node `resolveDensityBinColors` ignores `style.color_channel` (same as Python); only `color_ch` is a density-bin color channel. Node XYMS mark color uses `style.color` only (same as Python `_constant_color` style fallback); `trace.color` is not a mark-color fallback. Node XYTC style color uses `style.color` only (same as Python); `trace.color` is not a packed-color fallback. Node XYTC constant paint uses `channel.constant` only (same as Python); `channel.color` is not a packed-constant fallback. Node density-blit observation uses `scatterUsesDensity` (same as Python `use_density`); `style.color_channel` is not a per-item density extra. Node XYTC color_ch packing ignores string channels (same as Python object-only); only a channel object packs COLOR_CH. Node `scatterHasNonConstantColor` uses `channel.constant` only (same as Python); `channel.color` is not a packed-constant stand-in. Node XYTC `COLOR_CH_CONSTANT` packs whenever `channel.constant` is set (same as Python); `mode === "constant"` is not a gate. Node XYMS mark color uses `constantMarkColor` / ABI 252 (same as Python `_constant_color`); `style.color` is the code-1 fallback only. Node `scatterPerItemChannels` ignores `style.color_channel` / `size_channel` / `stroke_channel` (same as Python `has_per_item_channels`); only `*_ch` presence counts. Node `scatterPerItemChannels` is mode-based like Python `has_per_item_channels`; a constant `color_ch` is not per-item. Node `channelEndRgba8` ignores array and typed-array channels (same as Python object-only); only `null` and mode objects pack. Node `channelEndRgba8` categorical paint uses `DEFAULT_PALETTE` when palette is empty (same as Python); fallback CSS is not a missing-slot stand-in. Node `packXyTaColormap` stop bytes require RGB rows like Python `_colormap_stop_bytes`; a flat or RGBA list packs empty stops. Node `xyHfColormap` stop bytes require RGB rows like Python `_colormap_stop_bytes`; a flat or RGBA list packs empty stops. Node `packXyTaRgbaGrid` stacks flattened planes like Python `_pack_xyta` `rgba_grid`; nested 2D index fallback is not a plane layout. Node heatmap `trace.rgba` stores a flat uint8 buffer; `packXyTaRgba` packs that buffer like Python `_pack_xyta` and does not unwrap nested `.rgba`. Node heatmap and density Scene packing is XYTA-only like Python `_pack_xyta`; unused XYHF paint-plane helpers are not a second plane layout. Node `packXyTaGrid` flattens heatmap `grid` like Python `_pack_xyta` (`plane.values` or plane); nested length indexing is not a grid layout. Node `rectFiniteSel` drops nonfinite rectangle rows through `validIndicesF64` like Python `_rect_finite_sel`; NaN never reaches vertex buffers (§19). Node `packXyTa` density fill opacity uses `style.fill_opacity` only like Python `_pack_xyta`; `fillOpacity` is not a fill-opacity key. Node XYTC fill opacity uses `style.fill_opacity` only like Python `_pack_xytc`; `fillOpacity` is not a fill-opacity key. Node XYTC stroke opacity uses `style.stroke_opacity` only like Python `_pack_xytc`; `strokeOpacity` is not a stroke-opacity key. Node XYTC line opacity uses `style.line_opacity` only like Python `_pack_xytc`; `lineOpacity` is not a line-opacity key. Node XYTC stroke width uses `style.stroke_width` only like Python `_pack_xytc`; `strokeWidth` is not a stroke-width key. Node XYTC line width uses `style.line_width` only like Python `_pack_xytc`; `lineWidth` is not a line-width key. Node XYTC size uses `style.size` only like Python `_pack_xytc`; `diameter` is not a size key. Node XYTC line color uses `style.line_color` only like Python `_pack_xytc`; `lineColor` is not a line-color key. Node XYTC joined fill uses `style.joined_fill` only like Python `_pack_xytc`; `joinedFill` is not a joined-fill key. Node XYTC stroke perimeter uses `style.stroke_perimeter` only like Python `_pack_xytc`; `strokePerimeter` is not a stroke-perimeter key. Node XYTC COLOR_CH packing uses `color_ch` only like Python `_pack_xytc`; `colorChannel` is not a packed-channel fallback. Node XYTC size_ch packing uses `size_ch` only like Python `_pack_xytc`; `sizeChannel` is not a packed-channel fallback. Node XYEF stroke-width-only observation uses `style.stroke_width` only like Python; `strokeWidth` is not an observation key. Node `meshJoinedFill` uses `style.joined_fill` only like Python `_mesh_joined_fill`; `joinedFill` is not a joined-fill key. Node XYEF joined-fill observation uses `style.joined_fill` only like Python; `joinedFill` is not an observation key. Node `constantMarkColor` uses `color_ch` only like Python `_constant_color`; `colorChannel` is not a source-channel fallback. Node `sourceColorCss` uses `color_ch` only like Python `_trace_source_color_css`; `colorChannel` is not a source-css fallback. Node `scatterHasNonConstantColor` uses `color_ch` only like Python; `colorChannel` is not a non-constant-color fallback. Node `classifyRibbonColor2` source-constant CSS uses `color_ch` only like Python `_classify_ribbon_color2`; `colorChannel` is not a source-constant fallback. Node `itemFillRgba8` uses `color_ch` only like Python `_item_fill_rgba8`; `colorChannel` is not a fill-channel fallback. Node `resolveDensityBinColors` uses `color_ch` only like Python; `colorChannel` is not a density-bin color channel. Node `hexbinPacksColormapPlane` uses `color_ch` only like Python `_hexbin_packs_colormap_plane`; `colorChannel` is not a colormap-plane fallback. Node `ribbonEndRgbaPair` uses `color_ch` only like Python `_ribbon_end_rgba_pair`; `colorChannel` is not a ribbon-end source fallback. Node `hexbinXyTaColormap` uses `color_ch` only like Python `_pack_xyta` hexbin colormap; `colorChannel` is not a colormap fallback. Node `hexbinPacksRgbaPlane` uses `color_ch` only like Python `_hexbin_packs_rgba_plane`; `colorChannel` is not an RGBA-plane fallback. Node `hexbinCellRgba8` uses `color_ch` only like Python `_hexbin_cell_rgba8`; `colorChannel` is not a cell-paint fallback. Node XYTA density color_ch packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a packed-constant fallback. Node `itemStrokeRgba8` uses `stroke_ch` only like Python `_item_stroke_rgba8`; `strokeChannel` is not a stroke-channel fallback. Node `scatterPointStrokeRgba8` uses `stroke_ch` only like Python `_scatter_point_stroke_rgba8`; `strokeChannel` is not a match-fill opacity skip. Node `perItemChannelNames` uses `color_ch` / `stroke_ch` / `size_ch` / `style_channels` only like Python `per_item_channel_names`; camelCase channel fields are not per-item name fallbacks. Node `itemApplyOpacity` uses `style_channels` only like Python `_item_apply_opacity`; `styleChannels` is not an opacity-channel fallback. Node `itemWidths` uses `style_channels` only like Python `_item_widths`; `styleChannels` is not a width-channel fallback. Node `scatterUsesDensity` uses `force_density` only like Python `use_density`; `forceDensity` is not a density-force fallback. Node `figureTraceSupport` uses `style.linecap` only like Python `_figure_trace_support_flags`; `lineCap` is not a dashed-marker linecap fallback. Node `packXyTcLinecap` uses `style.linecap` only like Python `_pack_xytc`; `lineCap` is not a packed-linecap fallback. Node `packXyAfLinecap` uses `style.linecap` only like Python `_pack_xyaf`; `lineCap` is not an annotation-linecap fallback. Node `scatterUsesDensity` does not pass `force_direct` like Python `use_density`; `forceDirect` / `force_direct` are not density-direct overrides. Node hexbin XYTA values packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a hexbin-grid values fallback. Node `legendStyleFontSizes` uses `style.font_size` / `style.title_font_size` only like Python `_legend_input`; `fontSize` / `titleFontSize` are not legend-font fallbacks. Node `heatmapGridShape` uses `grid_shape` only like Python `_heatmap_shape`; `gridShape` is not a heatmap-lattice fallback. Node `hexbinStylePitch` uses `style.hex_dx` then `style.dx` like Python `_hexbin_pitch`; `hexDx` / `hexDy` are not hexbin-pitch fallbacks. Node `polarGridShape` uses axis `grid_shape` only like Python `_pack_polar_scene_input`; `gridShape` is not a polar-grid fallback. Node `polarAxisThetaUnit` uses axis `theta_unit` only like Python `_pack_polar_scene_input`; `thetaUnit` is not a polar-unit fallback. Node `polarAxisThetaZero` uses axis `theta_zero` only like Python `_pack_polar_scene_input`; `thetaZero` is not a polar-zero fallback. Node `polarAxisThetaDirection` uses axis `theta_direction` only like Python `_pack_polar_scene_input`; `thetaDirection` is not a polar-direction fallback. Node `polarAxisROrigin` uses axis `r_origin` only like Python `_pack_polar_scene_input`; `rOrigin` is not a polar-origin fallback. Node `axisTickValues` uses axis `tick_values` only like Python `_pack_figure_chrome`; `tickValues` is not a chrome-major-tick fallback. Node `axisMinorTickValues` uses axis `minor_tick_values` only like Python `_pack_figure_chrome`; `minorTickValues` is not a chrome-minor-tick fallback. Node `axisTickLabels` uses axis `tick_labels` only like Python `_pack_figure_chrome`; `tickLabels` is not a chrome-tick-label fallback. Node `figureXLabel` uses `x_label` then axis `label` like Python `_pack_figure_chrome`; `xLabel` is not a chrome-xlabel fallback. Node `figureYLabel` uses `y_label` then axis `label` like Python `_pack_figure_chrome`; `yLabel` is not a chrome-ylabel fallback. Node `plotTopAxisRoom` uses plot `top_axis_room` only like Python `recut_polar_plot`; `topAxisRoom` is not a polar-recut-room fallback. Node `axisTickLabelAnchor` uses axis `tick_label_anchor` only like Python `_scene_tick_anchor_code`; `tickLabelAnchor` is not a chrome-tick-anchor fallback. Node `axisTickLabelMinGap` uses axis `tick_label_min_gap` only like Python `_pack_tick_collision`; `tickLabelMinGap` is not a chrome-tick-gap fallback. Node `axisTickLabelAngle` uses axis `tick_label_angle` only like Python `_pack_tick_collision`; `tickLabelAngle` is not a chrome-tick-angle fallback. Node `axisTickLabelStrategy` uses `tick_label_strategy` then `collision` like Python `_scene_tick_label_strategy`; `tickLabelStrategy` is not a chrome-tick-strategy fallback. Node `polarCollisionKeys` uses snake-case keys only like Python `_POLAR_COLLISION_KEYS`; camelCase tick-label keys are not polar-collision-key extras. Node `figureChromeStyles` uses `chrome_styles` only like Python `_pack_figure_support`; `chromeStyles` is not a chrome-styles fallback. Node `chromeStyleHasFontFamily` uses `font-family` only like Python `_pack_figure_support`; `fontFamily` is not a chrome-font-family fallback. Node `figureClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not a figure-class-name fallback. Node `figureClassNames` uses `class_names` only like Python `_pack_figure_support`; `classNames` is not a figure-class-names fallback. Node `annotationClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not an annotation-class-name fallback. Node `figureExtraLegends` uses `extra_legends` only like Python `_pack_figure_support`; `extraLegends` is not an extra-legends fallback. Node `figureTitleOptions` uses `title_options` only like Python `_pack_public_export_support`; `titleOptions` is not a title-options fallback. Node `figureLegendOptions` uses `legend_options` only like Python `_legend_input`; `legend` is not a legend-options fallback. Node `figureColorbarOptions` uses `colorbar_options` only like Python `_colorbar_input`; `colorbarOptions` is not a colorbar-options fallback. Node `figureShowLegend` uses `show_legend` only like Python `_legend_input`; `showLegend` is not a show-legend fallback. Node `figureAxisOptions` uses `axis_options` only like Python `_pack_figure_chrome`; `xAxis` / `x_axis` are not axis-options fallbacks. Node `axisScaleName` uses axis `type` only like Python `_axis_scale`; `kind` is not an axis-scale fallback. Node `figureAutorangeAxisOptions` uses `axis_options` only like Python `_axis_scale`; `xAxis` is not an autorange-axis fallback. Node `_emitScatter` uses `force_density` only like Python `payload_force_density`; `style.force_density` is not a payload-density fallback. Node `_emitScatter` does not read `style.force_direct` like Python `_emit_scatter`; `style.force_direct` is not a payload-direct fallback. Node `_emitScatter` does not read `style.force_pyramid` like Python `_emit_scatter`; `style.force_pyramid` is not a payload-pyramid fallback. Node `chromeAxisMinorStyle` uses `minor_style` only like Python `_pack_chrome_axis`; `minorStyle` is not a chrome-minor-style fallback. Node `chromeAxisTickSides` uses `tick_sides` only like Python `_pack_chrome_axis`; `tickSides` is not a chrome-tick-sides fallback. Node `chromeAxisTickLabelSides` uses `tick_label_sides` only like Python `_pack_chrome_axis`; `tickLabelSides` is not a chrome-tick-label-sides fallback. Node `chromeAxisStyleKeys` admits snake-case keys only like Python `_SCENE_AXIS_STYLE_KEYS`; camelCase axis style keys are not a chrome-axis-style-keys fallback. Node `chromeAxisStyleHas` / `chromeAxisStyleValue` read snake-case keys only like Python `_pack_chrome_axis`; camelCase fields are not a chrome-axis-style-read fallback. Node `legendAxisScale` uses axis `type` only like Python `_axis_scale`; `scale` / `kind` are not a legend-axis-scale fallback. Node `figureAutorangeAxisScale` uses axis `type` only like Python `_axis_scale`; `kind` is not an autorange-axis-scale fallback. Node `figureAxisKind` matches Python `_axis_kind` (forced `type` time, then category labels, then `time_ms` columns); axis `kind` is not an autorange-axis-kind fallback. Node `chromeAxisTickKind` uses `Figure._axisKind` like Python `_pack_figure_chrome` / `_pack_tick_collision`; axis `kind` is not a chrome-tick-kind fallback. Node `xyEfResolvedKind` uses `Figure._axisKind` like Python `_pack_public_export_support`; axis `kind` is not an xyef-axis-kind fallback. Node `figureAutorangeThetaUnit` uses axis `theta_unit` only like Python `_pack_autorange`; `thetaUnit` is not an autorange-theta-unit fallback. Node `figureAxisIsLog` uses axis `type` only like Python `_axis_scale` log; `scale` is not an axis-is-log fallback. Node `figureAutorangeCategories` uses `_axis_categories` only like Python `_pack_autorange`; `options.categories` is not an autorange-categories fallback. Node `figureAutorangeDomain` uses axis `domain` only like Python `_pack_autorange`; `_axisRange` is not an autorange-domain fallback. Node `setPolarMeta` writes axis `theta_unit` like Python `set_axis`; `_polarMeta.thetaUnit` is not a polar-meta-unit fallback. Node `setPolarMeta` writes axis `theta_zero` like Python `set_axis`; `_polarMeta.thetaZero` is not a polar-meta-zero fallback. Node `setPolarMeta` writes axis `theta_direction` like Python `set_axis`; `_polarMeta.thetaDirection` is not a polar-meta-direction fallback. Node `setPolarMeta` writes axis `grid_shape` like Python `set_axis`; `_polarMeta.gridShape` is not a polar-meta-grid fallback. Node `setPolarMeta` writes axis `hole` like Python `set_axis`; `_polarMeta.hole` is not a polar-meta-hole fallback. Node `setPolarMeta` writes axis `sector` like Python `set_axis`; `_polarMeta.sector` is not a polar-meta-sector fallback. Node `polarAxisHole` uses axis `hole` only like Python `_pack_polar_scene_input`; `Hole` is not a polar-hole fallback. Node `polarAxisSector` uses axis `sector` only like Python `_pack_polar_scene_input`; `Sector` is not a polar-sector fallback. Node `_polarAxisSpecs` uses axis `theta_unit` like Python `_axis_spec`; `_polarMeta.thetaUnit` is not a polar-spec-unit fallback. Node `_polarAxisSpecs` uses axis `theta_zero` like Python `_axis_spec`; `_polarMeta.thetaZero` is not a polar-spec-zero fallback. Node `_polarAxisSpecs` uses axis `theta_direction` like Python `_axis_spec`; `_polarMeta.thetaDirection` is not a polar-spec-direction fallback. Node `_polarAxisSpecs` uses axis `grid_shape` like Python `_axis_spec`; `_polarMeta.gridShape` is not a polar-spec-grid fallback. Node `_polarAxisSpecs` uses axis `sector` like Python `_axis_spec`; `_polarMeta.sector` is not a polar-spec-sector fallback. Node `_polarAxisSpecs` uses axis `hole` like Python `_axis_spec`; `_polarMeta.hole` is not a polar-spec-hole fallback. Node `_polarAxisSpecs` uses axis `r_origin` like Python `_axis_spec`; `_polarMeta.rOrigin` is not a polar-spec-origin fallback. Node `_axisSpec` uses axis `nonpositive` on log axes like Python `_axis_spec`. Node `_axisSpec` uses axis `constant` on symlog axes like Python `_axis_spec`. Node `_axisSpec` uses `_axis_categories` on category axes like Python `_axis_spec`. Node `packPolarSceneInput` uses figure `_range("y")` like Python `_pack_polar_scene_input`; `rAxis.range` is not a polar-range fallback. Node `_emitTriangleMesh` ships x2/y2 via `payloadColumnShipPlan` / `shipRegistryColumns` like Python `_emit_triangle_mesh`. Node `buildPayload` ships `show_legend` like Python `build_payload` via ABI 303 `attach_show_legend`. Node `buildPayload` ships `legend` from `legend_options` like Python `build_payload` via ABI 303 `attach_legend`; `loc="best"` resolves via `resolveLegendBestLoc` like Python `_legendfit.resolve_for_figure`. Node `buildPayload` ships `colorbar` like Python `build_payload` via ABI 303 `attach_colorbar`. Node `buildPayload` ships `extra_legends` like Python `build_payload` via ABI 303 `attach_extra_legends`. Node `buildPayload` ships `annotations` like Python `build_payload` via ABI 303 `attach_annotations`; validated via `annotationSpecs` like Python `_annotation_specs`. Node `buildPayload` ships `title_options` like Python `build_payload` via ABI 303 `attach_title_options`; y/pad geometry packs via `shipScalar` like Python `ship_scalar`. Node `buildPayload` ships `padding` like Python `build_payload` via ABI 303 `attach_padding`. Node `buildPayload` ships `dom` via `domSpec` like Python `_dom_spec` via ABI 303 `attach_dom`; `domSpec` maps `chrome_styles` to `dom.styles` via `styleMapping`. Node `packXyTaDensityColorCh` uses trace `color_ch.constant` like Python `_pack_xyta`. Node `composeScatter` resolves `color_ch`, `size_ch`, `stroke_ch`, and `style.symbol` like Python `marks.scatter`. Hosts still coerce fill mappings, wrap authoring error text, radius lists, and `wedge_gap`. Post-M2 follow-ups (ChartView WASM parity, direct-browser aggregate production) stay outside the #731/#58 close bar.
## Disposition summary

| Policy | Files | Disposition | Destination |
| --- | ---: | --- | --- |
| `rust-engine` | generated inventory | `keep-rust` | current owner |
| `rust-c-abi` | 1 | `keep-rust` | current owner |
| `rust-wasm-abi` | 1 | `implement-rust-wasm` | [#59](https://github.com/CurateLabs/xyg/issues/59) |
| `python-host` | 168 | `keep-host` | current owner |
| `python-scene-migration` | 0 | — | [#58](https://github.com/CurateLabs/xyg/issues/58) closed for §302 |
| `python-abi-generated` | 1 | `generate` | [#57](https://github.com/CurateLabs/xyg/issues/57) |
| `node-host` | 42 | `keep-host` | current owner |
| `node-scene-migration` | 0 | — | [#58](https://github.com/CurateLabs/xyg/issues/58) closed for §302 Node marshal parity |
| `node-abi-generated` | 1 | `generate` | [#57](https://github.com/CurateLabs/xyg/issues/57) |
| `browser-client` | generated inventory | `keep-shared-client` | current owner |
| `browser-tick-presentation` | 1 | `keep-shared-client` | current owner |
| `browser-wasm-migration` | 1 | `replace-with-rust-wasm` | [#59](https://github.com/CurateLabs/xyg/issues/59) |
| `browser-wasm-adapter` | 2 | `implement-rust-wasm` | [#59](https://github.com/CurateLabs/xyg/issues/59) |
| `browser-wasm-generated` | 1 | `generate` | [#59](https://github.com/CurateLabs/xyg/issues/59) |

## Boundary policies

### `rust-engine`

Owner: Rust safe engine. Disposition: `keep-rust`.

Allowed:

- Row scans, geometry, aggregation, layout, LOD, encoding, and deterministic product policy.
- Canonical scene and static-export construction shared by every host.

Forbidden:

- Python, Node, browser DOM, or transport-specific API behavior.
- Host-specific error wording or package discovery.

### `rust-c-abi`

Owner: Rust C ABI shell. Disposition: `keep-rust`.

Allowed:

- C-compatible marshaling, panic containment, ABI versioning, and opaque-handle lifecycle.

Forbidden:

- A second implementation of algorithms or deterministic product policy that belongs in xyg-engine.
- Python- or Node-specific extension-module APIs.

### `rust-wasm-abi`

Owner: Rust WASM lifecycle adapter. Disposition: `implement-rust-wasm` under
[#59](https://github.com/CurateLabs/xyg/issues/59).

Allowed:

- Raw WebAssembly exports, bounded staging memory, instance handles, stable
  status codes, lifecycle diagnostics, and thin calls into `xyg-engine`.

Forbidden:

- A second implementation of engine policy, browser DOM/WebGL behavior,
  package asset discovery, or host-specific chart APIs.

### `python-host`

Owner: Python host. Disposition: `keep-host`.

Allowed:

- Composition and pyplot APIs, application transport, ingest coercion, validation messages, transport, and notebook lifecycle.

Forbidden:

- A parallel implementation of canonical layout, LOD, encoding, aggregation, scene, or export policy.
- Hand-maintained low-level C signatures.

### `python-scene-migration`

Owner: Python host with canonical-policy debt. Disposition: `split-and-move-rust` under [#58](https://github.com/CurateLabs/xyg/issues/58).

Allowed:

- Compatibility wrappers, Python object coercion, public error text, and temporary orchestration during migration.

Forbidden:

- New canonical scene, layout, tick, geometry, colormap, or static-export behavior.
- Expanding an implementation that must match Node and direct-browser hosts.

### `python-abi-generated`

Owner: Python low-level ABI binding. Disposition: `generate` under [#57](https://github.com/CurateLabs/xyg/issues/57).

Allowed:

- Generated ctypes declarations plus a narrow handwritten ergonomic wrapper layer.

Forbidden:

- Hand-maintained symbol signatures, argument order, pointer mutability, or return types.
- Canonical engine algorithms.

### `node-host`

Owner: Node host. Disposition: `keep-host`.

Allowed:

- Idiomatic JS APIs, TypedArray coercion, errors, native-library discovery, HTML embedding, and VS Code transport.

Forbidden:

- A parallel implementation of canonical layout, LOD, encoding, aggregation, scene, or export policy.
- Hand-maintained Koffi C signatures.

### `node-scene-migration`

Owner: Node host with canonical-policy debt. Disposition: `split-and-move-rust` under [#58](https://github.com/CurateLabs/xyg/issues/58).

Allowed:

- TypedArray coercion, idiomatic composition methods, and temporary scene orchestration during migration.

Forbidden:

- New canonical scene, layout, LOD, encoding, aggregation, or static-export policy.
- Behavior that can diverge from Python or direct-browser hosts.

### `node-abi-generated`

Owner: Node low-level ABI binding. Disposition: `generate` under [#57](https://github.com/CurateLabs/xyg/issues/57).

Allowed:

- Generated Koffi declarations plus minimal loading and ABI-version validation.

Forbidden:

- Hand-maintained C signatures or canonical engine behavior.

### `browser-client`

Owner: Shared TypeScript browser client. Disposition: `keep-shared-client`.

Allowed:

- WebGL painting, picking, gestures, DOM chrome, accessibility, animation, client cache, and browser lifecycle.
- Screen-bounded presentation and transport attachment over engine-produced buffers.

Forbidden:

- Canonical layout, tick generation, data aggregation, encoding, or full-data row scans.
- Node-only modules, Koffi, filesystem access, or a second renderer.

### `browser-tick-presentation`

Owner: shared TypeScript browser presentation. Disposition:
`keep-shared-client` after #869.

Allowed: tooltip and general value display formatting that does not choose
axis tick positions or labels.

Forbidden: canonical axis/colorbar ladders, authored-window filtering, minor
interpolation, or axis-label formatting. Machine guards reject the historical
generator/formatter names and the UTC-time step table.

### `browser-wasm-migration`

Owner: Shared TypeScript fallback compute. Disposition: `replace-with-rust-wasm` under [#59](https://github.com/CurateLabs/xyg/issues/59).

Allowed:

- A bounded compatibility fallback and the future thin Worker adapter around Rust/WASM.

Forbidden:

- Expanding JavaScript row scans, binning, encoding, aggregation, layout, or other engine algorithms.

### `browser-wasm-adapter`

Owner: Shared TypeScript WASM lifecycle adapter. Disposition:
`implement-rust-wasm` under [#59](https://github.com/CurateLabs/xyg/issues/59).

Allowed:

- Explicit static Worker/WASM asset loading, bounded memory copies, stable
  status transport, cancellation, trap handling, and disposal.
- Latest-wins viewport framing and cache admission for Rust-owned automatic,
  authored-value, and authored-empty primary Cartesian
  linear/log/symlog/category/UTC-time ticks; TypeScript may
  schedule and paint but may neither generate nor format a covered attached axis.
- O(series) validation and framing for transferable typed columns. Rust owns
  per-record expansion, stable identities, and default mark/bar geometry. Exact
  per-record u64 identities remain an attached transferable column; TypeScript
  does not inspect their values.
- Generated `XYTS` offsets, flags, and kind codes from the versioned WASM
  manifest; handwritten wire-layout numbers are forbidden in the adapter.

Forbidden:

- Canonical engine algorithms, implicit CDN/path lookup, eval, Blob workers,
  or silent JavaScript fallbacks.

### `browser-wasm-generated`

Owner: Generated TypeScript WASM binding. Disposition: `generate` under
[#59](https://github.com/CurateLabs/xyg/issues/59).

Allowed:

- Generated export declarations, version checks, and status constants from
  `spec/wasm/abi.json`.

Forbidden:

- Hand-maintained raw signatures or canonical engine behavior.

## File ledger

| Path | Current owner | Policy | Disposition | Follow-up |
| --- | --- | --- | --- | ---: |
| `crates/xyg-engine/src/geo_spatial_index.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_spatial_build_session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_index_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_indexed_query_session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_build.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_scene.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_linked_state.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |

| `crates/xyg-engine/src/geo_rows_session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_rows_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_frame_lease_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-core/src/lib.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `crates/xyg-engine/src/graph_interaction_state.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/composed.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/identity.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/coordination.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/coordination.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/gpu.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/gpu.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/p1.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/paint.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/pick.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/pick.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/update.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/layout.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/render.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/walk.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-wasm/src/lib.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm`; WASM ABI 25 exports engine-owned default-palette version/rows/indexed RGBA8 for #868 | #59 |
| `crates/xyg-wasm/src/compound.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/graphforge.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm`; WASM ABI 27 GraphForge `XYGQ` → `XYGF` compose | #59 |
| `crates/xyg-wasm/src/geo.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm`; WASM ABI 28 GeoColumn `XYGD` → `XYGM` ingest | #59 |
| `crates/xyg-wasm/src/dashboard.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/compile.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/bin/xyts_conformance.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/bin/geo_scene_conformance.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/bin/geo_viewport_conformance.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/graph.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/aggregate.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/temporal.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/ticks.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/temporal_graph.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `crates/xyg-wasm/src/typed_series_abi_generated.rs` | Generated cross-host WASM contract binding | `browser-wasm-generated` | `generate` | #59 |
| `crates/xyg-engine/src/css.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/autorange.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/arrow_geom.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 217 annotation-arrow geometry; ABI 254 style CSV pack | — |
| `crates/xyg-engine/src/dashboard.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/font.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_scene.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/chunked_columns.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/compat_layout.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 126 static-export padding/colorbar/polar recut; ABI 127 pyplot tight-layout; ABI 198 `_svg.layout()` combination + tight figure extras | — |
| `crates/xyg-engine/src/edge_route.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_viewport.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_fill.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_viewport_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geom.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graph.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graph_style.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graph_style/property.rs` | Rust safe engine | `rust-engine` | `keep-rust`; shared home/label and canonical property presentation remain parity-affecting Rust policy | — |
| `crates/xyg-engine/src/graph_scale.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graph_scene.rs` | Rust safe engine | `rust-engine` | `keep-rust`; composed graph static rebuild appends the base Scene's expanded authored annotation records and labels via `SceneDocument::with_graph_annotations` (#922) | — |
| `crates/xyg-engine/src/hexbin.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/jpeg.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/colormap.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 135 named colormap tables (`xyg_colormap_stops`, XYHP paint kind 2) | — |
| `crates/xyg-engine/src/kernels.rs` | Rust safe engine | `rust-engine` | `keep-rust`; sole versioned default palette/default mark-color source (ABI 360 native + WASM ABI 25); ABI 129 Cartesian static-export grid colormap (`colormap_rgba_into` / `colormap_rgba_canonical_into`); ABI 218 Scene dash admit; ABI 219 Scene linecap admit; ABI 220 density overlay opacity; ABI 221 Scene marker-path admit; ABI 222 Scene annotation style admit; ABI 223 Scene ribbon color2 classify; ABI 224 Scene tick-label strategy admit; ABI 225 Scene tick-label anchor admit; ABI 226 Scene fill-gradient admit; ABI 227 Scene linear-gradient CSS parse; ABI 228 Scene rect extra-flag pack; ABI 229 Scene gradient-dir pack; ABI 230 Scene linear-gradient CSS prefix; ABI 231 Scene gradient-space pack; ABI 232 Scene hexbin reduce admit; ABI 233 Scene curve-name classify; ABI 234 Scene marker-glyph admit; ABI 235 Scene product-kind admit; ABI 236 Scene packing-family classify; ABI 237 Scene hexbin pitch admit; ABI 238 Scene heatmap extent admit; ABI 239 Scene heatmap colormap admit; ABI 240 Scene heatmap shape admit; ABI 241 Scene scatter paint-channel admit; ABI 242 Scene hexbin colormap-plane admit; ABI 243 Scene hexbin RGBA-plane admit; ABI 244 Scene mesh paint-plane admit; ABI 245 Scene per-item RGBA8 artist-alpha/opacity; ABI 246 Scene per-item stroke-width admit; ABI 247 Scene continuous per-item fill unit-t; ABI 248 Scene finite-all admit; ABI 249 Scene gradient-solid CSS; ABI 250 Scene f64 arrays-equal; ABI 251 unit-f64 clip-quantize u8; ABI 252 Scene constant-color admit; ABI 253 Scene hidden-or-per-item admit; ABI 256 Scene channel-constant CSS | — |
| `crates/xyg-engine/src/layout_rooms.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 125 measured cartesian gutters. #297 routes default-font Scene-shaped specs through `xyg_scene_plot_layout` | — |
| `crates/xyg-engine/src/legend_fit.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/legend_layout.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 124 static legend box packing | — |
| `crates/xyg-engine/src/lib.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/canonical_drill.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 396 capped canonical-row admission/query, zone-map preflight, complete/overflow/scan-budget observations; Python/Node borrow f64/maps and pack the same ABI | — |
| `crates/xyg-engine/src/lod_plan.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 122 compile-time payload tier + visible mask; ABI 204 line M4 emit indices; ABI 205 emit visible/even/sample indices | — |
| `crates/xyg-engine/src/packed_ticks.rs` | Rust safe engine | `rust-engine` | `keep-rust`; packed XYTK/XYTO resolution introduced in WASM ABI 23/native ABI 360 and carried by current WASM ABI 27/native ABI 361 | — |
| `crates/xyg-engine/src/density_emit.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 132 first-paint density emit policy | — |
| `crates/xyg-engine/src/pdf.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/png_encode.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/payload_emit.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 292 segment emit gather orchestration | — |
| `crates/xyg-engine/src/density_grid_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/payload_channel_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/payload_column_gather_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/payload_trace_emit_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_chrome_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_figure_support_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_figure_support_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_polar_input_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xyaf_bulk_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xyaf_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xycf_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xyta_trace_observations_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xyta_trace_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xytc_trace_observations_materialize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_xytc_trace_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_y2.rs` | Rust safe engine | `rust-engine` | `keep-rust`; Scene v33 `XYY2` secondary-y block codec | — |
| `crates/xyg-engine/src/scene_y2_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust`; Scene v33 secondary-y proofs | — |
| `crates/xyg-engine/src/scene_wedge_arcs.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYWA exact polar wedge-arc sidecar validated against the flattened PolyFill vertices for SVG/PDF arcs (#1006) | — |
| `crates/xyg-core/src/payload_trace_emit_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `crates/xyg-core/src/scene_bulk_pack_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `crates/xyg-core/src/scene_xyta_trace_observations_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `crates/xyg-core/src/scene_xytc_trace_observations_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `packages/xy-node/src/payloadTraceMaterialize.js` | Node host | `node-host` | `keep-host`; ABI 321 trace emit materialize marshal | — |
| `packages/xy-node/src/tooltip-columns.js` | Node host | `node-host` | `keep-host`; typed tooltip-column wire packing (byte-identical to Python) | — |
| `crates/xyg-engine/src/polar.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 131 polar projection; ABI 133 XYPL polar Scene compile | — |
| `crates/xyg-engine/src/projection.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/arrow_ipc.rs` | Rust safe engine | `rust-engine` | `keep-rust`; bounded Arrow IPC reader for GraphForge result ingress (ABI 378) | — |
| `crates/xyg-engine/src/graphforge/base.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/columns.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/compose.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 378 GraphForge result compositions (XYGQ -> XYGF) | — |
| `crates/xyg-engine/src/graphforge/compose/tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/container.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/ledger.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/mod.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/recognize.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/request.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/scene.rs` | Rust safe engine | `rust-engine` | `keep-rust`; direct-tier canonical Scene of a GraphForge composition | — |
| `crates/xyg-engine/src/graphforge/views.rs` | Rust safe engine | `rust-engine` | `keep-rust`; GraphForge table, bar-chart, and embedding compositions | — |
| `crates/xyg-engine/src/raster.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/sankey.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_annotation_splice.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 159 XYAS annotation splice packing | — |
| `crates/xyg-engine/src/scene_annotations.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_arrow.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_colorbar.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_chrome.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 153 XYCF figure-chrome packing; ABI 161 XYSD legend-paint splice | — |
| `crates/xyg-engine/src/scene_density.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 151 Scene density grid packing | — |
| `crates/xyg-engine/src/scene_encode_assembled.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 160 XYAS/XYCC assembled encode; ABI 162 XYAS/XYCF encode from sidecars; ABI 163 product encode from packed facts; ABI 165 product-path XYFS support | — |
| `crates/xyg-engine/src/scene_export.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 152 XYEP packing from XYEF | — |
| `crates/xyg-engine/src/scene_extras.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 150 XYSS extras packing; ABI 161 XYSD XYHP wrapping | — |
| `crates/xyg-engine/src/scene_heatmap.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 149 XYHF paint-fact packing | — |
| `crates/xyg-engine/src/scene_legend.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_pack.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_pack_orchestrate.rs` | Rust safe engine | `rust-engine` | `keep-rust`; M2 #733 XYTC/XYTA/XYFS/XYCF/XYAF/XYEF pack orchestration | — |
| `crates/xyg-engine/src/scene_static.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 164 public static-export consumers | — |
| `crates/xyg-engine/src/scene_style.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/scene_style_sidecars.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 158 XYSS style-sidecar packing | — |
| `crates/xyg-engine/src/scene_trace_attach.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 155 XYTA heatmap/density attach packing | — |
| `crates/xyg-engine/src/scene_trace_compile.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 154 XYTC per-trace compile packing; ABI 221 Scene marker-path admit | — |
| `crates/xyg-engine/src/scene_trace_rows.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 156 XYCL product-row packing | — |
| `crates/xyg-engine/src/scene_trace_sidecars.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 157 XYSD trace-sidecar packing | — |
| `crates/xyg-engine/src/static_document.rs` | Rust safe engine | `rust-engine` | `keep-rust`; versioned bounded XYST decode, composition, compatibility overrides, and SVG/PNG/PDF/JPEG/WebP consumers | — |
| `crates/xyg-engine/src/static_document_layout.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYSL/XYLO normalized, grid, and facet panel placement plus title reservation | — |
| `crates/xyg-engine/src/static_annotation_style.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYAS/XYAO annotation-style admission, mechanical patches, and uniform XYST facts | — |
| `crates/xyg-engine/src/static_chrome_style.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYCS/XYCO title / axis-title / tick-label admission, the single axis > slot > root theme > default precedence rule, and resolved size/paint/weight/style decisions (#1004) | — |
| `crates/xyg-engine/src/static_chrome_style_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYCS framing, precedence, and atomic-validation proofs | — |
| `crates/xyg-engine/src/static_document_labels.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYDA document-label decode, validation, and SVG/raster emission | — |
| `crates/xyg-engine/src/static_document_legend.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYDL document-legend decode, normalization, and SVG/raster emission | — |
| `crates/xyg-engine/src/static_legend_fit.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYLF/XYLR pyplot legend measurement, footprint expansion, sampling, candidate geometry, and scoring | — |
| `crates/xyg-engine/src/static_panel_chrome.rs` | Rust safe engine | `rust-engine` | `keep-rust`; XYPC/XYPO pyplot panel gutters, outside padding, title/colorbar room, and measured-gutter reconciliation | — |
| `crates/xyg-engine/src/simd.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/static_export_registry.rs` | Rust safe engine | `rust-engine` | `keep-rust`; admitted static-export vocabulary and exhaustive host-pair evidence contract | — |
| `crates/xyg-engine/src/stats.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/stream.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/svg.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/temporal.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/temporal_controller.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/temporal_graph.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/textblock.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 125 newline-delimited chrome measure | — |
| `crates/xyg-engine/src/tick_layout.rs` | Rust safe engine | `rust-engine` | `keep-rust`; ABI 123 tick-label collision thinning; ABI 128 authored tick-window; ABI 199 Scene product-path authored filter/pairing; ABI 200 Scene product-path authored minor filter; ABI 201 Scene polar modular theta window / angular labels; ABI 202 Scene product-path ABI 130 time/angular formats; ABI 203 Scene cartesian ABI 123 collision emit; ABI 130 tick-label formatting (`format_axis_tick` in `scene.rs`) | — |
| `crates/xyg-engine/src/tile_paint_control.rs` | Rust safe engine | `rust-engine` | `keep-rust`; shared bounded XYDC inventory decoder for native painting and every C ABI wheel target, including Pyodide; independent of filesystem storage | — |
| `crates/xyg-engine/src/tile_store.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/tile_store/paint.rs` | Rust safe engine | `rust-engine` | `keep-rust`; density paint levels, retention, encoding, normalization, and resource budgets | — |
| `crates/xyg-engine/src/tiles.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/transition.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/webp.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `js/src/00_header.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/10_colormaps.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/20_theme.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/30_ticks.ts` | Shared TypeScript browser presentation | `browser-tick-presentation` | `keep-shared-client`; tooltip/presentation formatting only | — |
| `js/src/40_gl.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/41_gpu_storage.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/42_glhost.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/43_external_gl.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/45_lod.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/47_wasm.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; #868 diagnostics report and init fails closed on a mismatched direct-WASM palette contract | #59 |
| `js/src/48_wasm_scene.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_compound.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_graphforge.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; GraphForge request framing, document decoding, stable-ID identity, text-only tables | #59 |
| `js/src/49_wasm_geo.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; GeoColumn typed-plane framing only; shared Rust owns validation and limits | #59 |
| `js/src/59_maplibre_geo.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; GeoColumn typed-plane framing only; shared Rust owns validation and limits | #59 |
| `js/src/49_wasm_geoviewport.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; GeoColumn typed-plane framing only; shared Rust owns validation and limits | #59 |
| `js/src/49_wasm_dashboard.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_graph.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_columns.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_semantic_graph.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_ticks.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_chart.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_aggregate.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_density.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_temporal.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/49_wasm_temporal_graph.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/50_chartview.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/51_annotations.ts` | Shared TypeScript browser client | `browser-client` | `literal-projection-only`; Scene v24 owns rule/band/marker geometry, order, clipping, defaults, bounded attached-label anchors, literal Cartesian straight-arrow projection/head geometry, bounded Cartesian callout leader/label anchoring, fixed literal label backgrounds/borders, and wrapped-line/box geometry in Rust; markup, CSS/classes, custom fonts, and collision policy remain migration debt | #116 |
| `js/src/52_tooltip.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/53_interaction.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/54_kernel.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/55_marks.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/56_animation.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/57_viewstate.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/58_graph.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/60_entries.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `js/src/66_graph_host.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client`; notebook frame/ACK presentation and existing comm routing only | — |
| `js/src/63_graph_controller.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client`; explicit S5b keyboard/DOM/ARIA/companion/lifetime plus bounded automatic temporal scheduling; Rust owns membership/state/layout/pick | — |
| `js/src/63_graph_gpu.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client`; GPU-v1 validation/raw-buffer paint through GLHost | — |
| `js/src/63_graph_session_wire.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; internal XYGI/XYGR framing, no graph policy | #59 |
| `js/src/wasm_abi_generated.ts` | Generated cross-host WASM contract binding | `browser-wasm-generated` | `generate` | #59 |
| `js/src/wasm_frozen_graph.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; Shared raw byte staging only. | #59 |
| `js/src/wasm_inline_worker.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/wasm_worker.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/_abi_generated.js` | Node low-level ABI binding | `node-abi-generated` | `generate` | #57 |
| `packages/xy-node/src/abi.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/chunked-columns.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/charts.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/color.js` | Node host | `node-host` | `keep-host`; ABI 213 owns CSS/numeric split, domain pad, and direct RGBA admit; ABI 251 owns clip-quantize u8; `quantizeUnitU8` composes normalize then ABI 251; `factorize.js` delegates fixed-width categorical columns to native factorize/remap like Python `channels._factorize_categories`; JS string arrays still use label-policy fallback; hosts still pin palettes | — |
| `packages/xy-node/src/factorize.js` | Node host | `node-host` | `keep-host`; native factorize/remap for fixed-width TypedArray columns and stringlike JS arrays; mixed-object label-policy fallback returns counts=null like Python | — |
| `packages/xy-node/src/dom.js` | Node host | `node-host` | `keep-host`; DOM slot validation and style mapping for buildPayload domSpec parity with Python `dom.py` | — |
| `packages/xy-node/src/encode.js` | Node host | `node-host` | `keep-host`; ABI 360 populates frozen default-palette/default-mark exports from Rust at native initialization; ABI 206 owns colormap LUT RGB; `colormapLutRgba8` host-packs alpha 255; ABI 254 owns `packArrowStyle` CSV pack; ChartView still parses those strings until WASM; ABI 255 owns EncodedColumn offset/scale/kind-presence packing; hosts still copy the original kind string | — |
| `packages/xy-node/src/figure.js` | Node host | `node-host` | `keep-host`; ABI 220 owns density overlay opacity; Node scatterPerItemChannels ignores style.color_channel; Node scatterPerItemChannels is mode-based like Python has_per_item_channels; a constant color_ch is not per-item; Node `figureAutorangeAxisOptions` uses `axis_options` only like Python `_axis_scale`; `xAxis` is not an autorange-axis fallback; Node `_emitScatter` uses `force_density` only like Python `payload_force_density`; `style.force_density` is not a payload-density fallback. Node `_emitScatter` does not read `style.force_direct` like Python `_emit_scatter`; `style.force_direct` is not a payload-direct fallback. Node `_emitScatter` does not read `style.force_pyramid` like Python `_emit_scatter`; `style.force_pyramid` is not a payload-pyramid fallback. Node `chromeAxisMinorStyle` uses `minor_style` only like Python `_pack_chrome_axis`; `minorStyle` is not a chrome-minor-style fallback. Node `chromeAxisTickSides` uses `tick_sides` only like Python `_pack_chrome_axis`; `tickSides` is not a chrome-tick-sides fallback. Node `chromeAxisTickLabelSides` uses `tick_label_sides` only like Python `_pack_chrome_axis`; `tickLabelSides` is not a chrome-tick-label-sides fallback. Node `chromeAxisStyleKeys` admits snake-case keys only like Python `_SCENE_AXIS_STYLE_KEYS`; camelCase axis style keys are not a chrome-axis-style-keys fallback. Node `chromeAxisStyleHas` / `chromeAxisStyleValue` read snake-case keys only like Python `_pack_chrome_axis`; camelCase fields are not a chrome-axis-style-read fallback. Node `legendAxisScale` uses axis `type` only like Python `_axis_scale`; `scale` / `kind` are not a legend-axis-scale fallback. Node `figureAutorangeAxisScale` uses axis `type` only like Python `_axis_scale`; `kind` is not an autorange-axis-scale fallback. Node `figureAxisKind` matches Python `_axis_kind` (forced `type` time, then category labels, then `time_ms` columns); axis `kind` is not an autorange-axis-kind fallback. Node `chromeAxisTickKind` uses `Figure._axisKind` like Python `_pack_figure_chrome` / `_pack_tick_collision`; axis `kind` is not a chrome-tick-kind fallback. Node `xyEfResolvedKind` uses `Figure._axisKind` like Python `_pack_public_export_support`; axis `kind` is not an xyef-axis-kind fallback. Node `figureAutorangeThetaUnit` uses axis `theta_unit` only like Python `_pack_autorange`; `thetaUnit` is not an autorange-theta-unit fallback. Node `figureAxisIsLog` uses axis `type` only like Python `_axis_scale` log; `scale` is not an axis-is-log fallback. Node `figureAutorangeCategories` uses `_axis_categories` only like Python `_pack_autorange`; `options.categories` is not an autorange-categories fallback. Node `figureAutorangeDomain` uses axis `domain` only like Python `_pack_autorange`; `_axisRange` is not an autorange-domain fallback. Node `setPolarMeta` writes axis `theta_unit` like Python `set_axis`; `_polarMeta.thetaUnit` is not a polar-meta-unit fallback. Node `setPolarMeta` writes axis `theta_zero` like Python `set_axis`; `_polarMeta.thetaZero` is not a polar-meta-zero fallback. Node `setPolarMeta` writes axis `theta_direction` like Python `set_axis`; `_polarMeta.thetaDirection` is not a polar-meta-direction fallback. Node `setPolarMeta` writes axis `grid_shape` like Python `set_axis`; `_polarMeta.gridShape` is not a polar-meta-grid fallback. Node `setPolarMeta` writes axis `hole` like Python `set_axis`; `_polarMeta.hole` is not a polar-meta-hole fallback. Node `setPolarMeta` writes axis `sector` like Python `set_axis`; `_polarMeta.sector` is not a polar-meta-sector fallback. Node `polarAxisHole` uses axis `hole` only like Python `_pack_polar_scene_input`; `Hole` is not a polar-hole fallback. Node `polarAxisSector` uses axis `sector` only like Python `_pack_polar_scene_input`; `Sector` is not a polar-sector fallback. Node `_polarAxisSpecs` uses axis `theta_unit` like Python `_axis_spec`; `_polarMeta.thetaUnit` is not a polar-spec-unit fallback. Node `_polarAxisSpecs` uses axis `theta_zero` like Python `_axis_spec`; `_polarMeta.thetaZero` is not a polar-spec-zero fallback. Node `_polarAxisSpecs` uses axis `theta_direction` like Python `_axis_spec`; `_polarMeta.thetaDirection` is not a polar-spec-direction fallback. Node `_polarAxisSpecs` uses axis `grid_shape` like Python `_axis_spec`; `_polarMeta.gridShape` is not a polar-spec-grid fallback. Node `_polarAxisSpecs` uses axis `sector` like Python `_axis_spec`; `_polarMeta.sector` is not a polar-spec-sector fallback. Node `_polarAxisSpecs` uses axis `hole` like Python `_axis_spec`; `_polarMeta.hole` is not a polar-spec-hole fallback. Node `_polarAxisSpecs` uses axis `r_origin` like Python `_axis_spec`; `_polarMeta.rOrigin` is not a polar-spec-origin fallback. Node `_axisSpec` uses axis `nonpositive` on log axes like Python `_axis_spec`. Node `_axisSpec` uses axis `constant` on symlog axes like Python `_axis_spec`. Node `_axisSpec` uses `_axis_categories` on category axes like Python `_axis_spec`. Node `packPolarSceneInput` uses figure `_range("y")` like Python `_pack_polar_scene_input`; `rAxis.range` is not a polar-range fallback. Node `_emitTriangleMesh` ships x2/y2 via `payloadColumnShipPlan` / `shipRegistryColumns` like Python `_emit_triangle_mesh`. Node `buildPayload` ships `show_legend` like Python `build_payload` via ABI 303 `attach_show_legend`. Node `buildPayload` ships `legend` from `legend_options` like Python `build_payload` via ABI 303 `attach_legend`; `loc="best"` resolves via `resolveLegendBestLoc` like Python `_legendfit.resolve_for_figure`. Node `buildPayload` ships `colorbar` like Python `build_payload` via ABI 303 `attach_colorbar`. Node `buildPayload` ships `extra_legends` like Python `build_payload` via ABI 303 `attach_extra_legends`. Node `buildPayload` ships `annotations` like Python `build_payload` via ABI 303 `attach_annotations`; validated via `annotationSpecs` like Python `_annotation_specs`. Node `buildPayload` ships `title_options` like Python `build_payload` via ABI 303 `attach_title_options`; y/pad geometry packs via `shipScalar` like Python `ship_scalar`. Node `buildPayload` ships `padding` like Python `build_payload` via ABI 303 `attach_padding`. Node `buildPayload` ships `dom` via `domSpec` like Python `_dom_spec` via ABI 303 `attach_dom`; `domSpec` maps `chrome_styles` to `dom.styles` via `styleMapping`. Node `buildPayload` ships `wasm_density` like Python `build_payload` via ABI 303 `attach_wasm_density`. Node `buildPayload` ships `frame_sides`, `show_modebar`, `export`, `show_tooltip`, `tooltip`, `mark_style`, `interaction`, `animation`, `graph`, and `palette` like Python `build_payload` via the corresponding ABI 303 attach flags; mapped palettes ship `paletteCycle` values not category labels. Node `packXyTaDensityColorCh` uses trace `color_ch.constant` like Python `_pack_xyta`. Node `composeScatter` resolves `color_ch`, `size_ch`, `stroke_ch`, and `style.symbol` like Python `marks.scatter`. hosts still default omitted opacity to `0.8` and gather/ship | — |
| `packages/xy-node/src/force_scheduler.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geoarrow.js` | Node host | `node-host` | `keep-host`; Arrow-free GeoArrow-shaped plane → `geoColumnNew` descriptor packer (CRS metadata parse, null-point packing, stable codes) mirroring Python `_geoarrow.py`; Rust owns all validation, CRS, identity, and limits | — |
| `packages/xy-node/src/geoviewport.js` | Node host | `node-host` | `keep-host`; typed XYVC/XYVR framing only; Rust owns camera/projection policy | — |
| `packages/xy-node/src/graph.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/graphforge-container.js` | Node host | `node-host` | `keep-host`; ABI 378 GraphForge composition framing/decoding only | — |
| `packages/xy-node/src/graphforge.js` | Node host | `node-host` | `keep-host`; ABI 378 GraphForge composition framing/decoding only | — |
| `packages/xy-node/src/html.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/index.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/load.js` | Node host | `node-host` | `keep-host`; non-throwing `loadXygNode()` with stable native-loading codes | — |
| `packages/xy-node/src/marks/area.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/bar.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/box.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/contour.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/distribution.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/ecdf.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/error_band.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/errorbar.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/heatmap.js` | Node host | `node-host` | `keep-host`; constant-style, scalar-colormap, and truecolor Cartesian/polar Scene expand a regular lattice onto Rects (polar encode tessellates to PolyFill); remaining debt is irregular-grid assembly | — |
| `packages/xy-node/src/marks/hexbin.js` | Node host | `node-host` | `keep-host`; ABI 102 removed finite-pair/domain/aspect policy; ABI 103 moves Cartesian Scene hex-cell ring expansion into Rust; ABI 119 moves custom-reduce lattice groups into Rust; ABI 186 interned cartesian metric colormaps onto HexCell PolyFills; ABI 194 admits polar hexbin, custom host reducers, and categorical / `direct_rgba` cell paints | — |
| `packages/xy-node/src/marks/histogram.js` | Node host | `node-host` | `keep-host`; ABI 119 moves integer/empty-auto edge policy into Rust | — |
| `packages/xy-node/src/marks/line.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/polar.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/radar.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/ribbon.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/scatter.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/segments.js` | Node host | `node-host` | `keep-host`; ABI 104 moves Cartesian Scene endpoint-pair expansion into Rust; remaining debt is role/style assembly | — |
| `packages/xy-node/src/marks/stem.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/marks/step.js` | Node compact authoring adapter | `node-host-authoring` | `keep-thin`; ABI 95 passes compact step mode/source columns and Rust owns canonical Scene expansion | #58 |
| `packages/xy-node/src/marks/triangle_mesh.js` | Node host | `node-host` | `keep-host`; ABI 104 moves Cartesian Scene triangle-face expansion into Rust; remaining debt is joined-fill/style assembly | — |
| `packages/xy-node/src/marks/violin.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/native-path.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/native.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/pyramid.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/sankey.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/scene.js` | Node host | `node-host` | `keep-host`; ABI 218 owns Scene dash admit; ABI 219 owns Scene linecap admit; ABI 221 owns Scene marker-path admit; ABI 222 owns Scene annotation style admit; ABI 223 owns ribbon color2 classify; ABI 224 owns tick-label strategy admit; ABI 225 owns tick-label anchor admit; ABI 226 owns fill-gradient stop admit; ABI 227 owns linear-gradient CSS parse; ABI 228 owns rect extra-flag pack; ABI 229 owns gradient-dir pack; ABI 230 owns linear-gradient CSS prefix; ABI 231 owns gradient-space pack; ABI 232 owns hexbin reduce admit; ABI 233 owns curve-name classify; ABI 234 owns marker-glyph admit; ABI 235 owns product-kind admit; ABI 236 owns packing-family classify; smooth-kind eligibility uses LINE|BAND; ABI 237 owns hexbin pitch admit; ABI 238 owns heatmap extent admit; ABI 239 owns heatmap colormap admit; ABI 240 owns heatmap shape admit (XYEP and XYTA); ABI 241 owns scatter paint-channel admit; ABI 242 owns hexbin colormap-plane admit; ABI 243 owns hexbin RGBA-plane admit; ABI 244 owns mesh paint-plane admit; ABI 245 owns per-item RGBA8 artist-alpha/opacity; ABI 246 owns per-item stroke-width admit; ABI 247 owns continuous per-item fill unit-t; ABI 248 owns finite-all admit; ABI 249 owns gradient-solid CSS; ABI 250 owns f64 arrays-equal; ABI 251 owns clip-quantize u8; ABI 252 owns constant-color admit; ABI 253 owns hidden-or-per-item admit; Node `meshHasPerItem` uses `perItemChannelNames`; Node `scatterPaintChannelNames` uses `perItemChannelNames`; Node hexbin colormap packing uses `channel.values`; Node empty kind uses `|| "mark"`; Node does not fail-close `style.smooth`; Node `itemWidths` fail-closes a present `stroke_width` channel without values; Node `itemApplyOpacity` fail-closes a present opacity/artist_alpha channel without values; Node missing scatter kind uses `|| ""`; Node fillIsGradientAuthoring rejects arrays (same as Python dict-only); Node rectExtraFlags treats only mapping fills as gradient-fail (same as Python dict-only); Node admittedMarkerGlyph rejects non-strings (same as Python str-only); Node packXyTaColormap uses style.colormap only; Node hexbin XYTA colormap uses channel.colormap only; Node XYHF heatmap/density colormap uses style.colormap only; Node constantMarkColor uses color_ch.constant only; Node channelConstantCss uses channel.constant only; Node channelEndRgba8 constant paint uses channel.constant only; Node sourceColorCss uses color_ch only; Node resolveColorChannel constant CSS uses .constant; Node color2Channel uses color2_ch only; Node itemFillRgba8 uses color_ch only; Node scatterPaintChannelNames uses color_ch only; Node scatterHasNonConstantColor uses color_ch only; Node resolveDensityBinColors uses color_ch only; Node scatterHasNonConstantColor ignores style.color_channel; Node scatterPaintChannelNames ignores style.color_channel; Node resolveDensityBinColors ignores style.color_channel; Node XYMS mark color uses style.color only; Node XYTC style color uses style.color only; Node XYTC constant paint uses channel.constant only; Node density-blit observation uses scatterUsesDensity; Node XYTC color_ch packing ignores string channels; Node scatterHasNonConstantColor uses channel.constant only; Node XYTC COLOR_CH_CONSTANT packs whenever channel.constant is set; Node XYMS mark color uses constantMarkColor; Node scatterPerItemChannels ignores style.color_channel; Node scatterPerItemChannels is mode-based like Python has_per_item_channels; a constant color_ch is not per-item; Node channelEndRgba8 ignores array and typed-array channels; Node channelEndRgba8 categorical paint uses DEFAULT_PALETTE when palette is empty; Node packXyTaColormap stop bytes require RGB rows; Node xyHfColormap stop bytes require RGB rows; Node packXyTaRgbaGrid stacks flattened planes; Node heatmap trace.rgba stores a flat uint8 buffer; Node heatmap and density Scene packing is XYTA-only; Node packXyTaGrid flattens heatmap grid; Node rectFiniteSel drops nonfinite rectangle rows; Node packXyTa density fill opacity uses fill_opacity only; Node XYTC fill opacity uses fill_opacity only; Node XYTC stroke opacity uses stroke_opacity only; Node XYTC line opacity uses line_opacity only; Node XYTC stroke width uses stroke_width only; Node XYTC line width uses line_width only; Node XYTC size uses size only; Node XYTC line color uses line_color only; Node XYTC joined fill uses joined_fill only; Node XYTC stroke perimeter uses stroke_perimeter only; Node XYTC COLOR_CH packing uses color_ch only; Node XYTC size_ch packing uses size_ch only; Node XYEF stroke-width-only observation uses stroke_width only; Node meshJoinedFill uses joined_fill only; Node XYEF joined-fill observation uses joined_fill only; Node `constantMarkColor` uses `color_ch` only like Python `_constant_color`; `colorChannel` is not a source-channel fallback; Node `sourceColorCss` uses `color_ch` only like Python `_trace_source_color_css`; `colorChannel` is not a source-css fallback; Node `scatterHasNonConstantColor` uses `color_ch` only like Python; `colorChannel` is not a non-constant-color fallback; Node `classifyRibbonColor2` source-constant CSS uses `color_ch` only like Python `_classify_ribbon_color2`; `colorChannel` is not a source-constant fallback; Node `itemFillRgba8` uses `color_ch` only like Python `_item_fill_rgba8`; `colorChannel` is not a fill-channel fallback; Node `resolveDensityBinColors` uses `color_ch` only like Python; `colorChannel` is not a density-bin color channel; Node `hexbinPacksColormapPlane` uses `color_ch` only like Python `_hexbin_packs_colormap_plane`; `colorChannel` is not a colormap-plane fallback; Node `ribbonEndRgbaPair` uses `color_ch` only like Python `_ribbon_end_rgba_pair`; `colorChannel` is not a ribbon-end source fallback; Node `hexbinXyTaColormap` uses `color_ch` only like Python `_pack_xyta` hexbin colormap; `colorChannel` is not a colormap fallback; Node `hexbinPacksRgbaPlane` uses `color_ch` only like Python `_hexbin_packs_rgba_plane`; `colorChannel` is not an RGBA-plane fallback; Node `hexbinCellRgba8` uses `color_ch` only like Python `_hexbin_cell_rgba8`; `colorChannel` is not a cell-paint fallback; Node XYTA density color_ch packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a packed-constant fallback; Node `itemStrokeRgba8` uses `stroke_ch` only like Python `_item_stroke_rgba8`; `strokeChannel` is not a stroke-channel fallback; Node `scatterPointStrokeRgba8` uses `stroke_ch` only like Python `_scatter_point_stroke_rgba8`; `strokeChannel` is not a match-fill opacity skip; Node `perItemChannelNames` uses `color_ch` / `stroke_ch` / `size_ch` / `style_channels` only like Python `per_item_channel_names`; camelCase channel fields are not per-item name fallbacks; Node `itemApplyOpacity` uses `style_channels` only like Python `_item_apply_opacity`; `styleChannels` is not an opacity-channel fallback; Node `itemWidths` uses `style_channels` only like Python `_item_widths`; `styleChannels` is not a width-channel fallback; Node `scatterUsesDensity` uses `force_density` only like Python `use_density`; `forceDensity` is not a density-force fallback; Node `figureTraceSupport` uses `style.linecap` only like Python `_figure_trace_support_flags`; `lineCap` is not a dashed-marker linecap fallback; Node `packXyTcLinecap` uses `style.linecap` only like Python `_pack_xytc`; `lineCap` is not a packed-linecap fallback; Node `packXyAfLinecap` uses `style.linecap` only like Python `_pack_xyaf`; `lineCap` is not an annotation-linecap fallback; Node `scatterUsesDensity` does not pass `force_direct` like Python `use_density`; `forceDirect` / `force_direct` are not density-direct overrides; Node hexbin XYTA values packing uses `color_ch` only like Python `_pack_xyta`; `colorChannel` is not a hexbin-grid values fallback; Node `legendStyleFontSizes` uses `style.font_size` / `style.title_font_size` only like Python `_legend_input`; `fontSize` / `titleFontSize` are not legend-font fallbacks; Node `heatmapGridShape` uses `grid_shape` only like Python `_heatmap_shape`; `gridShape` is not a heatmap-lattice fallback; Node `hexbinStylePitch` uses `style.hex_dx` then `style.dx` like Python `_hexbin_pitch`; `hexDx` / `hexDy` are not hexbin-pitch fallbacks; Node `polarGridShape` uses axis `grid_shape` only like Python `_pack_polar_scene_input`; `gridShape` is not a polar-grid fallback; Node `polarAxisThetaUnit` uses axis `theta_unit` only like Python `_pack_polar_scene_input`; `thetaUnit` is not a polar-unit fallback; Node `polarAxisThetaZero` uses axis `theta_zero` only like Python `_pack_polar_scene_input`; `thetaZero` is not a polar-zero fallback; Node `polarAxisThetaDirection` uses axis `theta_direction` only like Python `_pack_polar_scene_input`; `thetaDirection` is not a polar-direction fallback; Node `polarAxisROrigin` uses axis `r_origin` only like Python `_pack_polar_scene_input`; `rOrigin` is not a polar-origin fallback; Node `axisTickValues` uses axis `tick_values` only like Python `_pack_figure_chrome`; `tickValues` is not a chrome-major-tick fallback; Node `axisMinorTickValues` uses axis `minor_tick_values` only like Python `_pack_figure_chrome`; `minorTickValues` is not a chrome-minor-tick fallback; Node `axisTickLabels` uses axis `tick_labels` only like Python `_pack_figure_chrome`; `tickLabels` is not a chrome-tick-label fallback; Node `figureXLabel` uses `x_label` then axis `label` like Python `_pack_figure_chrome`; `xLabel` is not a chrome-xlabel fallback; Node `figureYLabel` uses `y_label` then axis `label` like Python `_pack_figure_chrome`; `yLabel` is not a chrome-ylabel fallback; Node `plotTopAxisRoom` uses plot `top_axis_room` only like Python `recut_polar_plot`; `topAxisRoom` is not a polar-recut-room fallback; Node `axisTickLabelAnchor` uses axis `tick_label_anchor` only like Python `_scene_tick_anchor_code`; `tickLabelAnchor` is not a chrome-tick-anchor fallback; Node `axisTickLabelMinGap` uses axis `tick_label_min_gap` only like Python `_pack_tick_collision`; `tickLabelMinGap` is not a chrome-tick-gap fallback; Node `axisTickLabelAngle` uses axis `tick_label_angle` only like Python `_pack_tick_collision`; `tickLabelAngle` is not a chrome-tick-angle fallback; Node `axisTickLabelStrategy` uses `tick_label_strategy` then `collision` like Python `_scene_tick_label_strategy`; `tickLabelStrategy` is not a chrome-tick-strategy fallback; Node `polarCollisionKeys` uses snake-case keys only like Python `_POLAR_COLLISION_KEYS`; camelCase tick-label keys are not polar-collision-key extras; Node `figureChromeStyles` uses `chrome_styles` only like Python `_pack_figure_support`; `chromeStyles` is not a chrome-styles fallback; Node `chromeStyleHasFontFamily` uses `font-family` only like Python `_pack_figure_support`; `fontFamily` is not a chrome-font-family fallback. Node `figureClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not a figure-class-name fallback. Node `figureClassNames` uses `class_names` only like Python `_pack_figure_support`; `classNames` is not a figure-class-names fallback. Node `annotationClassName` uses `class_name` only like Python `_pack_figure_support`; `className` is not an annotation-class-name fallback. Node `figureExtraLegends` uses `extra_legends` only like Python `_pack_figure_support`; `extraLegends` is not an extra-legends fallback. Node `figureTitleOptions` uses `title_options` only like Python `_pack_public_export_support`; `titleOptions` is not a title-options fallback. Node `figureLegendOptions` uses `legend_options` only like Python `_legend_input`; `legend` is not a legend-options fallback. Node `figureColorbarOptions` uses `colorbar_options` only like Python `_colorbar_input`; `colorbarOptions` is not a colorbar-options fallback. Node `figureShowLegend` uses `show_legend` only like Python `_legend_input`; `showLegend` is not a show-legend fallback. Node `figureAxisOptions` uses `axis_options` only like Python `_pack_figure_chrome`; `xAxis` / `x_axis` are not axis-options fallbacks. Node `axisScaleName` uses axis `type` only like Python `_axis_scale`; `kind` is not an axis-scale fallback. Node `figureAutorangeAxisOptions` uses `axis_options` only like Python `_axis_scale`; `xAxis` is not an autorange-axis fallback. Node `_emitScatter` uses `force_density` only like Python `payload_force_density`; `style.force_density` is not a payload-density fallback. Node `_emitScatter` does not read `style.force_direct` like Python `_emit_scatter`; `style.force_direct` is not a payload-direct fallback. Node `_emitScatter` does not read `style.force_pyramid` like Python `_emit_scatter`; `style.force_pyramid` is not a payload-pyramid fallback. Node `chromeAxisMinorStyle` uses `minor_style` only like Python `_pack_chrome_axis`; `minorStyle` is not a chrome-minor-style fallback. Node `chromeAxisTickSides` uses `tick_sides` only like Python `_pack_chrome_axis`; `tickSides` is not a chrome-tick-sides fallback. Node `chromeAxisTickLabelSides` uses `tick_label_sides` only like Python `_pack_chrome_axis`; `tickLabelSides` is not a chrome-tick-label-sides fallback. Node `chromeAxisStyleKeys` admits snake-case keys only like Python `_SCENE_AXIS_STYLE_KEYS`; camelCase axis style keys are not a chrome-axis-style-keys fallback. Node `chromeAxisStyleHas` / `chromeAxisStyleValue` read snake-case keys only like Python `_pack_chrome_axis`; camelCase fields are not a chrome-axis-style-read fallback. Node `legendAxisScale` uses axis `type` only like Python `_axis_scale`; `scale` / `kind` are not a legend-axis-scale fallback. Node `figureAutorangeAxisScale` uses axis `type` only like Python `_axis_scale`; `kind` is not an autorange-axis-scale fallback. Node `figureAxisKind` matches Python `_axis_kind` (forced `type` time, then category labels, then `time_ms` columns); axis `kind` is not an autorange-axis-kind fallback. Node `chromeAxisTickKind` uses `Figure._axisKind` like Python `_pack_figure_chrome` / `_pack_tick_collision`; axis `kind` is not a chrome-tick-kind fallback. Node `xyEfResolvedKind` uses `Figure._axisKind` like Python `_pack_public_export_support`; axis `kind` is not an xyef-axis-kind fallback. Node `figureAutorangeThetaUnit` uses axis `theta_unit` only like Python `_pack_autorange`; `thetaUnit` is not an autorange-theta-unit fallback. Node `figureAxisIsLog` uses axis `type` only like Python `_axis_scale` log; `scale` is not an axis-is-log fallback. Node `figureAutorangeCategories` uses `_axis_categories` only like Python `_pack_autorange`; `options.categories` is not an autorange-categories fallback. Node `figureAutorangeDomain` uses axis `domain` only like Python `_pack_autorange`; `_axisRange` is not an autorange-domain fallback. Node `setPolarMeta` writes axis `theta_unit` like Python `set_axis`; `_polarMeta.thetaUnit` is not a polar-meta-unit fallback. Node `setPolarMeta` writes axis `theta_zero` like Python `set_axis`; `_polarMeta.thetaZero` is not a polar-meta-zero fallback. Node `setPolarMeta` writes axis `theta_direction` like Python `set_axis`; `_polarMeta.thetaDirection` is not a polar-meta-direction fallback. Node `setPolarMeta` writes axis `grid_shape` like Python `set_axis`; `_polarMeta.gridShape` is not a polar-meta-grid fallback. Node `setPolarMeta` writes axis `hole` like Python `set_axis`; `_polarMeta.hole` is not a polar-meta-hole fallback. Node `setPolarMeta` writes axis `sector` like Python `set_axis`; `_polarMeta.sector` is not a polar-meta-sector fallback. Node `polarAxisHole` uses axis `hole` only like Python `_pack_polar_scene_input`; `Hole` is not a polar-hole fallback. Node `polarAxisSector` uses axis `sector` only like Python `_pack_polar_scene_input`; `Sector` is not a polar-sector fallback. Node `_polarAxisSpecs` uses axis `theta_unit` like Python `_axis_spec`; `_polarMeta.thetaUnit` is not a polar-spec-unit fallback. Node `_polarAxisSpecs` uses axis `theta_zero` like Python `_axis_spec`; `_polarMeta.thetaZero` is not a polar-spec-zero fallback. Node `_polarAxisSpecs` uses axis `theta_direction` like Python `_axis_spec`; `_polarMeta.thetaDirection` is not a polar-spec-direction fallback. Node `_polarAxisSpecs` uses axis `grid_shape` like Python `_axis_spec`; `_polarMeta.gridShape` is not a polar-spec-grid fallback. Node `_polarAxisSpecs` uses axis `sector` like Python `_axis_spec`; `_polarMeta.sector` is not a polar-spec-sector fallback. Node `_polarAxisSpecs` uses axis `hole` like Python `_axis_spec`; `_polarMeta.hole` is not a polar-spec-hole fallback. Node `_polarAxisSpecs` uses axis `r_origin` like Python `_axis_spec`; `_polarMeta.rOrigin` is not a polar-spec-origin fallback. Node `_axisSpec` uses axis `nonpositive` on log axes like Python `_axis_spec`. Node `_axisSpec` uses axis `constant` on symlog axes like Python `_axis_spec`. Node `_axisSpec` uses `_axis_categories` on category axes like Python `_axis_spec`. Node `packPolarSceneInput` uses figure `_range("y")` like Python `_pack_polar_scene_input`; `rAxis.range` is not a polar-range fallback. Node `_emitTriangleMesh` ships x2/y2 via `payloadColumnShipPlan` / `shipRegistryColumns` like Python `_emit_triangle_mesh`. Node `buildPayload` ships `show_legend` like Python `build_payload` via ABI 303 `attach_show_legend`. Node `buildPayload` ships `legend` from `legend_options` like Python `build_payload` via ABI 303 `attach_legend`; `loc="best"` resolves via `resolveLegendBestLoc` like Python `_legendfit.resolve_for_figure`. Node `buildPayload` ships `colorbar` like Python `build_payload` via ABI 303 `attach_colorbar`. Node `buildPayload` ships `extra_legends` like Python `build_payload` via ABI 303 `attach_extra_legends`. Node `buildPayload` ships `annotations` like Python `build_payload` via ABI 303 `attach_annotations`; validated via `annotationSpecs` like Python `_annotation_specs`. Node `buildPayload` ships `title_options` like Python `build_payload` via ABI 303 `attach_title_options`; y/pad geometry packs via `shipScalar` like Python `ship_scalar`. Node `buildPayload` ships `padding` like Python `build_payload` via ABI 303 `attach_padding`. Node `buildPayload` ships `dom` via `domSpec` like Python `_dom_spec` via ABI 303 `attach_dom`; `domSpec` maps `chrome_styles` to `dom.styles` via `styleMapping`. Node `packXyTaDensityColorCh` uses trace `color_ch.constant` like Python `_pack_xyta`. Node `composeScatter` resolves `color_ch`, `size_ch`, `stroke_ch`, and `style.symbol` like Python `marks.scatter`. 256-texel LUT uses ABI 206; density-bin idx uses quantizeUnitU8; hosts still coerce channels, pack end RGBA8, skip markup/typography/rotation, raise error text, pick tick_label_strategy / tick_label_anchor vs collision vs camelCase keys, and coerce fill mappings | — |
| `packages/xy-node/src/sceneBulkNative.js` | Node host | `node-host` | `keep-host`; koffi bindings for scene bulk packers (ABI 321-324); mirrors `_scene_bulk_native.py` | — |
| `packages/xy-node/src/temporal-graph.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/vscode.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/__init__.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_abi_generated.py` | Python low-level ABI binding | `python-abi-generated` | `generate` | #57 |
| `python/xyg/_wasm_aggregate_generated.py` | Generated cross-host WASM contract binding | `browser-wasm-generated` | `generate` | #59 |
| `python/xyg/_annotations.py` | Python host | `python-host` | `keep-host`; re-export hub for `_annotations_*` mixins bound onto Figure | — |
| `python/xyg/_annotations_marks.py` | Python host | `python-host` | `keep-host`; text/label/marker/arrow/callout annotation builders | — |
| `python/xyg/_annotations_rules.py` | Python host | `python-host` | `keep-host`; rule/band/threshold annotation builders | — |
| `python/xyg/_annotations_spec.py` | Python host | `python-host` | `keep-host`; annotation spec compilation helpers | — |
| `python/xyg/_arrowgeom.py` | Python host | `python-host` | `keep-host`; ABI 217 owns connectionstyle/shaft/taper/trim/end geometry; ABI 254 owns `start_offset`/`label_clear` CSV pack; ABI 257 owns `arrow_shapes` orchestration; hosts coerce style keys and unpack kernel buffers; ChartView still parses CSV until WASM | — |
| `python/xyg/_benchmark_theme.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_chromium.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_channels_colormap.py` | Python host | `python-host` | `keep-host`; built-in colormap names and custom ramp resolution via Rust ABIs | — |
| `python/xyg/_channels_labels.py` | Python host | `python-host` | `keep-host`; categorical label factorization and native probe routing | — |
| `python/xyg/_channels_lut.py` | Python host | `python-host` | `keep-host`; palette/colormap LUT packing and bin color resolve | — |
| `python/xyg/_channels_resolve.py` | Python host | `python-host` | `keep-host`; color/size/style channel resolution | — |
| `python/xyg/_channels_ship.py` | Python host | `python-host` | `keep-host`; wire encode and payload ship registry | — |
| `python/xyg/_channels_types.py` | Python host | `python-host` | `keep-host`; ColorChannel/SizeChannel/StyleChannel dataclasses | — |
| `python/xyg/_columns.py` | Python host | `python-host` | `keep-host`; shared payload column decode for static export emitters | — |
| `python/xyg/_figure.py` | Python host | `python-host` | `keep-host`; Figure composition hub binding `_figure_*.py` modules and mark methods | — |
| `python/xyg/_figure_ingest.py` | Python host | `python-host` | `keep-host`; column ingest, array coercion, category-axis positions, heatmap cell edges | — |
| `python/xyg/_figure_traces.py` | Python host | `python-host` | `keep-host`; rectangle trace assembly and finite-row selection | — |
| `python/xyg/_figure_autorange.py` | Python host | `python-host` | `keep-host`; XYAR autorange packing; mirrors Node `figure.js` autorange path | — |
| `python/xyg/_figure_axis.py` | Python host | `python-host` | `keep-host`; axis configuration, scale/kind resolution, payload axis spec assembly | — |
| `python/xyg/_figure_interaction.py` | Python host | `python-host` | `keep-host`; interaction configuration, polar validation, interaction/mark-style payload specs | — |
| `python/xyg/_figure_palette.py` | Python host | `python-host` | `keep-host`; categorical palette cycle and series color selection | — |
| `python/xyg/_figure_dom.py` | Python host | `python-host` | `keep-host`; DOM class inventory and payload dom spec assembly | — |
| `python/xyg/_figure_runtime.py` | Python host | `python-host` | `keep-host`; runtime interaction delegates (widget comm path) | — |
| `python/xyg/_figure_view_state.py` | Python host | `python-host` | `keep-host`; durable view-state cache and state_patch wire messages | — |
| `python/xyg/_figure_export.py` | Python host | `python-host` | `keep-host`; display and static export entry points | — |
| `python/xyg/_fontmetrics.py` | Python host | `python-host` | `keep-host`; generated DejaVu advance table mirrored from Rust `font.rs` for compat SVG gutters | — |
| `python/xyg/_framing.py` | Python host | `python-host` | `keep-host`; XYBF transport framing, not chart policy | — |
| `python/xyg/_geoarrow.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geoviewport.py` | Python host | `python-host` | `keep-host`; typed XYVC/XYVR framing only; Rust owns camera/projection policy | — |
| `python/xyg/_graph.py` | Python host | `python-host` | `keep-host`; ingest/id maps; layout is `xyg_graph_layout` | — |
| `python/xyg/_graph_session.py` | Python host | `python-host` | `keep-host`; `GraphSession.__init__/_command/close` marshal opaque bytes into generated `_native._lib.xyg_graphforge_session_*` / `xyg_graphforge_coordinate_deliver` calls and serialize native handle lifetime/exact-capacity retries; [private transport contract](graph-session-python-transport.md) bounds Python to buffer coercion/lifecycle, with identity, sequence, admission, layout, selection, geometry and stamps in Rust | — |
| `python/xyg/_graphforge.py` | Python host | `python-host` | `keep-host`; GraphForge composition framing/decoding and chart wiring over the Rust C ABI (Node `graphforge.js` twin) | — |
| `python/xyg/_graphforge_container.py` | Python host | `python-host` | `keep-host`; `XYGQ`/`XYGF` container codec (byte-identical to Node and browser) | — |
| `python/xyg/_hosts.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_jpeg.py` | Python host | `python-host` | `keep-host`; ABI 114 moves baseline JPEG encode into Rust; this module only coerces a NumPy array and forwards `quality` | #274 |
| `python/xyg/_facets_data.py` | Python host | `python-host` | `keep-host`; facet row subsetting and column factorization | — |
| `python/xyg/_facets_grid.py` | Python host | `python-host` | `keep-host`; FacetGrid layout and static export composition | — |
| `python/xyg/_layout.py` | Python host | `python-host` | `keep-host`; shared static-export scale, polar projection, axis scales, wedge flatten, and grid warp for `_svg`/`_raster` | — |
| `python/xyg/_legendfit.py` | Python host | `python-host` | `keep-host`; ABI 120 occupancy scoring; ABI 197 Scene product encode settles `loc="best"` from XYCL/XYNM. This module still packs ChartView compatibility specs | — |
| `python/xyg/_lod_drill.py` | Python host | `python-host` | `keep-host`; drill-down subset bookkeeping on traces | — |
| `python/xyg/_lod_encode.py` | Python host | `python-host` | `keep-host`; offset-encoded geometry columns and wire buffer packing | — |
| `python/xyg/_lod_params.py` | Python host | `python-host` | `keep-host`; shared LOD argument coercion helpers | — |
| `python/xyg/_lod_plan.py` | Python host | `python-host` | `keep-host`; tier planning, grid shape, local log density | — |
| `python/xyg/_lod_sample.py` | Python host | `python-host` | `keep-host`; deterministic sampling tiers for LOD overlays | — |
| `python/xyg/_lod_types.py` | Python host | `python-host` | `keep-host`; LodPlan/EncodedColumn dataclasses and sampling constants | — |
| `python/xyg/_lod_viewport.py` | Python host | `python-host` | `keep-host`; viewport validation, visible mask, aligned window | — |
| `python/xyg/_native.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_ooc.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_paint.py` | Python host | `python-host` | `keep-host`; shared static-export paint/grid resolution for `_svg`/`_raster` (`trace_paint_rgba`, grid RGBA decode, stroke/CSS metadata helpers, `colormap_lut`, CSS→RGBA8); ABI 206 owns `effective_rgba`; `triangle_mesh_boundary` recorded stay-host joined-fill geometry | — |
| `python/xyg/_payload.py` | Python host | `python-host` | `keep-host`; marshal-only `build_payload` delegating to ABI 303 + ABI 321 via `_payload_trace_materialize.py` | — |
| `python/xyg/_payload_helpers.py` | Python host | `python-payload-migration` | `keep-host`; transition/tooltip attach, visible-mask predicates, binning coords, channel ship delegates | — |
| `python/xyg/_tooltip_columns.py` | Python host | `python-host` | `keep-host`; typed tooltip-column wire packing (byte-identical to Node) | — |
| `python/xyg/_graph_wire.py` | Python host | `python-host` | `keep-host`; wire form of graph meta (host-only identity planes omitted) | — |
| `python/xyg/_payload_ship.py` | Python host | `python-payload-migration` | `keep-host`; column registry gather + ship via `payload_column_gather_materialize` (ABI 310/314) | — |
| `python/xyg/_payload_spec_attach.py` | Python host | `python-payload-migration` | `keep-host`; apply `payload_build_plan` optional top-level spec attach fields (ABI 303) | — |
| `python/xyg/_payload_trace_materialize.py` | Python host | `python-host` | `keep-host`; ABI 321 trace emit materialize marshal | — |
| `python/xyg/_payload_writer.py` | Python host | `python-payload-migration` | `keep-host`; wire blob + column table accumulator for `build_payload` (§29 ship helpers) | — |
| `python/xyg/_payload_density.py` | Python host | `python-payload-migration` | `keep-host`; density tier payload helpers: grid ship (ABI 315/316), sample overlay, wasm source attach | — |
| `python/xyg/_pdf.py` | Python host | `python-host` | `keep-host`; ABI 113 moves closed-subset SVG→PDF into Rust; this module only coerces UTF-8 and raises the historical diagnostic wording | #274 |
| `python/xyg/_png.py` | Python host | `python-host` | `keep-host`; ABI 115 moves filter-0 PNG encode into Rust; this module only coerces host buffers and forwards `mode` / `compression` | #274 |
| `python/xyg/_sankey.py` | Python host | `python-host` | `keep-host`; ABI `xyg_sankey_layout`; this module resolves names and error text | — |
| `python/xyg/_marks_distribution.py` | Python host | `python-host` | `keep-host`; box/violin marks and shared multi-group helpers; mirrors Node `marks/distribution.js` | — |
| `python/xyg/_marks_style.py` | Python host | `python-host` | `keep-host`; cross-cutting mark style coercion and segment trace assembly | — |
| `python/xyg/_marks_bar.py` | Python host | `python-host` | `keep-host`; bar/column rect marks and multi-series style helpers; mirrors Node `marks/bar.js` | — |
| `python/xyg/_marks_contour.py` | Python host | `python-host` | `keep-host`; contour isolines and filled bands; mirrors Node `marks/contour.js` | — |
| `python/xyg/_marks_scatter.py` | Python host | `python-host` | `keep-host`; scatter mark with density fallback; mirrors Node `marks/scatter.js` | — |
| `python/xyg/_marks_errorbar.py` | Python host | `python-host` | `keep-host`; errorbar/error_band marks; mirrors Node `marks/errorbar.js` | — |
| `python/xyg/_marks_hexbin.py` | Python host | `python-host` | `keep-host`; hexbin density mark; mirrors Node `marks/hexbin.js` | — |
| `python/xyg/_marks_heatmap.py` | Python host | `python-host` | `keep-host`; heatmap grid mark; mirrors Node `marks/heatmap.js` | — |
| `python/xyg/_marks_line.py` | Python host | `python-host` | `keep-host`; line and area marks; mirrors Node `marks/line.js` / `marks/area.js` | — |
| `python/xyg/_marks_histogram.py` | Python host | `python-host` | `keep-host`; histogram/hist marks; mirrors Node `marks/histogram.js` | — |
| `python/xyg/_marks_ribbon.py` | Python host | `python-host` | `keep-host`; ribbon flow-band mark; mirrors Node `marks/ribbon.js` | — |
| `python/xyg/_marks_segments.py` | Python host | `python-host` | `keep-host`; segments line mark; mirrors Node `marks/segments.js` | — |
| `python/xyg/_marks_step.py` | Python host | `python-host` | `keep-host`; step/stairs/ecdf/stem marks; mirrors Node step/ecdf/stem modules | — |
| `python/xyg/_graph_static.py` | Python host | `python-host` | `keep-host`; reads a composed graph's resolved planes off its traces and strips them for the plain static pass; Rust rebuilds the Scene (`xyg_graph_composed_scene`); mirrors Node `composedGraphPlanes` | — |
| `python/xyg/_marks_graph.py` | Python host | `python-host` | `keep-host`; graph mark; mirrors Node `graph.js` | — |
| `python/xyg/_marks_sankey.py` | Python host | `python-host` | `keep-host`; sankey mark; mirrors Node `sankey.js` | — |
| `python/xyg/_marks_triangle_mesh.py` | Python host | `python-host` | `keep-host`; triangle mesh mark; mirrors Node `marks/triangle_mesh.js` | — |
| `python/xyg/_scene.py` | Python host | `python-host` | `keep-host`; ABI 121 tessellation wrappers; `grid_rgba` uses ABI 129/206 colormap kernels | — |
| `python/xyg/_scene_annotations.py` | Python host | `python-scene-migration` | `keep-host`; colorbar + XYAF validate/pack delegates | — |
| `python/xyg/_scene_errors.py` | Python host | `python-scene-migration` | `keep-host`; maps Rust Scene encode errors to Python exceptions for `figure_scene` | — |
| `python/xyg/_scene_marshal.py` | Python host | `python-host` | `keep-host`; chrome/export/XYTC/XYTA marshal helpers calling ABI 319-325 bulk packers | — |
| `python/xyg/_scene_observations.py` | Python host | `python-scene-migration` | `keep-host`; trace/figure observation helpers delegating admit/classify to Rust | — |
| `python/xyg/_scene_sidecars.py` | Python host | `python-scene-migration` | `keep-host`; XYCL/XYNM sidecars and thin ABI pack delegates | — |
| `python/xyg/_scene_unpack.py` | Python host | `python-scene-migration` | `keep-host`; Scene record unpack helpers for tests and export consumers | — |
| `python/xyg/_scene_bulk_native.py` | Python host | `python-scene-migration` | `keep-host`; ctypes bindings for scene bulk packers (ABI 321-324) | — |
| `python/xyg/_scene_v3.py` | Python host | `python-host` | `keep-host`; marshal-only `figure_scene` entry delegating to `_scene_marshal.py` + Rust encode | — |
| `python/xyg/_spatial.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_svg.py` | Python compat facade | `python-host` | `keep-host`; re-exports the pyplot measurement surface (`_layout` tick/layout helpers), `_paint` LUT alias, and static slot metadata; no renderer or layout policy remains in the module | — |
| `python/xyg/_static_document.py` | Python static-product adapter | `python-host` | `keep-host`; coerces public Figure/facet/pyplot facts, packs bounded XYST/XYSL/XYPC/XYLF/XYDA/XYDL frames, invokes generated native calls, and translates stable errors; no renderer/layout/scoring/glyph/style-default policy | — |
| `python/xyg/_textblock.py` | Python host | `python-host` | `keep-host`; ABI 125 packer plus a pass-scoped measurement cache | — |
| `python/xyg/_trace.py` | Python host | `python-host` | `keep-host`; ABI 122 owns the density/M4 threshold decision; this module packs kind/force/per-item onto `payload_tier` | — |
| `python/xyg/_typing.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_validate.py` | Python host | `python-host` | `keep-host`; `resolved_hex_paint` quantizes css_check 0-1 through ABI 251; `colormap_stops` delegates to ABI 349 | — |
| `python/xyg/_webp.py` | Python host | `python-host` | `keep-host`; ABI 114 moves lossless WebP encode into Rust; this module only coerces a NumPy array | #274 |
| `python/xyg/channel.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/channels.py` | Python host | `python-host` | `keep-host`; re-export hub for `_channels_*` modules (color/size/style resolve + wire ship) | — |
| `python/xyg/columns.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/components.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/config.py` | Python host | `python-host` | `keep-host`; lazy immutable ABI 360 proxy for the Rust-owned default palette avoids the native-binding import cycle | — |
| `python/xyg/dom.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/export.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/facets.py` | Python host | `python-host` | `keep-host`; re-export hub for `_facets_*` facet grid modules | — |
| `python/xyg/graph_layout.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/interaction.py` | Python host | `python-host` | `keep-host`; ABI 204 owns line/area re-decimate skip, closed-window ulp, and polar skip | — |
| `python/xyg/kernels.py` | Python host | `python-host` | `keep-host`; ABI 256 `scene_channel_constant_css` wrapper | — |
| `python/xyg/lod.py` | Python host | `python-host` | `keep-host`; re-export hub for `_lod_*` modules (viewport, plan, sample, drill, encode) | — |
| `python/xyg/marks.py` | Python host | `python-host` | `keep-host`; re-export hub for `_marks_*` modules bound onto Figure | — |
| `python/xyg/plugins.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/__init__.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_artists.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_axes.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_axisgrid.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_colors.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_fmt.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_grid.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_markers.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_mathtext.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_mplfig.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_plot_types.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_rc.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_state.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_ticker.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_transforms.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/_translate.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/pyplot/dates.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/styles.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/styling/__init__.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/styling/capabilities.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/temporal_controller.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/temporal_graph.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_graph_widget.py` | Python host | `python-host` | `keep-host`; native checkpoint scheduling and revisioned notebook transport only | — |
| `python/xyg/_graph_widget_identity.py` | Python host | `python-host` | `keep-host`; packs Rust identity requests and joins existing Rust membership planes | — |
| `python/xyg/widget.py` | Python host | `python-host` | `keep-host` | — |
| `crates/xyg-engine/src/geo_layers.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_layers_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_interaction.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/marker_geometry.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-wasm/src/bin/geo_layers_conformance.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `python/xyg/_geocatalog.py` | Python host | `python-host` | `keep-host` | — |
| `packages/xy-node/src/geocatalog.js` | Node host | `node-host` | `keep-host` | — |
| `js/src/61_geo_catalog.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/62_geographic_controller.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/bin/geo_scale_bench.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_lod.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_lod_hit.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_mixed_frame.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_lod_scene.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_membership_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_membership_session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_retained_painter.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_overview_painter_snapshot_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_scale_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_scale_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_simplify.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_snapshot.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_snapshot_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_source.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_source_session.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_tile_cache.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_tile_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_tile_scene.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_tile_scene_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_transport.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-wasm/src/bin/geo_scale_conformance.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |
| `js/src/63_geo_source.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/65_geo_host.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/64_geo_retained_controller.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-retained.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-live-host.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-webview.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-webview.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-retained.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-spatial.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-snapshot.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-spatial.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-snapshot.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-tiles.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-tiles.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geoscale.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geoscale.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/_geo_live_host.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_host.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_retained.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_spatial.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_snapshot.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_tiles.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geoscale.py` | Python host | `python-host` | `keep-host` | — |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_mixed_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_mixed_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `js/src/66_geo_mixed.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-mixed-wire.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-mixed.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-mixed.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/_geo_mixed.py` | Python host | `python-host` | `keep-host` | — |
| `crates/xyg-engine/src/geo_linked_state_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_linked_state_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_selected_snapshot_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_spatial_hierarchy.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_spatial_hierarchy_build.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_spatial_hierarchy_query.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_spatial_hierarchy_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_hierarchy_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_hierarchy_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/bin/geo_hierarchy_bench.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_selected_hierarchy_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |

The hierarchy protocol child reuses the shared private GeoScale registry, canonical
Scene encoder, owning source/result leases and common quotas. Its tests exercise
public typed bytes; no host geometry or separate publication policy is introduced.
See `geo-hierarchy-protocol.md` for the command and authority boundary.

### M6 typed overview transport

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `js/src/67_geo_overview.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `js/src/71_geo_overview_owner.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-overview.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-overview.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-overview-source.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-overview-source.d.ts` | Node host | `node-host` | `keep-host` | — |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `js/src/70_geo_hierarchy.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-hierarchy-wire.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-hierarchy.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-hierarchy.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/_geo_hierarchy.py` | Python host | `python-host` | `keep-host` | — |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `js/src/68_geo_selected.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-selected.d.ts` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-selected.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/_geo_selected.py` | Python host | `python-host` | `keep-host` | — |
### M6 internal Python overview transport

The adapter forwards Rust commands and validates typed framing, capacity and
callback lifetime under `geo-temporal-overview-protocol.md`. Rust retains all
temporal counts, source authority, cell geometry and palette policy.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `python/xyg/_geo_overview.py` | Python host | `python-host` | `keep-host` | — |
| `python/xyg/_geo_overview_source.py` | Python host | `python-host` | `keep-host` | — |



### M6 exact overview domain-cell membership

The private source driver reuses one canonical authenticated scan/ACK lifecycle.
The overview matcher owns domain-cell policy and immutable continuation authority;
its focused test module contains no production policy.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_source_membership_driver.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_membership.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_temporal_overview_membership_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_overview_membership_protocol.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_overview_membership_protocol_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
### M6 public temporal overview browser lifecycle

The browser controller validates private Worker/index/frame provenance and owns
publication, callback settlement, painter retirement and bounded count-table DOM.
Rust continues to own temporal/domain policy, projection, counts and paint buffers.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `js/src/71_geo_overview_controller.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |



### M6 typed geographic transport and bounded hierarchy

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_allocation_recovery.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_allocation_recovery_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/geo_snapshot_recovery_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `js/src/74_geo_overview_snapshot.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
### Issued overview membership adapters

| `js/src/73_geo_overview_members.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `python/xyg/_geo_overview_members.py` | Python host | `python-host` | `keep-host` | — |
| `packages/xy-node/src/geo-overview-members.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/geo-overview-members.d.ts` | Node host | `node-host` | `keep-host` | — |



### Issued overview allocation recovery

These adapters capture exact requests, private producer identity and canonical
cleanup before dispatch. Rust owns receipt banks, birth/phase authentication,
quotas and temporal/domain policy. Node output is mechanically generated from
TypeScript; Python owns its asynchronous settlement ergonomics.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `js/src/72_geo_allocation_attempt.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |
| `packages/xy-node/src/geo-allocation-attempt.js` | Node host | `node-host` | `keep-host` | — |
| `python/xyg/_geo_allocation_recovery.py` | Python host | `python-host` | `keep-host` | — |



### M6 selected mutation recovery proof

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_selected_mutation_recovery_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |



### M6 selected publication recovery proof

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_selected_publication_recovery_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |



### M6 hierarchy Scope local-credit regression

This Rust file is cfg-test-only byte-protocol/resource evidence. The mechanical
ledger applies the engine policy; it adds no shipped execution path.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_hierarchy_scope_credit_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |

### M6 selected hierarchy recovery proofs

The new cfg(test) file frames byte-level tests only. It reuses canonical hierarchy
admission, Scene encoding, private registry authorities and the existing receipt
bank; it introduces no alternate host policy or production constructor.

| File | Current owner | Policy | Disposition | Follow-up issue |
| --- | --- | --- | --- | --- |
| `crates/xyg-engine/src/geo_hierarchy_recovery_tests.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |

## Public43 admission host boundary

The existing70/Python hierarchy and72 allocation owners adopt only authentic
exact264-byte command43 admission and strict47 confirmation. Native capture adds
43 to its existing fixed16 mutation bank, with no new Query6/10 purpose. Storage,
geometry, selection and LOD policy stay Rust-owned. Mechanical Node outputs
reuse that lifecycle. New `tests/browser/geo_hierarchy_admission_capture_entry.ts`,
`tests/browser/geo_hierarchy_admission_hosts_page.mjs` and
`scripts/geo_hierarchy_admission_hosts_smoke.mjs` are test-only and outside the
production inventory. No new production file requires a JSON inventory row.
[Bounded evidence](../performance/geo-hierarchy-admission-hosts-2026-10-10/README.md)
records the remaining44 and lostQuery10 guards.

### GraphSession S4 wire and ABI ownership

These additions use the existing ownership policies without adding a host policy path.

| File | Current owner | Policy | Disposition | Follow-up |
|---|---|---|---|---|
| `crates/xyg-core/src/graphforge_session_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/wire.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/wire_memory.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/wire_paint.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-wasm/src/graphforge_session.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm` | #59 |


| `packages/xy-node/src/graphforge_layout.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/graphforge_layout_worker.js` | Node host | `node-host` | `keep-host` | — |

| `crates/xyg-engine/src/graphforge/interaction/tests/wire/picked.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/picked_checkpoint.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/projection_probe.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/projection_reuse.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-engine/src/graphforge/interaction/tests/wire/representation.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |

| `crates/xyg-engine/src/filter_tier_c.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `crates/xyg-core/src/filter_session_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust` | — |
| `python/xyg/filter_session.py` | Python host | `python-host` | `keep-host` | — |
| `packages/xy-node/src/filter-session.js` | Node host | `node-host` | `keep-host` | — |
| `packages/xy-node/src/filter-protocol.js` | Node host | `node-host` | `keep-host` | — |
| `js/src/49_filter_session.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm` | #59 |

| `crates/xyg-engine/src/filter_tier_c_linked.rs` | Rust safe engine | `rust-engine` | `keep-rust` | — |
| `js/src/49_filter_dashboard.ts` | Shared TypeScript browser client | `browser-client` | `keep-shared-client` | — |
| `crates/xyg-engine/src/temporal_scene.rs` | Rust safe engine | rust-engine | keep-rust |
| `js/src/75_temporal_scene.ts` | Browser adapter | browser-wasm-adapter | implement-rust-wasm |
| `packages/xy-node/src/temporal-scene-framing.js` | Node host | node-host | keep-host |
| `packages/xy-node/src/temporal-scene.js` | Node host | node-host | keep-host |
| `python/xyg/_temporal_scene.py` | Python host | python-host | keep-host |
| `python/xyg/_geo_temporal.py` | Python host | `python-host` | `keep-host` | — |
| `packages/xy-node/src/geo-temporal.js` | Node host | `node-host` | `keep-host` | — |
| `crates/xyg-engine/src/graph_marker_contour.rs` | Rust safe engine | `rust-engine` | `keep-rust`; The safe engine is the single implementation of parity-affecting behavior. | — |
| `crates/xyg-engine/src/retained_png.rs` | Rust safe engine | `rust-engine` | `keep-rust`; Shared checked raster/PNG capability adapter. | — |
| `crates/xyg-engine/src/shared_sort.rs` | Rust safe engine | `rust-engine` | `keep-rust`; Shared standard-library stable-sort bodies for the bounded browser module. | — |
| `crates/xyg-engine/src/temporal_graph_export.rs` | Rust safe engine | `rust-engine` | `keep-rust`; The safe engine is the single implementation of parity-affecting behavior. | — |
| `crates/xyg-engine/src/temporal_graph_frozen.rs` | Rust safe engine | `rust-engine` | `keep-rust`; The safe engine is the single implementation of parity-affecting behavior. | — |
| `crates/xyg-core/src/temporal_graph_frozen_ffi.rs` | Rust C ABI shell | `rust-c-abi` | `keep-rust`; One versioned cdylib serves ctypes, Koffi, and future browser-facing adapters. | — |
| `crates/xyg-wasm/src/temporal_graph_frozen.rs` | Rust WASM lifecycle adapter | `rust-wasm-abi` | `implement-rust-wasm`; Issue #59 needs a minimal target-specific lifecycle shell over the same safe Rust engine. | #59 |
| `python/xyg/_temporal_graph_frozen.py` | Python host | `python-host` | `keep-host`; This file provides Python-specific ergonomics without making Rust-owned product decisions. | — |
| `packages/xy-node/src/temporal-graph-frozen.js` | Node host | `node-host` | `keep-host`; This file is a Node-specific shell around shared engine and paint-client contracts. | — |
| `js/src/67_frozen_graph.ts` | Shared TypeScript WASM lifecycle adapter | `browser-wasm-adapter` | `implement-rust-wasm`; Issue #59 keeps browser lifecycle thin while the same Rust engine owns computation. | #59 |

| `python/xyg/_chunked_live.py` | Python host | `python-host` | `keep-host`; bounded native read/ACK lifecycle and exact identity transport | — |
| `packages/xy-node/src/chunked-live.js` | Node host | `node-host` | `keep-host`; asynchronous native read/ACK lifecycle and exact identity transport | — |

## Contributor rule

Run `python3 scripts/verify_ownership.py` after adding, removing, or renaming production source. A new file is intentionally unclassified until this ledger names its owner and boundary in the same change. Moving a file between policies requires updating both this audit and its JSON twin; do not weaken a policy to make a new host algorithm pass.

A new or changed `python-host` / `node-host` classification must cite the exact
code path that only marshals/coerces into a native call, or the exact spec
section that authorizes host ownership. Repeating the policy's generic
"host shell" rationale is not classification evidence. A ledger-only
reclassification is valid only when that evidence shows the product code was
already marshal/coerce-only; otherwise the same change must move the policy to
Rust or carry a numbered migration issue.

## Geographic catalog and interaction additions

Rust owns catalog compilation, source identity, glyph predicates, bounded picking
and state transitions. Browser code captures events, paints the shared Scene
and presents paged companion rows; the shell supplies its WebGL context.

## Retained geographic source and tile ownership

- `crates/xyg-engine/src/bin/geo_scale_bench.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_lod.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_lod_hit.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_lod_scene.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_membership_protocol_tests.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_membership_session.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_retained_painter.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_scale_protocol.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_scale_protocol_tests.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_simplify.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_snapshot.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_snapshot_protocol.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_source.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_source_session.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_tile_cache.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_tile_protocol.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_tile_scene.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_tile_scene_tests.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-engine/src/geo_transport.rs`: **rust-engine**. Retained geographic source, LOD, membership, tile, snapshot, and quota decisions are shared engine policy; see spec/design/geo-retained-source.md, geo-scale-protocol.md, geo-tile-protocol.md, and geo-frozen-export.md.
- `crates/xyg-wasm/src/bin/geo_scale_conformance.rs`: **rust-wasm-abi**. Bounded WASM retained-source oracle and marshaling use the shared geographic engine; see spec/design/geo-transport.md.
- `js/src/63_geo_source.ts`: **browser-wasm-adapter**. Browser retained geographic framing, DOM provenance, cancellation, and Worker ownership call Rust for projection, reduction, picking, and membership; see spec/design/geo-transport.md and geo-retained-hosts.md.
- `js/src/64_geo_retained_controller.ts`: **browser-wasm-adapter**. Browser retained geographic framing, DOM provenance, cancellation, and Worker ownership call Rust for projection, reduction, picking, and membership; see spec/design/geo-transport.md and geo-retained-hosts.md.
- `packages/xy-node/src/geo-retained.d.ts`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geo-retained.js`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geo-snapshot.d.ts`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geo-snapshot.js`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geo-tiles.d.ts`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geo-tiles.js`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geoscale.d.ts`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `packages/xy-node/src/geoscale.js`: **node-host**. Node geographic ownership and typed binary framing call the shared native engine; see spec/design/geo-retained-hosts.md and geo-tile-protocol.md.
- `python/xyg/_geo_retained.py`: **python-host**. Python geographic ownership, asynchronous reader lifecycle, and typed binary framing call the native engine without reimplementing geographic policy; see spec/design/geo-retained-hosts.md and geo-frozen-export.md.
- `python/xyg/_geo_snapshot.py`: **python-host**. Python geographic ownership, asynchronous reader lifecycle, and typed binary framing call the native engine without reimplementing geographic policy; see spec/design/geo-retained-hosts.md and geo-frozen-export.md.
- `python/xyg/_geo_tiles.py`: **python-host**. Python geographic ownership, asynchronous reader lifecycle, and typed binary framing call the native engine without reimplementing geographic policy; see spec/design/geo-retained-hosts.md and geo-frozen-export.md.
- `python/xyg/_geoscale.py`: **python-host**. Python geographic ownership, asynchronous reader lifecycle, and typed binary framing call the native engine without reimplementing geographic policy; see spec/design/geo-retained-hosts.md and geo-frozen-export.md.

The temporal overview selected-input repair keeps canonical admission in Rust: command27 rejects private selected/Scope authority before a source-only builder can discard it. Shared typed/Python frame-aware encoders provide pre-dispatch rejection without a new chart constructor or duplicated temporal policy. Empty selected intent remains selected; ordinary None count/Scene contracts are unchanged. [Bounded proof](../performance/geo-overview-selected-guard-2026-10-09/README.md).

Selected19 dispatcher evidence adds only test-owned
`tests/browser/geo_selected19_capture_entry.mjs` and
`scripts/geo_selected19_capture_smoke.mjs`; these remain outside the production
inventory above. The existing browser transport owner for `js/src/47_wasm.ts`
retains its responsibility; no host geometry or selection policy was added.

Hierarchy43/44 dispatcher evidence adds test-owned
`tests/browser/geo_hierarchy_capture_entry.mjs` and
`scripts/geo_hierarchy_capture_smoke.mjs`, outside the production inventory.
The existing browser transport owner for `js/src/47_wasm.ts` remains unchanged;
[the exact capture contract](geo-hierarchy-dispatch-capture.md) adds no host
geometry, selection policy, or new public surface.


Graph #36 S3 retains typed picking geometry in `graphforge/interaction/paint.rs`
and its bounded index/query policy in `pick.rs`; both read the one session
publication, never a Scene or independent layout. `interaction/update.rs`
validates full replacements and reconciles the temporal owner's state under one
lock. `interaction/coordination.rs` owns exact graph snapshot ordering/delivery;
`coordination.rs` is the small validation/commit gate shared with the temporal
controller (whose range validation and no-op behavior stay unchanged). These
Rust-only changes introduce no host, ABI or browser policy surface.


Bounded #36 S5b adds the three TypeScript product files listed above.
`47_wasm.ts` owns the one serialized non-cancellable retained graph byte lane,
exact request retention, reply/lifetime matching and CLOSE/drain lifecycle;
`wasm_worker.ts` stages only existing session exports and copies a complete
successful XYGR reply. Both reject unrelated compiler/job/geo ownership before
staging can mutate the retained session. `49_wasm_graphforge.ts` factors raw
named-section/UUID framing without eagerly decoding unused CPU planes.
`40_gl.ts` retains generic GL lifecycle and raw-buffer paint ownership. The
controller never scans source rows, resolves identities, calculates selection
or CSR neighborhoods, generates geometry/styles, or calls legacy CPU hit-test/
selection paths. `58_graph.ts` remains for ordinary host graph payloads until
S6; this bounded attachment does not remove that migration debt. Exact hover/
picked-ref wire projection and broader S5b/S6/S7 remain open. See the
[contract](graph-interaction.md#bounded-explicit-s5b-attachment) and
[append-only proof](../performance/graph-s5b-attachment-2026-11-04/README.md).


The retained graph R2 repair keeps Clear applicability in the shared Rust owner:
`GraphInteractionState::can_clear` is reused by Clear and the XYGR serializer's
post-operation state snapshot. TypeScript validates this required fact and owns
synchronous keyboard default cancellation after local command admission. It does
not infer applicability from selection counts, projected refs, styles or DOM.
GLHost resets textures/samplers through unit 2 for shared-client isolation.


The R7 inventory review disposition classifies the five R6 picked-target Rust
test modules in the file ledger under the existing `rust-engine` policy, without
a new policy or exclusion. They cover exact receipts, projection admission,
retry/atomicity and diagnostic corpus generation for the shared Rust owner.

The #112 programmatic filter session owns canonical source identity, cumulative
counts, exact-boundary admission, budget, intent and publication in
`xyg-engine::filter_tier_c`. New Python/Node/browser modules only frame the
same raw XYFC/XYFR packets and own handles/Worker lifecycle. No ordinary filter
policy is migrated to hosts and no renderer or GPU ledger is introduced.

Linked density additions use the same ownership boundary: Rust owns the exact
count/paint protocol, and the shared client owns DOM input and ordinary GPU
trace lifecycle. The two files are classified in the file ledger above.
The partial temporal catalog owns exact membership/ticks/geometry in
`xyg-engine::temporal_scene`; Python, Node and browser framing modules only
pack source rows and call that compiler. See temporal-catalog.md for unshipped
interaction, dense-LOD and packaging requirements.
### Frozen retained graph export continuation

`graph_marker_contour.rs`, `temporal_graph_frozen.rs` and
`temporal_graph_export.rs` are **rust-engine**: bounded shared-SDF lowering,
phase splitting, immutable provenance, carrier validation and shared Scene
export. `xyg-core/temporal_graph_frozen_ffi.rs` is **rust-c-abi**.
`xyg-wasm/temporal_graph_frozen.rs` is **rust-wasm-abi**, borrowing actual
accepted private owners and enforcing lifetime/budget/status boundaries.
`js/src/67_frozen_graph.ts` is **browser-wasm-adapter**: binary framing and owned
copies only. The controller captures computed CSS through the existing painter
parser. Python/Node frozen modules are **python-host**/**node-host** package
client discovery, scalar marshaling and native ownership. No second chart
builder, layout, routing, semantic style resolver or renderer is introduced.

The shared retained PNG continuation adds `retained_png.rs` (checked allocation
and command capability admission) and `shared_sort.rs` (one standard-library
stable-sort body per browser record type). Both are **rust-engine**. The existing
raster/PNG implementation, draw policy and full native text routes remain shared.
`vendor/png` and `vendor/crc32fast` retain the existing dependency algorithms and
licenses with auditable compile-time capability/table changes; they do not move
product policy into hosts. Callback sharing keeps the same Rust transaction
validation, locking and lifetime sequence.

Both Worker entries call `wasm_frozen_graph.ts` for bounded XYFX byte staging
and owned output copying. The module and strict-CSP offline classic Worker
invoke the same Rust export/recovery operation; no export policy enters JS.

Native chunked-chart continuation owns only lifecycle and transport:

| Source | Policy | Disposition |
| --- | --- | --- |
| `python/xyg/_chunked_live.py` | python-host | keep-host |
| `packages/xy-node/src/chunked-live.js` | node-host | keep-host |

Rust retains admission, chunk selection, canonical predicates, identity and paint encoding.
