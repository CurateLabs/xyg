from pathlib import Path
import ast,ctypes,gzip,hashlib,json,os,shlex,subprocess,sys
root=Path.cwd();d=root/'target/task-tmp/filter-catalog-union';out=root/'spec/performance/filter-catalog-abi-union-2026-11-07';A='c90fcd3047e4cac69c307ffe1f27c37c4d69c0f8';B='b8000a60900d4685969a6d68f55324e561199df5'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def git(c,p):return subprocess.check_output(['git','show',c+':'+p])
def zipped(name,raw):
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);archive=gzip.compress(raw,mtime=0);dest.write_bytes(archive)
 return {'file':str(dest.relative_to(root)),'sha256':sha(archive),'bytes':len(archive),'rawSha256':sha(raw),'rawBytes':len(raw)}
def tree(c):
 result={}
 for row in subprocess.check_output(['git','ls-tree','-rz',c]).split(b'\0'):
  if row:
   meta,p=row.split(b'\t');m,t,h=meta.decode().split();result[p.decode()]={'mode':m,'type':t,'object':h}
 return result
pa,pb=tree(A),tree(B);protection=[];combined=[]
for p in sorted(pa.keys()|pb.keys()):
 f=root/p; assert f.exists() or f.is_symlink(),p
 raw=os.readlink(f).encode() if f.is_symlink() else f.read_bytes();h=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();matches=[n for n,t in [('filter',pa),('catalog',pb)] if t.get(p,{}).get('object')==h]
 mode='120000' if f.is_symlink() else ('100755' if os.access(f,os.X_OK) else '100644')
 row={'path':p,'parents':{n:t[p] for n,t in [('filter',pa),('catalog',pb)] if p in t},'current':{'mode':mode,'object':h},'matches':matches}
 if matches:protection.append(row)
 else:combined.append(row)
expected={'.cargo/config.toml','.gitattributes','crates/xyg-core/src/lib.rs','crates/xyg-engine/src/lib.rs','crates/xyg-wasm/src/lib.rs','js/src/47_wasm.ts','js/src/60_entries.ts','js/src/wasm_abi_generated.ts','js/src/wasm_worker.ts','packages/xy-node/package.json','packages/xy-node/src/_abi_generated.js','packages/xy-node/src/index.js','python/xyg/_abi_generated.py','python/xyg/_figure.py','python/xyg/components.py','scripts/gen_capability_matrix.py','scripts/wasm_foundation_smoke.mjs','spec/abi/xyg-abi.json','spec/abi/xyg.h','spec/api/capability-matrix.md','spec/design/build-ci.md','spec/design/filter-tier-c.md','spec/design/host-parity.md','spec/design/ownership-audit.json','spec/design/ownership-audit.md','spec/design/temporal-catalog.md','spec/design/wire-protocol.md','spec/releases/0.6.0-api-inventory.json','spec/wasm/abi.json','tests/browser/wasm_foundation_page.mjs','tests/test_cross_host_abi_transition.py','tests/test_graphforge_contract_corpus.py'}
transition=json.loads((out/'abi402-source-fixtures.json').read_text());expected.update(transition)
assert {r['path'] for r in combined}==expected,({'r':sorted({r['path'] for r in combined}-expected),'missing':sorted(expected-{r['path'] for r in combined})})
# No frozen performance/release blob is an integration exception, apart from the declared preparation inventory.
assert not any(r['path'].startswith(('spec/performance/','spec/temporal/evidence/','spec/releases/')) and r['path']!='spec/releases/0.6.0-api-inventory.json' for r in combined)
protected=zipped('parent-protection.json.gz',(json.dumps({'parents':[A,B],'protected':protection,'combined':combined},indent=2,sort_keys=True)+'\n').encode())
# Preserve every top-level Python composition definition from either parent.
def definitions(raw):
 t=ast.parse(raw);return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))}
current=definitions((root/'python/xyg/components.py').read_text());union={}
for c in [A,B]:
 for n,v in definitions(git(c,'python/xyg/components.py')).items():
  if n in union and union[n]!=v:
   assert n=='Chart',n
   oldclasses=[next(x for x in ast.parse(git(parent,'python/xyg/components.py')).body if isinstance(x,ast.ClassDef) and x.name=='Chart') for parent in [A,B]]
   methodmaps=[{x.name:ast.dump(x,include_attributes=False) for x in cls.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))} for cls in oldclasses]
   ma,mb=methodmaps;assert ma.keys()-mb.keys()=={'filter_session'};assert mb.keys()<=ma.keys();assert all(ma[k]==mb[k] for k in mb)
   assert [ast.dump(x,include_attributes=False) for x in oldclasses[0].body if not isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]==[ast.dump(x,include_attributes=False) for x in oldclasses[1].body if not isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]
   assert union[n]==current[n]
   continue
  union[n]=v
assert current==union
# Node command, ledger and API gaps are complete unions, not sums that hide duplication.
node=[json.loads(git(c,'packages/xy-node/package.json')) for c in [A,B]];now=json.loads((root/'packages/xy-node/package.json').read_text());commands=[shlex.split(v['scripts']['test']) for v in node];tests=list(dict.fromkeys(commands[0][2:]+commands[1][2:]));assert shlex.split(now['scripts']['test'])==commands[0][:2]+tests
for k in now:
 if k!='scripts':assert now[k]==node[0][k]==node[1][k]
for k,v in now['scripts'].items():
 if k!='test':assert v==node[0]['scripts'][k]==node[1]['scripts'][k]
ledger={}
for c in [A,B]:
 for v in json.loads(git(c,'spec/design/ownership-audit.json'))['files']:
  if v['path'] in ledger:assert ledger[v['path']]==v
  ledger[v['path']]=v
assert {v['path']:v for v in json.loads((root/'spec/design/ownership-audit.json').read_text())['files']}==ledger
inventory=json.loads((root/'spec/releases/0.6.0-api-inventory.json').read_text());gaps=set()
for c in [A,B]:gaps.update(json.loads(git(c,'spec/releases/0.6.0-api-inventory.json'))['gaps'])
assert set(inventory['gaps'])==gaps
write(out/'union-seams.json',{'parents':[A,B],'protectedPaths':len(protection),'combinedPaths':[v['path'] for v in combined],'noMissingParentPaths':True,'pythonTopLevelDefinitions':len(union),'allPythonDefinitionsParentExact':True,'nodeTestFiles':tests,'ownershipFiles':len(ledger),'preparationGaps':len(gaps),'noNewGaps':True,'protection':protected})
# Current provenance follows both immutable history chains. Only current hashes advance.
bind=json.loads((out/'current-bindings.json').read_text());bind['sourceIdentity']='Combined native ABI403/WASM37 filtering/catalog source, O2/inline50 wasm32 recipe; exact predecessor history retained.'
for p,h in bind['historicalBindings'].items():assert sha((root/p).read_bytes())==h,p
for p in bind['sourceSha256']:bind['sourceSha256'][p]=sha((root/p).read_bytes())
write(out/'current-bindings.json',bind)
inputs={}
for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0'):
 if p and ((p.startswith('crates/') and (p.endswith('.rs') or p.endswith('Cargo.toml'))) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']):inputs[p]=sha((root/p).read_bytes())
write(out/'rust-producer-inputs.json',{'sourceSha256':inputs,'nativeReleaseOptLevel':'3 (Cargo default, no native target override)','wasm32ReleaseOptLevel':'2','wasm32LlvmInlineThreshold':50,'toolchain':'1.96.0'})
assets={}
for p in ['target/release/libxyg_core.so','packages/xy-client/dist/index.js','packages/xy-client/dist/standalone.js','packages/xy-client/dist/wasm-worker.js','packages/xy-client/dist/xyg-wasm.wasm','packages/xy-client/dist/xyg-wasm.manifest.json','packages/xy-client/dist/xyg-wasm-inline.js','python/xyg/static/index.js','python/xyg/static/standalone.js','python/xyg/static/wasm-worker.js','python/xyg/static/xyg-wasm.wasm','python/xyg/static/xyg-wasm.manifest.json','python/xyg/static/xyg-wasm-inline.js']:
 f=root/p;raw=f.read_bytes();assets[p]={'sha256':sha(raw),'bytes':len(raw)}
assert assets['target/release/libxyg_core.so']['sha256']=='ed21f677c9e474814e408f534893befc4e53f0ab05bb40ae82c54ace0cff74ff'
lib=ctypes.CDLL(str(root/'target/release/libxyg_core.so'));assert lib.xyg_abi_version()==403
for name in ['index.js','standalone.js','wasm-worker.js','xyg-wasm.wasm','xyg-wasm.manifest.json','xyg-wasm-inline.js']:assert (root/'packages/xy-client/dist'/name).read_bytes()==(root/'python/xyg/static'/name).read_bytes(),name
archives={}
for f in sorted(d.glob('*.log')):archives[f.name]=zipped(f.name+'.gz',f.read_bytes())
for name in ['wasm-o3-inline50.raw.wasm','wasm-o3-inline50.wasm','wasm-o3-inline40.raw.wasm']:
 f=d/name;archives[name]=zipped(name+'.gz',f.read_bytes())
for name in ['run.py','assemble.py','loader-negatives.py','wasm-loader-negatives.mjs','profile-new-paths.mjs','catalog-html.py','foundation-proof-negatives.mjs','resolve.py','write_node_fixtures.py','final-contracts.py']:
 archives[name]=zipped('procedures/'+name+'.gz',(d/name).read_bytes())
reports={}
for name in ['profile-abba.json','profile-new-paths.json','linked-filter.json','loader-negatives.json','wasm-loader-negatives.json','foundation-proof-negatives.json','wasm-o3-inline50-source.json','wasm-o3-inline40-source.json','scheduling.json','foundation.json','foundation.json.retained-temporal.json']:
 f=d/name
 if f.exists():
  raw=f.read_bytes();dest=out/name;dest.write_bytes(raw);reports[name]={'sha256':sha(raw),'bytes':len(raw)}
captures={}
for f in sorted(list(d.glob('*.png'))+list((d/'catalog-html').glob('*.png'))):
 name=('catalog-' if f.parent.name=='catalog-html' else '')+f.name;raw=f.read_bytes();(out/name).write_bytes(raw);captures[name]={'sha256':sha(raw),'bytes':len(raw)}
for f in sorted((d/'catalog-html').glob('*.html')):archives['catalog-'+f.name]=zipped('catalog-'+f.name+'.gz',f.read_bytes())
for f in sorted(d.glob('*.requests.bin')):archives[f.name]=zipped(f.name+'.gz',f.read_bytes())
commands={f.name:json.loads(f.read_text()) for f in sorted(d.glob('*.exit.json'))}
write(out/'checks.json',{'schema':'xyg.filter-catalog-union-evidence/v1','parents':[A,B],'nativeAbi':403,'wasmAbi':37,'artifacts':assets,'sourceBindings':{'file':str((out/'current-bindings.json').relative_to(root)),'sha256':sha((out/'current-bindings.json').read_bytes()),'current':len(bind['sourceSha256']),'historical':len(bind['historicalBindings'])},'rustInputs':{'count':len(inputs),'sha256':sha((out/'rust-producer-inputs.json').read_bytes())},'protection':protected,'commands':commands,'archives':archives,'reports':reports,'captures':captures,'declarationManifests':{p:sha((out/p).read_bytes()) for p in ['native-symbol-union.json','wasm-export-union.json','abi402-source-fixtures.json','fixture-transition.json','abi402-transition.json','union-seams.json']},'limits':{'rawWasm':1927168,'node22Gzip6':786432},'freshResults':{'pythonAffected':194,'nodePassed':1112,'nodeExistingSkips':2,'engineFilter':7,'engineTemporal':2,'wasmHost':76,'abiSmoke':673,'coreInventoryOwnership':42},'limitations':['Combined current source has not yet received its independent final diff review or hosted CI.','Source build checks remain separate from historical producer evidence; no new milestone acceptance claim.','Shared-VM ABBA contains slower cases; no performance win claimed.','Old fixture/provenance/tool setup failures and initial O3/50 and O3/40 package refusals remain preserved.','Original 10k missing-reply collection failure remains unresolved; no reliability claim.','New mounted M6 correction, GPU integration, keyboard continuation and frozen export candidate are not part of these two parents.']})
print('assembled',len(protection),'protected,',len(combined),'combined paths,',len(inputs),'Rust inputs,',len(archives),'archives,',len(captures),'captures')
