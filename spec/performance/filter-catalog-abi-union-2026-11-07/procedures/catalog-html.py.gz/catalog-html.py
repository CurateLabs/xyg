from pathlib import Path
import xyg
from xyg import export
p=Path('target/task-tmp/filter-catalog-union/catalog-html');p.mkdir(exist_ok=True)
old=export._bundled_js
export._bundled_js=lambda name:old(name)+'\n;globalThis.__bundlePayload="</script><script>globalThis.__bundleInjected=1</script>";'
origin=(1<<63)-100
for kind in ['event','interval','gantt','line','bar','scatter']:
 chart=xyg.temporal_chart(kind,[(origin+1,origin+4,1,(1<<64)-1),(origin+5,None,2,42)],domain=(origin,origin+10),timezone='UTC',title='</title><script>globalThis.__titleInjected=1</script>')
 chart.to_html(p/(kind+'.html'),custom_css='#chart { background: white; }')
print('six current403 offline HTML exports with hostile title/script strings generated')
