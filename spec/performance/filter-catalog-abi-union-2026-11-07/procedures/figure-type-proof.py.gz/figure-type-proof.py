from pathlib import Path
import ast,json,subprocess,hashlib
A='c90fcd3047e4cac69c307ffe1f27c37c4d69c0f8';B='b8000a60900d4685969a6d68f55324e561199df5';path='python/xyg/_figure.py'
a=subprocess.check_output(['git','show',A+':'+path]);b=subprocess.check_output(['git','show',B+':'+path]);assert a==b
raw=Path(path).read_bytes();t=ast.parse(raw);removed=[]
for n in list(t.body):
 if isinstance(n,ast.ImportFrom) and n.module=='typing':
  names=[v for v in n.names if v.name=='TYPE_CHECKING'];assert len(names)==1;n.names=[v for v in n.names if v.name!='TYPE_CHECKING'];removed.append('typing.TYPE_CHECKING import')
 if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='TYPE_CHECKING':
  assert len(n.body)==1 and isinstance(n.body[0],ast.ImportFrom) and n.body[0].module=='components' and n.body[0].level==1 and [v.name for v in n.body[0].names]==['TemporalChart'];assert n.orelse==[];t.body.remove(n);removed.append('type-check-only TemporalChart import')
 if isinstance(n,ast.ClassDef) and n.name=='Figure':
  fields=[v for v in n.body if isinstance(v,ast.AnnAssign) and isinstance(v.target,ast.Name) and v.target.id=='_temporal_composition'];assert len(fields)==1;field=fields[0];assert field.value is None and isinstance(field.annotation,ast.Name) and field.annotation.id=='TemporalChart';n.body.remove(field);removed.append('annotation without default')
dump=ast.dump(t,include_attributes=False);assert dump==ast.dump(ast.parse(a),include_attributes=False)
result={'path':path,'parentsIdentical':True,'parentSha256':hashlib.sha256(a).hexdigest(),'currentSha256':hashlib.sha256(raw).hexdigest(),'removedOnly':removed,'everyOtherAstNodeIdentical':True,'preservesAbsentFieldBehavior':True}
Path('spec/performance/filter-catalog-abi-union-2026-11-07/figure-type-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
