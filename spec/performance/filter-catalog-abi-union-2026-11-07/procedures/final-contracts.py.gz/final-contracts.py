from pathlib import Path
import os,subprocess,json,time
r=Path.cwd();d=r/'target/task-tmp/filter-catalog-union';env=os.environ.copy();env.update({'PATH':str(r/'target/task-tmp/node-v22.23.4-linux-x64/bin')+':/home/ubuntu/.cargo/bin:'+env['PATH'],'TMPDIR':'/var/tmp','XYG_NATIVE_LIB':str(r/'target/release/libxyg_core.so'),'PYTHONPATH':str(r/'python'),'XYG_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome','XYG_TEST_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'})
commands=[('abi-final',['python3','scripts/gen_abi_manifest.py','--check']),('wasm-abi-final',['python3','scripts/gen_wasm_abi.py','--check']),('capability-final',['uv','run','python','scripts/gen_capability_matrix.py','--check']),('floor-final',['uv','run','python','scripts/check_python_floor.py']),('types-final',['uv','run','ty','check']),('ci-final',['make','check-ci']),('source-final',['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_verify_ownership.py','tests/test_cross_host_abi_transition.py','tests/test_gen_wasm_abi.py','tests/test_verify_wasm_assets.py']),('naming-final',['uv','run','pytest','-q','tests/test_stale_names.py'])]
for name,command in commands:
 start=time.monotonic()
 with (d/(name+'.log')).open('w') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
 (d/(name+'.exit.json')).write_text(json.dumps({'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start})+'\n');print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
