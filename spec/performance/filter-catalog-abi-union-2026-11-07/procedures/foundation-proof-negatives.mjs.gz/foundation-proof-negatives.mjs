import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const dir='target/task-tmp/filter-catalog-union',source=fs.readFileSync('scripts/wasm_foundation_smoke.mjs','utf8'),begin=source.indexOf('  if (!only && result.filterDensityProof?'),end=source.indexOf('  if (!only) console.log(`direct-browser density policy',begin);
assert.ok(begin>=0&&end>begin);const block=source.slice(begin,end),report=JSON.parse(fs.readFileSync(dir+'/foundation.json','utf8'));vm.runInNewContext(block,{only:'',result:report});
const cases=[['missing-filter',r=>delete r.filterDensityProof],['nonindexed-filter',r=>r.filterDensityProof.indexedRowsRead='1'],['missing-catalog',r=>delete r.temporalCatalogProof],['nonarray-catalog',r=>r.temporalCatalogProof={}],...['event','interval','gantt','line','bar','scatter'].map(k=>['missing-'+k,r=>r.temporalCatalogProof=r.temporalCatalogProof.filter(e=>e.kind!==k)]),['duplicated-family',r=>r.temporalCatalogProof[0].kind=r.temporalCatalogProof[1].kind]];
for(const [name,mutate] of cases){const r=structuredClone(report);mutate(r);assert.throws(()=>vm.runInNewContext(block,{only:'',result:r}),/omitted/,name);}
vm.runInNewContext(block,{only:'density-no-refinement',result:{}});
fs.writeFileSync(dir+'/foundation-proof-negatives.json',JSON.stringify({realReportAccepted:true,exactShippingHarnessBlock:true,rejected:cases.map(([n])=>n),focusedDensityScopeRetained:true},null,2)+'\n');console.log('actual full proof accepted;11 removed/corrupted feature proofs rejected; focused density scope preserved');
