from pathlib import Path
import os,subprocess,json,time,sys
r=Path.cwd();d=r/'target/task-tmp/filter-catalog-union';env=os.environ.copy();env['TMPDIR']='/var/tmp';env['PATH']=str(r/'target/task-tmp/node-v22.23.4-linux-x64/bin')+':/home/ubuntu/.cargo/bin:'+env['PATH']
label=sys.argv[1] if len(sys.argv)>1 else 'final'
for name,command in [('hooks-'+label,['uv','run','--with','pre-commit','pre-commit','run','--all-files']),('ruff-check-'+label,['uv','run','ruff','check','.']),('ruff-format-'+label,['uv','run','ruff','format','--check','.'])]:
 start=time.monotonic()
 with (d/(name+'.log')).open('w') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
 (d/(name+'.exit.json')).write_text(json.dumps({'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start})+'\n');print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
