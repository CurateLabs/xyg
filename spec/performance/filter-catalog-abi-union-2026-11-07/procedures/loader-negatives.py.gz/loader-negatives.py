from pathlib import Path
import subprocess,os,json,hashlib,ctypes
root=Path.cwd();out=root/'target/task-tmp/filter-catalog-union';env=os.environ.copy();env.update({'TMPDIR':'/var/tmp','PYTHONPATH':str(root/'python'),'PATH':str(root/'target/task-tmp/node-v22.23.4-linux-x64/bin')+':'+env['PATH']})
rows=[]
for name,path,wanted in [('filter','/home/ubuntu/.t3/worktrees/xyg/t3-a6fec95d/target/release/libxyg_core.so','347ca67b5eb09aed8b8f6d6578f1f21913c195ab197ce70a68ba6a2e1dac35f6'),('catalog','/home/ubuntu/.t3/worktrees/xyg/t3-6f28d134/target/release/libxyg_core.so','8f1b7a544bdefab946099fbeab11e658e73c1262381113637baa7e131c561aa5')]:
 p=Path(path); digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==wanted,(name,digest)
 lib=ctypes.CDLL(str(p));assert lib.xyg_abi_version()==402
 e=env|{'XYG_NATIVE_LIB':str(p)}
 commands=[('python',['uv','run','python','-c','import xyg._native']),('node',['node','--input-type=module','-e',"try{await import('./packages/xy-node/src/native.js');throw Error('unexpected success');}catch(e){console.log(JSON.stringify({code:e.code,message:e.message,expected:e.expected,actual:e.actual}));if(!e.message.includes('wrapper expects 403, library reports 402'))process.exit(2);process.exit(1);}"])]
 for host,command in commands:
  result=subprocess.run(command,env=e,capture_output=True,text=True);log=result.stdout+result.stderr;(out/f'loader-negative-{name}-{host}.log').write_text(log);assert result.returncode==1,(name,host,result.returncode,log)
  assert ('expects 403, library reports 402' in log) if host=='node' else ('wrapper expects 403, library reports 402' in log)
  rows.append({'parent':name,'host':host,'nativeSha256':digest,'nativeAbi':402,'wrapperAbi':403,'command':command,'exitCode':result.returncode,'rejectedBeforeGeneratedBinding':True})
(out/'loader-negatives.json').write_text(json.dumps(rows,indent=2)+'\n');print('all four actual old402/new403 loader negatives rejected before generated symbol binding')
