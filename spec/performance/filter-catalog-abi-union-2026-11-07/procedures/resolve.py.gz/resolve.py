from pathlib import Path
import subprocess,json,re,shlex
A='c90fcd3047e4cac69c307ffe1f27c37c4d69c0f8';B='b8000a60900d4685969a6d68f55324e561199df5'
def blob(c,n):return subprocess.check_output(['git','show',c+':'+n]).decode()
def both(n):
 p=Path(n);s=p.read_text();rx=r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> '+B+r'\n';s,nsub=re.subn(rx,lambda m:m[1]+m[2],s,flags=re.S);assert nsub,n;assert '<<<<<<<' not in s;p.write_text(s)
for n in ['.cargo/config.toml','.gitattributes','js/src/60_entries.ts','packages/xy-node/src/index.js','spec/design/host-parity.md','spec/design/wire-protocol.md','spec/design/ownership-audit.md']:both(n)
n='crates/xyg-core/src/lib.rs';s=blob(A,n);b=blob(B,n);marker='/// Compile an exact XYTM temporal composition into the canonical Scene.';assert b.count(marker)==1;s=s.rstrip()+'\n\n'+b[b.index(marker):];assert s.count('pub const ABI_VERSION: u32 = 402;')==1;s=s.replace('pub const ABI_VERSION: u32 = 402;','pub const ABI_VERSION: u32 = 403;');Path(n).write_text(s)
n='crates/xyg-wasm/src/lib.rs';s=blob(A,n);b=blob(B,n);marker='/// Compile an exact packed temporal composition through the shared Scene engine.';assert b.count(marker)==1;extra=b[b.index(marker):];anchor='#[cfg(test)]\nmod filter_tier_c_tests';assert anchor in s;s=s.replace(anchor,extra+'\n'+anchor);assert s.count('pub const WASM_ABI_VERSION: u32 = 36;')==1;s=s.replace('pub const WASM_ABI_VERSION: u32 = 36;','pub const WASM_ABI_VERSION: u32 = 37;');Path(n).write_text(s)
n='spec/wasm/abi.json';v=json.loads(Path(n).read_text());v['abi_version']=37;Path(n).write_text(json.dumps(v,indent=2)+'\n')
for n in ['spec/abi/xyg-abi.json','spec/abi/xyg.h','python/xyg/_abi_generated.py','packages/xy-node/src/_abi_generated.js','spec/releases/0.6.0-api-inventory.json']:Path(n).write_text(blob(A,n))
n='packages/xy-node/package.json';a,b=[json.loads(blob(p,n)) for p in [A,B]];d=json.loads(blob(A,n));fa=shlex.split(a['scripts']['test']);fb=shlex.split(b['scripts']['test']);assert fa[:2]==fb[:2]
for k in a:
 if k!='scripts':assert a[k]==b[k],k
for k in a['scripts']:
 if k!='test':assert a['scripts'][k]==b['scripts'][k],k
files=list(dict.fromkeys(fa[2:]+fb[2:]));d['scripts']['test']=' '.join(fa[:2]+files);Path(n).write_text(json.dumps(d,indent=2)+'\n');print('Node tests',len(files))
n='spec/design/ownership-audit.json';a,b=[json.loads(blob(p,n)) for p in [A,B]]
for k in a:
 if k!='files':assert a[k]==b[k],k
ka={v['path']:v for v in a['files']};kb={v['path']:v for v in b['files']};assert all(ka[k]==kb[k] for k in ka.keys()&kb.keys());a['files']+= [v for v in b['files'] if v['path'] not in ka];Path(n).write_text(json.dumps(a,indent=2)+'\n');print('ownership',len(a['files']))
n='tests/browser/wasm_foundation_page.mjs';s=Path(n).read_text();rx=r'<<<<<<< HEAD\n.*?=======\n.*?>>>>>>> '+B+r'\n';s,count=re.subn(rx,'  return { ok: true, densityPolicy, densityNoRefinement, temporalControllerProof, filterDensityProof, temporalCatalogProof };\n',s,flags=re.S);assert count==1;Path(n).write_text(s)
n='tests/test_cross_host_abi_transition.py';s=Path(n).read_text();s,count=re.subn(rx,'CURRENT_RECEIPT = ROOT / "spec/performance/filter-catalog-abi-union-2026-11-07"\n',s,flags=re.S);assert count==1;Path(n).write_text(s)
n='tests/test_graphforge_contract_corpus.py';s=blob(A,n);s=s.replace('spec/performance/filter-graph-native-union-2026-11-07/current-bindings.json','spec/performance/filter-catalog-abi-union-2026-11-07/current-bindings.json');Path(n).write_text(s)
print('all conflict markers resolved in intended files')
