from pathlib import Path
import os,sys,subprocess,json,time
r=Path.cwd();d=r/'target/task-tmp/filter-catalog-union';env=os.environ.copy();env['PATH']='/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin:/home/ubuntu/.cargo/bin:'+env['PATH'];env.update({'TMPDIR':'/var/tmp','CARGO_BUILD_JOBS':'2','XYG_NATIVE_LIB':str(r/'target/release/libxyg_core.so'),'PYTHONPATH':str(r/'python'),'XYG_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome','XYG_TEST_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'})
groups={'build':[('native-build',['cargo','build','--release']),('client-build',['node','js/build.mjs']),('wasm-o3-build',['cargo','build','-p','xyg-wasm','--release','--target','wasm32-unknown-unknown']),('wasm-o3-package',['node','js/package-wasm.mjs'])], 'metadata':[('abi-generated',['python3','scripts/gen_abi_manifest.py','--check']),('wasm-generated',['python3','scripts/gen_wasm_abi.py','--check']),('inventory-write',['uv','run','python','scripts/check_release_inventory.py','--write'])]}
groups['fixtures']=[('fixture-'+str(i),row['command']) for i,row in enumerate(json.loads((r/'spec/performance/filter-catalog-abi-union-2026-11-07/abi402-source-fixtures.json').read_text()).values())]
groups['wasm40']=[('wasm-o3-inline40-build',['cargo','build','-p','xyg-wasm','--release','--target','wasm32-unknown-unknown']),('wasm-o3-inline40-package',['node','js/package-wasm.mjs'])]
groups['wasm-o2']=[('wasm-o2-inline50-build',['cargo','build','-p','xyg-wasm','--release','--target','wasm32-unknown-unknown']),('wasm-o2-inline50-package',['node','js/package-wasm.mjs'])]
groups['profile']=[('profile-abba',['node','benchmarks/bench_wasm_profiles.mjs',str(d/'wasm-o3-inline50.wasm'),str(r/'packages/xy-client/dist/xyg-wasm.wasm'),str(d/'profile-inputs'),str(d/'profile-abba.json')])]
groups['qualify']=[
 ('rust-filter',['cargo','test','-p','xyg-engine','filter_tier_c','--lib']),
 ('rust-temporal',['cargo','test','-p','xyg-engine','temporal_scene','--lib']),
 ('wasm-tests',['cargo','test','-p','xyg-wasm','--lib']),
 ('python-host',['uv','run','pytest','-q','tests/test_filter_tier_c.py','tests/test_filter_tier_c_density.py','tests/test_temporal_catalog.py','tests/test_temporal_catalog_geo_integration.py','tests/test_geo_temporal_binding.py','tests/test_temporal_controller.py','tests/test_cross_host_abi_transition.py','tests/test_chunked_columns.py']),
 ('node-full',['npm','test','--prefix','packages/xy-node']),
 ('abi-smoke',['python3','scripts/abi_smoke.py']),
 ('assets',['python3','scripts/verify_wasm_assets.py']),
 ('core-inventory',['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_verify_ownership.py']),
 ('clippy',['cargo','clippy','-p','xyg-engine','--all-targets','--','-D','warnings'])]
groups['public10k']=[('public10k-final',['node','scripts/graph_session_public10k_smoke.mjs']),('public10k-replay-final',['node','scripts/graph_session_public10k_replay.mjs',str(d/'public10k.json')])]
env['XYG_GRAPH_SESSION_REPORT']=str(d/'public10k.json')
groups['foundation-final']=[('foundation-final',['node','scripts/wasm_foundation_smoke.mjs'])]
groups['browser']=[
 ('temporal-packet-parity',['node','scripts/temporal_catalog_wasm_parity.mjs',str(r/'packages/xy-client/dist/xyg-wasm.wasm')]),
 ('filter-browser',['node','scripts/filter_tier_c_conformance.mjs','--capture',str(d/'linked-filter.png'),'--report',str(d/'linked-filter.json')]),
 ('foundation',['node','scripts/wasm_foundation_smoke.mjs'])]
env['XYG_WASM_FOUNDATION_REPORT']=str(d/'foundation.json')
env['XYG_GRAPH_SCHEDULING_REPORT']=str(d/'scheduling.json')
for name,args in groups[sys.argv[1]]:
 t=time.monotonic()
 with (d/(name+'.log')).open('w') as f:v=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 (d/(name+'.exit.json')).write_text(json.dumps({'command':args,'exitCode':v.returncode,'elapsedSeconds':time.monotonic()-t})+'\n');print(name,v.returncode,flush=True)
 if v.returncode:sys.exit(v.returncode)
