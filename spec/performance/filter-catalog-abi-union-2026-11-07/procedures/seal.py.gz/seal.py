from pathlib import Path
import hashlib,json,gzip,subprocess,os
r=Path.cwd();d=r/'target/task-tmp/filter-catalog-union';o=r/'spec/performance/filter-catalog-abi-union-2026-11-07';sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
p=o/'current-bindings.json';bind=json.loads(p.read_text());changes=[]
for n,h in bind['sourceSha256'].items():
 actual=sha((r/n).read_bytes())
 if h!=actual:changes.append(n);bind['sourceSha256'][n]=actual
assert set(changes)<= {'.gitattributes','spec/performance/filter-catalog-abi-union-2026-11-07/README.md'},changes
for n,h in bind['historicalBindings'].items():assert sha((r/n).read_bytes())==h,n
write(p,bind);p=o/'checks.json';checks=json.loads(p.read_text());checks['sourceBindings'].update({'current':len(bind['sourceSha256']),'historical':len(bind['historicalBindings']),'sha256':sha((o/'current-bindings.json').read_bytes())})
def archive(name,raw):
 dst=o/name;dst.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(raw,mtime=0);dst.write_bytes(z);return {'file':str(dst.relative_to(r)),'sha256':sha(z),'bytes':len(z),'rawSha256':sha(raw),'rawBytes':len(raw)}
for f in sorted(d.glob('*.log')):checks['archives'][f.name]=archive(f.name+'.gz',f.read_bytes())
for name in ['assemble.py','final-contracts.py','gates.py','seal.py','figure-type-proof.py','run.py']:
 checks['archives'][name]=archive('procedures/'+name+'.gz',(d/name).read_bytes())
raw=gzip.decompress((d/'assemble-first.py.gz').read_bytes());checks['archives']['assemble-first.py']=archive('procedures/assemble-first.py.gz',raw)
for f in sorted(d.glob('*.exit.json')):checks['commands'][f.name]=json.loads(f.read_text())
for name in ['foundation-proof-negatives.json','linked-filter.json']:
 raw=(d/name).read_bytes();(o/name).write_bytes(raw);checks['reports'][name]={'sha256':sha(raw),'bytes':len(raw)}
for f in sorted(d.glob('public10k*.png')):
 raw=f.read_bytes();(o/f.name).write_bytes(raw);checks['captures'][f.name]={'sha256':sha(raw),'bytes':len(raw)}
raw=(d/'public10k.json').read_bytes();checks['archives']['public10k.json']=archive('public10k.json.gz',raw)
# Retain the verified parent inventory; refresh only explicit combined rows.
protection=json.loads(gzip.decompress((o/'parent-protection.json.gz').read_bytes()))
index={}
for row in subprocess.check_output(['git','ls-files','-s','-z']).split(b'\0'):
 if row:
  meta,path=row.split(b'\t');mode,obj,stage=meta.decode().split();assert stage=='0';index[path.decode()]={'mode':mode,'object':obj}
for row in protection['protected']:assert index[row['path']]==row['current'],row['path']
combined={row['path'] for row in protection['combined']}
unstaged=set(subprocess.check_output(['git','diff','--name-only']).decode().splitlines());assert not ((unstaged-combined)&{row['path'] for row in protection['protected']}),unstaged-combined
for row in protection['combined']:
 f=r/row['path'];raw=os.readlink(f).encode() if f.is_symlink() else f.read_bytes();row['current']={'mode':'120000' if f.is_symlink() else ('100755' if os.access(f,os.X_OK) else '100644'),'object':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
raw=(json.dumps(protection,indent=2,sort_keys=True)+'\n').encode();record=archive('parent-protection.json.gz',raw);checks['protection']=record
pseam=o/'union-seams.json';seams=json.loads(pseam.read_text());seams['protection']=record;write(pseam,seams);checks['declarationManifests']['union-seams.json']=sha(pseam.read_bytes())
checks['declarationManifests']['figure-type-proof.json']=sha((o/'figure-type-proof.json').read_bytes())
checks['freshResults'].update({'postTypePythonPassed':276,'postTypePythonBrowserDiscoverySkip':1,'previouslySkippedFigureChromiumCase':1,'python311Final':89,'finalSourceContracts':181,'ciContracts':775,'namingAfterLocalNotes':155,'finalCore350Sources':7,'public10kPrimaryPainted':60,'public10kPeerPainted':59,'public10kReplayPrimary':63,'public10kReplayPeer':60})
checks['setupFailures']={'typeDeclarationBeforeCorrection':{'exitCode':1,'log':'types-before-field.log'},'namingBeforeLocalWorksheetCorrection':{'exitCode':1,'passed':154,'failed':1,'log':'naming-final.log','scope':'Four historical references in untracked TASKS.md; checker and exemptions unchanged.'},'initialWholeClassAstComparator':{'exitCode':1,'log':'parent-seam-first-helper.log'},'firstFoundationReport':'Log-only pass: wrapper selected unrecognized XYG_WASM_REPORT; final material guard/report change reran full foundation with correct variable.'}
write(p,checks)
print('sealed',len(bind['sourceSha256']),'current sources and',len(checks['archives']),'archives; refreshed',changes)
