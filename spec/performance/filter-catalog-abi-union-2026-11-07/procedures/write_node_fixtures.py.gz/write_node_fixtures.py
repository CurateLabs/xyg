from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path.cwd();d=r/'target/task-tmp/filter-catalog-union';out=r/'spec/performance/filter-catalog-abi-union-2026-11-07';records=json.loads((out/'abi402-source-fixtures.json').read_text());env=os.environ.copy();env.update({'PATH':'/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin:'+env['PATH'],'XYG_NATIVE_LIB':str(r/'target/release/libxyg_core.so'),'TMPDIR':'/var/tmp'})
for p,row in records.items():
 if row['command'][0]!='node':continue
 name='fixture-output-'+Path(p).stem;t=time.monotonic();raw=d/(name+'.json')
 with raw.open('wb') as f,(d/(name+'.log')).open('wb') as e:v=subprocess.run(row['command'],env=env,stdout=f,stderr=e)
 rec={'command':row['command'],'exitCode':v.returncode,'elapsedSeconds':time.monotonic()-t,'fixture':p,'outputSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'stdoutDisposition':'complete producer stdout, separately captured from stderr'};(d/(name+'.exit.json')).write_text(json.dumps(rec)+'\n');assert v.returncode==0,row
 current=json.loads(raw.read_bytes());before=json.loads((out/'abi402-predecessor'/Path(p).name).read_bytes());assert current['abi_version']==403 and current==dict(before,abi_version=403),p
 Path(p).write_bytes(raw.read_bytes());print('regenerated',p,flush=True)
sha=lambda x:hashlib.sha256(x).hexdigest();a={};b={}
for p,row in records.items():
 current=Path(p).read_bytes();p402=(out/'abi402-predecessor'/Path(p).name).read_bytes();p401=(out/'abi401-predecessor'/Path(p).name).read_bytes();assert json.loads(current)==dict(json.loads(p402),abi_version=403),p
 for v,raw,data in [(401,p401,a),(402,p402,b)]:data[p]={'historicalAbi':v,'currentAbi':403,'predecessorSha256':sha(raw),'currentSha256':sha(current),'command':row['command']}
for n,v in [('fixture-transition.json',a),('abi402-transition.json',b)]: (out/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
print('complete ten-fixture ABI-only transition verified')
