import {densityAssets} from '/home/ubuntu/.t3/worktrees/xyg/t3-a6fec95d/scripts/filter_density_browser.mjs';
import {writeFile} from 'node:fs/promises';
const assets=await densityAssets(new URL('file:///home/ubuntu/.t3/worktrees/xyg/t3-a6fec95d/'));
const packets=[];
for(const [name,asset] of assets){const n=Buffer.from(name),data=Buffer.from(asset.data),header=Buffer.alloc(8);header.writeUInt32LE(n.length);header.writeUInt32LE(data.length,4);packets.push(header,n,data);}
await writeFile('/var/tmp/xyg-f112/public-composition.bin',Buffer.concat(packets));console.log('10 public composed spec/buffer entries, u32 name/data byte lengths followed by UTF8 name and raw data');
