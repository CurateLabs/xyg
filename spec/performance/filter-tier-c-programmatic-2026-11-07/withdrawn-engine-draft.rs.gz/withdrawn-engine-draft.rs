//! Exact, budgeted active-dimension prefix slabs (§34).
//!
//! This is an engine building block, not the shipped linked-filter protocol.
//! Counts are indexed; materializing membership is a separate, reported cost.
use std::sync::Arc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Error {
    Invalid,
    Budget,
    Stale,
    Cancelled,
    Allocation,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SourceIdentity {
    /// Assigned by the canonical source owner, never a view-local identifier.
    pub source: u64,
    /// Changes on schema/base-predicate changes, not cache eviction.
    pub generation: u64,
    /// Absolute row identity is first_row + canonical position.
    pub first_row: u64,
}

#[derive(Debug, Clone)]
pub struct Source {
    pub identity: SourceIdentity,
    columns: Vec<Arc<[f64]>>,
    rows: usize,
}

impl Source {
    pub fn new(identity: SourceIdentity, columns: Vec<Arc<[f64]>>) -> Result<Self, Error> {
        let rows = columns.first().ok_or(Error::Invalid)?.len();
        if identity.source == 0
            || identity.generation == 0
            || columns.iter().any(|c| c.len() != rows)
            || identity.first_row.checked_add(rows as u64).is_none()
        {
            return Err(Error::Invalid);
        }
        Ok(Self {
            identity,
            columns,
            rows,
        })
    }

    pub fn rows(&self) -> usize {
        self.rows
    }

    pub fn value(&self, dimension: usize, row: usize) -> Option<f64> {
        self.columns.get(dimension)?.get(row).copied()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Axis {
    pub dimension: usize,
    /// Strictly increasing exact f64 cuts. Cells are [-inf,cut0), ..., [cutN,inf].
    pub cuts: Vec<f64>,
}

impl Axis {
    fn validate(&self, source: &Source) -> Result<(), Error> {
        if self.dimension >= source.columns.len()
            || self.cuts.iter().any(|v| !v.is_finite())
            || self.cuts.windows(2).any(|v| v[0] >= v[1])
        {
            return Err(Error::Invalid);
        }
        Ok(())
    }
    fn cell(&self, value: f64) -> usize {
        self.cuts.partition_point(|cut| *cut <= value)
    }
}

#[derive(Debug, Clone)]
pub struct View {
    pub id: u64,
    pub axis: Axis,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Serving {
    IndexedExact,
    ExactBoundaryScan,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostics {
    pub serving: Serving,
    pub index_bytes: usize,
    pub result_bytes: usize,
    pub canonical_rows_read: usize,
    pub prefix_cells_read: usize,
    pub membership_words_written: usize,
}

#[derive(Debug, Clone)]
pub struct ResultSet {
    pub identity: SourceIdentity,
    pub revision: u64,
    pub active_dimension: usize,
    pub bounds: [f64; 2],
    pub selected_count: u64,
    pub views: Vec<(u64, Vec<u64>)>,
    pub membership: Vec<u64>,
    pub diagnostics: Diagnostics,
}

impl ResultSet {
    pub fn contains(&self, source: SourceIdentity, row: u64) -> bool {
        if source != self.identity {
            return false;
        }
        let Some(index) = row.checked_sub(source.first_row) else {
            return false;
        };
        let Ok(index) = usize::try_from(index) else {
            return false;
        };
        self.membership
            .get(index / 64)
            .is_some_and(|word| word & (1 << (index % 64)) != 0)
    }
}

fn add(a: usize, b: usize) -> Result<usize, Error> {
    a.checked_add(b).ok_or(Error::Budget)
}
fn mul(a: usize, b: usize) -> Result<usize, Error> {
    a.checked_mul(b).ok_or(Error::Budget)
}
fn zeroes<T: Default + Clone>(n: usize) -> Result<Vec<T>, Error> {
    let mut v = Vec::new();
    v.try_reserve_exact(n).map_err(|_| Error::Allocation)?;
    v.resize(n, T::default());
    Ok(v)
}

/// Memory plan includes in-flight old index/result and the new index/result.
/// Caller-owned Arc canonical storage is deliberately separate from derived bytes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Admission {
    pub index_bytes: usize,
    pub result_bytes: usize,
    pub peak_bytes: usize,
}

#[derive(Debug)]
pub struct Index {
    source: Source,
    active: Axis,
    views: Vec<View>,
    offsets: Vec<usize>,
    width: usize,
    words: usize,
    counts: Vec<u64>,
    masks: Vec<u64>,
    extrema: Vec<[f64; 2]>,
    admission: Admission,
}

impl Index {
    pub fn plan(
        source: &Source,
        active: &Axis,
        views: &[View],
        retained_bytes: usize,
        budget: usize,
    ) -> Result<Admission, Error> {
        active.validate(source)?;
        if views.is_empty() {
            return Err(Error::Invalid);
        }
        let mut bins = 0;
        let mut descriptors = mul(active.cuts.len(), 8)?;
        for (i, view) in views.iter().enumerate() {
            view.axis.validate(source)?;
            if view.id == 0 || views[..i].iter().any(|v| v.id == view.id) {
                return Err(Error::Invalid);
            }
            bins = add(bins, add(view.axis.cuts.len(), 1)?)?;
            descriptors = add(descriptors, mul(view.axis.cuts.len(), 8)?)?;
        }
        let cells = add(active.cuts.len(), 1)?;
        let words = add(source.rows, 63)? / 64;
        let slabs = mul(add(cells, 1)?, add(bins, words)?)?;
        let index_bytes = add(mul(slabs, 8)?, add(mul(cells, 16)?, descriptors)?)?;
        // View IDs, source-column Arc slots, offsets, and Vec/object headers.
        let overhead = add(
            std::mem::size_of::<Self>(),
            add(
                mul(source.columns.len(), std::mem::size_of::<Arc<[f64]>>())?,
                mul(
                    views.len(),
                    std::mem::size_of::<View>() + std::mem::size_of::<usize>(),
                )?,
            )?,
        )?;
        let index_bytes = add(index_bytes, overhead)?;
        let result_bytes = add(
            std::mem::size_of::<ResultSet>(),
            add(
                mul(add(bins, words)?, 8)?,
                mul(views.len(), std::mem::size_of::<(u64, Vec<u64>)>())?,
            )?,
        )?;
        let peak_bytes = add(retained_bytes, add(index_bytes, result_bytes)?)?;
        if peak_bytes > budget {
            return Err(Error::Budget);
        }
        Ok(Admission {
            index_bytes,
            result_bytes,
            peak_bytes,
        })
    }

    pub fn build(
        source: Source,
        active: Axis,
        views: Vec<View>,
        retained_bytes: usize,
        budget: usize,
        mut cancelled: impl FnMut() -> bool,
    ) -> Result<Self, Error> {
        let admission = Self::plan(&source, &active, &views, retained_bytes, budget)?;
        let cells = active.cuts.len() + 1;
        let words = (source.rows + 63) / 64;
        let mut offsets = Vec::new();
        offsets
            .try_reserve_exact(views.len())
            .map_err(|_| Error::Allocation)?;
        let mut width = 0;
        for view in &views {
            offsets.push(width);
            width += view.axis.cuts.len() + 1;
        }
        let mut counts: Vec<u64> = zeroes((cells + 1) * width)?;
        let mut masks: Vec<u64> = zeroes((cells + 1) * words)?;
        let mut extrema = zeroes(cells)?;
        extrema.fill([f64::INFINITY, f64::NEG_INFINITY]);
        for row in 0..source.rows {
            if row % 4096 == 0 && cancelled() {
                return Err(Error::Cancelled);
            }
            let value = source.columns[active.dimension][row];
            if !value.is_finite() {
                continue;
            }
            let cell = active.cell(value);
            extrema[cell][0] = extrema[cell][0].min(value);
            extrema[cell][1] = extrema[cell][1].max(value);
            masks[(cell + 1) * words + row / 64] |= 1 << (row % 64);
            for (view, offset) in views.iter().zip(&offsets) {
                let passive = source.columns[view.axis.dimension][row];
                if passive.is_finite() {
                    counts[(cell + 1) * width + offset + view.axis.cell(passive)] += 1;
                }
            }
        }
        for cell in 1..=cells {
            if cancelled() {
                return Err(Error::Cancelled);
            }
            for bin in 0..width {
                counts[cell * width + bin] += counts[(cell - 1) * width + bin];
            }
            // Prefix XOR: each canonical row occurs in exactly one active cell.
            for word in 0..words {
                masks[cell * words + word] ^= masks[(cell - 1) * words + word];
            }
        }
        Ok(Self {
            source,
            active,
            views,
            offsets,
            width,
            words,
            counts,
            masks,
            extrema,
            admission,
        })
    }

    pub fn admission(&self) -> Admission {
        self.admission
    }

    pub fn query(
        &self,
        revision: u64,
        bounds: [f64; 2],
        mut cancelled: impl FnMut() -> bool,
    ) -> Result<ResultSet, Error> {
        if revision == 0 || bounds.iter().any(|v| !v.is_finite()) {
            return Err(Error::Invalid);
        }
        if cancelled() {
            return Err(Error::Cancelled);
        }
        let bounds = [bounds[0].min(bounds[1]), bounds[0].max(bounds[1])];
        let mut first = None;
        let mut end = 0;
        let mut boundary = false;
        // Classify against observed extrema, never silently snap f64 endpoints.
        for (cell, [min, max]) in self.extrema.iter().copied().enumerate() {
            if min > max || max < bounds[0] || min > bounds[1] {
                continue;
            }
            if min < bounds[0] || max > bounds[1] {
                boundary = true;
                break;
            }
            first.get_or_insert(cell);
            end = cell + 1;
        }
        let mut membership = zeroes(self.words)?;
        let mut views = Vec::new();
        views
            .try_reserve_exact(self.views.len())
            .map_err(|_| Error::Allocation)?;
        for view in &self.views {
            views.push((view.id, zeroes(view.axis.cuts.len() + 1)?));
        }
        let mut rows_read = 0;
        let mut prefix_cells_read = 0;
        if boundary {
            for row in 0..self.source.rows {
                if row % 4096 == 0 && cancelled() {
                    return Err(Error::Cancelled);
                }
                rows_read += 1;
                let value = self.source.columns[self.active.dimension][row];
                if !value.is_finite() || value < bounds[0] || value > bounds[1] {
                    continue;
                }
                membership[row / 64] |= 1 << (row % 64);
                for (view, (_, counts)) in self.views.iter().zip(&mut views) {
                    let value = self.source.columns[view.axis.dimension][row];
                    if value.is_finite() {
                        counts[view.axis.cell(value)] += 1;
                    }
                }
            }
        } else if let Some(first) = first {
            for (word, out) in membership.iter_mut().enumerate() {
                *out = self.masks[end * self.words + word] ^ self.masks[first * self.words + word];
            }
            for ((_, counts), offset) in views.iter_mut().zip(&self.offsets) {
                for (bin, count) in counts.iter_mut().enumerate() {
                    *count = self.counts[end * self.width + offset + bin]
                        - self.counts[first * self.width + offset + bin];
                }
            }
            prefix_cells_read = 2 * (self.words + self.width);
        }
        if cancelled() {
            return Err(Error::Cancelled);
        }
        let selected_count = membership.iter().map(|w| w.count_ones() as u64).sum();
        Ok(ResultSet {
            identity: self.source.identity,
            revision,
            active_dimension: self.active.dimension,
            bounds,
            selected_count,
            views,
            membership,
            diagnostics: Diagnostics {
                serving: if boundary {
                    Serving::ExactBoundaryScan
                } else {
                    Serving::IndexedExact
                },
                index_bytes: self.admission.index_bytes,
                result_bytes: self.admission.result_bytes,
                canonical_rows_read: rows_read,
                prefix_cells_read,
                membership_words_written: self.words,
            },
        })
    }
}

/// Publication watermark is separate from the currently visible result.
/// New requests and cancellation prevent an old prepared reply from publishing.
#[derive(Debug, Default)]
pub struct Publication {
    newest: u64,
    cancelled: u64,
    current: Option<ResultSet>,
}

impl Publication {
    pub fn request(&mut self, revision: u64) -> Result<(), Error> {
        if revision == 0 || revision <= self.newest {
            return Err(Error::Stale);
        }
        self.newest = revision;
        Ok(())
    }
    pub fn cancel(&mut self, revision: u64) {
        self.cancelled = self.cancelled.max(revision);
    }
    /// No state changes if transport capacity/admission failed.
    pub fn publish(&mut self, result: ResultSet, admitted: bool) -> Result<(), Error> {
        if result.revision <= self.cancelled {
            return Err(Error::Cancelled);
        }
        if result.revision != self.newest {
            return Err(Error::Stale);
        }
        if !admitted {
            return Err(Error::Budget);
        }
        self.current = Some(result);
        Ok(())
    }
    pub fn current(&self) -> Option<&ResultSet> {
        self.current.as_ref()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn source() -> Source {
        Source::new(
            SourceIdentity {
                source: 7,
                generation: 1,
                first_row: 900,
            },
            vec![
                Arc::from([-1., 0., 0.25, 0.5, 1., 2., f64::NAN, f64::INFINITY]),
                Arc::from([5., 4., 3., 2., 1., 0., 9., 8.]),
            ],
        )
        .unwrap()
    }
    fn index() -> Index {
        Index::build(
            source(),
            Axis {
                dimension: 0,
                cuts: vec![0., 1., 2.],
            },
            vec![View {
                id: 12,
                axis: Axis {
                    dimension: 1,
                    cuts: vec![1., 3., 5.],
                },
            }],
            0,
            100_000,
            || false,
        )
        .unwrap()
    }
    #[test]
    fn filter_tier_c_exact_oracle_boundaries() {
        let index = index();
        for bounds in [
            [-2., 3.],
            [0., 0.5],
            [0.1, 0.4],
            [0.25, 0.25],
            [0.4, 0.1],
            [4., 5.],
            [1., 1.],
            [0., 1.],
            [-1., -1.],
        ] {
            let result = index.query(1, bounds, || false).unwrap();
            let mut counts = [0u64; 4];
            let mut selected = 0;
            for row in 0..8 {
                let x = source().value(0, row).unwrap();
                let yes =
                    x.is_finite() && x >= bounds[0].min(bounds[1]) && x <= bounds[0].max(bounds[1]);
                assert_eq!(result.contains(source().identity, row as u64 + 900), yes);
                if yes {
                    selected += 1;
                    let y = source().value(1, row).unwrap();
                    // Independent explicit fixture oracle, not Axis::cell.
                    counts[if y < 1. {
                        0
                    } else if y < 3. {
                        1
                    } else if y < 5. {
                        2
                    } else {
                        3
                    }] += 1;
                }
            }
            assert_eq!(result.selected_count, selected);
            assert_eq!(result.views[0].1, counts);
        }
        assert_eq!(
            index
                .query(1, [0., 0.5], || false)
                .unwrap()
                .diagnostics
                .canonical_rows_read,
            0
        );
        assert_eq!(
            index
                .query(1, [0.1, 0.4], || false)
                .unwrap()
                .diagnostics
                .serving,
            Serving::ExactBoundaryScan
        );
    }
    #[test]
    fn filter_tier_c_budget_and_malformed() {
        let i = index();
        let plan = i.admission();
        assert_eq!(
            Index::plan(&source(), &i.active, &i.views, 0, plan.peak_bytes - 1),
            Err(Error::Budget)
        );
        assert!(Index::plan(&source(), &i.active, &i.views, 0, plan.peak_bytes).is_ok());
        assert_eq!(
            Index::plan(&source(), &i.active, &i.views, usize::MAX, usize::MAX),
            Err(Error::Budget)
        );
        assert!(matches!(
            i.query(1, [f64::NAN, 1.], || false),
            Err(Error::Invalid)
        ));
        assert!(matches!(
            i.query(1, [0., 1.], || true),
            Err(Error::Cancelled)
        ));
        let mut bad = i.active.clone();
        bad.cuts = vec![1., 1.];
        assert_eq!(
            Index::plan(&source(), &bad, &i.views, 0, usize::MAX),
            Err(Error::Invalid)
        );
    }
    #[test]
    fn filter_tier_c_publication_atomicity_and_identity() {
        let i = index();
        let mut p = Publication::default();
        p.request(1).unwrap();
        p.publish(i.query(1, [0., 1.], || false).unwrap(), true)
            .unwrap();
        p.request(2).unwrap();
        assert_eq!(
            p.publish(i.query(1, [0., 1.], || false).unwrap(), true),
            Err(Error::Stale)
        );
        assert_eq!(
            p.publish(i.query(2, [0., 1.], || false).unwrap(), false),
            Err(Error::Budget)
        );
        assert_eq!(p.current().unwrap().revision, 1);
        p.cancel(2);
        assert_eq!(
            p.publish(i.query(2, [0., 1.], || false).unwrap(), true),
            Err(Error::Cancelled)
        );
        let r = p.current().unwrap();
        assert!(!r.contains(
            SourceIdentity {
                source: 8,
                ..r.identity
            },
            901
        ));
        assert!(!r.contains(r.identity, 899));
        assert!(!r.contains(r.identity, 1000));
    }
}
