import gzip,hashlib,json,shutil,subprocess
from pathlib import Path
root=Path.cwd();run=root/'target/task-tmp/frozen-combined-union';dest=root/'spec/performance/frozen-combined-module-2026-11-07';sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def arc(src,name=None):
 raw=src.read_bytes();name=name or str(src.relative_to(run)).replace('/','__')+'.gz';packed=gzip.compress(raw,mtime=0);(dest/name).write_bytes(packed);return {'archive':name,'archiveSha256':sha(packed),'sha256':sha(raw),'bytes':len(raw)}
inputs=json.loads((run/'before-size-repair-source-inputs.json').read_text())
for p,h in inputs.items():assert sha((root/p).read_bytes())==h,p
write(dest/'compiled-source-inputs.json',inputs)
logs={str(f.relative_to(run)):arc(f) for f in sorted(run.glob('*.log'))}
results={f.name:json.loads(f.read_text()) for f in sorted(run.glob('*.exit.json'))}
reports={str(f.relative_to(run)):arc(f) for f in sorted(run.glob('*.json')) if not f.name.endswith('.exit.json')}
scripts={str(f.relative_to(run)):arc(f) for f in sorted(run.glob('*.py'))}
experiments={}
for dirname in ['before-unstable-sharing','rejected-unstable-sharing','before-geo-callback-sharing','rejected-geo-callback-sharing']:
 for f in sorted((run/dirname).rglob('*')):
  if f.is_file():experiments[str(f.relative_to(run))]=arc(f)
artifacts={}
for name in ['native405-before-size-repair.so','over-cap-combined-baseline.wasm','combined-before-size-repair.wasm','rejected-unstable-sharing.wasm','rejected-geo-callback-sharing.wasm']:
 artifacts[name]=arc(run/name)
parents=['bef92b1dc20894cf5f801d2421832dda8589bb45','fc50daad4a011c920fe18f814d951901ae797049']
def tree(ref):
 out={}
 for line in subprocess.check_output(['git','ls-tree','-rz',ref]).split(b'\0'):
  if not line:continue
  m,p=line.split(b'\t',1);mode,typ,blob=m.decode().split();out[p.decode()]=(mode,blob)
 return out
a,c=map(tree,parents);protected=[];combined=[]
for p in sorted(a.keys()|c.keys()):
 data=(root/p).read_bytes() if not (root/p).is_symlink() else (root/p).readlink().as_posix().encode()
 mode='120000' if (root/p).is_symlink() else ('100755' if (root/p).stat().st_mode&0o111 else '100644');blob=sha(data)
 rawid=subprocess.check_output(['git','hash-object','--stdin'],input=data).decode().strip();v=(mode,rawid)
 if v==a.get(p) or v==c.get(p):protected.append({'path':p,'mode':mode,'blob':rawid})
 else:combined.append(p)
write(dest/'protection.json',{'parents':parents,'protected':protected,'combined':combined,'shippingQualification':False})
b=json.loads((dest/'current-bindings.json').read_text());b['sourceSha256']={p:sha((root/p).read_bytes()) for p in b['sourceSha256']};write(dest/'current-bindings.json',b)
write(dest/'checks.json',{'schemaVersion':1,'scope':'Source integration checkpoint only; packaging rejected, NOT shipping qualified','parents':parents,'versions':{'native':405,'wasm':38,'nativeSymbols':551,'wasmExports':68},'qualification':'incomplete','package':json.loads((run/'over-cap-combined-baseline.json').read_text()),'results':results,'logs':logs,'reports':reports,'scripts':scripts,'rejectedExperiments':experiments,'artifacts':artifacts,'sourceBindingSha256':sha((dest/'current-bindings.json').read_bytes()),'sourceCounts':{'current':len(b['sourceSha256']),'historical':len(b['historicalBindings'])},'knownFreshPassing':{'fixtureTransitions':131,'nativeFrozen':35,'nativeFrozenWorkerDeselected':1,'coreInventoryOwnership':42},'gates':'Recorded separately; not a substitute for required package/CI qualification','remaining':['Reduce full module below unchanged raw/gzip caps without dropping features','Fresh matching native/WASM/client builds and full combined qualification','Independent final-diff review, current-main freshness, hosted CI and merge queue','Whole milestones4-7 scale, memory, accessibility, all-host and competitor acceptance']});print('checkpoint evidence',len(logs),'logs',len(artifacts),'artifacts',len(protected),'protected',len(combined),'combined')
