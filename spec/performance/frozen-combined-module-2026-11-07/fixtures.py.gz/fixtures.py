import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();dest=root/'spec/performance/frozen-combined-module-2026-11-07';run=root/'target/task-tmp/frozen-combined-union';commands=json.loads((root/'spec/performance/filter-catalog-abi-union-2026-11-07/fixture-transition.json').read_text());prepared=json.loads((dest/'fixture-transition-preparation.json').read_text());env=dict(os.environ,TMPDIR='/var/tmp',PYTHONPATH=str(root/'python'),XYG_NATIVE_LIB=str(root/'target/milestone-integration-build/release/libxyg_core.so'));env['PATH']=str(root/'target/task-tmp/node-v22.23.4-linux-x64/bin')+':'+env['PATH']
for path,row in commands.items():
 cmd=list(row['command'])
 if cmd[:2]==['uv','run']:cmd.insert(2,'--no-sync')
 result=subprocess.run(cmd,cwd=root,env=env,capture_output=True);name=Path(path).stem;(run/(name+'.generator.log')).write_bytes(result.stderr+(result.stdout if cmd[0]!='node' else b''));assert result.returncode==0,(path,result.stderr.decode(errors='replace'))
 if cmd[0]=='node':(root/path).write_bytes(result.stdout)
 current=(root/path).read_bytes();data=json.loads(current);assert data['abi_version']==405
 for version in [403,404]:
  before=(dest/f'abi{version}-predecessor'/Path(path).name).read_bytes();assert data==dict(json.loads(before),abi_version=405),(path,version)
 prepared[path].update(command=cmd,generatorExit=result.returncode,currentAbi=405,currentSha256=hashlib.sha256(current).hexdigest(),bytes=len(current),changedFields=['/abi_version'],productPacketChanges=[])
 print('generated unchanged packets',path,flush=True)
(dest/'fixture-transition.json').write_text(json.dumps(prepared,indent=2,sort_keys=True)+'\n')
