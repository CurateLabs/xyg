//! One stable-sort body per record type in the size-bounded browser module.
//! Native keeps the original comparator specialization. Ordering, stability,
//! allocation and the standard-library sorting algorithm are unchanged.
use std::cmp::Ordering;
pub(crate) fn by<T>(values: &mut [T], compare: impl FnMut(&T, &T) -> Ordering) {
    #[cfg(target_arch = "wasm32")]
    {
        let mut compare = compare;
        erased(values, &mut compare);
    }
    #[cfg(not(target_arch = "wasm32"))]
    values.sort_by(compare);
}
pub(crate) fn by_key<T, K: Ord>(values: &mut [T], key: impl FnMut(&T) -> K) {
    #[cfg(target_arch = "wasm32")]
    {
        let mut key = key;
        erased(values, &mut |a, b| key(a).cmp(&key(b)));
    }
    #[cfg(not(target_arch = "wasm32"))]
    values.sort_by_key(key);
}
#[cfg(target_arch = "wasm32")]
#[inline(never)]
fn erased<T>(values: &mut [T], compare: &mut dyn FnMut(&T, &T) -> Ordering) {
    values.sort_by(compare);
}

// Match the same standard-library unstable algorithm while sharing comparator
// dispatch per record type in wasm32. Native keeps its original specialization.
pub(crate) fn unstable_by<T>(values: &mut [T], compare: impl FnMut(&T, &T) -> Ordering) {
    #[cfg(target_arch = "wasm32")]
    {
        let mut compare = compare;
        unstable_erased(values, &mut compare);
    }
    #[cfg(not(target_arch = "wasm32"))]
    values.sort_unstable_by(compare);
}
pub(crate) fn unstable_by_key<T, K: Ord>(values: &mut [T], key: impl FnMut(&T) -> K) {
    #[cfg(target_arch = "wasm32")]
    {
        let mut key = key;
        unstable_erased(values, &mut |a, b| key(a).cmp(&key(b)));
    }
    #[cfg(not(target_arch = "wasm32"))]
    values.sort_unstable_by_key(key);
}
#[cfg(any(target_arch = "wasm32", test))]
#[inline(never)]
fn unstable_erased<T>(values: &mut [T], compare: &mut dyn FnMut(&T, &T) -> Ordering) {
    values.sort_unstable_by(compare);
}

#[cfg(test)]
mod unstable_tests {
    use super::*;

    #[test]
    fn erased_unstable_preserves_tie_permutations_and_key_order() {
        let mut seed = 0x4e36_1120_4510_0043u64;
        for len in 0..256 {
            let input: Vec<_> = (0..len)
                .map(|id| {
                    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                    ((seed >> 32) % 11, id)
                })
                .collect();
            let mut expected = input.clone();
            expected.sort_unstable_by_key(|r| r.0);
            let mut actual = input;
            unstable_erased(&mut actual, &mut |a, b| a.0.cmp(&b.0));
            assert_eq!(actual, expected, "length {len}");
        }
    }

    #[test]
    fn erased_unstable_preserves_float_bits_and_comparison_sequence() {
        let bits = [0, 1u64 << 63, 0x7ff0_0000_0000_0000, 0xfff0_0000_0000_0000,
            0x7ff8_0000_0000_0001, 0xfff8_0000_0000_0002, 1, u64::MAX,
            1f64.to_bits(), (-1f64).to_bits()];
        for len in [0, 1, 2, 7, 16, 31, 64, 127, 257] {
            let mut expected: Vec<_> = (0..len)
                .map(|i| f64::from_bits(bits[(i * 7 + i / 3) % bits.len()]))
                .collect();
            let mut actual = expected.clone();
            let mut before = Vec::new();
            let mut after = Vec::new();
            expected.sort_unstable_by(|a, b| {
                before.push((a.to_bits(), b.to_bits()));
                a.total_cmp(b)
            });
            unstable_erased(&mut actual, &mut |a, b| {
                after.push((a.to_bits(), b.to_bits()));
                a.total_cmp(b)
            });
            assert_eq!(after, before, "comparison sequence length {len}");
            assert_eq!(actual.iter().map(|v| v.to_bits()).collect::<Vec<_>>(),
                expected.iter().map(|v| v.to_bits()).collect::<Vec<_>>());
        }
    }

    #[test]
    fn erased_unstable_preserves_unwind_ownership() {
        use std::panic::{AssertUnwindSafe, catch_unwind};
        let input: Vec<_> = (0..128u64).map(|i| (i * 79) % 137).collect();
        let mut expected = input.clone();
        let mut actual = input;
        let mut before = 0;
        let mut after = 0;
        assert!(catch_unwind(AssertUnwindSafe(|| expected.sort_unstable_by(|a, b| {
            before += 1;
            assert!(before != 37, "comparator failure");
            a.cmp(b)
        }))).is_err());
        assert!(catch_unwind(AssertUnwindSafe(|| unstable_erased(&mut actual, &mut |a, b| {
            after += 1;
            assert!(after != 37, "comparator failure");
            a.cmp(b)
        }))).is_err());
        assert_eq!(after, before);
        assert_eq!(actual, expected);
        actual.sort_unstable();
        expected.sort_unstable();
        assert_eq!(actual, expected);
    }
}
