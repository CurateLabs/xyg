from pathlib import Path
import json,re,subprocess
parents=['bef92b1dc20894cf5f801d2421832dda8589bb45','fc50daad4a011c920fe18f814d951901ae797049']
def original(p,n=0):return subprocess.check_output(['git','show',parents[n]+':'+p])
def resolve(p,fn):
 f=Path(p);s=f.read_text();pat=r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n';counter=0
 def step(m):
  nonlocal counter
  out=fn(m.group(1),m.group(2),counter);counter+=1;return out
 s=re.sub(pat,step,s,flags=re.S|re.M);assert '<<<<<<<' not in s,p;f.write_text(s);print(p,'blocks',counter)
join=lambda a,b,i:a+b
resolve('.cargo/config.toml',join)
resolve('.gitattributes',join)
resolve('crates/xyg-engine/src/lib.rs',join)
resolve('crates/xyg-core/src/lib.rs',lambda a,b,i:'pub const ABI_VERSION: u32 = 405;\n' if i==0 else a+'    })\n}\n\n'+b)
resolve('crates/xyg-wasm/src/lib.rs',lambda a,b,i:'pub const WASM_ABI_VERSION: u32 = 38;\n' if i==0 else a+'    })\n    .unwrap_or(STATUS_INVALID_HANDLE)\n}\n\n'+b)
resolve('js/src/60_entries.ts',join)
resolve('js/src/63_graph_gpu.ts',lambda a,b,i:'  let visible = true;\n'+b if i==0 else b.replace('const completed = host.render(client, staging, width, height, (gl) => {','const completed = host.render(client, staging, width, height, () => {\n      const gl = host.clientContext(client);'))
p='packages/xy-node/package.json';a,b=[json.loads(original(p,i)) for i in (0,1)];av=a['scripts']['test'].split();bv=b['scripts']['test'].split();assert av[:2]==bv[:2]==['node','--test'];a['scripts']['test']=' '.join(av+[v for v in bv[2:] if v not in av[2:]]);Path(p).write_text(json.dumps(a,indent=2)+'\n')
p='spec/wasm/abi.json';a,b=[json.loads(original(p,i)) for i in (0,1)];a['abi_version']=38
for k,v in b['temporal_graph'].items():
 assert k not in a['temporal_graph'] or a['temporal_graph'][k]==v,k
 a['temporal_graph'][k]=v
symbols={v['name']:v for v in a['exports']}
for v in b['exports']:
 if v['name'] in symbols:assert v==symbols[v['name']],v['name']
 else:a['exports'].append(v)
assert len(a['exports'])==68;Path(p).write_text(json.dumps(a,indent=2)+'\n')
for p in ['python/xyg/_abi_generated.py','packages/xy-node/src/_abi_generated.js','spec/abi/xyg-abi.json','spec/abi/xyg.h','js/src/wasm_abi_generated.ts','spec/releases/0.6.0-api-inventory.json','tests/test_cross_host_abi_transition.py']:
 Path(p).write_bytes(original(p))
for p in ['spec/api/browser-wasm.md','spec/design/build-ci.md','spec/design/graph-interaction.md','spec/design/host-parity.md','spec/design/ownership-audit.md']:resolve(p,join)
p='spec/design/ownership-audit.json';a,b=[json.loads(original(p,i)) for i in (0,1)];print('ownership keys',list(a));key='entries' if 'entries' in a else 'files';entries={v['path']:v for v in a[key]}
for v in b[key]:
 if v['path'] in entries:assert entries[v['path']]==v,v['path']
 else:a[key].append(v)
a[key].sort(key=lambda x:x['path']);Path(p).write_text(json.dumps(a,indent=2)+'\n')
p='tests/test_graphforge_contract_corpus.py';resolve(p,lambda a,b,i:'    "spec/performance/frozen-combined-module-2026-11-07/current-bindings.json"\n')
