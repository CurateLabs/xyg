from pathlib import Path
p=Path('target/task-tmp/frozen-combined-union');snap=p/'before-geo-callback-sharing';snap.mkdir(exist_ok=True)
files=['crates/xyg-engine/src/geo_scale_protocol.rs','crates/xyg-engine/src/geo_tile_protocol.rs']
for f in files:
 q=snap/f;q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(Path(f).read_bytes())
items=[('crates/xyg-engine/src/geo_scale_protocol.rs','with_scene_data','handle: u64,\n    sequence: u64','GeoSceneDataBorrow<\'_>','T','Result<T>','handle, sequence'),('crates/xyg-engine/src/geo_scale_protocol.rs','with_overview_data','handle: u64,\n    sequence: u64',"&[u8], &crate::geo_temporal_overview::GeoOverviewResult, GeoViewport",'Result<T>','Result<T>','handle, sequence'),('crates/xyg-engine/src/geo_tile_protocol.rs','with_frame_data','handle: u64,\n    epoch: u64',"GeoTileFrameView<'_>",'T','Result<T>','handle, epoch')]
for f,name,args,callback,result,returns,values in items:
 pth=Path(f);s=pth.read_text();start=s.index(f'pub fn {name}<T>(');body=s.index(' {',start);header=s[start:body+2]
 paramnames=['scene','result','camera'] if name=='with_overview_data' else ['view'];params=', '.join(paramnames)
 wrapper=f'''pub fn {name}<T>(
    {args},
    callback: impl FnOnce({callback}) -> {result},
) -> {returns} {{
    #[cfg(target_arch = "wasm32")]
    {{
        let mut callback = Some(callback);
        {name}_erased({values}, &mut |{params}| {{
            callback.take().expect("one borrowed geographic operation")({params})
        }})
    }}
    #[cfg(not(target_arch = "wasm32"))]
    {name}_impl({values}, callback)
}}

#[cfg(target_arch = "wasm32")]
#[inline(never)]
fn {name}_erased<T>(
    {args},
    callback: &mut dyn FnMut({callback}) -> {result},
) -> {returns} {{
    {name}_impl({values}, callback)
}}

'''
 impl_header=header.replace('pub fn '+name+'<T>','fn '+name+'_impl<T>');s=s[:start]+wrapper+impl_header+s[body+2:];pth.write_text(s)
print('outlined3borrow-boundaries, original locks/validation/callback bodies retained')
