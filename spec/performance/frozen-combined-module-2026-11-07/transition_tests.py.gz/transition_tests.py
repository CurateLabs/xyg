import ast,subprocess
from pathlib import Path
p=Path('tests/test_cross_host_abi_transition.py');s=p.read_text();s=s.replace('TRANSITION = json.loads((RECEIPT / "fixture-transition.json").read_text())','''TRANSITION = json.loads((RECEIPT / "fixture-transition.json").read_text())
UNIFIED_RECEIPT = ROOT / "spec/performance/frozen-combined-module-2026-11-07"
HISTORICAL = RECEIPT
FROZEN_RECEIPT = ROOT / "spec/performance/temporal-graph-freeze-2026-11-07"
FROZEN_TRANSITION = json.loads(
    (ROOT / "spec/performance/temporal-worker-export-2026-11-07/fixture-transition.json").read_text()
)''')
start=s.index('def test_append_only_401_to_current_transition');prefix=s[:start];tail=s[start:];tail=tail.replace('current = (ROOT / path).read_bytes()','current = (UNIFIED_RECEIPT / "abi403-predecessor" / Path(path).name).read_bytes()').replace('abi_version=ABI_VERSION','abi_version=403').replace('transition["currentAbi"] == ABI_VERSION','transition["currentAbi"] == 403');s=prefix+tail
frozen=subprocess.check_output(['git','show','MERGE_HEAD:tests/test_cross_host_abi_transition.py'],text=True);tree=ast.parse(frozen)
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ['test_authentic_399_to_401_transition_is_preserved','test_preserved_402_producer_and_only_version_changed','test_preserved_403_producer_and_only_version_changed']:
  lines=frozen.splitlines();begin=min([node.lineno]+[d.lineno for d in node.decorator_list])-1;code='\n'.join(lines[begin:node.end_lineno]);code=code.replace('(RECEIPT /','(FROZEN_RECEIPT /').replace('TRANSITION[path]','FROZEN_TRANSITION[path]');s+='\n\n'+code+'\n'
s+='''\n\n@pytest.mark.parametrize("path", TRANSITION)
def test_frozen_historical_401_to_404_transition(path: str) -> None:
    entry = FROZEN_TRANSITION[path]
    before = (FROZEN_RECEIPT / "predecessor401" / Path(path).name).read_bytes()
    after = (UNIFIED_RECEIPT / "abi404-predecessor" / Path(path).name).read_bytes()
    assert hashlib.sha256(before).hexdigest() == entry["predecessorSha256"]
    assert hashlib.sha256(after).hexdigest() == entry["currentSha256"]
    assert json.loads(before)["abi_version"] == 401
    assert json.loads(after) == dict(json.loads(before), abi_version=404)


@pytest.mark.parametrize("path", TRANSITION)
@pytest.mark.parametrize("predecessor_abi", [403, 404])
def test_both_complete_parent_fixtures_survive_combined_abi(
    path: str, predecessor_abi: int
) -> None:
    entry = json.loads((UNIFIED_RECEIPT / "fixture-transition.json").read_text())[path]
    before = (UNIFIED_RECEIPT / f"abi{predecessor_abi}-predecessor" / Path(path).name).read_bytes()
    after = (ROOT / path).read_bytes()
    assert hashlib.sha256(before).hexdigest() == entry["predecessors"][str(predecessor_abi)]["sha256"]
    assert hashlib.sha256(after).hexdigest() == entry["currentSha256"]
    assert json.loads(before)["abi_version"] == predecessor_abi
    assert entry["currentAbi"] == ABI_VERSION
    assert json.loads(after) == dict(json.loads(before), abi_version=ABI_VERSION)
'''
p.write_text(s)
