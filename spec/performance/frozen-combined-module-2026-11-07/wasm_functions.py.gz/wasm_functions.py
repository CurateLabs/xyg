import json,subprocess,sys
from pathlib import Path
b=Path(sys.argv[1]).read_bytes()
def u(at):
 n=s=0
 while True:
  v=b[at];at+=1;n|=(v&127)<<s
  if not v&128:return n,at
  s+=7
at=8;names={};sizes=[]
while at<len(b):
 kind=b[at];at+=1;length,at=u(at);end=at+length
 if kind==0:
  n,p=u(at);name=b[p:p+n];p+=n
  if name==b'name':
   while p<end:
    sub=b[p];p+=1;n,p=u(p);finish=p+n
    if sub==1:
     count,p=u(p)
     for _ in range(count):
      ix,p=u(p);n,p=u(p);names[ix]=b[p:p+n].decode(errors='replace');p+=n
    p=finish
 if kind==10:
  count,p=u(at)
  for i in range(count):
   n,p=u(p);sizes.append((n,i));p+=n
 at=end
rows=[{'bytes':n,'index':i,'name':names.get(i,str(i))} for n,i in sorted(sizes,reverse=True)];decoded=subprocess.run(['c++filt','-s','rust'],input='\n'.join(x['name'] for x in rows),capture_output=True,text=True)
if decoded.returncode==0:
 for row,name in zip(rows,decoded.stdout.splitlines()):row['name']=name
out=Path(sys.argv[2]);out.write_text(json.dumps(rows,indent=2)+'\n');print('code',len(rows),'functions',sum(x['bytes'] for x in rows),'bytes; names',len(names))
for row in rows[:40]:print(row['bytes'],row['name'][:160])
