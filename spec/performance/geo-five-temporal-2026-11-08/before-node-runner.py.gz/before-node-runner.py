import os,subprocess
from pathlib import Path
paths=[Path('packages/xy-node/src/geo-temporal.js'),Path('packages/xy-node/src/geo-live-host.js')]
saved={p:p.read_bytes() for p in paths}
test=Path('packages/xy-node/test/geo-five-temporal.test.mjs').read_text()
test=test.replace('bindings.push(host.bindTemporal(h));', '''if(bindings.length){assert.throws(()=>host.bindTemporal(h),/source already has a temporal binding/);break;}bindings.push(host.bindTemporal(h));''').replace('assert.equal(bindings.length,5);','assert.equal(bindings.length,1);console.log("FINAL: second genuine lane refused on old Node; one original source, five issued histories");')
probe=Path('packages/xy-node/test/geo-five-negative-local.mjs')
try:
 for p in paths:p.write_bytes(subprocess.check_output(['git','show','b007e2d:'+str(p)]))
 probe.write_text(test)
 env={**os.environ,'XYG_NATIVE_LIB':'/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/release/libxyg_core.so','TMPDIR':'/var/tmp'}
 with open('target/task-tmp/five-temporal/before-node-final.log','w') as out:
  result=subprocess.run(['/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin/node','--test',str(probe)],env=env,stdout=out,stderr=subprocess.STDOUT)
  out.write(f'\nexit={result.returncode}\n')
finally:
 for p,b in saved.items():p.write_bytes(b)
 probe.unlink(missing_ok=True)
