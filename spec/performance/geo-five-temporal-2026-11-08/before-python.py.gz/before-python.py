import asyncio,json
from dataclasses import replace
import numpy as np
import xyg
from geo_mounted_hierarchy_temporal_fixture import mounted_hierarchy_chart_fixture
from test_geo_retained import style

async def run():
 source,scope,lane,frame,chart=mounted_hierarchy_chart_fixture()
 fork=second=state=operation=None
 widgets=[];binding=None;controller=xyg.TemporalController(instance_id=991,domain=(-100,100))
 try:
  fork=lane.fork();query=dict(chart.layers[0].properties['query'])
  state=scope.state(revision=1,ids=np.array([(1<<64)-1],dtype='<u8'),fill=b'\x00\xff\x00\xff')
  operation=fork.begin_selected(state,query,sequence=4);operation.drive();second=operation.prepare(style());state.close();state=None
  other=replace(chart,layers=(replace(chart.layers[0],properties={**chart.layers[0].properties,'sequence':4}),))
  widgets=[chart.widget(frame=frame,selected_scope=scope,hierarchy_lane=lane),other.widget(frame=second,selected_scope=scope,hierarchy_lane=fork)]
  binding=widgets[0].bind_temporal(controller)
  try:
   unexpected=widgets[1].bind_temporal(controller)
  except RuntimeError as e:
   assert str(e)=='source already has a temporal binding';print(json.dumps({'sameCanonicalSource':widgets[0]._adapter._source is widgets[1]._adapter._source,'independentNativeLanes':lane.handle!=fork.handle,'secondBindingRefused':str(e),'scope':'Real native issued selected hierarchy forks; premount admission only, no browser/paint/performance claim'}))
  else:
   await unexpected.aclose();raise AssertionError('Expected original source-key refusal')
 finally:
  if binding is not None:await binding.aclose()
  for w in widgets:
   w.close()
   if w._geo_rpc_task is not None:await w._geo_rpc_task
  controller.close()
  if state is not None:state.close()
  if operation is not None:operation.close()
  if second is not None:second.close()
  frame.close()
  if fork is not None:fork.close()
  lane.close();source.close();scope.close()
asyncio.run(run())
