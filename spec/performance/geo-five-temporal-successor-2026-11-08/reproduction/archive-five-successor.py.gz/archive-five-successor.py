from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile,io,os
root=Path.cwd();source=root/'target/task-tmp/five-temporal-successor';dest=root/'spec/performance/geo-five-temporal-successor-2026-11-08'
def bind(p):
 data=p.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def packed(path,output):
 output.parent.mkdir(parents=True,exist_ok=True)
 with path.open('rb') as inp,output.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=6,mtime=0) as out:
  while block:=inp.read(1<<20):out.write(block)
for p in source.rglob('*'):
 if not p.is_file() or 'source' in p.relative_to(source).parts:continue
 name=p.relative_to(source)
 if p.suffix in ('.log','.json','.txt'):packed(p,dest/'receipts'/(str(name)+'.gz'))
 elif p.suffix in ('.png','.bin'):(dest/'receipts'/name).parent.mkdir(parents=True,exist_ok=True);(dest/'receipts'/name).write_bytes(p.read_bytes())
for p in source.glob('*.js.gz'):
 (dest/'runtime').mkdir(exist_ok=True);(dest/'runtime'/p.name).write_bytes(p.read_bytes())
for name,p in {'native-405':root/'target/release/libxyg_core.so','wasm-38':root/'packages/xy-client/dist/xyg-wasm.wasm','client-esm':root/'packages/xy-client/dist/index.js','client-iife':root/'packages/xy-client/dist/standalone.js','borrowed-unmatched-catalog-oracle':source/'borrowed-geo_layers_conformance','source-built-catalog-oracle':root/'target/debug/geo_layers_conformance'}.items():
 packed(p,dest/'runtime'/(name+'.gz'))
with (dest/'source.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w|',format=tarfile.USTAR_FORMAT) as archive:
 for p in sorted((source/'source').glob('*.gz')):
  data=gzip.decompress(p.read_bytes());name=p.stem;assert hashlib.sha256(data).hexdigest()==name
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0;archive.addfile(info,io.BytesIO(data))
changed=subprocess.check_output(['git','diff','--name-only','4e2496892'],text=True).splitlines()
for name in changed:
 try:data=subprocess.check_output(['git','show','4e2496892:'+name],stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:continue
 p=dest/'predecessor'/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0))
expected=json.loads((root/'spec/performance/dense-native-navigation-union-2026-11-08/compiled-input-equality.json').read_text())
assert len(expected)==324
assert all(bind(root/p)['sha256']==h for p,h in expected.items())
(dest/'compiled-input-equality.json').write_text(json.dumps(expected,indent=2)+'\n')
client_expected=json.loads((root/'spec/performance/browser-css-color-2026-11-08/browser-producer-inputs.json').read_text());client_current={p:bind(root/p) for p in client_expected}
(dest/'browser-producer-inputs.json').write_text(json.dumps(client_current,indent=2)+'\n')
node='/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin/node';chrome='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'
interpreters=[str(root/'.venv/bin/python'),'/home/ubuntu/.t3/worktrees/xyg/t3-1319e871/.venv/bin/python'];python_env={}
for executable in interpreters:
 result=subprocess.check_output([executable,'-c',"import sys,json,importlib.metadata as m;print(json.dumps({'version':sys.version,'executable':sys.executable,'packages':{d.metadata['Name']:d.version for d in m.distributions()}}))"],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},text=True)
 python_env[executable]={**json.loads(result),'binary':bind(Path(executable))}
wasm=subprocess.check_output([node,'--input-type=module','-e',"import{readFileSync}from'node:fs';import{gzipSync}from'node:zlib';const b=readFileSync('packages/xy-client/dist/xyg-wasm.wasm');console.log(JSON.stringify({functionExports:WebAssembly.Module.exports(new WebAssembly.Module(b)).filter(e=>e.kind==='function').length,raw:b.length,gzip6:gzipSync(b,{level:6}).length}));"],text=True)
env={'parent':'4e2496892fe258f09f2911249005292be43bd5ad','parentTree':subprocess.check_output(['git','rev-parse','4e2496892^{tree}'],text=True).strip(),'rootBase':'b007e2d7cafac6d107d6bb409eac89f8a79ee4c9','nativeInputs324Unchanged':True,'nativeCoreFreshBuild':False,'wasmFreshBuild':False,'conformanceFreshBuild':True,'clientFreshOfficialBuild':True,'nativeFunctions':551,'wasm':json.loads(wasm),'node':{'path':node,**bind(Path(node))},'chrome':{'path':chrome,**bind(Path(chrome))},'python':python_env,'rustc':subprocess.check_output(['/home/ubuntu/.cargo/bin/rustc','--version','--verbose'],text=True),'nativeAndClient':{str(p.relative_to(root)):bind(p) for p in [root/'target/release/libxyg_core.so',root/'packages/xy-client/dist/xyg-wasm.wasm',root/'packages/xy-client/dist/index.js',root/'packages/xy-client/dist/standalone.js',root/'python/xyg/static/index.js',root/'python/xyg/static/standalone.js']},'oracles':{str(p.relative_to(root)):bind(p) for p in (root/'target/debug').glob('*conformance')},'borrowedOracleSource':'unknown; unqualified. Exact bytes and reproducible output mismatch archived.','buildCommands':[['/home/ubuntu/.cargo/bin/cargo','build','--offline','-p','xyg-wasm','--bin','geo_layers_conformance'],['/home/ubuntu/.cargo/bin/cargo','build','--offline','-p','xyg-wasm','--bins'],[node,'js/build.mjs']],'remoteMutations':False}
(dest/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
print(json.dumps({'sourceObjects':len(list((source/'source').glob('*.gz'))),'sourceArchive':bind(dest/'source.tar.gz'),'environment':bind(dest/'environment.json')}))
