import os,subprocess
from pathlib import Path
root=Path.cwd();base={**os.environ,'TMPDIR':'/var/tmp','PYTHONDONTWRITEBYTECODE':'1','XYG_NATIVE_LIB':str(root/'target/release/libxyg_core.so'),'XYG_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'}
for name,options in [('canonical-oneview',{}),('indexed-oneview',{'XYG_GEO_INDEXED':'1'}),('hierarchy-oneview',{'XYG_GEO_HIERARCHY':'1'})]:
 env={**base,**options}
 r=subprocess.run([str(root/'.venv/bin/python'),'scripts/qualify_geo_five_temporal.py','--name',name,'--','/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin/node','tests/browser/geo_mounted_temporal_test.mjs'],env=env)
 if r.returncode:raise SystemExit(r.returncode)
