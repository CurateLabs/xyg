import os,subprocess
from pathlib import Path
root=Path.cwd();node='/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin/node'
base={**os.environ,'TMPDIR':'/var/tmp','PYTHONDONTWRITEBYTECODE':'1','XYG_NATIVE_LIB':str(root/'target/release/libxyg_core.so'),'XYG_CHROMIUM':'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome'}
cases=[('baseline-reduced-negative',{'XYG_GEO_AGGREGATE':'1','XYG_CLIENT_ESM':str(root/'target/task-tmp/five-temporal-successor/baseline-index.js')},1),('direct-cursor-matrix',{},0),('direct-range-matrix',{'XYG_GEO_RANGE':'1'},0),('reduced-cursor-matrix',{'XYG_GEO_AGGREGATE':'1'},0),('reduced-range-matrix',{'XYG_GEO_AGGREGATE':'1','XYG_GEO_RANGE':'1'},0)]
for name,options,expected in cases:
 directory=root/'target/task-tmp/five-temporal-successor'/name;directory.mkdir(exist_ok=True)
 env={**base,**options,'XYG_GEO_ARTIFACT_DIR':str(directory)}
 r=subprocess.run([str(root/'.venv/bin/python'),'scripts/qualify_geo_five_temporal.py','--name',name,'--',node,'tests/browser/geo_five_temporal_test.mjs'],env=env)
 assert r.returncode==expected,(name,r.returncode,expected)
