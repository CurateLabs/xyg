"""Negative control: final assertions against the exact reviewed parent module."""

def pytest_configure(config):
    import hashlib
    import subprocess
    import xyg._geo_temporal as module
    before = subprocess.check_output([
        "git", "show", "2c67a5638265ed6881d6aa50ea466b860cd2195f:python/xyg/_geo_temporal.py"
    ])
    bindings = module._BINDINGS
    exec(compile(before, module.__file__, "exec"), module.__dict__)
    module._BINDINGS = bindings
    print("original production SHA256", hashlib.sha256(before).hexdigest())
