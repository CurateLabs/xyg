import ast,subprocess,sys
import xyg._geo_temporal as binding
import xyg._geo_retained as retained
import pytest
base='bfb7aaecf909680d2613a9a00a689e880269ad38'
for path,module,cls,names in [('python/xyg/_geo_temporal.py',binding,binding.GeoTemporalBinding,['_accept','_pump']),('python/xyg/_geo_retained.py',retained,retained.RetainedGeoSource,['acancel','_dispose_async'])]:
 tree=ast.parse(subprocess.check_output(['git','show',base+':'+path],text=True))
 for c in tree.body:
  if isinstance(c,ast.ClassDef) and c.name==cls.__name__:
   for f in c.body:
    if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name in names:
     ns={};exec(compile(ast.Module(body=[f],type_ignores=[]),path,'exec'),module.__dict__,ns);setattr(cls,f.name,ns[f.name])
sys.exit(pytest.main(['tests/test_geo_temporal_binding.py','-k','source_cancellation or foreign_thread','-q']))
