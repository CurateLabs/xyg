import os,json,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parents[3];d=r/'target/task-tmp/gpu-default1k-union'
env=dict(os.environ,TMPDIR='/var/tmp',PYTHONPATH=str(r/'python'),XYG_NATIVE_LIB=str(r/'target/task-tmp/default1k-mounted-catalog-union/artifacts/libxyg_core.so'),XYG_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome',XYG_TEST_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome',XYG_WASM_FOUNDATION_REPORT=str(d/'foundation.json'),XYG_GPU_REPORT_DIR=str(d/'gpu'))
env['PATH']=str(r/'target/task-tmp/node-v22.23.4-linux-x64/bin')+':/home/ubuntu/.cargo/bin:'+env['PATH']
phases={
'build':[('client-build',['node','js/build.mjs']),('package',['node','js/package-wasm.mjs','target/milestone-integration-build/wasm32-unknown-unknown/release/xyg_wasm.wasm']),('assets',['python3','scripts/verify_wasm_assets.py'])],
'native':[('python',['uv','run','pytest','-q','tests/test_shared_glhost.py','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_verify_ownership.py','tests/test_geo_mounted_temporal.py','tests/test_geo_temporal_binding.py','tests/test_temporal_catalog.py','tests/test_temporal_catalog_geo_integration.py','tests/test_filter_tier_c_density.py']),('node-full',['npm','test','--prefix','packages/xy-node']),('types',['uv','run','ty','check']),('abi',['python3','scripts/gen_abi_manifest.py','--check']),('wasm-abi',['python3','scripts/gen_wasm_abi.py','--check'])],
'browser':[('foundation',['node','scripts/wasm_foundation_smoke.mjs']),('gpu',['node','scripts/dashboard_gpu_smoke.mjs']),('filter',['node','scripts/filter_tier_c_conformance.mjs','--capture',str(d/'filter.png')])],
'colored':[('colored',['uv','run','python','benchmarks/bench_density_e2e.py','--workload','colored-spill','--points','16384','--chunk-points','4096','--chrome',env['XYG_CHROMIUM'],'--timeout','180','--max-rss-gib','4','--max-disk-gib','1','--output',str(d/'colored-host.json'),'--colored-browser-report',str(d/'colored-browser.json')]),('colored-host-verify',['uv','run','python','scripts/verify_density_spill_report.py',str(d/'colored-host.json'),'--artifact-root',str(r)]),('colored-browser-verify',['uv','run','python','scripts/verify_density_spill_browser_report.py',str(d/'colored-browser.json'),'--host-report',str(d/'colored-host.json'),'--sha','cf5581e681524451e0e99806c8aa26a40b2b3760','--artifact-root',str(r)])],
'core-final':[('core-final',['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_verify_ownership.py'])],
'ci':[('ci',['make','check-ci'])],
'gates':[('hooks',['uv','run','--with','pre-commit','pre-commit','run','--all-files']),('ruff',['uv','run','ruff','check','.']),('format',['uv','run','ruff','format','--check','.'])]
}
for name,cmd in phases[sys.argv[1]]:
 t=time.time()
 with (d/(name+'.log')).open('wb') as f:code=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 row={'command':cmd,'exit':code,'seconds':time.time()-t,'log':str(d/(name+'.log'))};(d/(name+'.exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:sys.exit(code)
