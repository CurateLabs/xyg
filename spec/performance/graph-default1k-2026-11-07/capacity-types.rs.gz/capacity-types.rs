use xyg_engine::graphforge::interaction::{NodePaint,EdgePiece};
use xyg_engine::graph_style::{ResolvedGraphStyle,SemanticPaintLayers};
fn main(){println!("NodePaint={} EdgePiece={} ResolvedGraphStyle={} SemanticPaintLayers={}",std::mem::size_of::<NodePaint>(),std::mem::size_of::<EdgePiece>(),std::mem::size_of::<ResolvedGraphStyle>(),std::mem::size_of::<SemanticPaintLayers>());}
