# Incomplete DEFAULT1k investigation; no implementation candidate

Base/head: c90fcd3047e4cac69c307ffe1f27c37c4d69c0f8. No commit, no changed tracked paths. Production modifications were experimental and reverted. No positive default-arena evidence or acceptance claim.

Read AGENTS.md, dossier §§27/29/34, graph-interaction memory and progressive contracts, and graphforge-node-scheduling.md. No children, remote actions, GitHub/PR/push/watch/queue actions or paid runs.

## Measurements before changing policy

Diagnostic ledger source and patch are adjacent. The patch extends the existing isolated Counting GlobalAlloc executable; it does not change admission. Execute with TMPDIR=/var/tmp CARGO_TARGET_DIR=/var/tmp/xyg-default1k-target /home/ubuntu/.cargo/bin/cargo test -p xyg-engine --test graph_session_memory -- --nocapture. XYG_MEMORY_CAPTURE=/var/tmp/xyg-default1k-evidence writes OPEN/RENDER bytes consumed by the WASM probe.

1k XYGF is 69,672 bytes and OPEN is 69,992. Default 16,777,216-byte OPEN refuses before session allocation; native temporary peak is 1,088 requested bytes. At explicit 384 MiB OPEN retains 484,784 requested bytes, peak 485,648. Retained admission envelope after OPEN is 57,019,312 bytes.

Document envelope components (excluding actual caches/state and next request/external): fixed 114,688; node GPU 2,048,000; edge GPU 8,192,000; document 3,344,256; rows 16,384,000; grid 16,777,216; possible state 9,217,024; projection 520,192; total 56,597,376. Even removing all grid accounting leaves 39,820,160 bytes. Removing this reservation would not solve default1k and would discard required old/new owners.

With the current public camera [.25,.25,320,160,640,320,1], OPEN/RENDER/38 STEP commands (10 native ticks each) peak at 9,090,844 requested native heap bytes. Retained live delta after seq40 is 3,678,320. Pick grid grows through 81,792, 172,265, 282,096 and eventually ~444,000 entries, with no degradation. An initial-capacity estimator would be unsafe. Disposal leaves a 4,704-byte process baseline delta (includes first-use output/runtime allocations; not a session leak qualification).

With camera [.01,.01,320,160,640,320,1], initial 1k render peaks at 8,207,265; STEP peaks at 14,150,146. Degraded grid has zero logical entries while its Vec cell capacities remain allocated. This is a real capacity-retention issue, separate from the up-front reservation.

Shipping WASM hash matches the c90 parent: b262993164c6b55c5c8571b209df423e1d554708440d8629e2db5a5cd3a18680. The independent direct-WASM probe uses the captured complete native test OPEN/RENDER and canonical STEP requests. At 16 MiB OPEN returns -4; memory is 1,376,256 bytes. At explicit 384 MiB it opens, renders and steps; linear memory reaches 10,944,512 bytes and cannot shrink on disposal. This is actual WASM linear memory, not requested Rust heap, browser-process RSS or GPU accounting. It is a baseline diagnostic, not a successful DEFAULT journey or full browser/native/WASM replay.

The public .25 camera culls the initial geometry: initial GPU header has 458 nodes/456 edges, then 790/788, then 1000/1000. Source identity remains 1000/1000. This camera cannot pass the requested full painted-node/edge assertion at every publication without a deliberate camera decision. Do not mislabel retained identity counts as every-publication paint counts.

## Rejected experiment and preserved regression

Changed only degraded grid reset from cell.clear() to *cell=Vec::new(), then ran the allocation ledger. Public 1k peak and admission were unchanged. 10k degraded STEP live bytes fell from 18,516,776 to 12,132,648, but cumulative requested peak stayed 39,103,392. This experiment was reverted; it is neither the requested fix nor admission evidence. predecessor-pick.rs contains exact original bytes.

The unmodified independent UPDATE exact-boundary regression passes at 3,526,208 and refuses 3,526,207 with failure atomicity and cached retry. Full output is exact-update-predecessor.log.

First WASM probe incorrectly passed 0 to instance_new; that creates an invalid handle (not a default-size instance). It failed at arena resize with status1. Preserved as wasm-probe-invalid-zero.failure.log; corrected probe passes explicit16MiB to match the Worker default. It still refuses OPEN. No failure is counted as a positive proof.

## Engineering work still required

There is no verified hard impossibility: measured plain-graph allocation fits under16MiB. No safe product repair was completed. The current document-wide potential reservations overlap old/new sources, layout, publications, routes, builder/final/cached replies, grid and possible state. Replacing them with actual capacity admission needs allocation plans or bounded builders before each phase, including failure-atomic whole replacement. Native measurements alone cannot establish those bounds for arbitrary text/derived/compound documents. Simply lowering constants, ignoring possible owners, or using initial-grid sizes was rejected.

The requested positive default1k browser initial/progressive paint, unfinished trusted pick, keyboard/realTab identity/emphasis, camera, coalescing/stale suppression, peer isolation, convergence/cleanup, exact complete native/WASM browser replay and adversarial capacity boundaries remain undone. No ABI/default/cap/LOD/profile/package change; no M4, issue or milestone claim. Parent independent review, current-main integration, PR/CI/queue remain required for any future candidate.

## Fresh baseline browser and replay result

The untouched `graph_session_public10k_smoke.mjs` passes: it explicitly asserts default1k GF_INTERACTION_BUDGET, then completes the historical explicit384MiB10k and explicit384MiB1k journeys. Primary60frames/peer59frames, both458native ticks, no recorded errors. Adjacent JSON/screenshots retain the actual capture. This does not add keyboard acceptance or fix default admission.

After restoring every production source, native was rebuilt sequentially: ABI402 / SHA256347ca67b5eb09aed8b8f6d6578f1f21913c195ab197ce70a68ba6a2e1dac35f6 (matches supplied c90 artifact). Complete browser/native402/shippingWASM replay passes for62primary and60peer commands. The replay reuses one WASM module, so its46,137,344-byte linear high water includes the10k case and is NOT isolated1k memory. See public10k-baseline-replay.log.

Exact ordered parents of retained HEAD: 81c4ba55bb23a858b8f3dd8dd4ecbbf4e97377e5 then0a85b8da98ceb5dd0f2ef308f51c85a46f22460e. No new candidate commit exists; changed tracked paths are empty. Canonical final diff is empty (SHA256e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855). Baseline source/native/WASM/client/environment bindings are in baseline-bindings.json; exact relevant commands/exits including failed attempt are in commands.txt. Historical repository evidence was not modified. No full-worktree hooks/Ruff run or independent review is claimed.
