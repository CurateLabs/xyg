import fs from 'node:fs';
import assert from 'node:assert/strict';
import {encodeContainer,decodeContainer,DTYPE} from '/home/ubuntu/.t3/worktrees/xyg/t3-cc3b03dc/packages/xy-node/src/graphforge-container.js';
const artifact=process.argv[2];
for(const budget of [16*1024*1024,384*1024*1024]) {
 const {instance:{exports:x}}=await WebAssembly.instantiate(fs.readFileSync(artifact),{});
 const h=x.xyg_wasm_instance_new(budget), frames=[];
 const call=(name,b)=>{assert.equal(x.xyg_wasm_arena_resize(h,b.length),0); new Uint8Array(x.memory.buffer,x.xyg_wasm_arena_ptr(h)>>>0,b.length).set(b); const status=x[name](h,0,b.length);const out=new Uint8Array(x.memory.buffer,x.xyg_wasm_output_ptr(h)>>>0,x.xyg_wasm_output_len(h)>>>0).slice();return {status,out,memory:x.memory.buffer.byteLength};};
 const open=call('xyg_wasm_graphforge_session_open',fs.readFileSync('/var/tmp/xyg-default1k-evidence/open-1000.xygi'));
 console.log(JSON.stringify({budget,phase:'open',status:open.status,linear:open.memory}));
 if(budget===16*1024*1024){assert.equal(open.status,-4);x.xyg_wasm_instance_dispose(h);continue;}
 assert.equal(open.status,0);
 let reply=call('xyg_wasm_graphforge_session_render',fs.readFileSync('/var/tmp/xyg-default1k-evidence/render-1000.xygi'));
 for(let seq=3;seq<=40;seq++){
  assert.equal(reply.status,0);let c=decodeContainer(reply.out,'XYGR'), rev=c.get('header.u32#0').value[0];
  frames.push({seq:seq-1,output:reply.out.length,linear:reply.memory,nodes:c.get('gpu.header.u32#0').value[2],edges:c.get('gpu.header.u32#0').value[3]});
  const f=(name,type,values)=>({name,dtype:DTYPE[type],values});
  reply=call('xyg_wasm_graphforge_session_interact',encodeContainer('XYGI',[f('header.u64','u64',[7101n,0n,BigInt(seq)]),f('header.u32','u32',[rev,15,0,0,0,0,0,10,0])]));
 }
 console.log(JSON.stringify({budget,frames}));
 assert.equal(x.xyg_wasm_graphforge_session_close(h),0);assert.equal(x.xyg_wasm_instance_dispose(h),0);
 console.log(JSON.stringify({budget,phase:'disposed',linear:x.memory.buffer.byteLength}));
}
