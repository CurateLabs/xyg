import time
from types import SimpleNamespace
import numpy as np
import xyg
from xyg._graph_widget_identity import NotebookGraphIdentity
from xyg._graph_session import GraphSessionError

def composition(n):
    ids=b''.join((i+1).to_bytes(16,'big') for i in range(n))
    return xyg.compose_graphforge(base={'node_uuid':ids,'edge_uuid':b'','edge_source_uuid':b'','edge_target_uuid':b''})

n=40000;c=composition(n);w=xyg.graphforge_chart(c).widget()
try:
    cp=SimpleNamespace(x=np.arange(n,dtype=np.float64),y=np.zeros(n),step=1,alpha=1.)
    try:
        w._compile(cp)
        print('40000 no-callback frame compiled',flush=True)
    except GraphSessionError as e: print('40000 no-callback frame refused',e.status,flush=True)
finally:w.close()
n=10001;c=composition(n)
class Figure: pass
f=Figure();m={'tier_name':'direct','node_trace':0,'edge_trace':1,'member_of':np.arange(n),'n_nodes':n}
a=NotebookGraphIdentity(c,m,f,np.arange(n,dtype=np.float64),np.zeros(n))
try:
    t=time.monotonic()
    try:
        out=a.project({0:np.arange(n)})
        print('10001 projection returned',len(out),'seconds',time.monotonic()-t,flush=True)
    except GraphSessionError as e:print('10001 projection refused',e.status,'seconds',time.monotonic()-t,flush=True)
finally:a.session.close()
