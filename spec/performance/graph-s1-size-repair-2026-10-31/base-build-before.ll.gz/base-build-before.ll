define dso_local void @_ZN10xyg_engine10graphforge4base5build17heb466ba8ea0468e8E(ptr dead_on_unwind noalias noundef writable sret([144 x i8]) align 8 captures(none) dereferenceable(144) %_0, ptr noalias noundef nonnull readonly align 4 captures(address) %tables.0, i32 noundef range(i32 0, 53687092) %tables.1, ptr dead_on_return noalias noundef readonly align 4 captures(none) dereferenceable(32) %planes, i1 noundef zeroext %directed) unnamed_addr #4 {
"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit31":
  %args.i.i.i.i = alloca [8 x i8], align 4
  %_2.i.i.i.i = alloca [40 x i8], align 4
  %field.i.i.i.i = alloca [8 x i8], align 4
  %id.i.i.i = alloca [16 x i8], align 1
  %_6.i.i.i.i.i.i.i.i.i = alloca [16 x i8], align 1
  %_66.i.i = alloca [40 x i8], align 4
  %args.i = alloca [8 x i8], align 4
  %_25.i = alloca [16 x i8], align 1
  %_19.i35 = alloca [16 x i8], align 1
  %_16.i36 = alloca [16 x i8], align 1
  %id.i = alloca [16 x i8], align 1
  %missing.i = alloca [8 x i8], align 8
  %args.i.i = alloca [8 x i8], align 4
  %_2.i.i = alloca [40 x i8], align 4
  %field.i.i = alloca [8 x i8], align 4
  %item.i.i.i.i = alloca [16 x i8], align 4
  %_9.i.i.i.i = alloca [16 x i8], align 4
  %self.i.i.i.i = alloca [16 x i8], align 4
  %_7.i.i.i.i = alloca [16 x i8], align 4
  %array.i.i.i = alloca [48 x i8], align 4
  %0 = alloca [16 x i8], align 1
  %_308.i = alloca [40 x i8], align 4
  %_242.i = alloca [40 x i8], align 4
  %_233.i = alloca [40 x i8], align 4
  %_227.i = alloca [40 x i8], align 4
  %_123.i = alloca [16 x i8], align 4
  %_121.i = alloca [40 x i8], align 4
  %_114.i = alloca [17 x i8], align 1
  %_108.i = alloca [40 x i8], align 4
  %id22.i = alloca [16 x i8], align 1
  %iter19.i = alloca [68 x i8], align 4
  %_89.i = alloca [40 x i8], align 4
  %_85.i = alloca [16 x i8], align 4
  %_82.i = alloca [16 x i8], align 4
  %kinds16.i = alloca [12 x i8], align 4
  %_78.i = alloca [48 x i8], align 4
  %names15.i = alloca [12 x i8], align 4
  %_74.i = alloca [16 x i8], align 4
  %_73.i = alloca [16 x i8], align 4
  %_71.i = alloca [40 x i8], align 4
  %val10.i = alloca [16 x i8], align 1
  %val8.i = alloca [16 x i8], align 1
  %val6.i = alloca [16 x i8], align 1
  %_53.i = alloca [40 x i8], align 4
  %iter.i = alloca [88 x i8], align 4
  %_38.i = alloca [16 x i8], align 4
  %_37.i = alloca [16 x i8], align 4
  %kinds.i = alloca [12 x i8], align 4
  %_34.i = alloca [16 x i8], align 4
  %_33.i = alloca [16 x i8], align 4
  %_31.i = alloca [40 x i8], align 4
  %_27.i = alloca [16 x i8], align 4
  %_26.i = alloca [16 x i8], align 4
  %_24.i = alloca [40 x i8], align 4
  %_19.i = alloca [16 x i8], align 4
  %_18.i = alloca [16 x i8], align 4
  %_16.i = alloca [40 x i8], align 4
  %_45 = alloca [192 x i8], align 8
  %_35 = alloca [16 x i8], align 1
  %_33 = alloca [16 x i8], align 1
  %_31 = alloca [16 x i8], align 1
  %_29 = alloca [40 x i8], align 4
  %_23 = alloca [40 x i8], align 4
  %id = alloca [16 x i8], align 1
  %collector = alloca [192 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %collector)
  %1 = zext i1 %directed to i8
  %2 = getelementptr inbounds nuw i8, ptr %collector, i32 16
  store ptr @alloc_a48736f782ce01888cde2ce41f6badc9, ptr %2, align 8
  %_5.sroa.0.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 20
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %_5.sroa.0.sroa.4.0..sroa_idx, ptr noundef nonnull align 4 dereferenceable(12) getelementptr inbounds nuw (i8, ptr @anon.372511f0247cd277e01b2285bd0376b0.0, i32 4), i32 12, i1 false)
  %_5.sroa.0.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 32
  store ptr @alloc_a48736f782ce01888cde2ce41f6badc9, ptr %_5.sroa.0.sroa.5.0..sroa_idx, align 8
  %_5.sroa.0.sroa.5.sroa.4.0._5.sroa.0.sroa.5.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 36
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %_5.sroa.0.sroa.5.sroa.4.0._5.sroa.0.sroa.5.0..sroa_idx.sroa_idx, ptr noundef nonnull align 4 dereferenceable(12) getelementptr inbounds nuw (i8, ptr @anon.372511f0247cd277e01b2285bd0376b0.0, i32 4), i32 12, i1 false)
  %_5.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 48
  store i64 0, ptr %_5.sroa.5.0..sroa_idx, align 8
  %_5.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 56
  store i32 0, ptr %_5.sroa.6.0..sroa_idx, align 8
  %_5.sroa.6.sroa.4.0._5.sroa.6.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 60
  store ptr inttoptr (i32 1 to ptr), ptr %_5.sroa.6.sroa.4.0._5.sroa.6.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.6.sroa.5.0._5.sroa.6.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 64
  store i32 0, ptr %_5.sroa.6.sroa.5.0._5.sroa.6.0..sroa_idx.sroa_idx, align 8
  %_5.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 68
  store i32 0, ptr %_5.sroa.7.0..sroa_idx, align 4
  %_5.sroa.7.sroa.4.0._5.sroa.7.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 72
  store ptr inttoptr (i32 4 to ptr), ptr %_5.sroa.7.sroa.4.0._5.sroa.7.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.7.sroa.5.0._5.sroa.7.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 76
  store i32 0, ptr %_5.sroa.7.sroa.5.0._5.sroa.7.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.8.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 80
  store i32 0, ptr %_5.sroa.8.0..sroa_idx, align 8
  %_5.sroa.8.sroa.4.0._5.sroa.8.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 84
  store ptr inttoptr (i32 4 to ptr), ptr %_5.sroa.8.sroa.4.0._5.sroa.8.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.8.sroa.5.0._5.sroa.8.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 88
  store i32 0, ptr %_5.sroa.8.sroa.5.0._5.sroa.8.0..sroa_idx.sroa_idx, align 8
  %_5.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 92
  store i32 0, ptr %_5.sroa.9.0..sroa_idx, align 4
  %_5.sroa.9.sroa.4.0._5.sroa.9.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 96
  store ptr inttoptr (i32 1 to ptr), ptr %_5.sroa.9.sroa.4.0._5.sroa.9.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.9.sroa.5.0._5.sroa.9.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 100
  store i32 0, ptr %_5.sroa.9.sroa.5.0._5.sroa.9.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.10.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 104
  store i32 0, ptr %_5.sroa.10.0..sroa_idx, align 8
  %_5.sroa.10.sroa.4.0._5.sroa.10.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 108
  store ptr inttoptr (i32 4 to ptr), ptr %_5.sroa.10.sroa.4.0._5.sroa.10.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.10.sroa.5.0._5.sroa.10.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 112
  store i32 0, ptr %_5.sroa.10.sroa.5.0._5.sroa.10.0..sroa_idx.sroa_idx, align 8
  %_5.sroa.11.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 116
  store i32 0, ptr %_5.sroa.11.0..sroa_idx, align 4
  %_5.sroa.11.sroa.4.0._5.sroa.11.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 120
  store ptr inttoptr (i32 4 to ptr), ptr %_5.sroa.11.sroa.4.0._5.sroa.11.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.11.sroa.5.0._5.sroa.11.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 124
  store i32 0, ptr %_5.sroa.11.sroa.5.0._5.sroa.11.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.12.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 128
  store i32 0, ptr %_5.sroa.12.0..sroa_idx, align 8
  %_5.sroa.12.sroa.4.0._5.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 132
  store ptr inttoptr (i32 4 to ptr), ptr %_5.sroa.12.sroa.4.0._5.sroa.12.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.12.sroa.5.0._5.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 136
  store i32 0, ptr %_5.sroa.12.sroa.5.0._5.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_5.sroa.13.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 140
  store i32 0, ptr %_5.sroa.13.0..sroa_idx, align 4
  %_5.sroa.13.sroa.4.0._5.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 144
  store ptr inttoptr (i32 8 to ptr), ptr %_5.sroa.13.sroa.4.0._5.sroa.13.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.13.sroa.5.0._5.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 148
  store i32 0, ptr %_5.sroa.13.sroa.5.0._5.sroa.13.0..sroa_idx.sroa_idx, align 4
  %_5.sroa.14.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 152
  store i8 %1, ptr %_5.sroa.14.0..sroa_idx, align 8
  %3 = getelementptr inbounds nuw i8, ptr %collector, i32 160
  store i32 0, ptr %3, align 8
  %_9.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 164
  store ptr inttoptr (i32 4 to ptr), ptr %_9.sroa.4.0..sroa_idx, align 4
  %_9.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 168
  store i32 0, ptr %_9.sroa.5.0..sroa_idx, align 8
  store ptr @alloc_a48736f782ce01888cde2ce41f6badc9, ptr %collector, align 8
  %_10.sroa.4.0.collector.sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 4
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %_10.sroa.4.0.collector.sroa_idx, ptr noundef nonnull align 4 dereferenceable(12) getelementptr inbounds nuw (i8, ptr @anon.372511f0247cd277e01b2285bd0376b0.0, i32 4), i32 12, i1 false)
  %4 = getelementptr inbounds nuw i8, ptr %collector, i32 172
  store i32 0, ptr %4, align 4
  %_11.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 176
  store ptr inttoptr (i32 1 to ptr), ptr %_11.sroa.4.0..sroa_idx, align 4
  %_11.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %collector, i32 180
  store i32 0, ptr %_11.sroa.5.0..sroa_idx, align 4
  %5 = getelementptr inbounds nuw i8, ptr %collector, i32 184
  store i8 0, ptr %5, align 8
  %6 = load ptr, ptr %planes, align 4, !noundef !1
  %.not = icmp eq ptr %6, null
  br i1 %.not, label %bb18, label %bb5

bb5:                                              ; preds = %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit31"
  %7 = getelementptr inbounds nuw i8, ptr %planes, i32 8
  %planes.05 = load ptr, ptr %7, align 4, !nonnull !1, !noundef !1
  %8 = getelementptr inbounds nuw i8, ptr %planes, i32 12
  %planes.16 = load i32, ptr %8, align 4, !noundef !1
  %9 = getelementptr inbounds nuw i8, ptr %planes, i32 16
  %planes.07 = load ptr, ptr %9, align 4, !nonnull !1, !noundef !1
  %10 = getelementptr inbounds nuw i8, ptr %planes, i32 20
  %planes.18 = load i32, ptr %10, align 4, !noundef !1
  %11 = getelementptr inbounds nuw i8, ptr %planes, i32 24
  %planes.09 = load ptr, ptr %11, align 4, !nonnull !1, !noundef !1
  %12 = getelementptr inbounds nuw i8, ptr %planes, i32 28
  %planes.110 = load i32, ptr %12, align 4, !noundef !1
  %_13 = icmp ne i32 %planes.18, %planes.16
  %_16 = icmp ne i32 %planes.110, %planes.16
  %or.cond = or i1 %_13, %_16
  br i1 %or.cond, label %bb7, label %bb9

bb18:                                             ; preds = %bb34, %bb13.preheader.split, %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit31"
  %_86.idx = mul nuw nsw i32 %tables.1, 40
  %_86 = getelementptr inbounds nuw i8, ptr %tables.0, i32 %_86.idx
  %_93508 = icmp eq i32 %tables.1, 0
  br i1 %_93508, label %bb35, label %bb36.lr.ph

bb36.lr.ph:                                       ; preds = %bb18
  %13 = getelementptr inbounds nuw i8, ptr %_121.i, i32 4
  %14 = getelementptr inbounds nuw i8, ptr %_71.i, i32 4
  %_265.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_71.i, i32 8
  %_265.sroa.6.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_71.i, i32 12
  %self1.1.i.i.i.i = getelementptr inbounds nuw i8, ptr %array.i.i.i, i32 16
  %self1.2.i.i.i.i = getelementptr inbounds nuw i8, ptr %array.i.i.i, i32 32
  %15 = getelementptr inbounds nuw i8, ptr %_89.i, i32 4
  %_276.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_89.i, i32 8
  %_276.sroa.6.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_89.i, i32 12
  %16 = getelementptr inbounds nuw i8, ptr %names15.i, i32 4
  %17 = getelementptr inbounds nuw i8, ptr %names15.i, i32 8
  %18 = getelementptr inbounds nuw i8, ptr %kinds16.i, i32 4
  %19 = getelementptr inbounds nuw i8, ptr %kinds16.i, i32 8
  %_93.sroa.0.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 4
  %_93.sroa.0.sroa.0.sroa.0.sroa.3.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 8
  %_93.sroa.0.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 12
  %_93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 16
  %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 20
  %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.3.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 24
  %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.4.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 28
  %_93.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 32
  %_93.sroa.0.sroa.0.sroa.3.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 36
  %_93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 40
  %_93.sroa.0.sroa.0.sroa.4.sroa.2.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 44
  %_93.sroa.0.sroa.0.sroa.4.sroa.3.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 48
  %_93.sroa.0.sroa.0.sroa.4.sroa.4.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 52
  %_93.sroa.0.sroa.2.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 56
  %_93.sroa.0.sroa.3.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 60
  %_93.sroa.2.0.iter19.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter19.i, i32 64
  %20 = getelementptr inbounds nuw i8, ptr %collector, i32 28
  %21 = getelementptr inbounds nuw i8, ptr %id22.i, i32 8
  %_36.i.i = getelementptr inbounds nuw i8, ptr %_114.i, i32 1
  %22 = getelementptr inbounds nuw i8, ptr %field.i.i, i32 4
  %23 = ptrtoint ptr %field.i.i to i32
  %_7.sroa.0.sroa.4.0.insert.ext.i.i = zext i32 ptrtoint (ptr @"_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17h1f491e2c0cb9581eE" to i32) to i64
  %_7.sroa.0.sroa.4.0.insert.shift.i.i = shl nuw i64 %_7.sroa.0.sroa.4.0.insert.ext.i.i, 32
  %_7.sroa.0.sroa.0.0.insert.ext.i.i = zext i32 %23 to i64
  %_7.sroa.0.sroa.0.0.insert.insert.i.i = or disjoint i64 %_7.sroa.0.sroa.4.0.insert.shift.i.i, %_7.sroa.0.sroa.0.0.insert.ext.i.i
  %24 = getelementptr inbounds nuw i8, ptr %_2.i.i, i32 8
  %25 = getelementptr inbounds nuw i8, ptr %_2.i.i, i32 32
  %26 = getelementptr inbounds nuw i8, ptr %_2.i.i, i32 36
  %27 = getelementptr inbounds nuw i8, ptr %_2.i.i, i32 20
  %_104.sroa.6.0._308.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_308.i, i32 4
  %_104.sroa.6.i.sroa.5.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 8
  %_104.sroa.6.i.sroa.6.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 12
  %_104.sroa.6.i.sroa.7.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 16
  %_104.sroa.8.0._308.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_308.i, i32 20
  %_42.sroa.65.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 24
  %_42.sroa.65117.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 32
  %_42.sroa.68.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_308.i, i32 36
  %_42.sroa.23.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 4
  %_42.sroa.34.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 8
  %_42.sroa.42.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 12
  %_42.sroa.50.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 16
  %_42.sroa.58.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 20
  %_42.sroa.65.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 24
  %_42.sroa.65117.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 32
  %_42.sroa.68.0._108.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_108.i, i32 36
  %28 = getelementptr inbounds nuw i8, ptr %_16.i, i32 4
  %_172.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_16.i, i32 8
  %_172.sroa.6.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_16.i, i32 12
  %29 = getelementptr inbounds nuw i8, ptr %_24.i, i32 4
  %_181.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_24.i, i32 8
  %_181.sroa.6.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_24.i, i32 12
  %30 = getelementptr inbounds nuw i8, ptr %_31.i, i32 4
  %_190.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_31.i, i32 8
  %_190.sroa.6.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_31.i, i32 12
  %31 = getelementptr inbounds nuw i8, ptr %kinds.i, i32 4
  %32 = getelementptr inbounds nuw i8, ptr %kinds.i, i32 8
  %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 4
  %_40.sroa.0.sroa.0.sroa.0.sroa.3.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 8
  %_40.sroa.0.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 12
  %_40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 16
  %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 20
  %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.3.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 24
  %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.4.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 28
  %_40.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 32
  %_40.sroa.0.sroa.0.sroa.3.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 36
  %_40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 40
  %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 44
  %_40.sroa.0.sroa.0.sroa.4.sroa.3.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 48
  %_40.sroa.0.sroa.0.sroa.4.sroa.4.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 52
  %_40.sroa.0.sroa.2.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 56
  %_40.sroa.0.sroa.3.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 60
  %_40.sroa.0.sroa.4.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 64
  %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 68
  %_40.sroa.0.sroa.4.sroa.3.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 72
  %_40.sroa.0.sroa.4.sroa.4.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 76
  %_40.sroa.3.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 80
  %_40.sroa.4.0.iter.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.i, i32 84
  %_55.sroa.6.0._227.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_227.i, i32 4
  %_55.sroa.6.i.sroa.5.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 8
  %_55.sroa.6.i.sroa.6.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 12
  %_55.sroa.6.i.sroa.7.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 16
  %_55.sroa.8.0._227.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_227.i, i32 20
  %_42.sroa.65.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 24
  %_42.sroa.65117.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 32
  %_42.sroa.68.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_227.i, i32 36
  %_59.sroa.6.0._233.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_233.i, i32 4
  %_59.sroa.6.i.sroa.5.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 8
  %_59.sroa.6.i.sroa.6.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 12
  %_59.sroa.6.i.sroa.7.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 16
  %_59.sroa.8.0._233.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_233.i, i32 20
  %_42.sroa.65.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 24
  %_42.sroa.65117.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 32
  %_42.sroa.68.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_233.i, i32 36
  %_63.sroa.6.0._242.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_242.i, i32 4
  %_63.sroa.6.i.sroa.5.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 8
  %_63.sroa.6.i.sroa.6.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 12
  %_63.sroa.6.i.sroa.7.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 16
  %_63.sroa.8.0._242.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_242.i, i32 20
  %_42.sroa.65.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 24
  %_42.sroa.65117.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 32
  %_42.sroa.68.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_242.i, i32 36
  %_42.sroa.23.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 4
  %_42.sroa.34.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 8
  %_42.sroa.42.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 12
  %_42.sroa.50.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 16
  %_42.sroa.58.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 20
  %_42.sroa.65.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 24
  %_42.sroa.65117.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 32
  %_42.sroa.68.0._53.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_53.i, i32 36
  br label %bb36

bb7:                                              ; preds = %bb5
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4135
; call __rustc::__rust_alloc
  %33 = tail call noundef dereferenceable_or_null(58) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef range(i32 20, 87) 58, i32 noundef range(i32 1, 9) 1) #137, !noalias !4135
  %34 = icmp eq ptr %33, null
  br i1 %34, label %bb3.i.i.i.i.i, label %_ZN10xyg_engine10graphforge7GfError3new17h458bb2c7a678a52dE.exit

bb3.i.i.i.i.i:                                    ; preds = %bb7
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 range(i32 20, 87) 58) #138, !noalias !4151
  unreachable

_ZN10xyg_engine10graphforge7GfError3new17h458bb2c7a678a52dE.exit: ; preds = %bb7
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(58) %33, ptr noundef nonnull readonly align 1 dereferenceable(58) @alloc_318582e508f899a3c448f30101c0374f, i32 range(i32 20, 87) 58, i1 false), !noalias !4152
  store i32 0, ptr %_0, align 8
  %_18.sroa.471.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 58, ptr %_18.sroa.471.0._0.sroa_idx, align 8
  %_18.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store ptr %33, ptr %_18.sroa.5.0._0.sroa_idx, align 4
  %_18.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i32 58, ptr %_18.sroa.6.0._0.sroa_idx, align 8
  %_18.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 20
  store i32 -2147483648, ptr %_18.sroa.7.0._0.sroa_idx, align 4
  %_18.sroa.872.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store ptr @alloc_636f9819f9a903d7b5a5510511d6f8fc, ptr %_18.sroa.872.0._0.sroa_idx, align 8
  %_18.sroa.9.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 26, ptr %_18.sroa.9.0._0.sroa_idx, align 4
  %35 = getelementptr inbounds nuw i8, ptr %_0, i32 124
  store i32 -2147483648, ptr %35, align 4
  br label %bb22

bb9:                                              ; preds = %bb5
  %36 = getelementptr inbounds nuw i8, ptr %planes, i32 4
  %planes.1 = load i32, ptr %36, align 4, !noundef !1
  %_51.idx = shl nuw nsw i32 %planes.1, 4
  %_51 = getelementptr inbounds nuw i8, ptr %6, i32 %_51.idx
  %_58504 = icmp eq i32 %planes.1, 0
  br i1 %_58504, label %bb13.preheader.split, label %bb28

bb13.preheader.split:                             ; preds = %bb30, %bb9
  %_72506.not = icmp eq i32 %planes.16, 0
  br i1 %_72506.not, label %bb18, label %bb31

bb28:                                             ; preds = %bb9, %bb30
  %iter.sroa.0.0505 = phi ptr [ %_64, %bb30 ], [ %6, %bb9 ]
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %id, ptr noundef nonnull align 1 dereferenceable(16) %iter.sroa.0.0505, i32 16, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %_23)
; call xyg_engine::graphforge::base::Collector::node
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector4node17h52562e58bb6025cdE(ptr noalias noundef align 4 captures(none) dereferenceable(40) %_23, ptr noalias noundef align 8 dereferenceable(192) %collector, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %id, ptr noalias noundef readonly captures(address, read_provenance) null, i32 undef, ptr noalias noundef readonly captures(address, read_provenance) null, i32 undef) #137
  %37 = load i32, ptr %_23, align 4, !range !616, !noundef !1
  %.not14 = icmp eq i32 %37, 2
  br i1 %.not14, label %bb30, label %bb29

bb29:                                             ; preds = %bb28
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(40) %_0, ptr noundef nonnull align 4 dereferenceable(40) %_23, i32 40, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_23)
  %38 = getelementptr inbounds nuw i8, ptr %_0, i32 124
  store i32 -2147483648, ptr %38, align 4
  br label %bb22

bb30:                                             ; preds = %bb28
  %_64 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0505, i32 16
  call void @llvm.lifetime.end.p0(ptr nonnull %_23)
  %_58 = icmp eq ptr %_64, %_51
  br i1 %_58, label %bb13.preheader.split, label %bb28

bb22:                                             ; preds = %bb37, %_ZN10xyg_engine10graphforge7GfError3new17h458bb2c7a678a52dE.exit, %bb33, %bb29
; call core::ptr::drop_in_place<xyg_engine::graphforge::base::Collector>
  call fastcc void @"_ZN4core3ptr60drop_in_place$LT$xyg_engine..graphforge..base..Collector$GT$17h14c5511454e0be32E"(ptr noalias noundef align 8 dereferenceable(192) %collector) #137
  br label %bb24

bb31:                                             ; preds = %bb13.preheader.split, %bb34
  %iter4.sroa.0.0507 = phi i32 [ %44, %bb34 ], [ 0, %bb13.preheader.split ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_29)
  call void @llvm.lifetime.start.p0(ptr nonnull %_31)
  %39 = getelementptr inbounds nuw [16 x i8], ptr %planes.05, i32 %iter4.sroa.0.0507
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_31, ptr noundef nonnull align 1 dereferenceable(16) %39, i32 16, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %_33)
  %40 = getelementptr inbounds nuw [16 x i8], ptr %planes.07, i32 %iter4.sroa.0.0507
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_33, ptr noundef nonnull align 1 dereferenceable(16) %40, i32 16, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %_35)
  %41 = getelementptr inbounds nuw [16 x i8], ptr %planes.09, i32 %iter4.sroa.0.0507
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_35, ptr noundef nonnull align 1 dereferenceable(16) %41, i32 16, i1 false)
; call xyg_engine::graphforge::base::Collector::edge
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector4edge17h55fe5b03624b7ffeE(ptr noalias noundef align 4 captures(none) dereferenceable(40) %_29, ptr noalias noundef align 8 dereferenceable(192) %collector, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %_31, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %_33, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %_35, ptr noalias noundef readonly captures(address, read_provenance) null, i32 undef) #137
  call void @llvm.lifetime.end.p0(ptr nonnull %_35)
  call void @llvm.lifetime.end.p0(ptr nonnull %_33)
  call void @llvm.lifetime.end.p0(ptr nonnull %_31)
  %42 = load i32, ptr %_29, align 4, !range !616, !noundef !1
  %.not16 = icmp eq i32 %42, 2
  br i1 %.not16, label %bb34, label %bb33

bb33:                                             ; preds = %bb31
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(40) %_0, ptr noundef nonnull align 4 dereferenceable(40) %_29, i32 40, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_29)
  %43 = getelementptr inbounds nuw i8, ptr %_0, i32 124
  store i32 -2147483648, ptr %43, align 4
  br label %bb22

bb34:                                             ; preds = %bb31
  %44 = add nuw i32 %iter4.sroa.0.0507, 1
  call void @llvm.lifetime.end.p0(ptr nonnull %_29)
  %exitcond.not = icmp eq i32 %44, %planes.16
  br i1 %exitcond.not, label %bb18, label %bb31

bb36:                                             ; preds = %bb36.lr.ph, %bb38
  %iter2.sroa.0.0521 = phi ptr [ %tables.0, %bb36.lr.ph ], [ %_99, %bb38 ]
  %_42.sroa.23.sroa.16.sroa.0.0519 = phi i24 [ undef, %bb36.lr.ph ], [ %_42.sroa.23.sroa.16.sroa.0.9196, %bb38 ]
  %_42.sroa.23.sroa.0.0517 = phi i8 [ undef, %bb36.lr.ph ], [ %_42.sroa.23.sroa.0.9195, %bb38 ]
  %_42.sroa.68.0516 = phi i32 [ undef, %bb36.lr.ph ], [ %_42.sroa.68.9194, %bb38 ]
  %_42.sroa.65117.0515 = phi ptr [ undef, %bb36.lr.ph ], [ %_42.sroa.65117.9193, %bb38 ]
  %_42.sroa.65.0513 = phi i64 [ undef, %bb36.lr.ph ], [ %_42.sroa.65.9192, %bb38 ]
  %_42.sroa.58.0512 = phi i32 [ undef, %bb36.lr.ph ], [ %_42.sroa.58.9191, %bb38 ]
  %_42.sroa.50.0511 = phi i32 [ undef, %bb36.lr.ph ], [ %_42.sroa.50.9190, %bb38 ]
  %_42.sroa.42.0510 = phi i32 [ undef, %bb36.lr.ph ], [ %_42.sroa.42.9189, %bb38 ]
  %_42.sroa.34.0509 = phi i32 [ undef, %bb36.lr.ph ], [ %_42.sroa.34.9188, %bb38 ]
  call void @llvm.experimental.noalias.scope.decl(metadata !4153)
  call void @llvm.experimental.noalias.scope.decl(metadata !4156)
  call void @llvm.lifetime.start.p0(ptr nonnull %id22.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_85.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %val10.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %val8.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %val6.i)
  %45 = getelementptr inbounds nuw i8, ptr %iter2.sroa.0.0521, i32 4
  %_135.i = load ptr, ptr %45, align 4, !alias.scope !4156, !noalias !4158, !nonnull !1, !noundef !1
  %46 = getelementptr inbounds nuw i8, ptr %iter2.sroa.0.0521, i32 8
  %iter27.i = load i32, ptr %46, align 4, !alias.scope !4156, !noalias !4158, !noundef !1
  %47 = shl nuw nsw i32 %iter27.i, 3
  %48 = icmp eq i32 %iter27.i, 0
  br i1 %48, label %bb45.i, label %bb3.i.i.i.i

bb3.i.i.i.i:                                      ; preds = %bb36
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4160
; call __rustc::__rust_alloc
  %49 = call noundef align 4 ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %47, i32 noundef range(i32 1, 9) 4) #137, !noalias !4160
  %50 = icmp eq ptr %49, null
  br i1 %50, label %bb3.i.i.i, label %bb8.i.i.i.i.i.i.i

bb3.i.i.i:                                        ; preds = %bb3.i.i.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 4, i32 %47) #138, !noalias !4165
  unreachable

bb8.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i, %bb8.i.i.i.i.i.i.i
  %51 = phi i32 [ %55, %bb8.i.i.i.i.i.i.i ], [ 0, %bb3.i.i.i.i ]
  %_40.i.i.i.i.i.i.i = getelementptr inbounds nuw %"arrow_ipc::Field", ptr %_135.i, i32 %51
  %52 = getelementptr i8, ptr %_40.i.i.i.i.i.i.i, i32 4
  %_40.val.i.i.i.i.i.i.i = load ptr, ptr %52, align 4, !noalias !4166, !nonnull !1, !noundef !1
  %53 = getelementptr i8, ptr %_40.i.i.i.i.i.i.i, i32 8
  %_40.val6.i.i.i.i.i.i.i = load i32, ptr %53, align 4, !noalias !4166, !noundef !1
  %_3.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw { ptr, i32 }, ptr %49, i32 %51
  store ptr %_40.val.i.i.i.i.i.i.i, ptr %_3.i.i.i.i.i.i.i.i.i.i, align 4, !noalias !4177
  %54 = getelementptr inbounds nuw i8, ptr %_3.i.i.i.i.i.i.i.i.i.i, i32 4
  store i32 %_40.val6.i.i.i.i.i.i.i, ptr %54, align 4, !noalias !4186
  %55 = add nuw i32 %51, 1
  %_25.i.i.i.i.i.i.i = icmp eq i32 %55, %iter27.i
  br i1 %_25.i.i.i.i.i.i.i, label %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h55363a2b884a4350E.exit.i", label %bb8.i.i.i.i.i.i.i

"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h55363a2b884a4350E.exit.i": ; preds = %bb8.i.i.i.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4187)
  %_10.i.i = getelementptr inbounds nuw i8, ptr %49, i32 %47
  br label %bb11.i.i.i

bb11.i.i.i:                                       ; preds = %bb1.backedge.i.i.i, %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h55363a2b884a4350E.exit.i"
  %_2224.i.i.i = phi ptr [ %_22.i.i.i, %bb1.backedge.i.i.i ], [ %49, %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h55363a2b884a4350E.exit.i" ]
  %_22.i.i.i = getelementptr inbounds nuw i8, ptr %_2224.i.i.i, i32 8
  %56 = getelementptr i8, ptr %_2224.i.i.i, i32 4
  %ptr.val1.i.i.i = load i32, ptr %56, align 4, !alias.scope !4187, !noalias !4190, !noundef !1
  %_8.i.i.i.i.i.i = icmp eq i32 %ptr.val1.i.i.i, 9
  br i1 %_8.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i, label %bb1.backedge.i.i.i

bb1.i.i.i.i.i.i:                                  ; preds = %bb11.i.i.i
  %ptr.val.i.i.i = load ptr, ptr %_2224.i.i.i, align 4, !alias.scope !4187, !noalias !4190, !nonnull !1, !noundef !1
  %57 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(9) %ptr.val.i.i.i, ptr noundef nonnull readonly dereferenceable(9) @alloc_02b1bce354e2ec5181c1277f1a11b9f6, i32 9), !alias.scope !4194, !noalias !4198
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %bb1.i, label %bb1.backedge.i.i.i

bb1.backedge.i.i.i:                               ; preds = %bb1.i.i.i.i.i.i, %bb11.i.i.i
  %_12.not.i.i.i = icmp eq ptr %_22.i.i.i, %_10.i.i
  br i1 %_12.not.i.i.i, label %bb20.i, label %bb11.i.i.i

bb20.i:                                           ; preds = %bb1.backedge.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4199)
  br label %bb11.i.i92.i

bb11.i.i92.i:                                     ; preds = %bb1.backedge.i.i97.i, %bb20.i
  %_2224.i.i93.i = phi ptr [ %_22.i.i94.i, %bb1.backedge.i.i97.i ], [ %49, %bb20.i ]
  %_22.i.i94.i = getelementptr inbounds nuw i8, ptr %_2224.i.i93.i, i32 8
  %59 = getelementptr i8, ptr %_2224.i.i93.i, i32 4
  %ptr.val1.i.i95.i = load i32, ptr %59, align 4, !alias.scope !4199, !noalias !4202, !noundef !1
  %_8.i.i.i.i.i96.i = icmp eq i32 %ptr.val1.i.i95.i, 9
  br i1 %_8.i.i.i.i.i96.i, label %bb1.i.i.i.i.i100.i, label %bb1.backedge.i.i97.i

bb1.i.i.i.i.i100.i:                               ; preds = %bb11.i.i92.i
  %ptr.val.i.i101.i = load ptr, ptr %_2224.i.i93.i, align 4, !alias.scope !4199, !noalias !4202, !nonnull !1, !noundef !1
  %60 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(9) %ptr.val.i.i101.i, ptr noundef nonnull readonly dereferenceable(9) @alloc_cf31b62cfed39ba50ebff67f88563271, i32 9), !alias.scope !4206, !noalias !4210
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %bb21.i, label %bb1.backedge.i.i97.i

bb1.backedge.i.i97.i:                             ; preds = %bb1.i.i.i.i.i100.i, %bb11.i.i92.i
  %_12.not.i.i98.i = icmp eq ptr %_22.i.i94.i, %_10.i.i
  br i1 %_12.not.i.i98.i, label %bb39.i, label %bb11.i.i92.i

bb1.i:                                            ; preds = %bb1.i.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4211
; call __rustc::__rust_alloc
  %62 = call noundef align 4 ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %47, i32 noundef range(i32 1, 9) 4) #137, !noalias !4211
  %63 = icmp eq ptr %62, null
  br i1 %63, label %bb3.i.i.i.i.i.i.i, label %bb8.i.i.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i:                                ; preds = %bb1.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 4, i32 %47) #138, !noalias !4224
  unreachable

bb8.i.i.i.i.i.i.i.i.i.i.i:                        ; preds = %bb1.i, %bb8.i.i.i.i.i.i.i.i.i.i.i
  %64 = phi i32 [ %67, %bb8.i.i.i.i.i.i.i.i.i.i.i ], [ 0, %bb1.i ]
  %_40.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw { ptr, i32 }, ptr %49, i32 %64
  %_40.val.i.i.i.i.i.i.i.i.i.i.i = load ptr, ptr %_40.i.i.i.i.i.i.i.i.i.i.i, align 4, !noalias !4225, !nonnull !1, !noundef !1
  %65 = getelementptr i8, ptr %_40.i.i.i.i.i.i.i.i.i.i.i, i32 4
  %_40.val6.i.i.i.i.i.i.i.i.i.i.i = load i32, ptr %65, align 4, !noalias !4225, !noundef !1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw { ptr, i32 }, ptr %62, i32 %64
  store ptr %_40.val.i.i.i.i.i.i.i.i.i.i.i, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, align 4, !noalias !4236
  %66 = getelementptr inbounds nuw i8, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, i32 4
  store i32 %_40.val6.i.i.i.i.i.i.i.i.i.i.i, ptr %66, align 4, !noalias !4245
  %67 = add nuw i32 %64, 1
  %_25.i.i.i.i.i.i.i.i.i.i.i = icmp eq i32 %67, %iter27.i
  br i1 %_25.i.i.i.i.i.i.i.i.i.i.i, label %_ZN4core4iter6traits8iterator8Iterator7collect17hd31f9a39cd3fb257E.exit.i.i, label %bb8.i.i.i.i.i.i.i.i.i.i.i

_ZN4core4iter6traits8iterator8Iterator7collect17hd31f9a39cd3fb257E.exit.i.i: ; preds = %bb8.i.i.i.i.i.i.i.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4246)
  %_10.i.i.i = getelementptr inbounds nuw i8, ptr %62, i32 %47
  br label %bb11.i.i.i.i

bb11.i.i.i.i:                                     ; preds = %bb1.backedge.i.i.i.i, %_ZN4core4iter6traits8iterator8Iterator7collect17hd31f9a39cd3fb257E.exit.i.i
  %_2224.i.i.i.i = phi ptr [ %_22.i.i.i.i, %bb1.backedge.i.i.i.i ], [ %62, %_ZN4core4iter6traits8iterator8Iterator7collect17hd31f9a39cd3fb257E.exit.i.i ]
  %_22.i.i.i.i = getelementptr inbounds nuw i8, ptr %_2224.i.i.i.i, i32 8
  %68 = getelementptr i8, ptr %_2224.i.i.i.i, i32 4
  %ptr.val1.i.i.i.i = load i32, ptr %68, align 4, !alias.scope !4246, !noalias !4249, !noundef !1
  %_8.i.i.i.i.i.i.i = icmp eq i32 %ptr.val1.i.i.i.i, 8
  br i1 %_8.i.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i.i, label %bb1.backedge.i.i.i.i

bb1.i.i.i.i.i.i.i:                                ; preds = %bb11.i.i.i.i
  %ptr.val.i.i.i.i = load ptr, ptr %_2224.i.i.i.i, align 4, !alias.scope !4246, !noalias !4249, !nonnull !1, !noundef !1
  %69 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(8) %ptr.val.i.i.i.i, ptr noundef nonnull readonly dereferenceable(8) @alloc_7c56d378fe2cfdd66798923da4f517f8, i32 8), !alias.scope !4253, !noalias !4257
  %70 = icmp eq i32 %69, 0
  br i1 %70, label %bb2.i.i, label %bb1.backedge.i.i.i.i

bb1.backedge.i.i.i.i:                             ; preds = %bb1.i.i.i.i.i.i.i, %bb11.i.i.i.i
  %_12.not.i.i.i.i = icmp eq ptr %_22.i.i.i.i, %_10.i.i.i
  br i1 %_12.not.i.i.i.i, label %bb11.i.i8.preheader.i.i, label %bb11.i.i.i.i

bb11.i.i8.preheader.i.i:                          ; preds = %bb1.backedge.i.i.i.i, %bb1.backedge.i.i27.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4258)
  br label %bb11.i.i8.i.i

bb11.i.i8.i.i:                                    ; preds = %bb1.backedge.i.i13.i.i, %bb11.i.i8.preheader.i.i
  %_2224.i.i9.i.i = phi ptr [ %_22.i.i10.i.i, %bb1.backedge.i.i13.i.i ], [ %62, %bb11.i.i8.preheader.i.i ]
  %_22.i.i10.i.i = getelementptr inbounds nuw i8, ptr %_2224.i.i9.i.i, i32 8
  %71 = getelementptr i8, ptr %_2224.i.i9.i.i, i32 4
  %ptr.val1.i.i11.i.i = load i32, ptr %71, align 4, !alias.scope !4258, !noalias !4261, !noundef !1
  %_8.i.i.i.i.i12.i.i = icmp eq i32 %ptr.val1.i.i11.i.i, 11
  br i1 %_8.i.i.i.i.i12.i.i, label %bb1.i.i.i.i.i16.i.i, label %bb1.backedge.i.i13.i.i

bb1.i.i.i.i.i16.i.i:                              ; preds = %bb11.i.i8.i.i
  %ptr.val.i.i17.i.i = load ptr, ptr %_2224.i.i9.i.i, align 4, !alias.scope !4258, !noalias !4261, !nonnull !1, !noundef !1
  %72 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(11) %ptr.val.i.i17.i.i, ptr noundef nonnull readonly dereferenceable(11) @alloc_b8132c6d4826de804c89aedc6d99e768, i32 11), !alias.scope !4265, !noalias !4269
  %73 = icmp eq i32 %72, 0
  br i1 %73, label %bb5.i.i, label %bb1.backedge.i.i13.i.i

bb1.backedge.i.i13.i.i:                           ; preds = %bb1.i.i.i.i.i16.i.i, %bb11.i.i8.i.i
  %_12.not.i.i14.i.i = icmp eq ptr %_22.i.i10.i.i, %_10.i.i.i
  br i1 %_12.not.i.i14.i.i, label %_ZN10xyg_engine10graphforge4base14endpoint_names17h37c5deba6d3ec044E.exit.thread265.i, label %bb11.i.i8.i.i

bb2.i.i:                                          ; preds = %bb1.i.i.i.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4270)
  br label %bb11.i.i22.i.i

bb11.i.i22.i.i:                                   ; preds = %bb1.backedge.i.i27.i.i, %bb2.i.i
  %_2224.i.i23.i.i = phi ptr [ %_22.i.i24.i.i, %bb1.backedge.i.i27.i.i ], [ %62, %bb2.i.i ]
  %_22.i.i24.i.i = getelementptr inbounds nuw i8, ptr %_2224.i.i23.i.i, i32 8
  %74 = getelementptr i8, ptr %_2224.i.i23.i.i, i32 4
  %ptr.val1.i.i25.i.i = load i32, ptr %74, align 4, !alias.scope !4270, !noalias !4273, !noundef !1
  %_8.i.i.i.i.i26.i.i = icmp eq i32 %ptr.val1.i.i25.i.i, 8
  br i1 %_8.i.i.i.i.i26.i.i, label %bb1.i.i.i.i.i30.i.i, label %bb1.backedge.i.i27.i.i

bb1.i.i.i.i.i30.i.i:                              ; preds = %bb11.i.i22.i.i
  %ptr.val.i.i31.i.i = load ptr, ptr %_2224.i.i23.i.i, align 4, !alias.scope !4270, !noalias !4273, !nonnull !1, !noundef !1
  %75 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(8) %ptr.val.i.i31.i.i, ptr noundef nonnull readonly dereferenceable(8) @alloc_feb20d710638e21c23e6ad6113be7b89, i32 8), !alias.scope !4277, !noalias !4281
  %76 = icmp eq i32 %75, 0
  br i1 %76, label %bb82.i, label %bb1.backedge.i.i27.i.i

bb1.backedge.i.i27.i.i:                           ; preds = %bb1.i.i.i.i.i30.i.i, %bb11.i.i22.i.i
  %_12.not.i.i28.i.i = icmp eq ptr %_22.i.i24.i.i, %_10.i.i.i
  br i1 %_12.not.i.i28.i.i, label %bb11.i.i8.preheader.i.i, label %bb11.i.i22.i.i

bb5.i.i:                                          ; preds = %bb1.i.i.i.i.i16.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4282)
  br label %bb11.i.i36.i.i

bb11.i.i36.i.i:                                   ; preds = %bb1.backedge.i.i41.i.i, %bb5.i.i
  %_2224.i.i37.i.i = phi ptr [ %_22.i.i38.i.i, %bb1.backedge.i.i41.i.i ], [ %62, %bb5.i.i ]
  %_22.i.i38.i.i = getelementptr inbounds nuw i8, ptr %_2224.i.i37.i.i, i32 8
  %77 = getelementptr i8, ptr %_2224.i.i37.i.i, i32 4
  %ptr.val1.i.i39.i.i = load i32, ptr %77, align 4, !alias.scope !4282, !noalias !4285, !noundef !1
  %_8.i.i.i.i.i40.i.i = icmp eq i32 %ptr.val1.i.i39.i.i, 11
  br i1 %_8.i.i.i.i.i40.i.i, label %bb1.i.i.i.i.i44.i.i, label %bb1.backedge.i.i41.i.i

bb1.i.i.i.i.i44.i.i:                              ; preds = %bb11.i.i36.i.i
  %ptr.val.i.i45.i.i = load ptr, ptr %_2224.i.i37.i.i, align 4, !alias.scope !4282, !noalias !4285, !nonnull !1, !noundef !1
  %78 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(11) %ptr.val.i.i45.i.i, ptr noundef nonnull readonly dereferenceable(11) @alloc_8703c957d53c74b83d1cf52e90443d36, i32 11), !alias.scope !4289, !noalias !4293
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %bb82.i, label %bb1.backedge.i.i41.i.i

bb1.backedge.i.i41.i.i:                           ; preds = %bb1.i.i.i.i.i44.i.i, %bb11.i.i36.i.i
  %_12.not.i.i42.i.i = icmp eq ptr %_22.i.i38.i.i, %_10.i.i.i
  br i1 %_12.not.i.i42.i.i, label %_ZN10xyg_engine10graphforge4base14endpoint_names17h37c5deba6d3ec044E.exit.thread265.i, label %bb11.i.i36.i.i

_ZN10xyg_engine10graphforge4base14endpoint_names17h37c5deba6d3ec044E.exit.thread265.i: ; preds = %bb1.backedge.i.i13.i.i, %bb1.backedge.i.i41.i.i
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %62, i32 noundef %47, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4294
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4297
; call __rustc::__rust_alloc
  %80 = call noundef dereferenceable_or_null(68) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 68, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4297
  %81 = icmp eq ptr %80, null
  br i1 %81, label %bb5.i133.i, label %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i"

bb39.i:                                           ; preds = %bb1.backedge.i.i97.i
  %_332.i = icmp ult i32 %iter27.i, 48806447
  call void @llvm.assume(i1 %_332.i)
  br label %bb132.i

bb21.i:                                           ; preds = %bb1.i.i.i.i.i100.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_71.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_73.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_74.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_74.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_cf31b62cfed39ba50ebff67f88563271, i32 noundef 9) #137
  %82 = load i32, ptr %_74.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not68.i = icmp eq i32 %82, -2147483648
  br i1 %.not68.i, label %bb113.i, label %bb114.i, !prof !4

bb133.i:                                          ; preds = %bb135.i
  br i1 %89, label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread, label %bb45.i

bb132.i:                                          ; preds = %bb135.i, %bb39.i
  %iter26.sroa.0.0428.i = phi i32 [ 0, %bb39.i ], [ %87, %bb135.i ]
  %found.sroa.0.0.off0427.i = phi i1 [ false, %bb39.i ], [ %89, %bb135.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_121.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_123.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column_at
  call void @_ZN10xyg_engine9arrow_ipc5Table9column_at17h223cf9fb9dbff030E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_123.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, i32 noundef %iter26.sroa.0.0428.i) #137
; call xyg_engine::graphforge::base::Collector::entities
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector8entities17hcb0195d0ffe6d8adE(ptr noalias noundef align 4 captures(address) dereferenceable(40) %_121.i, ptr noalias noundef nonnull align 8 dereferenceable(192) %collector, ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) %_123.i, i32 noundef 0) #137, !noalias !4156
  %83 = load i32, ptr %_121.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not.i = icmp eq i32 %83, 2
  br i1 %.not.i, label %bb135.i, label %bb134.i

bb45.i:                                           ; preds = %bb133.i, %bb36
  %_10.idx.i230.ph251.ph505.i = phi i32 [ %47, %bb133.i ], [ 0, %bb36 ]
  %_4.sroa.10.0.i8.i228.ph252.ph504.i = phi ptr [ %49, %bb133.i ], [ inttoptr (i32 4 to ptr), %bb36 ]
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4303
; call __rustc::__rust_alloc
  %84 = call noundef dereferenceable_or_null(62) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 62, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4303
  %85 = icmp eq ptr %84, null
  br i1 %85, label %bb139.i, label %bb140.i

_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread: ; preds = %bb133.i
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %49, i32 noundef %47, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4306
  call void @llvm.lifetime.end.p0(ptr nonnull %id22.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_85.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val10.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val8.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val6.i)
  br label %bb38

bb139.i:                                          ; preds = %bb45.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 62) #138, !noalias !4156
  unreachable

bb140.i:                                          ; preds = %bb45.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(62) %84, ptr noundef nonnull align 1 dereferenceable(62) @alloc_636c8e62adcb7954712a58665514ce91, i32 62, i1 false), !noalias !4156
  %86 = ptrtoint ptr %84 to i32
  br i1 %48, label %bb37.sink.split, label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb134.i:                                          ; preds = %bb132.i
  %_339.sroa.5.0.copyload.i = load i8, ptr %13, align 4, !noalias !4302
  %_339.sroa.6.0._121.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_121.i, i32 5
  %_42.sroa.23.sroa.16.sroa.0.0.copyload = load i24, ptr %_339.sroa.6.0._121.sroa_idx.i, align 1, !noalias !4309
  %_42.sroa.34.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 8
  %_42.sroa.34.5.copyload = load i32, ptr %_42.sroa.34.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.42.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 12
  %_42.sroa.42.5.copyload = load i32, ptr %_42.sroa.42.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.50.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 16
  %_42.sroa.50.5.copyload = load i32, ptr %_42.sroa.50.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.58.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 20
  %_42.sroa.58.5.copyload = load i32, ptr %_42.sroa.58.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.65.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 24
  %_42.sroa.65.5.copyload = load i64, ptr %_42.sroa.65.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.65117.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 32
  %_42.sroa.65117.5.copyload = load ptr, ptr %_42.sroa.65117.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  %_42.sroa.68.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_121.i, i32 36
  %_42.sroa.68.5.copyload = load i32, ptr %_42.sroa.68.5._339.sroa.6.0._121.sroa_idx.i.sroa_idx, align 1, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_121.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_123.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_123.i), !noalias !4302
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb135.i:                                          ; preds = %bb132.i
  %87 = add nuw nsw i32 %iter26.sroa.0.0428.i, 1
  %88 = load i8, ptr %13, align 4, !range !88, !noalias !4302, !noundef !1
  %_338.i = trunc nuw i8 %88 to i1
  call void @llvm.lifetime.end.p0(ptr nonnull %_121.i), !noalias !4302
  %89 = or i1 %found.sroa.0.0.off0427.i, %_338.i
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_123.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_123.i), !noalias !4302
  %exitcond.not.i = icmp eq i32 %87, %iter27.i
  br i1 %exitcond.not.i, label %bb133.i, label %bb132.i

bb114.i:                                          ; preds = %bb21.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_73.i, ptr noundef nonnull align 4 dereferenceable(16) %_74.i, i32 16, i1 false), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %_74.i), !noalias !4302
; call xyg_engine::graphforge::columns::uuids
  call void @_ZN10xyg_engine10graphforge7columns5uuids17h5d3cca72d573f03eE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_71.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %_73.i, i1 noundef zeroext true) #137, !noalias !4156
  %90 = load i32, ptr %_71.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not69.i = icmp eq i32 %90, 2
  %_265.sroa.0.0.copyload.i = load i32, ptr %14, align 4, !noalias !4302
  %_265.sroa.5.0.copyload.i = load ptr, ptr %_265.sroa.5.0..sroa_idx.i, align 4, !noalias !4302
  %_265.sroa.6.0.copyload.i = load i32, ptr %_265.sroa.6.0..sroa_idx.i, align 4, !noalias !4302
  br i1 %.not69.i, label %bb116.i, label %bb115.i

bb113.i:                                          ; preds = %bb21.i
; call core::option::unwrap_failed
  call void @_RNvNtCs3O6bguQwcd4_4core6option13unwrap_failed(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_e80f353f6503cc8a14499f4abf73a330) #139, !noalias !4156
  unreachable

bb115.i:                                          ; preds = %bb114.i
  %_266.sroa.6.0._71.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_71.i, i32 16
  %_42.sroa.50.16.copyload = load i32, ptr %_266.sroa.6.0._71.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.58.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_71.i, i32 20
  %_42.sroa.58.16.copyload = load i32, ptr %_42.sroa.58.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_71.i, i32 24
  %_42.sroa.65.16.copyload = load i64, ptr %_42.sroa.65.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_71.i, i32 32
  %_42.sroa.65117.16.copyload = load ptr, ptr %_42.sroa.65117.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_71.i, i32 36
  %_42.sroa.68.16.copyload = load i32, ptr %_42.sroa.68.16._266.sroa.6.0._71.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_71.i), !noalias !4302
  %_42.sroa.23.sroa.0.0.extract.trunc137 = trunc i32 %_265.sroa.0.0.copyload.i to i8
  %_42.sroa.23.sroa.16.0.extract.shift148 = lshr i32 %_265.sroa.0.0.copyload.i, 8
  %_42.sroa.23.sroa.16.0.extract.trunc149 = trunc nuw i32 %_42.sroa.23.sroa.16.0.extract.shift148 to i24
  %91 = ptrtoint ptr %_265.sroa.5.0.copyload.i to i32
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_73.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_73.i), !noalias !4302
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb116.i:                                          ; preds = %bb114.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_71.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_73.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_73.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %names15.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_78.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %array.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %item.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_9.i.i.i.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_f00db71d77c58f05d86c38101680e143, i32 noundef 4) #137, !noalias !4321
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, ptr noundef nonnull readonly align 4 dereferenceable(16) %_9.i.i.i.i, i32 16, i1 false), !alias.scope !4322, !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %array.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, i32 16, i1 false), !noalias !4326
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_9.i.i.i.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_196593b9205aea024185423a0d7cea2c, i32 noundef 5) #137, !noalias !4321
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, ptr noundef nonnull readonly align 4 dereferenceable(16) %_9.i.i.i.i, i32 16, i1 false), !alias.scope !4322, !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %self1.1.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, i32 16, i1 false), !noalias !4326
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_9.i.i.i.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_26acf872710e59b3ecb100ae7aec0990, i32 noundef 5) #137, !noalias !4321
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, ptr noundef nonnull readonly align 4 dereferenceable(16) %_9.i.i.i.i, i32 16, i1 false), !alias.scope !4322, !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_9.i.i.i.i), !noalias !4310
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %self.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %self.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %_7.i.i.i.i, i32 16, i1 false), !noalias !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %self1.2.i.i.i.i, ptr noundef nonnull align 4 dereferenceable(16) %item.i.i.i.i, i32 16, i1 false), !noalias !4326
  call void @llvm.lifetime.end.p0(ptr nonnull %item.i.i.i.i)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(48) %_78.i, ptr noundef nonnull readonly align 4 dereferenceable(48) %array.i.i.i, i32 48, i1 false), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %array.i.i.i)
  %_273.i = icmp ult i32 %_265.sroa.6.0.copyload.i, 126322568
  call void @llvm.assume(i1 %_273.i)
; call xyg_engine::graphforge::base::Collector::captions
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector8captions17h217cf46137d0cde8E(ptr noalias noundef align 4 captures(address) dereferenceable(12) %names15.i, ptr noalias noundef readonly align 4 captures(none) dereferenceable(48) %_78.i, i32 noundef %_265.sroa.6.0.copyload.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_78.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %kinds16.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_82.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_82.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_2210d8dc23b43f3f269246a8f83675d6, i32 noundef 6) #137
; call xyg_engine::graphforge::base::Collector::first_labels
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector12first_labels17h154b064fe77eb77dE(ptr noalias noundef align 4 captures(address) dereferenceable(12) %kinds16.i, ptr noalias noundef readonly align 4 captures(none) dereferenceable(16) %_82.i, i32 noundef %_265.sroa.6.0.copyload.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_82.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_85.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_6a1cd3d11f17db4f9b9736d8df854438, i32 noundef 11) #137
  %92 = load i32, ptr %_85.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not70.i = icmp eq i32 %92, -2147483648
  br i1 %.not70.i, label %bb71.i, label %bb30.i

bb30.i:                                           ; preds = %bb116.i
  store i8 1, ptr %5, align 8, !alias.scope !4153, !noalias !4327
  call void @llvm.lifetime.start.p0(ptr nonnull %_89.i), !noalias !4302
; call xyg_engine::graphforge::columns::uuids
  call void @_ZN10xyg_engine10graphforge7columns5uuids17h5d3cca72d573f03eE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_89.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %_85.i, i1 noundef zeroext true) #137, !noalias !4156
  %93 = load i32, ptr %_89.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not71.i = icmp eq i32 %93, 2
  %_276.sroa.0.0.copyload.i = load i32, ptr %15, align 4, !noalias !4302
  %_276.sroa.5.0.copyload.i = load ptr, ptr %_276.sroa.5.0..sroa_idx.i, align 4, !noalias !4302
  %_276.sroa.6.0.copyload.i = load i32, ptr %_276.sroa.6.0..sroa_idx.i, align 4, !noalias !4302
  br i1 %.not71.i, label %bb119.i, label %bb118.i

bb71.i:                                           ; preds = %bb119.i, %bb116.i
  %parents.sroa.0.0.i = phi i32 [ %_276.sroa.0.0.copyload.i, %bb119.i ], [ -2147483648, %bb116.i ]
  %parents.sroa.7.0.i = phi ptr [ %_276.sroa.5.0.copyload.i, %bb119.i ], [ undef, %bb116.i ]
  %parents.sroa.9.0.i = phi i32 [ %_276.sroa.6.0.copyload.i, %bb119.i ], [ undef, %bb116.i ]
  %94 = icmp ne ptr %_265.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %94)
  %_368.idx.i = mul nuw nsw i32 %_265.sroa.6.0.copyload.i, 17
  %_368.i = getelementptr inbounds nuw i8, ptr %_265.sroa.5.0.copyload.i, i32 %_368.idx.i
  %_391.i = load ptr, ptr %16, align 4, !noalias !4302, !nonnull !1, !noundef !1
  %_384.i = load i32, ptr %names15.i, align 4, !range !67, !noalias !4302, !noundef !1
  %_377.i = load i32, ptr %17, align 4, !noalias !4302, !noundef !1
  %_288.i = icmp ult i32 %_377.i, 268435456
  call void @llvm.assume(i1 %_288.i)
  %_286.i = getelementptr inbounds nuw %"core::option::Option<&str>", ptr %_391.i, i32 %_377.i
  %_392.i = load ptr, ptr %18, align 4, !noalias !4302, !nonnull !1, !noundef !1
  %_385.i = load i32, ptr %kinds16.i, align 4, !range !67, !noalias !4302, !noundef !1
  %_378.i = load i32, ptr %19, align 4, !noalias !4302, !noundef !1
  %_295.i = icmp ult i32 %_378.i, 268435456
  call void @llvm.assume(i1 %_295.i)
  %_293.i = getelementptr inbounds nuw %"core::option::Option<&str>", ptr %_392.i, i32 %_378.i
  call void @llvm.lifetime.start.p0(ptr nonnull %iter19.i), !noalias !4302
  store ptr %_265.sroa.5.0.copyload.i, ptr %iter19.i, align 4, !noalias !4302
  store i32 %_265.sroa.0.0.copyload.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.3.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store ptr %_368.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store ptr %_391.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store i32 %_384.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.3.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store ptr %_286.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.4.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_93.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_93.sroa.0.sroa.0.sroa.3.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store ptr %_392.i, ptr %_93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store i32 %_385.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.3.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store ptr %_293.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.4.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_93.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_93.sroa.0.sroa.3.0.iter19.sroa_idx.i, align 4, !noalias !4302
  %_9.i.i.i.i349.i = icmp eq i32 %_265.sroa.6.0.copyload.i, 0
  br i1 %_9.i.i.i.i349.i, label %bb121.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i": ; preds = %bb71.i
  %.not74.i = icmp eq i32 %parents.sroa.0.0.i, -2147483648
  %95 = icmp ne ptr %parents.sroa.7.0.i, null
  br label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i"

bb118.i:                                          ; preds = %bb30.i
  %_277.sroa.6.0._89.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_89.i, i32 16
  %_42.sroa.50.16.copyload95 = load i32, ptr %_277.sroa.6.0._89.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.58.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_89.i, i32 20
  %_42.sroa.58.16.copyload101 = load i32, ptr %_42.sroa.58.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_89.i, i32 24
  %_42.sroa.65.16.copyload110 = load i64, ptr %_42.sroa.65.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_89.i, i32 32
  %_42.sroa.65117.16.copyload120 = load ptr, ptr %_42.sroa.65117.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_89.i, i32 36
  %_42.sroa.68.16.copyload129 = load i32, ptr %_42.sroa.68.16._277.sroa.6.0._89.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_89.i), !noalias !4302
  %_42.sroa.23.sroa.0.0.extract.trunc138 = trunc i32 %_276.sroa.0.0.copyload.i to i8
  %_42.sroa.23.sroa.16.0.extract.shift150 = lshr i32 %_276.sroa.0.0.copyload.i, 8
  %_42.sroa.23.sroa.16.0.extract.trunc151 = trunc nuw i32 %_42.sroa.23.sroa.16.0.extract.shift150 to i24
  %96 = ptrtoint ptr %_276.sroa.5.0.copyload.i to i32
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_85.i) #137, !noalias !4156
  call void @llvm.experimental.noalias.scope.decl(metadata !4328)
  %_1.val1.i109.i = load i32, ptr %kinds16.i, align 4, !range !67, !alias.scope !4328, !noalias !4302, !noundef !1
  %97 = icmp eq i32 %_1.val1.i109.i, 0
  br i1 %97, label %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit.i", label %bb2.i.i.i.i110.i

bb2.i.i.i.i110.i:                                 ; preds = %bb118.i
  %_1.val2.i111.i = load ptr, ptr %18, align 4, !alias.scope !4328, !noalias !4302, !nonnull !1, !noundef !1
  %alloc_size.i.i.i.i.i112.i = shl nuw i32 %_1.val1.i109.i, 3
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i111.i, i32 noundef %alloc_size.i.i.i.i.i112.i, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4331
  br label %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit.i"

"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit.i": ; preds = %bb2.i.i.i.i110.i, %bb118.i
  call void @llvm.lifetime.end.p0(ptr nonnull %kinds16.i), !noalias !4302
  call void @llvm.experimental.noalias.scope.decl(metadata !4332)
  %_1.val1.i113.i = load i32, ptr %names15.i, align 4, !range !67, !alias.scope !4332, !noalias !4302, !noundef !1
  %98 = icmp eq i32 %_1.val1.i113.i, 0
  br i1 %98, label %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i", label %bb2.i.i.i.i114.i

bb2.i.i.i.i114.i:                                 ; preds = %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit.i"
  %_1.val2.i115.i = load ptr, ptr %16, align 4, !alias.scope !4332, !noalias !4302, !nonnull !1, !noundef !1
  %alloc_size.i.i.i.i.i116.i = shl nuw i32 %_1.val1.i113.i, 3
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i115.i, i32 noundef %alloc_size.i.i.i.i.i116.i, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4335
  br label %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i"

"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i": ; preds = %bb2.i.i.i.i114.i, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit.i"
  call void @llvm.lifetime.end.p0(ptr nonnull %names15.i), !noalias !4302
  %99 = icmp eq i32 %_265.sroa.0.0.copyload.i, 0
  br i1 %99, label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219, label %bb2.i.i.i.i119.i

bb2.i.i.i.i119.i:                                 ; preds = %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i"
  %100 = icmp ne ptr %_265.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %100)
  %alloc_size.i.i.i.i.i121.i = mul nuw i32 %_265.sroa.0.0.copyload.i, 17
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_265.sroa.5.0.copyload.i, i32 noundef %alloc_size.i.i.i.i.i121.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4336
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb119.i:                                          ; preds = %bb30.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_89.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_85.i) #137, !noalias !4156
  br label %bb71.i

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i": ; preds = %bb37.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i"
  %ids12.sroa.5.4._390213355.i = phi ptr [ %_265.sroa.5.0.copyload.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i" ], [ %_23.i.i.i.i.i, %bb37.i ]
  %_391215354.i = phi ptr [ %_391.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i" ], [ %_23.i8.i.i.i.i, %bb37.i ]
  %_392217353.i = phi ptr [ %_392.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i" ], [ %_23.i.i.i, %bb37.i ]
  %_300.0342350.i = phi i32 [ 0, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.lr.ph.i" ], [ %_300.0.i, %bb37.i ]
  %_23.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %ids12.sroa.5.4._390213355.i, i32 17
  %self1.sroa.0.0.copyload9.i.i.i.i = load i8, ptr %ids12.sroa.5.4._390213355.i, align 1, !noalias !4339
  %self1.sroa.7.0._21.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %ids12.sroa.5.4._390213355.i, i32 1
  %.not.i.i.i.i = icmp eq i8 %self1.sroa.0.0.copyload9.i.i.i.i, 2
  br i1 %.not.i.i.i.i, label %bb121.i, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i"
  %_9.i6.i.i.i.i = icmp eq ptr %_391215354.i, %_286.i
  br i1 %_9.i6.i.i.i.i, label %bb121.i, label %bb7.i122.i

bb7.i122.i:                                       ; preds = %bb7.i.i.i.i
  %_23.i8.i.i.i.i = getelementptr inbounds nuw i8, ptr %_391215354.i, i32 8
  %_17.0.i.i.i.i.i = load ptr, ptr %_391215354.i, align 4, !noalias !4351, !noundef !1
  %101 = getelementptr inbounds nuw i8, ptr %_391215354.i, i32 4
  %_17.1.i.i.i.i.i = load i32, ptr %101, align 4, !noalias !4351
  %_9.i.i.i = icmp eq ptr %_392217353.i, %_293.i
  br i1 %_9.i.i.i, label %bb121.i, label %bb122.i

bb122.i:                                          ; preds = %bb7.i122.i
  %_23.i.i.i = getelementptr inbounds nuw i8, ptr %_392217353.i, i32 8
  %_300.0.i = add nuw nsw i32 %_300.0342350.i, 1
  %102 = trunc nuw i8 %self1.sroa.0.0.copyload9.i.i.i.i to i1
  br i1 %102, label %bb125.i, label %bb124.i

bb121.i:                                          ; preds = %bb37.i, %bb7.i122.i, %bb7.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i", %bb71.i
  %_300.0342.lcssa.i = phi i32 [ 0, %bb71.i ], [ %_265.sroa.6.0.copyload.i, %bb37.i ], [ %_377.i, %bb7.i.i.i.i ], [ %_300.0342350.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i" ], [ %_378.i, %bb7.i122.i ]
  %_23.i.i335.lcssa.i = phi ptr [ %_392.i, %bb71.i ], [ %_23.i.i.i, %bb37.i ], [ %_392217353.i, %bb7.i.i.i.i ], [ %_392217353.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i" ], [ %_293.i, %bb7.i122.i ]
  %_23.i8.i.i.i328.i = phi ptr [ %_391.i, %bb71.i ], [ %_23.i8.i.i.i.i, %bb37.i ], [ %_286.i, %bb7.i.i.i.i ], [ %_391215354.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i" ], [ %_23.i8.i.i.i.i, %bb7.i122.i ]
  %_23.i.i.i.i320.i = phi ptr [ %_265.sroa.5.0.copyload.i, %bb71.i ], [ %_368.i, %bb37.i ], [ %_23.i.i.i.i.i, %bb7.i.i.i.i ], [ %_23.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i" ], [ %_23.i.i.i.i.i, %bb7.i122.i ]
  store ptr %_23.i.i.i.i320.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i8.i.i.i328.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i335.lcssa.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.2.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store i32 %_300.0342.lcssa.i, ptr %_93.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  br label %bb52.i

bb52.i:                                           ; preds = %bb124.i, %bb127.i, %bb130.i, %bb121.i
  %_42.sroa.0.2 = phi i32 [ 2, %bb121.i ], [ 0, %bb130.i ], [ %105, %bb127.i ], [ %_104.sroa.0.0.copyload.i, %bb124.i ]
  %_42.sroa.34.3 = phi i32 [ %_42.sroa.34.0509, %bb121.i ], [ 58, %bb130.i ], [ %_42.sroa.34.0.copyload80, %bb127.i ], [ %_104.sroa.6.i.sroa.5.0.copyload, %bb124.i ]
  %_42.sroa.42.3 = phi i32 [ %_42.sroa.42.0510, %bb121.i ], [ %133, %bb130.i ], [ %_42.sroa.42.0.copyload85, %bb127.i ], [ %_104.sroa.6.i.sroa.6.0.copyload, %bb124.i ]
  %_42.sroa.50.3 = phi i32 [ %_42.sroa.50.0511, %bb121.i ], [ 58, %bb130.i ], [ %_42.sroa.50.0.copyload90, %bb127.i ], [ %_104.sroa.6.i.sroa.7.0.copyload, %bb124.i ]
  %_42.sroa.58.3 = phi i32 [ %_42.sroa.58.0512, %bb121.i ], [ -2147483648, %bb130.i ], [ %_42.sroa.58.0.copyload99, %bb127.i ], [ %_42.sroa.58.20.copyload, %bb124.i ]
  %_42.sroa.65.3 = phi i64 [ %_42.sroa.65.0513, %bb121.i ], [ %_42.sroa.65.0513, %bb130.i ], [ %_42.sroa.65.0.copyload108, %bb127.i ], [ %_42.sroa.65.20.copyload, %bb124.i ]
  %_42.sroa.65117.3 = phi ptr [ %_42.sroa.65117.0515, %bb121.i ], [ @alloc_baf8a0c4f165a36478d562053e9f806a, %bb130.i ], [ %_42.sroa.65117.0.copyload118, %bb127.i ], [ %_42.sroa.65117.20.copyload, %bb124.i ]
  %_42.sroa.68.3 = phi i32 [ %_42.sroa.68.0516, %bb121.i ], [ 23, %bb130.i ], [ %_42.sroa.68.0.copyload127, %bb127.i ], [ %_42.sroa.68.20.copyload, %bb124.i ]
  %_42.sroa.23.sroa.0.3 = phi i8 [ %_42.sroa.23.sroa.0.0517, %bb121.i ], [ %_42.sroa.23.sroa.0.0517, %bb130.i ], [ %_42.sroa.23.sroa.0.0.extract.trunc, %bb127.i ], [ %_42.sroa.23.sroa.0.0.extract.trunc142, %bb124.i ]
  %_42.sroa.23.sroa.16.sroa.0.3 = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.0519, %bb121.i ], [ %_42.sroa.23.sroa.16.sroa.0.0519, %bb130.i ], [ %_42.sroa.23.sroa.16.0.extract.trunc, %bb127.i ], [ %_42.sroa.23.sroa.16.0.extract.trunc159, %bb124.i ]
; call core::ptr::drop_in_place<core::iter::adapters::zip::Zip<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<core::option::Option<[u8; 16]>>,alloc::vec::into_iter::IntoIter<core::option::Option<&str>>>,alloc::vec::into_iter::IntoIter<core::option::Option<&str>>>>
  call fastcc void @"_ZN4core3ptr342drop_in_place$LT$core..iter..adapters..zip..Zip$LT$core..iter..adapters..zip..Zip$LT$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$C$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$$C$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$$GT$17heeffd248ec5de409E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(68) %iter19.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %iter19.i), !noalias !4302
  switch i32 %parents.sroa.0.0.i, label %bb2.i.i.i.i.i125.i [
    i32 -2147483648, label %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i"
    i32 0, label %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i"
  ]

bb2.i.i.i.i.i125.i:                               ; preds = %bb52.i
  %103 = icmp ne ptr %parents.sroa.7.0.i, null
  call void @llvm.assume(i1 %103)
  %alloc_size.i.i.i.i.i.i.i = mul nuw i32 %parents.sroa.0.0.i, 17
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %parents.sroa.7.0.i, i32 noundef %alloc_size.i.i.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4355
  br label %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i"

"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i": ; preds = %bb2.i.i.i.i.i125.i, %bb52.i, %bb52.i
  call void @llvm.lifetime.end.p0(ptr nonnull %kinds16.i), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %names15.i), !noalias !4302
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit

bb125.i:                                          ; preds = %bb122.i
  %104 = getelementptr inbounds nuw i8, ptr %_392217353.i, i32 4
  %_17.1.i.i.i = load i32, ptr %104, align 4, !noalias !4358
  %_17.0.i.i.i = load ptr, ptr %_392217353.i, align 4, !noalias !4358, !noundef !1
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %id22.i, ptr noundef nonnull align 1 dereferenceable(16) %self1.sroa.7.0._21.i.sroa_idx.i.i.i.i, i32 16, i1 false), !noalias !4156
  call void @llvm.lifetime.start.p0(ptr nonnull %_108.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %0), !noalias !4302
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %0, ptr noundef nonnull align 1 dereferenceable(16) %self1.sroa.7.0._21.i.sroa_idx.i.i.i.i, i32 16, i1 false), !noalias !4156
; call xyg_engine::graphforge::base::Collector::node
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector4node17h52562e58bb6025cdE(ptr noalias noundef align 4 captures(none) dereferenceable(40) %_108.i, ptr noalias noundef nonnull align 8 dereferenceable(192) %collector, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %0, ptr noalias noundef readonly captures(address, read_provenance) %_17.0.i.i.i.i.i, i32 %_17.1.i.i.i.i.i, ptr noalias noundef readonly captures(address, read_provenance) %_17.0.i.i.i, i32 %_17.1.i.i.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %0), !noalias !4302
  %105 = load i32, ptr %_108.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not73.i = icmp eq i32 %105, 2
  br i1 %.not73.i, label %bb128.i, label %bb127.i

bb124.i:                                          ; preds = %bb122.i
  store ptr %_23.i.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i8.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.2.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store i32 %_300.0.i, ptr %_93.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_308.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %field.i.i), !noalias !4302
  store ptr @alloc_cf31b62cfed39ba50ebff67f88563271, ptr %field.i.i, align 4, !noalias !4362
  store i32 9, ptr %22, align 4, !noalias !4362
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.i.i), !noalias !4362
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i), !noalias !4362
  store i64 %_7.sroa.0.sroa.0.0.insert.insert.i.i, ptr %args.i.i, align 4, !noalias !4362
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs8qIlIohfSgY_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([12 x i8]) align 4 captures(none) dereferenceable(12) %24, ptr noundef nonnull @alloc_153d62d021461a19fad1d5bc991f0b21, ptr noundef nonnull %args.i.i) #137, !noalias !4366
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i), !noalias !4362
  store ptr @alloc_043d642a805b35924998976671176b07, ptr %25, align 4, !noalias !4362
  store i32 21, ptr %26, align 4, !noalias !4362
  store i32 0, ptr %_2.i.i, align 4, !noalias !4362
  store i32 -2147483648, ptr %27, align 4, !noalias !4362
  %106 = load ptr, ptr %field.i.i, align 4, !noalias !4362, !nonnull !1, !noundef !1
  %107 = load i32, ptr %22, align 4, !noalias !4362, !noundef !1
; call xyg_engine::graphforge::GfError::with_field
  call void @_ZN10xyg_engine10graphforge7GfError10with_field17h3bfba332006c675cE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_308.i, ptr noalias noundef nonnull align 4 captures(address) dereferenceable(40) %_2.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %106, i32 noundef %107) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.i.i), !noalias !4362
  call void @llvm.lifetime.end.p0(ptr nonnull %field.i.i), !noalias !4302
  %_104.sroa.0.0.copyload.i = load i32, ptr %_308.i, align 4, !noalias !4302
  %_104.sroa.6.i.sroa.0.0.copyload = load i32, ptr %_104.sroa.6.0._308.sroa_idx.i, align 4, !noalias !4302
  %_104.sroa.6.i.sroa.5.0.copyload = load i32, ptr %_104.sroa.6.i.sroa.5.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_104.sroa.6.i.sroa.6.0.copyload = load i32, ptr %_104.sroa.6.i.sroa.6.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_104.sroa.6.i.sroa.7.0.copyload = load i32, ptr %_104.sroa.6.i.sroa.7.0._104.sroa.6.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_42.sroa.58.20.copyload = load i32, ptr %_104.sroa.8.0._308.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.65.20.copyload = load i64, ptr %_42.sroa.65.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.20.copyload = load ptr, ptr %_42.sroa.65117.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.20.copyload = load i32, ptr %_42.sroa.68.20._104.sroa.8.0._308.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_308.i), !noalias !4302
  %_42.sroa.23.sroa.0.0.extract.trunc142 = trunc i32 %_104.sroa.6.i.sroa.0.0.copyload to i8
  %_42.sroa.23.sroa.16.0.extract.shift158 = lshr i32 %_104.sroa.6.i.sroa.0.0.copyload, 8
  %_42.sroa.23.sroa.16.0.extract.trunc159 = trunc nuw i32 %_42.sroa.23.sroa.16.0.extract.shift158 to i24
  br label %bb52.i

bb127.i:                                          ; preds = %bb125.i
  store ptr %_23.i.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i8.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.2.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store i32 %_300.0.i, ptr %_93.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  %_42.sroa.23.0.copyload75 = load i32, ptr %_42.sroa.23.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.23.sroa.0.0.extract.trunc = trunc i32 %_42.sroa.23.0.copyload75 to i8
  %_42.sroa.23.sroa.16.0.extract.shift = lshr i32 %_42.sroa.23.0.copyload75, 8
  %_42.sroa.23.sroa.16.0.extract.trunc = trunc nuw i32 %_42.sroa.23.sroa.16.0.extract.shift to i24
  %_42.sroa.34.0.copyload80 = load i32, ptr %_42.sroa.34.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.42.0.copyload85 = load i32, ptr %_42.sroa.42.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.50.0.copyload90 = load i32, ptr %_42.sroa.50.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.58.0.copyload99 = load i32, ptr %_42.sroa.58.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.0.copyload108 = load i64, ptr %_42.sroa.65.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.0.copyload118 = load ptr, ptr %_42.sroa.65117.0._108.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.0.copyload127 = load i32, ptr %_42.sroa.68.0._108.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_108.i), !noalias !4302
  br label %bb52.i

bb128.i:                                          ; preds = %bb125.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_108.i), !noalias !4302
  br i1 %.not74.i, label %bb37.i, label %bb35.i

bb35.i:                                           ; preds = %bb128.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_114.i), !noalias !4302
  %_325.i = icmp ult i32 %_300.0342350.i, %parents.sroa.9.0.i
  br i1 %_325.i, label %bb129.i, label %panic.i

bb37.i:                                           ; preds = %bb131.i, %bb128.i
  %_9.i.i.i.i.i = icmp eq ptr %_23.i.i.i.i.i, %_368.i
  br i1 %_9.i.i.i.i.i, label %bb121.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i"

bb129.i:                                          ; preds = %bb35.i
  call void @llvm.assume(i1 %95)
  %_115.i = getelementptr inbounds nuw %"core::option::Option<[u8; 16]>", ptr %parents.sroa.7.0.i, i32 %_300.0342350.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(17) %_114.i, ptr noundef nonnull align 1 dereferenceable(17) %_115.i, i32 17, i1 false), !noalias !4156
  call void @llvm.experimental.noalias.scope.decl(metadata !4367)
  call void @llvm.experimental.noalias.scope.decl(metadata !4370)
  call void @llvm.experimental.noalias.scope.decl(metadata !4372)
  call void @llvm.experimental.noalias.scope.decl(metadata !4374)
  call void @llvm.experimental.noalias.scope.decl(metadata !4377)
  %_11.i.i.i = load i32, ptr %20, align 4, !alias.scope !4379, !noalias !4380, !noundef !1
  %108 = icmp eq i32 %_11.i.i.i, 0
  br i1 %108, label %bb8.i127.i, label %bb2.i.i.i

bb2.i.i.i:                                        ; preds = %bb129.i
  %_4.val.i.i.i.i.i = load i64, ptr %id22.i, align 1, !alias.scope !4382, !noalias !4385
  %_4.val1.i.i.i.i.i = load i64, ptr %21, align 1, !alias.scope !4382, !noalias !4385
  %109 = call noundef i64 @llvm.fshl.i64(i64 %_4.val1.i.i.i.i.i, i64 %_4.val1.i.i.i.i.i, i64 29)
  %110 = xor i64 %_4.val.i.i.i.i.i, %109
  %111 = xor i64 %110, -7046029254386353131
  %_15.i.i.i.i.i.i = lshr i64 %111, 30
  %_13.i.i.i.i.i.i = xor i64 %_15.i.i.i.i.i.i, %111
  %112 = mul i64 %_13.i.i.i.i.i.i, -4658895280553007687
  %_19.i.i.i.i.i.i = lshr i64 %112, 27
  %_17.i.i.i.i.i.i = xor i64 %_19.i.i.i.i.i.i, %112
  %113 = mul i64 %_17.i.i.i.i.i.i, -7723592293110705685
  %_23.i.i.i.i.i.i = lshr i64 %113, 31
  %_21.i.i.i.i.i.i = xor i64 %_23.i.i.i.i.i.i, %113
  call void @llvm.experimental.noalias.scope.decl(metadata !4388)
  call void @llvm.experimental.noalias.scope.decl(metadata !4391)
  %_19.i.i.i.i.i = lshr i64 %_21.i.i.i.i.i.i, 25
  %tag_hash.i.i.i.i.i = and i64 %_19.i.i.i.i.i, 127
  %_23.i.i.i.i126.i = trunc i64 %_21.i.i.i.i.i.i to i32
  %bucket_mask.i.i.i.i.i = load i32, ptr %_5.sroa.0.sroa.4.0..sroa_idx, align 4, !alias.scope !4394, !noalias !4395, !noundef !1
  %_22.i.i.i.i.i = and i32 %bucket_mask.i.i.i.i.i, %_23.i.i.i.i126.i
  %_27.i.i.i.i.i = load ptr, ptr %2, align 4, !alias.scope !4394, !noalias !4395, !nonnull !1, !noundef !1
  %_44.sroa.0.0.isplat.i.i.i.i.i = mul nuw nsw i64 %tag_hash.i.i.i.i.i, 72340172838076673
  br label %bb1.i.i.i.i.i

bb1.i.i.i.i.i:                                    ; preds = %bb13.i.i.i.i.i, %bb2.i.i.i
  %probe_seq.sroa.9.0.i.i.i.i.i = phi i32 [ 0, %bb2.i.i.i ], [ %122, %bb13.i.i.i.i.i ]
  %probe_seq.sroa.0.0.i.i.i.i.i = phi i32 [ %_22.i.i.i.i.i, %bb2.i.i.i ], [ %124, %bb13.i.i.i.i.i ]
  %_25.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_27.i.i.i.i.i, i32 %probe_seq.sroa.0.0.i.i.i.i.i
  %_29.sroa.0.0.copyload.i.i.i.i.i = load i64, ptr %_25.i.i.i.i.i, align 1, !noalias !4398
  %_36.i.i.i.i.i = xor i64 %_29.sroa.0.0.copyload.i.i.i.i.i, %_44.sroa.0.0.isplat.i.i.i.i.i
  %_40.i.i.i.i.i = add i64 %_36.i.i.i.i.i, -72340172838076673
  %_42.i.i.i.i.i = and i64 %_36.i.i.i.i.i, -9187201950435737472
  %_39.i.i.i.i.i = xor i64 %_42.i.i.i.i.i, -9187201950435737472
  %_38.i.i.i.i.i = and i64 %_39.i.i.i.i.i, %_40.i.i.i.i.i
  %.not.i.not8.i.i.i.i = icmp eq i64 %_38.i.i.i.i.i, 0
  br i1 %.not.i.not8.i.i.i.i, label %bb7.i.i.i.i.i, label %bb6.i.i.i.i.i

bb6.i.i.i.i.i:                                    ; preds = %bb1.i.i.i.i.i, %bb10.i.i.i.i.i
  %iter.sroa.0.0.i9.i.i.i.i = phi i64 [ %_63.i.i.i.i.i, %bb10.i.i.i.i.i ], [ %_38.i.i.i.i.i, %bb1.i.i.i.i.i ]
  %114 = call range(i64 1, 65) i64 @llvm.cttz.i64(i64 %iter.sroa.0.0.i9.i.i.i.i, i1 true)
  %115 = trunc nuw nsw i64 %114 to i32
  %_5314.i.i.i.i.i = lshr i32 %115, 3
  %_13.i.i.i.i.i = add i32 %_5314.i.i.i.i.i, %probe_seq.sroa.0.0.i.i.i.i.i
  %index5.i.i.i.i.i = and i32 %_13.i.i.i.i.i, %bucket_mask.i.i.i.i.i
  %_18.i.i.i.i.i = sub nsw i32 0, %index5.i.i.i.i.i
  %116 = getelementptr inbounds { %"graphforge::UuidKey", i32 }, ptr %_27.i.i.i.i.i, i32 %_18.i.i.i.i.i
  %117 = getelementptr inbounds i8, ptr %116, i32 -20
  %118 = call i32 @memcmp(ptr noundef nonnull readonly align 1 dereferenceable(16) %id22.i, ptr noundef nonnull readonly align 4 dereferenceable(20) %117, i32 16), !alias.scope !4399, !noalias !4406
  %119 = icmp eq i32 %118, 0
  br i1 %119, label %bb9.i128.i, label %bb10.i.i.i.i.i, !prof !6

bb7.i.i.i.i.i:                                    ; preds = %bb10.i.i.i.i.i, %bb1.i.i.i.i.i
  %_71.i.i.i.i.i = shl i64 %_29.sroa.0.0.copyload.i.i.i.i.i, 1
  %_70.i.i.i.i.i = and i64 %_29.sroa.0.0.copyload.i.i.i.i.i, -9187201950435737472
  %self6.i.i.i.i.i = and i64 %_70.i.i.i.i.i, %_71.i.i.i.i.i
  %120 = icmp eq i64 %self6.i.i.i.i.i, 0
  br i1 %120, label %bb13.i.i.i.i.i, label %bb8.i127.i, !prof !4

bb10.i.i.i.i.i:                                   ; preds = %bb6.i.i.i.i.i
  %121 = add i64 %iter.sroa.0.0.i9.i.i.i.i, -1
  %_63.i.i.i.i.i = and i64 %121, %iter.sroa.0.0.i9.i.i.i.i
  %.not.i.not.i.i.i.i = icmp eq i64 %_63.i.i.i.i.i, 0
  br i1 %.not.i.not.i.i.i.i, label %bb7.i.i.i.i.i, label %bb6.i.i.i.i.i

bb13.i.i.i.i.i:                                   ; preds = %bb7.i.i.i.i.i
  %122 = add i32 %probe_seq.sroa.9.0.i.i.i.i.i, 8
  %123 = add i32 %probe_seq.sroa.0.0.i.i.i.i.i, %122
  %124 = and i32 %123, %bucket_mask.i.i.i.i.i
  br label %bb1.i.i.i.i.i

bb9.i128.i:                                       ; preds = %bb6.i.i.i.i.i
  %v.i.i.i = getelementptr inbounds i8, ptr %116, i32 -4
  %dense.i.i = load i32, ptr %v.i.i.i, align 4, !noalias !4409, !noundef !1
  %_22.i.i = load i32, ptr %_11.sroa.5.0..sroa_idx, align 4, !alias.scope !4410, !noalias !4411, !noundef !1
  %_24.i.i = icmp ult i32 %dense.i.i, %_22.i.i
  br i1 %_24.i.i, label %bb10.i129.i, label %panic.i.i

bb8.i127.i:                                       ; preds = %bb129.i, %bb7.i.i.i.i.i
; call core::option::expect_failed
  call void @_RNvNtCs3O6bguQwcd4_4core6option13expect_failed(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_a7d7769291fb702cd4ca6ef64f027ff9, i32 noundef 22, ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_61e1f29cf0c14be71c8af6b786642541) #139, !noalias !4409
  unreachable

bb10.i129.i:                                      ; preds = %bb9.i128.i
  %_23.i.i = load ptr, ptr %_11.sroa.4.0..sroa_idx, align 4, !alias.scope !4410, !noalias !4411, !nonnull !1, !noundef !1
  %_8.i.i = getelementptr inbounds nuw %"core::option::Option<core::option::Option<[u8; 16]>>", ptr %_23.i.i, i32 %dense.i.i
  %125 = load i8, ptr %_8.i.i, align 1, !range !669, !noalias !4409, !noundef !1
  switch i8 %125, label %bb13.i.i [
    i8 2, label %bb131.i
    i8 0, label %bb12.i.i
  ]

panic.i.i:                                        ; preds = %bb9.i128.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCs3O6bguQwcd4_4core9panicking18panic_bounds_check(i32 noundef %dense.i.i, i32 noundef %_22.i.i, ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_8d6b86dd837a585da77917062b8636fa) #139, !noalias !4409
  unreachable

bb13.i.i:                                         ; preds = %bb10.i129.i
  %126 = load i8, ptr %_114.i, align 1, !range !88, !alias.scope !4372, !noalias !4412, !noundef !1
  %127 = trunc nuw i8 %126 to i1
  br i1 %127, label %bb16.i.i, label %bb3.i.i

bb12.i.i:                                         ; preds = %bb10.i129.i
  %128 = load i8, ptr %_114.i, align 1, !range !88, !alias.scope !4372, !noalias !4412, !noundef !1
  %129 = trunc nuw i8 %128 to i1
  br i1 %129, label %bb3.i.i, label %bb131.i

bb16.i.i:                                         ; preds = %bb13.i.i
  %_35.i.i = getelementptr inbounds nuw i8, ptr %_8.i.i, i32 1
  %130 = call i32 @memcmp(ptr noundef nonnull dereferenceable(16) %_35.i.i, ptr noundef nonnull readonly dereferenceable(16) %_36.i.i, i32 16), !noalias !4413
  %.not.i.i = icmp eq i32 %130, 0
  br i1 %.not.i.i, label %bb131.i, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb16.i.i, %bb12.i.i, %bb13.i.i
  store ptr %_23.i.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i8.i.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._93.sroa.0.sroa.0.sroa.0.sroa.5.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i, ptr %_93.sroa.0.sroa.0.sroa.4.sroa.2.0._93.sroa.0.sroa.0.sroa.4.0.iter19.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store i32 %_300.0.i, ptr %_93.sroa.2.0.iter19.sroa_idx.i, align 1, !noalias !4302
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4414
; call __rustc::__rust_alloc
  %131 = call noundef dereferenceable_or_null(58) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 58, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4414
  %132 = icmp eq ptr %131, null
  br i1 %132, label %bb20.i.i, label %bb130.i

bb20.i.i:                                         ; preds = %bb3.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 58) #138, !noalias !4409
  unreachable

panic.i:                                          ; preds = %bb35.i
; call core::panicking::panic_bounds_check
  call void @_RNvNtCs3O6bguQwcd4_4core9panicking18panic_bounds_check(i32 noundef %_300.0342350.i, i32 noundef %parents.sroa.9.0.i, ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_2a8f7f3ad7949cc2a5b1a076b7f53881) #139, !noalias !4156
  unreachable

bb130.i:                                          ; preds = %bb3.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(58) %131, ptr noundef nonnull align 1 dereferenceable(58) @alloc_5c677e6759319b9a02e8072a748bdda1, i32 58, i1 false), !noalias !4409
  call void @llvm.lifetime.end.p0(ptr nonnull %_114.i), !noalias !4302
  %133 = ptrtoint ptr %131 to i32
  br label %bb52.i

bb131.i:                                          ; preds = %bb16.i.i, %bb12.i.i, %bb10.i129.i
  call void @llvm.memmove.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(17) %_8.i.i, ptr noundef nonnull align 1 dereferenceable(17) %_115.i, i32 17, i1 false), !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_114.i), !noalias !4302
  br label %bb37.i

bb82.i:                                           ; preds = %bb1.i.i.i.i.i30.i.i, %bb1.i.i.i.i.i44.i.i
  %_10.sroa.15.0.i = phi i32 [ 11, %bb1.i.i.i.i.i44.i.i ], [ 8, %bb1.i.i.i.i.i30.i.i ]
  %_10.sroa.12.0.i = phi ptr [ @alloc_8703c957d53c74b83d1cf52e90443d36, %bb1.i.i.i.i.i44.i.i ], [ @alloc_feb20d710638e21c23e6ad6113be7b89, %bb1.i.i.i.i.i30.i.i ]
  %_10.sroa.0.0.i = phi ptr [ @alloc_b8132c6d4826de804c89aedc6d99e768, %bb1.i.i.i.i.i44.i.i ], [ @alloc_7c56d378fe2cfdd66798923da4f517f8, %bb1.i.i.i.i.i30.i.i ]
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %62, i32 noundef %47, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4294
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_18.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_19.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_19.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_02b1bce354e2ec5181c1277f1a11b9f6, i32 noundef 9) #137
  %134 = load i32, ptr %_19.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not77.i = icmp eq i32 %134, -2147483648
  br i1 %.not77.i, label %bb84.i, label %bb85.i, !prof !4

bb5.i133.i:                                       ; preds = %_ZN10xyg_engine10graphforge4base14endpoint_names17h37c5deba6d3ec044E.exit.thread265.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 68) #138, !noalias !4417
  unreachable

"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i": ; preds = %_ZN10xyg_engine10graphforge4base14endpoint_names17h37c5deba6d3ec044E.exit.thread265.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(68) %80, ptr noundef nonnull align 1 dereferenceable(68) @alloc_bf20693dc65d2eba05fbef9e47650439, i32 68, i1 false), !noalias !4417
  %135 = ptrtoint ptr %80 to i32
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb85.i:                                           ; preds = %bb82.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_18.i, ptr noundef nonnull align 4 dereferenceable(16) %_19.i, i32 16, i1 false), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %_19.i), !noalias !4302
; call xyg_engine::graphforge::columns::uuids
  call void @_ZN10xyg_engine10graphforge7columns5uuids17h5d3cca72d573f03eE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_16.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %_18.i, i1 noundef zeroext true) #137, !noalias !4156
  %136 = load i32, ptr %_16.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not78.i = icmp eq i32 %136, 2
  %_172.sroa.0.0.copyload.i = load i32, ptr %28, align 4, !noalias !4302
  %_172.sroa.5.0.copyload.i = load ptr, ptr %_172.sroa.5.0..sroa_idx.i, align 4, !noalias !4302
  %_172.sroa.6.0.copyload.i = load i32, ptr %_172.sroa.6.0..sroa_idx.i, align 4, !noalias !4302
  br i1 %.not78.i, label %bb87.i, label %bb86.i

bb84.i:                                           ; preds = %bb82.i
; call core::option::unwrap_failed
  call void @_RNvNtCs3O6bguQwcd4_4core6option13unwrap_failed(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_1bfd0ba74f98ffc3d87d5ef61edb032c) #139, !noalias !4156
  unreachable

bb86.i:                                           ; preds = %bb85.i
  %_173.sroa.6.0._16.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_16.i, i32 16
  %_42.sroa.50.16.copyload96 = load i32, ptr %_173.sroa.6.0._16.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.58.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_16.i, i32 20
  %_42.sroa.58.16.copyload102 = load i32, ptr %_42.sroa.58.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_16.i, i32 24
  %_42.sroa.65.16.copyload111 = load i64, ptr %_42.sroa.65.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_16.i, i32 32
  %_42.sroa.65117.16.copyload121 = load ptr, ptr %_42.sroa.65117.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_16.i, i32 36
  %_42.sroa.68.16.copyload130 = load i32, ptr %_42.sroa.68.16._173.sroa.6.0._16.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i), !noalias !4302
  %_42.sroa.23.sroa.0.0.extract.trunc139 = trunc i32 %_172.sroa.0.0.copyload.i to i8
  %_42.sroa.23.sroa.16.0.extract.shift152 = lshr i32 %_172.sroa.0.0.copyload.i, 8
  %_42.sroa.23.sroa.16.0.extract.trunc153 = trunc nuw i32 %_42.sroa.23.sroa.16.0.extract.shift152 to i24
  %137 = ptrtoint ptr %_172.sroa.5.0.copyload.i to i32
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_18.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i), !noalias !4302
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

bb87.i:                                           ; preds = %bb85.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_18.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_18.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_24.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_26.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_27.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_27.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_10.sroa.0.0.i, i32 noundef %_10.sroa.15.0.i) #137
  %138 = load i32, ptr %_27.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not79.i = icmp eq i32 %138, -2147483648
  br i1 %.not79.i, label %bb88.i, label %bb89.i, !prof !4

bb89.i:                                           ; preds = %bb87.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_26.i, ptr noundef nonnull align 4 dereferenceable(16) %_27.i, i32 16, i1 false), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %_27.i), !noalias !4302
; call xyg_engine::graphforge::columns::uuids
  call void @_ZN10xyg_engine10graphforge7columns5uuids17h5d3cca72d573f03eE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_24.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %_26.i, i1 noundef zeroext true) #137, !noalias !4156
  %139 = load i32, ptr %_24.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not80.i = icmp eq i32 %139, 2
  %_181.sroa.0.0.copyload.i = load i32, ptr %29, align 4, !noalias !4302
  %_181.sroa.5.0.copyload.i = load ptr, ptr %_181.sroa.5.0..sroa_idx.i, align 4, !noalias !4302
  %_181.sroa.6.0.copyload.i = load i32, ptr %_181.sroa.6.0..sroa_idx.i, align 4, !noalias !4302
  br i1 %.not80.i, label %bb91.i, label %bb90.i

bb88.i:                                           ; preds = %bb87.i
; call core::option::unwrap_failed
  call void @_RNvNtCs3O6bguQwcd4_4core6option13unwrap_failed(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_400f2544c6064a8be6584f41968c1023) #139, !noalias !4156
  unreachable

bb90.i:                                           ; preds = %bb89.i
  %_182.sroa.6.0._24.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_24.i, i32 16
  %_42.sroa.50.16.copyload97 = load i32, ptr %_182.sroa.6.0._24.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.58.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_24.i, i32 20
  %_42.sroa.58.16.copyload103 = load i32, ptr %_42.sroa.58.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_24.i, i32 24
  %_42.sroa.65.16.copyload112 = load i64, ptr %_42.sroa.65.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_24.i, i32 32
  %_42.sroa.65117.16.copyload122 = load ptr, ptr %_42.sroa.65117.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_24.i, i32 36
  %_42.sroa.68.16.copyload131 = load i32, ptr %_42.sroa.68.16._182.sroa.6.0._24.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_26.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i), !noalias !4302
  br label %bb141.i

bb91.i:                                           ; preds = %bb89.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_26.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_26.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_31.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_33.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_34.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_34.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_10.sroa.12.0.i, i32 noundef %_10.sroa.15.0.i) #137
  %140 = load i32, ptr %_34.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not81.i = icmp eq i32 %140, -2147483648
  br i1 %.not81.i, label %bb92.i, label %bb93.i, !prof !4

bb93.i:                                           ; preds = %bb91.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_33.i, ptr noundef nonnull align 4 dereferenceable(16) %_34.i, i32 16, i1 false), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %_34.i), !noalias !4302
; call xyg_engine::graphforge::columns::uuids
  call void @_ZN10xyg_engine10graphforge7columns5uuids17h5d3cca72d573f03eE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_31.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(16) %_33.i, i1 noundef zeroext true) #137, !noalias !4156
  %141 = load i32, ptr %_31.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not82.i = icmp eq i32 %141, 2
  %_190.sroa.0.0.copyload.i = load i32, ptr %30, align 4, !noalias !4302
  %_190.sroa.5.0.copyload.i = load ptr, ptr %_190.sroa.5.0..sroa_idx.i, align 4, !noalias !4302
  %_190.sroa.6.0.copyload.i = load i32, ptr %_190.sroa.6.0..sroa_idx.i, align 4, !noalias !4302
  br i1 %.not82.i, label %bb95.i, label %bb94.i

bb92.i:                                           ; preds = %bb91.i
; call core::option::unwrap_failed
  call void @_RNvNtCs3O6bguQwcd4_4core6option13unwrap_failed(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_440601b7cc6aa6649325689dd9a24225) #139, !noalias !4156
  unreachable

bb94.i:                                           ; preds = %bb93.i
  %_191.sroa.8.0._31.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_31.i, i32 16
  %_42.sroa.50.16.copyload98 = load i32, ptr %_191.sroa.8.0._31.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.58.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_31.i, i32 20
  %_42.sroa.58.16.copyload104 = load i32, ptr %_42.sroa.58.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_31.i, i32 24
  %_42.sroa.65.16.copyload113 = load i64, ptr %_42.sroa.65.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_31.i, i32 32
  %_42.sroa.65117.16.copyload123 = load ptr, ptr %_42.sroa.65117.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_31.i, i32 36
  %_42.sroa.68.16.copyload132 = load i32, ptr %_42.sroa.68.16._191.sroa.8.0._31.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_31.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_33.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i), !noalias !4302
  %142 = icmp eq i32 %_181.sroa.0.0.copyload.i, 0
  br i1 %142, label %bb141.i, label %bb2.i.i.i.i135.i

bb2.i.i.i.i135.i:                                 ; preds = %bb94.i
  %143 = icmp ne ptr %_181.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %143)
  %alloc_size.i.i.i.i.i137.i = mul nuw i32 %_181.sroa.0.0.copyload.i, 17
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_181.sroa.5.0.copyload.i, i32 noundef %alloc_size.i.i.i.i.i137.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4418
  br label %bb141.i

bb95.i:                                           ; preds = %bb93.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_31.i), !noalias !4302
; call core::ptr::drop_in_place<xyg_engine::arrow_ipc::Column>
  call fastcc void @"_ZN4core3ptr50drop_in_place$LT$xyg_engine..arrow_ipc..Column$GT$17hdc98edca8c152827E"(ptr noalias noundef align 4 dereferenceable(16) %_33.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %kinds.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_37.i), !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_38.i), !noalias !4302
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_38.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_7a36ced804ab40813fe305851bc84a65, i32 noundef 8) #137
  %144 = load i32, ptr %_38.i, align 4, !range !325, !noalias !4302, !noundef !1
  %.not83.i = icmp eq i32 %144, -2147483648
  br i1 %.not83.i, label %"_ZN4core3ptr78drop_in_place$LT$core..option..Option$LT$xyg_engine..arrow_ipc..Column$GT$$GT$17h634c7bef72a1b38bE.exit.i", label %bb98.i

bb98.i:                                           ; preds = %bb95.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(16) %_37.i, ptr noundef nonnull align 4 dereferenceable(16) %_38.i, i32 16, i1 false), !noalias !4302
  br label %bb96.i

"_ZN4core3ptr78drop_in_place$LT$core..option..Option$LT$xyg_engine..arrow_ipc..Column$GT$$GT$17h634c7bef72a1b38bE.exit.i": ; preds = %bb95.i
; call xyg_engine::arrow_ipc::Table::column
  call void @_ZN10xyg_engine9arrow_ipc5Table6column17hb96ef4b4909a6da5E(ptr noalias noundef nonnull sret([16 x i8]) align 4 captures(none) dereferenceable(16) %_37.i, ptr noalias noundef nonnull readonly align 4 captures(address, read_provenance) dereferenceable(40) %iter2.sroa.0.0521, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_e3cdb18238014d5a684aa2d34b54858d, i32 noundef 17) #137
  br label %bb96.i

bb96.i:                                           ; preds = %"_ZN4core3ptr78drop_in_place$LT$core..option..Option$LT$xyg_engine..arrow_ipc..Column$GT$$GT$17h634c7bef72a1b38bE.exit.i", %bb98.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_38.i), !noalias !4302
  %_197.i = icmp ult i32 %_172.sroa.6.0.copyload.i, 126322568
  call void @llvm.assume(i1 %_197.i)
; call xyg_engine::graphforge::base::Collector::optional_text
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector13optional_text17hf4dc4249fbe9ab81E(ptr noalias noundef align 4 captures(address) dereferenceable(12) %kinds.i, ptr noalias noundef align 4 captures(address) dereferenceable(16) %_37.i, i32 noundef %_172.sroa.6.0.copyload.i) #140, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %_37.i), !noalias !4302
  %145 = icmp ne ptr %_172.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %145)
  %_201.idx.i = mul nuw nsw i32 %_172.sroa.6.0.copyload.i, 17
  %_201.i = getelementptr inbounds nuw i8, ptr %_172.sroa.5.0.copyload.i, i32 %_201.idx.i
  %146 = icmp ne ptr %_181.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %146)
  %_210.i = icmp ult i32 %_181.sroa.6.0.copyload.i, 126322568
  call void @llvm.assume(i1 %_210.i)
  %_208.i = getelementptr inbounds nuw %"core::option::Option<[u8; 16]>", ptr %_181.sroa.5.0.copyload.i, i32 %_181.sroa.6.0.copyload.i
  %_217.i = icmp ult i32 %_190.sroa.6.0.copyload.i, 126322568
  call void @llvm.assume(i1 %_217.i)
  %_215.i = getelementptr inbounds nuw %"core::option::Option<[u8; 16]>", ptr %_190.sroa.5.0.copyload.i, i32 %_190.sroa.6.0.copyload.i
  %147 = icmp sgt i32 %_190.sroa.0.0.copyload.i, -1
  call void @llvm.assume(i1 %147)
  %_389.i = load ptr, ptr %31, align 4, !noalias !4302, !nonnull !1, !noundef !1
  %_382.i = load i32, ptr %kinds.i, align 4, !range !67, !noalias !4302, !noundef !1
  %_375.i = load i32, ptr %32, align 4, !noalias !4302, !noundef !1
  %_224.i = icmp ult i32 %_375.i, 268435456
  call void @llvm.assume(i1 %_224.i)
  %_222.i = getelementptr inbounds nuw %"core::option::Option<&str>", ptr %_389.i, i32 %_375.i
  call void @llvm.lifetime.start.p0(ptr nonnull %iter.i), !noalias !4302
  store ptr %_172.sroa.5.0.copyload.i, ptr %iter.i, align 4, !noalias !4302
  store ptr %_172.sroa.5.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 %_172.sroa.0.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.3.0.iter.sroa_idx.i, align 4, !noalias !4302
  store ptr %_201.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.i, align 4, !noalias !4302
  store ptr %_181.sroa.5.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 %_181.sroa.0.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.3.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store ptr %_208.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.4.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.0.sroa.0.sroa.3.0.iter.sroa_idx.i, align 4, !noalias !4302
  store ptr %_190.sroa.5.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 %_190.sroa.0.0.copyload.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.3.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store ptr %_215.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.4.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.0.sroa.2.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.0.sroa.3.0.iter.sroa_idx.i, align 4, !noalias !4302
  store ptr %_389.i, ptr %_40.sroa.0.sroa.4.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 %_382.i, ptr %_40.sroa.0.sroa.4.sroa.3.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store ptr %_222.i, ptr %_40.sroa.0.sroa.4.sroa.4.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.3.0.iter.sroa_idx.i, align 4, !noalias !4302
  store i32 0, ptr %_40.sroa.4.0.iter.sroa_idx.i, align 4, !noalias !4302
  %_9.i.i.i.i.i.i390.i = icmp eq i32 %_172.sroa.6.0.copyload.i, 0
  br i1 %_9.i.i.i.i.i.i390.i, label %bb17.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i": ; preds = %bb96.i, %bb111.i
  %ids.sroa.5.4._387187397.i = phi ptr [ %_23.i.i.i.i.i.i.i, %bb111.i ], [ %_172.sroa.5.0.copyload.i, %bb96.i ]
  %sources.sroa.6.4._388190396.i = phi ptr [ %_23.i10.i.i.i.i.i.i, %bb111.i ], [ %_181.sroa.5.0.copyload.i, %bb96.i ]
  %_190.sroa.5.0.copyload193395.i = phi ptr [ %_23.i.i.i.i146.i, %bb111.i ], [ %_190.sroa.5.0.copyload.i, %bb96.i ]
  %_389195394.i = phi ptr [ %_23.i.i153.i, %bb111.i ], [ %_389.i, %bb96.i ]
  %_23.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %ids.sroa.5.4._387187397.i, i32 17
  %self1.sroa.0.0.copyload13.i.i.i.i.i.i = load i8, ptr %ids.sroa.5.4._387187397.i, align 1, !noalias !4421
  %self1.sroa.7.0._21.i.sroa_idx.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %ids.sroa.5.4._387187397.i, i32 1
  %.not.i.i.i.i.i.i = icmp eq i8 %self1.sroa.0.0.copyload13.i.i.i.i.i.i, 2
  br i1 %.not.i.i.i.i.i.i, label %bb17.i, label %bb7.i.i.i.i.i.i

bb7.i.i.i.i.i.i:                                  ; preds = %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i"
  %_9.i8.i.i.i.i.i.i = icmp eq ptr %sources.sroa.6.4._388190396.i, %_208.i
  br i1 %_9.i8.i.i.i.i.i.i, label %bb17.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i": ; preds = %bb7.i.i.i.i.i.i
  %_23.i10.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %sources.sroa.6.4._388190396.i, i32 17
  %self2.sroa.0.0.copyload14.i.i.i.i.i.i = load i8, ptr %sources.sroa.6.4._388190396.i, align 1, !noalias !4439
  %.not4.i.i.i.i.i.i = icmp eq i8 %self2.sroa.0.0.copyload14.i.i.i.i.i.i, 2
  br i1 %.not4.i.i.i.i.i.i, label %bb17.i, label %bb7.i.i.i140.i

bb7.i.i.i140.i:                                   ; preds = %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i"
  %self2.sroa.7.0._21.i7.sroa_idx.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %sources.sroa.6.4._388190396.i, i32 1
  %_9.i.i.i.i144.i = icmp eq ptr %_190.sroa.5.0.copyload193395.i, %_215.i
  br i1 %_9.i.i.i.i144.i, label %bb17.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i": ; preds = %bb7.i.i.i140.i
  %_23.i.i.i.i146.i = getelementptr inbounds nuw i8, ptr %_190.sroa.5.0.copyload193395.i, i32 17
  %self2.sroa.0.0.copyload5.i.i.i.i = load i8, ptr %_190.sroa.5.0.copyload193395.i, align 1, !noalias !4442
  %.not4.i.i.i.i = icmp eq i8 %self2.sroa.0.0.copyload5.i.i.i.i, 2
  br i1 %.not4.i.i.i.i, label %bb17.i, label %bb7.i147.i

bb7.i147.i:                                       ; preds = %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i"
  %_9.i.i151.i = icmp eq ptr %_389195394.i, %_222.i
  br i1 %_9.i.i151.i, label %bb17.i, label %bb16.i

bb16.i:                                           ; preds = %bb7.i147.i
  %self2.sroa.7.0._21.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_190.sroa.5.0.copyload193395.i, i32 1
  %_23.i.i153.i = getelementptr inbounds nuw i8, ptr %_389195394.i, i32 8
  %_17.0.i.i154.i = load ptr, ptr %_389195394.i, align 4, !noalias !4445, !noundef !1
  %148 = getelementptr inbounds nuw i8, ptr %_389195394.i, i32 4
  %_17.1.i.i155.i = load i32, ptr %148, align 4, !noalias !4445
  call void @llvm.lifetime.start.p0(ptr nonnull %_53.i), !noalias !4302
  %149 = trunc nuw i8 %self1.sroa.0.0.copyload13.i.i.i.i.i.i to i1
  br i1 %149, label %bb102.i, label %bb101.i

bb17.i:                                           ; preds = %bb111.i, %bb7.i147.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i", %bb7.i.i.i140.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i", %bb7.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i", %bb96.i
  %_23.i.i153386.lcssa.i = phi ptr [ %_389.i, %bb96.i ], [ %_23.i.i153.i, %bb111.i ], [ %_389195394.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i" ], [ %_389195394.i, %bb7.i.i.i140.i ], [ %_389195394.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i" ], [ %_389195394.i, %bb7.i.i.i.i.i.i ], [ %_389195394.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i" ], [ %_222.i, %bb7.i147.i ]
  %_23.i.i.i.i146382.i = phi ptr [ %_190.sroa.5.0.copyload.i, %bb96.i ], [ %_23.i.i.i.i146.i, %bb111.i ], [ %_23.i.i.i.i146.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i" ], [ %_215.i, %bb7.i.i.i140.i ], [ %_190.sroa.5.0.copyload193395.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i" ], [ %_190.sroa.5.0.copyload193395.i, %bb7.i.i.i.i.i.i ], [ %_190.sroa.5.0.copyload193395.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i" ], [ %_23.i.i.i.i146.i, %bb7.i147.i ]
  %_23.i10.i.i.i.i.i377.i = phi ptr [ %_181.sroa.5.0.copyload.i, %bb96.i ], [ %_23.i10.i.i.i.i.i.i, %bb111.i ], [ %_23.i10.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i" ], [ %_23.i10.i.i.i.i.i.i, %bb7.i.i.i140.i ], [ %_23.i10.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i" ], [ %_208.i, %bb7.i.i.i.i.i.i ], [ %sources.sroa.6.4._388190396.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i" ], [ %_23.i10.i.i.i.i.i.i, %bb7.i147.i ]
  %_23.i.i.i.i.i.i372.i = phi ptr [ %_172.sroa.5.0.copyload.i, %bb96.i ], [ %_201.i, %bb111.i ], [ %_23.i.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i145.i" ], [ %_23.i.i.i.i.i.i.i, %bb7.i.i.i140.i ], [ %_23.i.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit12.i.i.i.i.i.i" ], [ %_23.i.i.i.i.i.i.i, %bb7.i.i.i.i.i.i ], [ %_23.i.i.i.i.i.i.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i" ], [ %_23.i.i.i.i.i.i.i, %bb7.i147.i ]
  store ptr %_23.i.i.i.i.i.i372.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i10.i.i.i.i.i377.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i.i146382.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i153386.lcssa.i, ptr %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  br label %bb61.i

bb61.i:                                           ; preds = %bb76.i, %bb17.i
  %_42.sroa.0.5 = phi i32 [ 2, %bb17.i ], [ %_42.sroa.0.4, %bb76.i ]
  %_42.sroa.34.6 = phi i32 [ %_42.sroa.34.0509, %bb17.i ], [ %_42.sroa.34.5, %bb76.i ]
  %_42.sroa.42.6 = phi i32 [ %_42.sroa.42.0510, %bb17.i ], [ %_42.sroa.42.5, %bb76.i ]
  %_42.sroa.50.6 = phi i32 [ %_42.sroa.50.0511, %bb17.i ], [ %_42.sroa.50.5, %bb76.i ]
  %_42.sroa.58.6 = phi i32 [ %_42.sroa.58.0512, %bb17.i ], [ %_42.sroa.58.5, %bb76.i ]
  %_42.sroa.65.6 = phi i64 [ %_42.sroa.65.0513, %bb17.i ], [ %_42.sroa.65.5, %bb76.i ]
  %_42.sroa.65117.6 = phi ptr [ %_42.sroa.65117.0515, %bb17.i ], [ %_42.sroa.65117.5, %bb76.i ]
  %_42.sroa.68.6 = phi i32 [ %_42.sroa.68.0516, %bb17.i ], [ %_42.sroa.68.5, %bb76.i ]
  %_42.sroa.23.sroa.0.6 = phi i8 [ %_42.sroa.23.sroa.0.0517, %bb17.i ], [ %_42.sroa.23.sroa.0.5, %bb76.i ]
  %_42.sroa.23.sroa.16.sroa.0.6 = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.0519, %bb17.i ], [ %_42.sroa.23.sroa.16.sroa.0.5, %bb76.i ]
; call core::ptr::drop_in_place<core::iter::adapters::zip::Zip<core::iter::adapters::zip::Zip<core::iter::adapters::zip::Zip<alloc::vec::into_iter::IntoIter<core::option::Option<[u8; 16]>>,alloc::vec::into_iter::IntoIter<core::option::Option<[u8; 16]>>>,alloc::vec::into_iter::IntoIter<core::option::Option<[u8; 16]>>>,alloc::vec::into_iter::IntoIter<core::option::Option<&str>>>>
  call fastcc void @"_ZN4core3ptr491drop_in_place$LT$core..iter..adapters..zip..Zip$LT$core..iter..adapters..zip..Zip$LT$core..iter..adapters..zip..Zip$LT$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$C$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$C$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$C$alloc..vec..into_iter..IntoIter$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$$GT$17h302ef741071820d0E"(ptr noalias noundef align 4 dereferenceable(88) %iter.i) #137, !noalias !4156
  call void @llvm.lifetime.end.p0(ptr nonnull %iter.i), !noalias !4302
  call void @llvm.lifetime.end.p0(ptr nonnull %kinds.i), !noalias !4302
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit

bb102.i:                                          ; preds = %bb16.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %val6.i, ptr noundef nonnull align 1 dereferenceable(16) %self1.sroa.7.0._21.i.sroa_idx.i.i.i.i.i.i, i32 16, i1 false), !noalias !4156
  %150 = trunc nuw i8 %self2.sroa.0.0.copyload14.i.i.i.i.i.i to i1
  br i1 %150, label %bb105.i, label %bb104.i

bb101.i:                                          ; preds = %bb16.i
  store ptr %_23.i.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i10.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i.i146.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i153.i, ptr %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_227.i), !noalias !4302
; call xyg_engine::graphforge::base::null_identity
  call fastcc void @_ZN10xyg_engine10graphforge4base13null_identity17hc237e7d3f2971fd3E(ptr noalias noundef align 4 captures(address) dereferenceable(40) %_227.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_02b1bce354e2ec5181c1277f1a11b9f6, i32 noundef 9) #137, !noalias !4156
  %_55.sroa.0.0.copyload.i = load i32, ptr %_227.i, align 4, !noalias !4302
  %_55.sroa.6.i.sroa.0.0.copyload = load i32, ptr %_55.sroa.6.0._227.sroa_idx.i, align 4, !noalias !4302
  %_55.sroa.6.i.sroa.5.0.copyload = load i32, ptr %_55.sroa.6.i.sroa.5.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_55.sroa.6.i.sroa.6.0.copyload = load i32, ptr %_55.sroa.6.i.sroa.6.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_55.sroa.6.i.sroa.7.0.copyload = load i32, ptr %_55.sroa.6.i.sroa.7.0._55.sroa.6.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_42.sroa.58.20.copyload105 = load i32, ptr %_55.sroa.8.0._227.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.65.20.copyload114 = load i64, ptr %_42.sroa.65.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.20.copyload124 = load ptr, ptr %_42.sroa.65117.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.20.copyload133 = load i32, ptr %_42.sroa.68.20._55.sroa.8.0._227.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_227.i), !noalias !4302
  br label %bb76.i

bb76.i:                                           ; preds = %bb107.i, %bb110.i, %bb104.i, %bb101.i
  %_42.sroa.0.4 = phi i32 [ %_55.sroa.0.0.copyload.i, %bb101.i ], [ %_59.sroa.0.0.copyload.i, %bb104.i ], [ %152, %bb110.i ], [ %_63.sroa.0.0.copyload.i, %bb107.i ]
  %_42.sroa.34.5 = phi i32 [ %_55.sroa.6.i.sroa.5.0.copyload, %bb101.i ], [ %_59.sroa.6.i.sroa.5.0.copyload, %bb104.i ], [ %_42.sroa.34.0.copyload81, %bb110.i ], [ %_63.sroa.6.i.sroa.5.0.copyload, %bb107.i ]
  %_42.sroa.42.5 = phi i32 [ %_55.sroa.6.i.sroa.6.0.copyload, %bb101.i ], [ %_59.sroa.6.i.sroa.6.0.copyload, %bb104.i ], [ %_42.sroa.42.0.copyload86, %bb110.i ], [ %_63.sroa.6.i.sroa.6.0.copyload, %bb107.i ]
  %_42.sroa.50.5 = phi i32 [ %_55.sroa.6.i.sroa.7.0.copyload, %bb101.i ], [ %_59.sroa.6.i.sroa.7.0.copyload, %bb104.i ], [ %_42.sroa.50.0.copyload91, %bb110.i ], [ %_63.sroa.6.i.sroa.7.0.copyload, %bb107.i ]
  %_42.sroa.58.5 = phi i32 [ %_42.sroa.58.20.copyload105, %bb101.i ], [ %_42.sroa.58.20.copyload106, %bb104.i ], [ %_42.sroa.58.0.copyload100, %bb110.i ], [ %_42.sroa.58.20.copyload107, %bb107.i ]
  %_42.sroa.65.5 = phi i64 [ %_42.sroa.65.20.copyload114, %bb101.i ], [ %_42.sroa.65.20.copyload115, %bb104.i ], [ %_42.sroa.65.0.copyload109, %bb110.i ], [ %_42.sroa.65.20.copyload116, %bb107.i ]
  %_42.sroa.65117.5 = phi ptr [ %_42.sroa.65117.20.copyload124, %bb101.i ], [ %_42.sroa.65117.20.copyload125, %bb104.i ], [ %_42.sroa.65117.0.copyload119, %bb110.i ], [ %_42.sroa.65117.20.copyload126, %bb107.i ]
  %_42.sroa.68.5 = phi i32 [ %_42.sroa.68.20.copyload133, %bb101.i ], [ %_42.sroa.68.20.copyload134, %bb104.i ], [ %_42.sroa.68.0.copyload128, %bb110.i ], [ %_42.sroa.68.20.copyload135, %bb107.i ]
  %_42.sroa.23.sroa.0.5.in = phi i32 [ %_55.sroa.6.i.sroa.0.0.copyload, %bb101.i ], [ %_59.sroa.6.i.sroa.0.0.copyload, %bb104.i ], [ %_42.sroa.23.0.copyload76, %bb110.i ], [ %_63.sroa.6.i.sroa.0.0.copyload, %bb107.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_53.i), !noalias !4302
  %_42.sroa.23.sroa.16.sroa.0.5.in = lshr i32 %_42.sroa.23.sroa.0.5.in, 8
  %_42.sroa.23.sroa.16.sroa.0.5 = trunc nuw i32 %_42.sroa.23.sroa.16.sroa.0.5.in to i24
  %_42.sroa.23.sroa.0.5 = trunc i32 %_42.sroa.23.sroa.0.5.in to i8
  br label %bb61.i

bb105.i:                                          ; preds = %bb102.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %val8.i, ptr noundef nonnull align 1 dereferenceable(16) %self2.sroa.7.0._21.i7.sroa_idx.i.i.i.i.i.i, i32 16, i1 false), !noalias !4156
  %151 = trunc nuw i8 %self2.sroa.0.0.copyload5.i.i.i.i to i1
  br i1 %151, label %bb108.i, label %bb107.i

bb104.i:                                          ; preds = %bb102.i
  store ptr %_23.i.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i10.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i.i146.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i153.i, ptr %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_233.i), !noalias !4302
; call xyg_engine::graphforge::base::null_identity
  call fastcc void @_ZN10xyg_engine10graphforge4base13null_identity17hc237e7d3f2971fd3E(ptr noalias noundef align 4 captures(address) dereferenceable(40) %_233.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_10.sroa.0.0.i, i32 noundef %_10.sroa.15.0.i) #137, !noalias !4156
  %_59.sroa.0.0.copyload.i = load i32, ptr %_233.i, align 4, !noalias !4302
  %_59.sroa.6.i.sroa.0.0.copyload = load i32, ptr %_59.sroa.6.0._233.sroa_idx.i, align 4, !noalias !4302
  %_59.sroa.6.i.sroa.5.0.copyload = load i32, ptr %_59.sroa.6.i.sroa.5.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_59.sroa.6.i.sroa.6.0.copyload = load i32, ptr %_59.sroa.6.i.sroa.6.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_59.sroa.6.i.sroa.7.0.copyload = load i32, ptr %_59.sroa.6.i.sroa.7.0._59.sroa.6.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_42.sroa.58.20.copyload106 = load i32, ptr %_59.sroa.8.0._233.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.65.20.copyload115 = load i64, ptr %_42.sroa.65.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.20.copyload125 = load ptr, ptr %_42.sroa.65117.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.20.copyload134 = load i32, ptr %_42.sroa.68.20._59.sroa.8.0._233.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_233.i), !noalias !4302
  br label %bb76.i

bb108.i:                                          ; preds = %bb105.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %val10.i, ptr noundef nonnull align 1 dereferenceable(16) %self2.sroa.7.0._21.i.sroa_idx.i.i.i.i, i32 16, i1 false), !noalias !4156
; call xyg_engine::graphforge::base::Collector::edge
  call fastcc void @_ZN10xyg_engine10graphforge4base9Collector4edge17h55fe5b03624b7ffeE(ptr noalias noundef align 4 captures(none) dereferenceable(40) %_53.i, ptr noalias noundef nonnull align 8 dereferenceable(192) %collector, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %val6.i, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %val8.i, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %val10.i, ptr noalias noundef readonly captures(address, read_provenance) %_17.0.i.i154.i, i32 %_17.1.i.i155.i) #137, !noalias !4156
  %152 = load i32, ptr %_53.i, align 4, !range !616, !noalias !4302, !noundef !1
  %.not85.i = icmp eq i32 %152, 2
  br i1 %.not85.i, label %bb111.i, label %bb110.i

bb107.i:                                          ; preds = %bb105.i
  store ptr %_23.i.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i10.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i.i146.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i153.i, ptr %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  call void @llvm.lifetime.start.p0(ptr nonnull %_242.i), !noalias !4302
; call xyg_engine::graphforge::base::null_identity
  call fastcc void @_ZN10xyg_engine10graphforge4base13null_identity17hc237e7d3f2971fd3E(ptr noalias noundef align 4 captures(address) dereferenceable(40) %_242.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %_10.sroa.12.0.i, i32 noundef %_10.sroa.15.0.i) #137, !noalias !4156
  %_63.sroa.0.0.copyload.i = load i32, ptr %_242.i, align 4, !noalias !4302
  %_63.sroa.6.i.sroa.0.0.copyload = load i32, ptr %_63.sroa.6.0._242.sroa_idx.i, align 4, !noalias !4302
  %_63.sroa.6.i.sroa.5.0.copyload = load i32, ptr %_63.sroa.6.i.sroa.5.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_63.sroa.6.i.sroa.6.0.copyload = load i32, ptr %_63.sroa.6.i.sroa.6.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_63.sroa.6.i.sroa.7.0.copyload = load i32, ptr %_63.sroa.6.i.sroa.7.0._63.sroa.6.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4302
  %_42.sroa.58.20.copyload107 = load i32, ptr %_63.sroa.8.0._242.sroa_idx.i, align 4, !noalias !4309
  %_42.sroa.65.20.copyload116 = load i64, ptr %_42.sroa.65.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.20.copyload126 = load ptr, ptr %_42.sroa.65117.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.20.copyload135 = load i32, ptr %_42.sroa.68.20._63.sroa.8.0._242.sroa_idx.i.sroa_idx, align 4, !noalias !4309
  call void @llvm.lifetime.end.p0(ptr nonnull %_242.i), !noalias !4302
  br label %bb76.i

bb110.i:                                          ; preds = %bb108.i
  store ptr %_23.i.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.2.0.iter.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i10.i.i.i.i.i.i, ptr %_40.sroa.0.sroa.0.sroa.0.sroa.5.sroa.2.0._40.sroa.0.sroa.0.sroa.0.sroa.5.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i.i.i146.i, ptr %_40.sroa.0.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  store ptr %_23.i.i153.i, ptr %_40.sroa.0.sroa.4.sroa.2.0._40.sroa.0.sroa.4.0.iter.sroa_idx.sroa_idx.i, align 1, !noalias !4302
  %_42.sroa.23.0.copyload76 = load i32, ptr %_42.sroa.23.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.34.0.copyload81 = load i32, ptr %_42.sroa.34.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.42.0.copyload86 = load i32, ptr %_42.sroa.42.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.50.0.copyload91 = load i32, ptr %_42.sroa.50.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.58.0.copyload100 = load i32, ptr %_42.sroa.58.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65.0.copyload109 = load i64, ptr %_42.sroa.65.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.65117.0.copyload119 = load ptr, ptr %_42.sroa.65117.0._53.i.sroa_idx, align 4, !noalias !4309
  %_42.sroa.68.0.copyload128 = load i32, ptr %_42.sroa.68.0._53.i.sroa_idx, align 4, !noalias !4309
  br label %bb76.i

bb111.i:                                          ; preds = %bb108.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_53.i), !noalias !4302
  %_9.i.i.i.i.i.i.i = icmp eq ptr %_23.i.i.i.i.i.i.i, %_201.i
  br i1 %_9.i.i.i.i.i.i.i, label %bb17.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17he97f59ab748b7ddeE.exit.i.i.i.i.i.i"

bb141.i:                                          ; preds = %bb2.i.i.i.i135.i, %bb94.i, %bb90.i
  %_42.sroa.0.3 = phi i32 [ %141, %bb94.i ], [ %141, %bb2.i.i.i.i135.i ], [ %139, %bb90.i ]
  %_42.sroa.34.4.in = phi ptr [ %_190.sroa.5.0.copyload.i, %bb94.i ], [ %_190.sroa.5.0.copyload.i, %bb2.i.i.i.i135.i ], [ %_181.sroa.5.0.copyload.i, %bb90.i ]
  %_42.sroa.42.4 = phi i32 [ %_190.sroa.6.0.copyload.i, %bb94.i ], [ %_190.sroa.6.0.copyload.i, %bb2.i.i.i.i135.i ], [ %_181.sroa.6.0.copyload.i, %bb90.i ]
  %_42.sroa.50.4 = phi i32 [ %_42.sroa.50.16.copyload98, %bb94.i ], [ %_42.sroa.50.16.copyload98, %bb2.i.i.i.i135.i ], [ %_42.sroa.50.16.copyload97, %bb90.i ]
  %_42.sroa.58.4 = phi i32 [ %_42.sroa.58.16.copyload104, %bb94.i ], [ %_42.sroa.58.16.copyload104, %bb2.i.i.i.i135.i ], [ %_42.sroa.58.16.copyload103, %bb90.i ]
  %_42.sroa.65.4 = phi i64 [ %_42.sroa.65.16.copyload113, %bb94.i ], [ %_42.sroa.65.16.copyload113, %bb2.i.i.i.i135.i ], [ %_42.sroa.65.16.copyload112, %bb90.i ]
  %_42.sroa.65117.4 = phi ptr [ %_42.sroa.65117.16.copyload123, %bb94.i ], [ %_42.sroa.65117.16.copyload123, %bb2.i.i.i.i135.i ], [ %_42.sroa.65117.16.copyload122, %bb90.i ]
  %_42.sroa.68.4 = phi i32 [ %_42.sroa.68.16.copyload132, %bb94.i ], [ %_42.sroa.68.16.copyload132, %bb2.i.i.i.i135.i ], [ %_42.sroa.68.16.copyload131, %bb90.i ]
  %_42.sroa.23.sroa.0.4.in = phi i32 [ %_190.sroa.0.0.copyload.i, %bb94.i ], [ %_190.sroa.0.0.copyload.i, %bb2.i.i.i.i135.i ], [ %_181.sroa.0.0.copyload.i, %bb90.i ]
  %_42.sroa.23.sroa.16.sroa.0.4.in = lshr i32 %_42.sroa.23.sroa.0.4.in, 8
  %_42.sroa.23.sroa.16.sroa.0.4 = trunc nuw i32 %_42.sroa.23.sroa.16.sroa.0.4.in to i24
  %_42.sroa.23.sroa.0.4 = trunc i32 %_42.sroa.23.sroa.0.4.in to i8
  %_42.sroa.34.4 = ptrtoint ptr %_42.sroa.34.4.in to i32
  %153 = icmp eq i32 %_172.sroa.0.0.copyload.i, 0
  br i1 %153, label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219, label %bb2.i.i.i.i165.i

bb2.i.i.i.i165.i:                                 ; preds = %bb141.i
  %154 = icmp ne ptr %_172.sroa.5.0.copyload.i, null
  call void @llvm.assume(i1 %154)
  %alloc_size.i.i.i.i.i167.i = mul nuw i32 %_172.sroa.0.0.copyload.i, 17
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_172.sroa.5.0.copyload.i, i32 noundef %alloc_size.i.i.i.i.i167.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4449
  br label %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219

_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219: ; preds = %bb140.i, %bb141.i, %bb2.i.i.i.i165.i, %bb86.i, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i", %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i", %bb2.i.i.i.i119.i, %bb115.i, %bb134.i
  %_42.sroa.0.0.ph = phi i32 [ %83, %bb134.i ], [ %90, %bb115.i ], [ %93, %bb2.i.i.i.i119.i ], [ %93, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ 0, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %136, %bb86.i ], [ %_42.sroa.0.3, %bb2.i.i.i.i165.i ], [ %_42.sroa.0.3, %bb141.i ], [ 0, %bb140.i ]
  %_42.sroa.34.1.ph = phi i32 [ %_42.sroa.34.5.copyload, %bb134.i ], [ %91, %bb115.i ], [ %96, %bb2.i.i.i.i119.i ], [ %96, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ 68, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %137, %bb86.i ], [ %_42.sroa.34.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.34.4, %bb141.i ], [ 62, %bb140.i ]
  %_42.sroa.42.1.ph = phi i32 [ %_42.sroa.42.5.copyload, %bb134.i ], [ %_265.sroa.6.0.copyload.i, %bb115.i ], [ %_276.sroa.6.0.copyload.i, %bb2.i.i.i.i119.i ], [ %_276.sroa.6.0.copyload.i, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %135, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_172.sroa.6.0.copyload.i, %bb86.i ], [ %_42.sroa.42.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.42.4, %bb141.i ], [ %86, %bb140.i ]
  %_42.sroa.50.1.ph = phi i32 [ %_42.sroa.50.5.copyload, %bb134.i ], [ %_42.sroa.50.16.copyload, %bb115.i ], [ %_42.sroa.50.16.copyload95, %bb2.i.i.i.i119.i ], [ %_42.sroa.50.16.copyload95, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ 68, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.50.16.copyload96, %bb86.i ], [ %_42.sroa.50.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.50.4, %bb141.i ], [ 62, %bb140.i ]
  %_42.sroa.58.1.ph = phi i32 [ %_42.sroa.58.5.copyload, %bb134.i ], [ %_42.sroa.58.16.copyload, %bb115.i ], [ %_42.sroa.58.16.copyload101, %bb2.i.i.i.i119.i ], [ %_42.sroa.58.16.copyload101, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ -2147483648, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.58.16.copyload102, %bb86.i ], [ %_42.sroa.58.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.58.4, %bb141.i ], [ -2147483648, %bb140.i ]
  %_42.sroa.65.1.ph = phi i64 [ %_42.sroa.65.5.copyload, %bb134.i ], [ %_42.sroa.65.16.copyload, %bb115.i ], [ %_42.sroa.65.16.copyload110, %bb2.i.i.i.i119.i ], [ %_42.sroa.65.16.copyload110, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %_42.sroa.65.0513, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.65.16.copyload111, %bb86.i ], [ %_42.sroa.65.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.65.4, %bb141.i ], [ %_42.sroa.65.0513, %bb140.i ]
  %_42.sroa.65117.1.ph = phi ptr [ %_42.sroa.65117.5.copyload, %bb134.i ], [ %_42.sroa.65117.16.copyload, %bb115.i ], [ %_42.sroa.65117.16.copyload120, %bb2.i.i.i.i119.i ], [ %_42.sroa.65117.16.copyload120, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ @alloc_5a31339c5067eb80f063480f80d2a06e, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.65117.16.copyload121, %bb86.i ], [ %_42.sroa.65117.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.65117.4, %bb141.i ], [ @alloc_5a31339c5067eb80f063480f80d2a06e, %bb140.i ]
  %_42.sroa.68.1.ph = phi i32 [ %_42.sroa.68.5.copyload, %bb134.i ], [ %_42.sroa.68.16.copyload, %bb115.i ], [ %_42.sroa.68.16.copyload129, %bb2.i.i.i.i119.i ], [ %_42.sroa.68.16.copyload129, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ 14, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.68.16.copyload130, %bb86.i ], [ %_42.sroa.68.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.68.4, %bb141.i ], [ 14, %bb140.i ]
  %_42.sroa.23.sroa.0.1.ph = phi i8 [ %_339.sroa.5.0.copyload.i, %bb134.i ], [ %_42.sroa.23.sroa.0.0.extract.trunc137, %bb115.i ], [ %_42.sroa.23.sroa.0.0.extract.trunc138, %bb2.i.i.i.i119.i ], [ %_42.sroa.23.sroa.0.0.extract.trunc138, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %_42.sroa.23.sroa.0.0517, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.23.sroa.0.0.extract.trunc139, %bb86.i ], [ %_42.sroa.23.sroa.0.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.23.sroa.0.4, %bb141.i ], [ %_42.sroa.23.sroa.0.0517, %bb140.i ]
  %_42.sroa.23.sroa.16.sroa.0.1.ph = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.0.copyload, %bb134.i ], [ %_42.sroa.23.sroa.16.0.extract.trunc149, %bb115.i ], [ %_42.sroa.23.sroa.16.0.extract.trunc151, %bb2.i.i.i.i119.i ], [ %_42.sroa.23.sroa.16.0.extract.trunc151, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %_42.sroa.23.sroa.16.sroa.0.0519, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %_42.sroa.23.sroa.16.0.extract.trunc153, %bb86.i ], [ %_42.sroa.23.sroa.16.sroa.0.4, %bb2.i.i.i.i165.i ], [ %_42.sroa.23.sroa.16.sroa.0.4, %bb141.i ], [ %_42.sroa.23.sroa.16.sroa.0.0519, %bb140.i ]
  %_10.idx.i230242277.i.ph = phi i32 [ %47, %bb134.i ], [ %47, %bb115.i ], [ %47, %bb2.i.i.i.i119.i ], [ %47, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %47, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %47, %bb86.i ], [ %47, %bb2.i.i.i.i165.i ], [ %47, %bb141.i ], [ %_10.idx.i230.ph251.ph505.i, %bb140.i ]
  %_4.sroa.10.0.i8.i228244276.i.ph = phi ptr [ %49, %bb134.i ], [ %49, %bb115.i ], [ %49, %bb2.i.i.i.i119.i ], [ %49, %"_ZN4core3ptr79drop_in_place$LT$alloc..vec..Vec$LT$core..option..Option$LT$$RF$str$GT$$GT$$GT$17h547a6406e7552a34E.exit117.i" ], [ %49, %"_ZN10xyg_engine10graphforge4base9Collector5table28_$u7b$$u7b$closure$u7d$$u7d$17h20ffb9b9a74be3b6E.exit.i" ], [ %49, %bb86.i ], [ %49, %bb2.i.i.i.i165.i ], [ %49, %bb141.i ], [ %_4.sroa.10.0.i8.i228.ph252.ph504.i, %bb140.i ]
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_4.sroa.10.0.i8.i228244276.i.ph, i32 noundef %_10.idx.i230242277.i.ph, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4452
  br label %bb37.sink.split

_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit: ; preds = %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i", %bb61.i
  %_42.sroa.0.0 = phi i32 [ %_42.sroa.0.2, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.0.5, %bb61.i ]
  %_42.sroa.34.1 = phi i32 [ %_42.sroa.34.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.34.6, %bb61.i ]
  %_42.sroa.42.1 = phi i32 [ %_42.sroa.42.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.42.6, %bb61.i ]
  %_42.sroa.50.1 = phi i32 [ %_42.sroa.50.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.50.6, %bb61.i ]
  %_42.sroa.58.1 = phi i32 [ %_42.sroa.58.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.58.6, %bb61.i ]
  %_42.sroa.65.1 = phi i64 [ %_42.sroa.65.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.65.6, %bb61.i ]
  %_42.sroa.65117.1 = phi ptr [ %_42.sroa.65117.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.65117.6, %bb61.i ]
  %_42.sroa.68.1 = phi i32 [ %_42.sroa.68.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.68.6, %bb61.i ]
  %_42.sroa.23.sroa.0.1 = phi i8 [ %_42.sroa.23.sroa.0.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.23.sroa.0.6, %bb61.i ]
  %_42.sroa.23.sroa.16.sroa.0.1 = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.3, %"_ZN4core3ptr124drop_in_place$LT$core..option..Option$LT$alloc..vec..Vec$LT$core..option..Option$LT$$u5b$u8$u3b$$u20$16$u5d$$GT$$GT$$GT$$GT$17h7446ad9894b54495E.exit.i" ], [ %_42.sroa.23.sroa.16.sroa.0.6, %bb61.i ]
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %49, i32 noundef %47, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4452
  call void @llvm.lifetime.end.p0(ptr nonnull %id22.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_85.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val10.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val8.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val6.i)
  %.not15 = icmp eq i32 %_42.sroa.0.0, 2
  br i1 %.not15, label %bb38, label %bb37

bb35:                                             ; preds = %bb38, %bb18
  call void @llvm.lifetime.start.p0(ptr nonnull %_45)
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(192) %_45, ptr noundef nonnull align 8 dereferenceable(192) %collector, i32 192, i1 false)
  call void @llvm.experimental.noalias.scope.decl(metadata !4455)
  call void @llvm.experimental.noalias.scope.decl(metadata !4458)
  call void @llvm.lifetime.start.p0(ptr nonnull %id.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %missing.i), !noalias !4460
  store i64 0, ptr %missing.i, align 8, !noalias !4460
  %155 = getelementptr inbounds nuw i8, ptr %_45, i32 160
  %156 = getelementptr inbounds nuw i8, ptr %_45, i32 164
  %edges.i = load ptr, ptr %156, align 4, !alias.scope !4458, !noalias !4455, !nonnull !1, !noundef !1
  %edges1.i = load i32, ptr %155, align 8, !range !67, !alias.scope !4458, !noalias !4455, !noundef !1
  %157 = getelementptr inbounds nuw i8, ptr %_45, i32 168
  %edges2.i = load i32, ptr %157, align 8, !alias.scope !4458, !noalias !4455, !noundef !1
  store i32 0, ptr %155, align 8, !alias.scope !4458, !noalias !4455
  store ptr inttoptr (i32 4 to ptr), ptr %156, align 4, !alias.scope !4458, !noalias !4455
  store i32 0, ptr %157, align 8, !alias.scope !4458, !noalias !4455
  %158 = getelementptr inbounds nuw i8, ptr %_45, i32 16
  %_4.i = getelementptr inbounds nuw i8, ptr %_45, i32 92
  %_46.i = icmp ult i32 %edges2.i, 35791395
  call void @llvm.assume(i1 %_46.i)
  %159 = getelementptr inbounds nuw i8, ptr %_45, i32 100
  %len.i.i = load i32, ptr %159, align 4, !alias.scope !4461, !noalias !4455, !noundef !1
  %self2.i.i = load i32, ptr %_4.i, align 4, !range !67, !alias.scope !4461, !noalias !4455, !noundef !1
  %_9.i.i = sub i32 %self2.i.i, %len.i.i
  %_7.i.i = icmp ugt i32 %edges2.i, %_9.i.i
  br i1 %_7.i.i, label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.thread.i", label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i", !prof !4

"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.thread.i": ; preds = %bb35
; call alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle
  call fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h361814e4f772f0e9E"(ptr noalias noundef nonnull align 4 dereferenceable(12) %_4.i, i32 noundef %len.i.i, i32 noundef %edges2.i, i32 noundef 1, i32 noundef 16) #137, !noalias !4455
  %_50.idx211.i = mul nuw nsw i32 %edges2.i, 60
  %_50212.i = getelementptr inbounds nuw i8, ptr %edges.i, i32 %_50.idx211.i
  br label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i"

"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i": ; preds = %bb35
  %_50.idx.i = mul nuw nsw i32 %edges2.i, 60
  %_50.i = getelementptr inbounds nuw i8, ptr %edges.i, i32 %_50.idx.i
  %_9.i13177.i = icmp eq i32 %edges2.i, 0
  br i1 %_9.i13177.i, label %bb6.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i": ; preds = %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i", %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.thread.i"
  %_50214.i = phi ptr [ %_50212.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.thread.i" ], [ %_50.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i" ]
  %160 = getelementptr inbounds nuw i8, ptr %_45, i32 28
  %161 = getelementptr inbounds nuw i8, ptr %_16.i36, i32 8
  %162 = getelementptr inbounds nuw i8, ptr %_45, i32 20
  %163 = getelementptr inbounds nuw i8, ptr %_19.i35, i32 8
  %_55.i = getelementptr inbounds nuw i8, ptr %_45, i32 32
  %164 = getelementptr inbounds nuw i8, ptr %_45, i32 96
  %165 = getelementptr inbounds nuw i8, ptr %_45, i32 104
  %166 = getelementptr inbounds nuw i8, ptr %_45, i32 112
  %167 = getelementptr inbounds nuw i8, ptr %_45, i32 108
  %168 = getelementptr inbounds nuw i8, ptr %_45, i32 116
  %169 = getelementptr inbounds nuw i8, ptr %_45, i32 124
  %170 = getelementptr inbounds nuw i8, ptr %_45, i32 120
  %171 = getelementptr inbounds nuw i8, ptr %_45, i32 128
  %172 = getelementptr inbounds nuw i8, ptr %_45, i32 136
  %173 = getelementptr inbounds nuw i8, ptr %_45, i32 132
  br label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i"

"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i": ; preds = %bb10.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i"
  %174 = phi i64 [ 0, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i" ], [ %326, %bb10.i ]
  %iter.sroa.4.0178.i = phi ptr [ %edges.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.lr.ph.i" ], [ %_23.i.i37, %bb10.i ]
  %_23.i.i37 = getelementptr inbounds nuw i8, ptr %iter.sroa.4.0178.i, i32 60
  %_7.sroa.7.0.iter.sroa.4.4._21.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.sroa.4.0178.i, i32 48
  %_7.sroa.7.0.copyload.i = load i32, ptr %_7.sroa.7.0.iter.sroa.4.4._21.i.sroa_idx.i, align 4, !noalias !4464
  %_7.sroa.10.0.iter.sroa.4.4._21.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %iter.sroa.4.0178.i, i32 52
  %_7.sroa.10.0.copyload.i = load i64, ptr %_7.sroa.10.0.iter.sroa.4.4._21.i.sroa_idx.i, align 4, !noalias !4464
  %_7.sroa.10.sroa.0.0.extract.trunc.i = trunc i64 %_7.sroa.10.0.copyload.i to i32
  %.not.i38 = icmp eq i32 %_7.sroa.7.0.copyload.i, -2147483647
  br i1 %.not.i38, label %bb6.loopexit.i, label %bb5.i

bb5.i:                                            ; preds = %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i"
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %id.i, ptr noundef nonnull align 4 dereferenceable(16) %iter.sroa.4.0178.i, i32 16, i1 false), !noalias !4455
  %175 = getelementptr inbounds nuw i8, ptr %iter.sroa.4.0178.i, i32 16
  call void @llvm.lifetime.start.p0(ptr nonnull %_16.i36), !noalias !4460
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_16.i36, ptr noundef nonnull align 4 dereferenceable(16) %175, i32 16, i1 false), !noalias !4455
  %176 = getelementptr inbounds nuw i8, ptr %iter.sroa.4.0178.i, i32 32
  call void @llvm.experimental.noalias.scope.decl(metadata !4467)
  call void @llvm.experimental.noalias.scope.decl(metadata !4470)
  %_11.i.i = load i32, ptr %160, align 4, !alias.scope !4472, !noalias !4473, !noundef !1
  %177 = icmp eq i32 %_11.i.i, 0
  br i1 %177, label %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.thread.i", label %bb2.i.i39

"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.thread.i": ; preds = %bb5.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i36), !noalias !4460
  call void @llvm.lifetime.start.p0(ptr nonnull %_19.i35), !noalias !4460
  br label %bb7.sink.split.i

bb2.i.i39:                                        ; preds = %bb5.i
  %_4.val.i.i.i.i = load i64, ptr %_16.i36, align 1, !alias.scope !4474, !noalias !4477
  %_4.val1.i.i.i.i = load i64, ptr %161, align 1, !alias.scope !4474, !noalias !4477
  %178 = call noundef i64 @llvm.fshl.i64(i64 %_4.val1.i.i.i.i, i64 %_4.val1.i.i.i.i, i64 29)
  %179 = xor i64 %_4.val.i.i.i.i, %178
  %180 = xor i64 %179, -7046029254386353131
  %_15.i.i.i.i.i = lshr i64 %180, 30
  %_13.i.i.i.i.i40 = xor i64 %_15.i.i.i.i.i, %180
  %181 = mul i64 %_13.i.i.i.i.i40, -4658895280553007687
  %_19.i.i.i.i.i41 = lshr i64 %181, 27
  %_17.i.i.i.i.i42 = xor i64 %_19.i.i.i.i.i41, %181
  %182 = mul i64 %_17.i.i.i.i.i42, -7723592293110705685
  %_23.i.i.i.i.i43 = lshr i64 %182, 31
  %_21.i.i.i.i.i = xor i64 %_23.i.i.i.i.i43, %182
  call void @llvm.experimental.noalias.scope.decl(metadata !4480)
  call void @llvm.experimental.noalias.scope.decl(metadata !4483)
  %_19.i.i.i.i = lshr i64 %_21.i.i.i.i.i, 25
  %tag_hash.i.i.i.i = and i64 %_19.i.i.i.i, 127
  %_23.i.i.i.i = trunc i64 %_21.i.i.i.i.i to i32
  %bucket_mask.i.i.i.i = load i32, ptr %162, align 4, !alias.scope !4486, !noalias !4487, !noundef !1
  %_22.i.i.i.i44 = and i32 %bucket_mask.i.i.i.i, %_23.i.i.i.i
  %_27.i.i.i.i = load ptr, ptr %158, align 4, !alias.scope !4486, !noalias !4487, !nonnull !1, !noundef !1
  %_44.sroa.0.0.isplat.i.i.i.i = mul nuw nsw i64 %tag_hash.i.i.i.i, 72340172838076673
  br label %bb1.i.i.i.i

bb1.i.i.i.i:                                      ; preds = %bb13.i.i.i.i, %bb2.i.i39
  %probe_seq.sroa.9.0.i.i.i.i = phi i32 [ 0, %bb2.i.i39 ], [ %191, %bb13.i.i.i.i ]
  %probe_seq.sroa.0.0.i.i.i.i = phi i32 [ %_22.i.i.i.i44, %bb2.i.i39 ], [ %193, %bb13.i.i.i.i ]
  %_25.i.i.i.i = getelementptr inbounds nuw i8, ptr %_27.i.i.i.i, i32 %probe_seq.sroa.0.0.i.i.i.i
  %_29.sroa.0.0.copyload.i.i.i.i = load i64, ptr %_25.i.i.i.i, align 1, !noalias !4490
  %_36.i.i.i.i = xor i64 %_29.sroa.0.0.copyload.i.i.i.i, %_44.sroa.0.0.isplat.i.i.i.i
  %_40.i.i.i.i = add i64 %_36.i.i.i.i, -72340172838076673
  %_42.i.i.i.i = and i64 %_36.i.i.i.i, -9187201950435737472
  %_39.i.i.i.i = xor i64 %_42.i.i.i.i, -9187201950435737472
  %_38.i.i.i.i = and i64 %_39.i.i.i.i, %_40.i.i.i.i
  %.not.i.not8.i.i.i = icmp eq i64 %_38.i.i.i.i, 0
  br i1 %.not.i.not8.i.i.i, label %bb7.i.i.i.i45, label %bb6.i.i.i.i

bb6.i.i.i.i:                                      ; preds = %bb1.i.i.i.i, %bb10.i.i.i.i
  %iter.sroa.0.0.i9.i.i.i = phi i64 [ %_63.i.i.i.i, %bb10.i.i.i.i ], [ %_38.i.i.i.i, %bb1.i.i.i.i ]
  %183 = call range(i64 1, 65) i64 @llvm.cttz.i64(i64 %iter.sroa.0.0.i9.i.i.i, i1 true)
  %184 = trunc nuw nsw i64 %183 to i32
  %_5314.i.i.i.i = lshr i32 %184, 3
  %_13.i.i.i.i = add i32 %_5314.i.i.i.i, %probe_seq.sroa.0.0.i.i.i.i
  %index5.i.i.i.i = and i32 %_13.i.i.i.i, %bucket_mask.i.i.i.i
  %_18.i.i.i.i = sub nsw i32 0, %index5.i.i.i.i
  %185 = getelementptr inbounds { %"graphforge::UuidKey", i32 }, ptr %_27.i.i.i.i, i32 %_18.i.i.i.i
  %186 = getelementptr inbounds i8, ptr %185, i32 -20
  %187 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(16) %_16.i36, ptr noundef nonnull readonly align 4 dereferenceable(20) %186, i32 16), !alias.scope !4491, !noalias !4498
  %188 = icmp eq i32 %187, 0
  br i1 %188, label %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i", label %bb10.i.i.i.i, !prof !6

bb7.i.i.i.i45:                                    ; preds = %bb10.i.i.i.i, %bb1.i.i.i.i
  %_71.i.i.i.i = shl i64 %_29.sroa.0.0.copyload.i.i.i.i, 1
  %_70.i.i.i.i = and i64 %_29.sroa.0.0.copyload.i.i.i.i, -9187201950435737472
  %self6.i.i.i.i = and i64 %_70.i.i.i.i, %_71.i.i.i.i
  %189 = icmp eq i64 %self6.i.i.i.i, 0
  br i1 %189, label %bb13.i.i.i.i, label %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i", !prof !4

bb10.i.i.i.i:                                     ; preds = %bb6.i.i.i.i
  %190 = add i64 %iter.sroa.0.0.i9.i.i.i, -1
  %_63.i.i.i.i = and i64 %190, %iter.sroa.0.0.i9.i.i.i
  %.not.i.not.i.i.i = icmp eq i64 %_63.i.i.i.i, 0
  br i1 %.not.i.not.i.i.i, label %bb7.i.i.i.i45, label %bb6.i.i.i.i

bb13.i.i.i.i:                                     ; preds = %bb7.i.i.i.i45
  %191 = add i32 %probe_seq.sroa.9.0.i.i.i.i, 8
  %192 = add i32 %probe_seq.sroa.0.0.i.i.i.i, %191
  %193 = and i32 %192, %bucket_mask.i.i.i.i
  br label %bb1.i.i.i.i

"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i": ; preds = %bb7.i.i.i.i45, %bb6.i.i.i.i
  %194 = phi ptr [ %185, %bb6.i.i.i.i ], [ null, %bb7.i.i.i.i45 ]
  %.not.i.i46 = icmp eq ptr %194, null
  %v.i.i = getelementptr inbounds i8, ptr %194, i32 -4
  call void @llvm.lifetime.end.p0(ptr nonnull %_16.i36), !noalias !4460
  call void @llvm.lifetime.start.p0(ptr nonnull %_19.i35), !noalias !4460
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_19.i35, ptr noundef nonnull align 4 dereferenceable(16) %176, i32 16, i1 false), !noalias !4455
  call void @llvm.experimental.noalias.scope.decl(metadata !4501)
  %_4.val.i.i.i17.i = load i64, ptr %_19.i35, align 1, !alias.scope !4504, !noalias !4507
  %_4.val1.i.i.i18.i = load i64, ptr %163, align 1, !alias.scope !4504, !noalias !4507
  %195 = call noundef i64 @llvm.fshl.i64(i64 %_4.val1.i.i.i18.i, i64 %_4.val1.i.i.i18.i, i64 29)
  %196 = xor i64 %_4.val.i.i.i17.i, %195
  %197 = xor i64 %196, -7046029254386353131
  %_15.i.i.i.i19.i = lshr i64 %197, 30
  %_13.i.i.i.i20.i = xor i64 %_15.i.i.i.i19.i, %197
  %198 = mul i64 %_13.i.i.i.i20.i, -4658895280553007687
  %_19.i.i.i.i21.i = lshr i64 %198, 27
  %_17.i.i.i.i22.i = xor i64 %_19.i.i.i.i21.i, %198
  %199 = mul i64 %_17.i.i.i.i22.i, -7723592293110705685
  %_23.i.i.i.i23.i = lshr i64 %199, 31
  %_21.i.i.i.i24.i = xor i64 %_23.i.i.i.i23.i, %199
  %_19.i.i.i25.i = lshr i64 %_21.i.i.i.i24.i, 25
  %tag_hash.i.i.i26.i = and i64 %_19.i.i.i25.i, 127
  %_23.i.i.i27.i = trunc i64 %_21.i.i.i.i24.i to i32
  %_22.i.i.i29.i = and i32 %bucket_mask.i.i.i.i, %_23.i.i.i27.i
  %_44.sroa.0.0.isplat.i.i.i31.i = mul nuw nsw i64 %tag_hash.i.i.i26.i, 72340172838076673
  br label %bb1.i.i.i32.i

bb1.i.i.i32.i:                                    ; preds = %bb13.i.i.i62.i, %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i"
  %probe_seq.sroa.9.0.i.i.i33.i = phi i32 [ 0, %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i" ], [ %208, %bb13.i.i.i62.i ]
  %probe_seq.sroa.0.0.i.i.i34.i = phi i32 [ %_22.i.i.i29.i, %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.i" ], [ %210, %bb13.i.i.i62.i ]
  %_25.i.i.i35.i = getelementptr inbounds nuw i8, ptr %_27.i.i.i.i, i32 %probe_seq.sroa.0.0.i.i.i34.i
  %_29.sroa.0.0.copyload.i.i.i36.i = load i64, ptr %_25.i.i.i35.i, align 1, !noalias !4511
  %_36.i.i.i37.i = xor i64 %_29.sroa.0.0.copyload.i.i.i36.i, %_44.sroa.0.0.isplat.i.i.i31.i
  %_40.i.i.i38.i = add i64 %_36.i.i.i37.i, -72340172838076673
  %_42.i.i.i39.i = and i64 %_36.i.i.i37.i, -9187201950435737472
  %_39.i.i.i40.i = xor i64 %_42.i.i.i39.i, -9187201950435737472
  %_38.i.i.i41.i = and i64 %_39.i.i.i40.i, %_40.i.i.i38.i
  %.not.i.not8.i.i42.i = icmp eq i64 %_38.i.i.i41.i, 0
  br i1 %.not.i.not8.i.i42.i, label %bb7.i.i.i52.i, label %bb6.i.i.i43.i

bb6.i.i.i43.i:                                    ; preds = %bb1.i.i.i32.i, %bb10.i.i.i49.i
  %iter.sroa.0.0.i9.i.i44.i = phi i64 [ %_63.i.i.i50.i, %bb10.i.i.i49.i ], [ %_38.i.i.i41.i, %bb1.i.i.i32.i ]
  %200 = call range(i64 1, 65) i64 @llvm.cttz.i64(i64 %iter.sroa.0.0.i9.i.i44.i, i1 true)
  %201 = trunc nuw nsw i64 %200 to i32
  %_5314.i.i.i45.i = lshr i32 %201, 3
  %_13.i.i.i46.i = add i32 %_5314.i.i.i45.i, %probe_seq.sroa.0.0.i.i.i34.i
  %index5.i.i.i47.i = and i32 %_13.i.i.i46.i, %bucket_mask.i.i.i.i
  %_18.i.i.i48.i = sub nsw i32 0, %index5.i.i.i47.i
  %202 = getelementptr inbounds { %"graphforge::UuidKey", i32 }, ptr %_27.i.i.i.i, i32 %_18.i.i.i48.i
  %203 = getelementptr inbounds i8, ptr %202, i32 -20
  %204 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(16) %_19.i35, ptr noundef nonnull readonly align 4 dereferenceable(20) %203, i32 16), !alias.scope !4518, !noalias !4525
  %205 = icmp eq i32 %204, 0
  br i1 %205, label %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit63.i", label %bb10.i.i.i49.i, !prof !6

bb7.i.i.i52.i:                                    ; preds = %bb10.i.i.i49.i, %bb1.i.i.i32.i
  %_71.i.i.i53.i = shl i64 %_29.sroa.0.0.copyload.i.i.i36.i, 1
  %_70.i.i.i54.i = and i64 %_29.sroa.0.0.copyload.i.i.i36.i, -9187201950435737472
  %self6.i.i.i55.i = and i64 %_70.i.i.i54.i, %_71.i.i.i53.i
  %206 = icmp eq i64 %self6.i.i.i55.i, 0
  br i1 %206, label %bb13.i.i.i62.i, label %bb7.sink.split.i, !prof !4

bb10.i.i.i49.i:                                   ; preds = %bb6.i.i.i43.i
  %207 = add i64 %iter.sroa.0.0.i9.i.i44.i, -1
  %_63.i.i.i50.i = and i64 %207, %iter.sroa.0.0.i9.i.i44.i
  %.not.i.not.i.i51.i = icmp eq i64 %_63.i.i.i50.i, 0
  br i1 %.not.i.not.i.i51.i, label %bb7.i.i.i52.i, label %bb6.i.i.i43.i

bb13.i.i.i62.i:                                   ; preds = %bb7.i.i.i52.i
  %208 = add i32 %probe_seq.sroa.9.0.i.i.i33.i, 8
  %209 = add i32 %probe_seq.sroa.0.0.i.i.i34.i, %208
  %210 = and i32 %209, %bucket_mask.i.i.i.i
  br label %bb1.i.i.i32.i

"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit63.i": ; preds = %bb6.i.i.i43.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_19.i35), !noalias !4460
  br i1 %.not.i.i46, label %bb7.i, label %bb9.i

bb6.loopexit.i:                                   ; preds = %bb10.i, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i"
  %_29190.i = phi i64 [ %326, %bb10.i ], [ %174, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i" ]
  %_23.i.lcssa.i = phi ptr [ %_50214.i, %bb10.i ], [ %_23.i.i37, %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i" ]
  %211 = icmp eq i64 %_29190.i, 0
  br label %bb6.i

bb6.i:                                            ; preds = %bb6.loopexit.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i"
  %_50215.i = phi ptr [ %_50.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i" ], [ %_50214.i, %bb6.loopexit.i ]
  %_29.i = phi i1 [ true, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i" ], [ %211, %bb6.loopexit.i ]
  %iter.sroa.4.186.i = phi ptr [ %edges.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17ha7f75e0790bd4eb8E.exit.i" ], [ %_23.i.lcssa.i, %bb6.loopexit.i ]
  %212 = ptrtoint ptr %_50215.i to i32
  %213 = ptrtoint ptr %iter.sroa.4.186.i to i32
  %214 = sub nuw i32 %212, %213
  %215 = udiv exact i32 %214, 60
  %_85.i.i.i = icmp eq ptr %_50215.i, %iter.sroa.4.186.i
  br i1 %_85.i.i.i, label %bb3.i.i.i47, label %bb4.i.i.i

bb4.i.i.i:                                        ; preds = %bb6.i, %"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i"
  %_6.sroa.0.06.i.i.i = phi i32 [ %216, %"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i" ], [ 0, %bb6.i ]
  %_7.i.i.i = getelementptr inbounds nuw { [16 x i8], [16 x i8], [16 x i8], %"core::option::Option<alloc::string::String>" }, ptr %iter.sroa.4.186.i, i32 %_6.sroa.0.06.i.i.i
  %216 = add i32 %_6.sroa.0.06.i.i.i, 1
  %217 = getelementptr i8, ptr %_7.i.i.i, i32 48
  %_7.val.i.i.i = load i32, ptr %217, align 4, !range !325, !noalias !4528, !noundef !1
  %switch.i.i.i = icmp sgt i32 %_7.val.i.i.i, 0
  br i1 %switch.i.i.i, label %bb2.i.i.i.i.i.i.i.i.i.i, label %"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i"

bb2.i.i.i.i.i.i.i.i.i.i:                          ; preds = %bb4.i.i.i
  %218 = getelementptr i8, ptr %_7.i.i.i, i32 52
  %_7.val3.i.i.i = load ptr, ptr %218, align 4, !noalias !4528, !nonnull !1, !noundef !1
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_7.val3.i.i.i, i32 noundef %_7.val.i.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4533
  br label %"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i"

"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i": ; preds = %bb2.i.i.i.i.i.i.i.i.i.i, %bb4.i.i.i
  %_8.i.i.i = icmp eq i32 %216, %215
  br i1 %_8.i.i.i, label %bb3.i.i.i47, label %bb4.i.i.i

bb3.i.i.i47:                                      ; preds = %"_ZN4core3ptr159drop_in_place$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$17h2dfe8a1f0655e76eE.exit.i.i.i", %bb6.i
  %219 = icmp eq i32 %edges1.i, 0
  br i1 %219, label %"_ZN4core3ptr198drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17h34d41c7557a4d7d8E.exit.i", label %bb2.i.i.i.i.i.i.i.i

bb2.i.i.i.i.i.i.i.i:                              ; preds = %bb3.i.i.i47
  %alloc_size.i.i.i.i.i.i.i.i.i = mul nuw i32 %edges1.i, 60
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %edges.i, i32 noundef %alloc_size.i.i.i.i.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 4) #137, !noalias !4528
  br label %"_ZN4core3ptr198drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17h34d41c7557a4d7d8E.exit.i"

"_ZN4core3ptr198drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17h34d41c7557a4d7d8E.exit.i": ; preds = %bb2.i.i.i.i.i.i.i.i, %bb3.i.i.i47
  br i1 %_29.i, label %bb14.i, label %bb12.i

bb14.i:                                           ; preds = %"_ZN4core3ptr198drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17h34d41c7557a4d7d8E.exit.i"
  %220 = getelementptr inbounds nuw i8, ptr %_45, i32 64
  %_100.i = load i32, ptr %220, align 8, !alias.scope !4458, !noalias !4455, !noundef !1
  %_101.i = icmp ult i32 %_100.i, 134217728
  call void @llvm.assume(i1 %_101.i)
  %221 = icmp eq i32 %_100.i, 0
  br i1 %221, label %bb15.i, label %bb16.i48

bb12.i:                                           ; preds = %"_ZN4core3ptr198drop_in_place$LT$alloc..vec..into_iter..IntoIter$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17h34d41c7557a4d7d8E.exit.i"
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i), !noalias !4460
  %222 = ptrtoint ptr %missing.i to i32
  %_35.sroa.0.sroa.4.0.insert.ext.i = zext i32 ptrtoint (ptr @_RNvXsd_NtNtNtCs3O6bguQwcd4_4core3fmt3num3impyNtB9_7Display3fmt to i32) to i64
  %_35.sroa.0.sroa.4.0.insert.shift.i = shl nuw i64 %_35.sroa.0.sroa.4.0.insert.ext.i, 32
  %_35.sroa.0.sroa.0.0.insert.ext.i = zext i32 %222 to i64
  %_35.sroa.0.sroa.0.0.insert.insert.i = or disjoint i64 %_35.sroa.0.sroa.4.0.insert.shift.i, %_35.sroa.0.sroa.0.0.insert.ext.i
  store i64 %_35.sroa.0.sroa.0.0.insert.insert.i, ptr %args.i, align 4, !noalias !4460
  %_30.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs8qIlIohfSgY_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([12 x i8]) align 4 captures(none) dereferenceable(12) %_30.sroa.5.0._0.sroa_idx.i, ptr noundef nonnull @alloc_8c08c1680856d5fff8d69372187ce837, ptr noundef nonnull %args.i) #137
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i), !noalias !4460
  store i32 0, ptr %_0, align 8, !alias.scope !4455, !noalias !4458
  br label %bb18.i

bb15.i:                                           ; preds = %bb14.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4538
; call __rustc::__rust_alloc
  %223 = call noundef dereferenceable_or_null(27) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 27, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4538
  %224 = icmp eq ptr %223, null
  br i1 %224, label %bb44.i, label %bb45.i60

bb16.i48:                                         ; preds = %bb14.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4541)
  %225 = getelementptr inbounds nuw i8, ptr %_45, i32 184
  %226 = load i8, ptr %225, align 8, !range !88, !alias.scope !4544, !noalias !4545, !noundef !1
  %_2.i.i49 = trunc nuw i8 %226 to i1
  br i1 %_2.i.i49, label %bb2.i71.i, label %bb47.i

bb2.i71.i:                                        ; preds = %bb16.i48
  %227 = getelementptr inbounds nuw i8, ptr %_45, i32 176
  %_33.i.i = load ptr, ptr %227, align 4, !alias.scope !4544, !noalias !4545, !nonnull !1, !noundef !1
  %228 = getelementptr inbounds nuw i8, ptr %_45, i32 180
  %_32.i.i = load i32, ptr %228, align 4, !alias.scope !4544, !noalias !4545, !noundef !1
  %229 = shl nuw i32 %_32.i.i, 4
  %_37.not.i.i.i.i.i = icmp slt i32 %229, 0
  br i1 %_37.not.i.i.i.i.i, label %bb3.i.i.i75.i, label %bb15.i.i.i.i.i, !prof !1792

bb15.i.i.i.i.i:                                   ; preds = %bb2.i71.i
  %230 = icmp eq i32 %_32.i.i, 0
  br i1 %230, label %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i", label %bb3.i.i.i.i.i52

bb3.i.i.i.i.i52:                                  ; preds = %bb15.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4547
; call __rustc::__rust_alloc
  %231 = call noundef ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %229, i32 noundef range(i32 1, 9) 1) #137, !noalias !4547
  %232 = icmp eq ptr %231, null
  br i1 %232, label %bb3.i.i.i75.i, label %bb8.i.i.i.i.i.i.i.i

bb3.i.i.i75.i:                                    ; preds = %bb3.i.i.i.i.i52, %bb2.i71.i
  %_4.sroa.4.0.ph.i.i.i.i = phi i32 [ 1, %bb3.i.i.i.i.i52 ], [ 0, %bb2.i71.i ]
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef %_4.sroa.4.0.ph.i.i.i.i, i32 %229) #138, !noalias !4552
  unreachable

bb8.i.i.i.i.i.i.i.i:                              ; preds = %bb3.i.i.i.i.i52, %"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i"
  %233 = phi i32 [ %234, %"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i" ], [ 0, %bb3.i.i.i.i.i52 ]
  %_40.i.i.i.i.i.i.i.i = getelementptr inbounds nuw %"core::option::Option<core::option::Option<[u8; 16]>>", ptr %_33.i.i, i32 %233
  call void @llvm.experimental.noalias.scope.decl(metadata !4553)
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.i.i.i.i.i.i.i.i.i)
  %_4.sroa.0.0.copyload.i.i.i.i.i.i.i.i.i.i = load i8, ptr %_40.i.i.i.i.i.i.i.i, align 1, !alias.scope !4556, !noalias !4559
  switch i8 %_4.sroa.0.0.copyload.i.i.i.i.i.i.i.i.i.i, label %bb6.i.i.i.i.i.i.i.i.i.i [
    i8 2, label %bb5.i.i.i.i.i.i.i.i.i.i
    i8 0, label %bb5.i.i.i.i.i.i.i.i.i.i
  ]

bb5.i.i.i.i.i.i.i.i.i.i:                          ; preds = %bb8.i.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i.i
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_6.i.i.i.i.i.i.i.i.i, i8 0, i32 16, i1 false), !noalias !4572
  br label %"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i"

bb6.i.i.i.i.i.i.i.i.i.i:                          ; preds = %bb8.i.i.i.i.i.i.i.i
  %_4.sroa.6.0.parent.sroa_idx.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_40.i.i.i.i.i.i.i.i, i32 1
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_6.i.i.i.i.i.i.i.i.i, ptr noundef nonnull readonly align 1 dereferenceable(16) %_4.sroa.6.0.parent.sroa_idx.i.i.i.i.i.i.i.i.i.i, i32 16, i1 false), !noalias !4573
  br label %"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i"

"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i": ; preds = %bb6.i.i.i.i.i.i.i.i.i.i, %bb5.i.i.i.i.i.i.i.i.i.i
  %_3.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw [16 x i8], ptr %231, i32 %233
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_3.i.i.i.i.i.i.i.i.i.i.i, ptr noundef nonnull readonly align 1 dereferenceable(16) %_6.i.i.i.i.i.i.i.i.i, i32 16, i1 false), !noalias !4574
  %234 = add nuw i32 %233, 1
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.i.i.i.i.i.i.i.i.i)
  %_25.i.i.i.i.i.i.i.i = icmp eq i32 %234, %_32.i.i
  br i1 %_25.i.i.i.i.i.i.i.i, label %bb3.i.i.i9.i.i, label %bb8.i.i.i.i.i.i.i.i

bb3.i.i.i9.i.i:                                   ; preds = %"_ZN4core4iter8adapters3map8map_fold28_$u7b$$u7b$closure$u7d$$u7d$17hb219f30aaf8d5b5fE.exit.i.i.i.i.i.i.i.i"
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4575
; call __rustc::__rust_alloc
  %235 = call noundef ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %_32.i.i, i32 noundef range(i32 1, 9) 1) #137, !noalias !4575
  %236 = icmp eq ptr %235, null
  br i1 %236, label %bb3.i.i16.i.i, label %bb8.i.i.i.i.i.i10.i.i

bb3.i.i16.i.i:                                    ; preds = %bb3.i.i.i9.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 %_32.i.i) #138, !noalias !4580
  unreachable

bb8.i.i.i.i.i.i10.i.i:                            ; preds = %bb3.i.i.i9.i.i, %bb8.i.i.i.i.i.i10.i.i
  %237 = phi i32 [ %238, %bb8.i.i.i.i.i.i10.i.i ], [ 0, %bb3.i.i.i9.i.i ]
  %_40.i.i.i.i.i.i11.i.i = getelementptr inbounds nuw %"core::option::Option<core::option::Option<[u8; 16]>>", ptr %_33.i.i, i32 %237
  %_40.val.i.i.i.i.i.i.i.i = load i8, ptr %_40.i.i.i.i.i.i11.i.i, align 1, !noalias !4581
  %_0.i.i.i.i.i.i.i.i.i.i = and i8 %_40.val.i.i.i.i.i.i.i.i, 1
  %_3.i.i.i.i.i.i.i.i.i12.i.i = getelementptr inbounds nuw i8, ptr %235, i32 %237
  store i8 %_0.i.i.i.i.i.i.i.i.i.i, ptr %_3.i.i.i.i.i.i.i.i.i12.i.i, align 1, !noalias !4592
  %238 = add nuw i32 %237, 1
  %_25.i.i.i.i.i.i13.i.i = icmp eq i32 %238, %_32.i.i
  br i1 %_25.i.i.i.i.i.i13.i.i, label %bb3.i1.i.i.i.i, label %bb8.i.i.i.i.i.i10.i.i

"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i": ; preds = %bb15.i.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4599)
  call void @llvm.experimental.noalias.scope.decl(metadata !4602)
  br label %bb20.i.i53

bb3.i1.i.i.i.i:                                   ; preds = %bb8.i.i.i.i.i.i10.i.i
  %_62108.i.i = icmp ult i32 %_32.i.i, 134217728
  call void @llvm.assume(i1 %_62108.i.i)
  %_32.0.i.i.i.i.i = shl nuw nsw i32 %_32.i.i, 3
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4604
; call __rustc::__rust_alloc_zeroed
  %239 = call noundef align 8 ptr @_RNvCsGIExRX8pES_7___rustc19___rust_alloc_zeroed(i32 noundef range(i32 1, -2147483648) %_32.0.i.i.i.i.i, i32 noundef range(i32 1, 9) 8) #137, !noalias !4604
  %240 = icmp eq ptr %239, null
  br i1 %240, label %bb8.i.i.i.i, label %bb3.i.i.i17.i.i

bb8.i.i.i.i:                                      ; preds = %bb3.i1.i.i.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 8, i32 %_32.0.i.i.i.i.i) #138, !noalias !4611
  unreachable

bb3.i.i.i17.i.i:                                  ; preds = %bb3.i1.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4612
; call __rustc::__rust_alloc_zeroed
  %241 = call noundef ptr @_RNvCsGIExRX8pES_7___rustc19___rust_alloc_zeroed(i32 noundef range(i32 1, 134217728) %_32.i.i, i32 noundef range(i32 1, 9) 1) #137, !noalias !4612
  %242 = icmp eq ptr %241, null
  br i1 %242, label %bb6.i.i.i74.i, label %bb24.lr.ph.i.i.i

bb6.i.i.i74.i:                                    ; preds = %bb3.i.i.i17.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 range(i32 0, 134217728) %_32.i.i) #138, !noalias !4617
  unreachable

bb24.lr.ph.i.i.i:                                 ; preds = %bb3.i.i.i17.i.i
  %243 = getelementptr inbounds nuw i8, ptr %_45, i32 28
  %_11.i.i.i.i.i = load i32, ptr %243, align 4, !alias.scope !4618, !noalias !4619
  %_11.i.i.fr.i.i.i = freeze i32 %_11.i.i.i.i.i
  %244 = icmp eq i32 %_11.i.i.fr.i.i.i, 0
  %245 = getelementptr inbounds nuw i8, ptr %id.i.i.i, i32 8
  %246 = getelementptr inbounds nuw i8, ptr %_45, i32 20
  %bucket_mask.i.i.i.i.i.i.i = load i32, ptr %246, align 4, !alias.scope !4618, !noalias !4619
  %_27.i.i.i.i.i.i.i = load ptr, ptr %158, align 4, !alias.scope !4618, !noalias !4619, !nonnull !1
  br i1 %244, label %bb24.us.i.i.i, label %bb24.i.i.i

bb24.us.i.i.i:                                    ; preds = %bb24.lr.ph.i.i.i, %bb12.us.i.i.i
  %iter.sroa.9.021.us.i.i.i = phi i32 [ %247, %bb12.us.i.i.i ], [ 0, %bb24.lr.ph.i.i.i ]
  %247 = add nuw nsw i32 %iter.sroa.9.021.us.i.i.i, 1
  %_3.i.i.us.i.i.i = getelementptr inbounds nuw [16 x i8], ptr %231, i32 %iter.sroa.9.021.us.i.i.i
  %_3.i1.i.us.i.i.i = getelementptr inbounds nuw i8, ptr %235, i32 %iter.sroa.9.021.us.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %id.i.i.i), !noalias !4620
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %id.i.i.i, ptr noundef nonnull readonly align 1 dereferenceable(16) %_3.i.i.us.i.i.i, i32 16, i1 false), !noalias !4621
  %valid.us.i.i.i = load i8, ptr %_3.i1.i.us.i.i.i, align 1, !alias.scope !4599, !noalias !4622, !noundef !1
  %_19.us.i.i.i = icmp ugt i8 %valid.us.i.i.i, 1
  br i1 %_19.us.i.i.i, label %bb1.i.i73.i, label %bb7.us.i.i.i

bb7.us.i.i.i:                                     ; preds = %bb24.us.i.i.i
  %248 = icmp eq i8 %valid.us.i.i.i, 1
  br i1 %248, label %bb8.us.i.i.i, label %bb12.us.i.i.i

bb8.us.i.i.i:                                     ; preds = %bb7.us.i.i.i
  %249 = call i32 @memcmp(ptr noundef nonnull dereferenceable(16) %id.i.i.i, ptr noundef nonnull dereferenceable(16) @alloc_c5ed243ef76953fbd5d669b214245e94, i32 16), !noalias !4620
  %250 = icmp eq i32 %249, 0
  br i1 %250, label %bb2.i20.i.i, label %bb10.us.i.i.i

bb10.us.i.i.i:                                    ; preds = %bb8.us.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4623)
  call void @llvm.experimental.noalias.scope.decl(metadata !4626)
  br label %bb3.i18.i.i

bb12.us.i.i.i:                                    ; preds = %bb7.us.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i.i.i), !noalias !4620
  %exitcond30.not.i.i.i = icmp eq i32 %247, %_32.i.i
  br i1 %exitcond30.not.i.i.i, label %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i, label %bb24.us.i.i.i

bb24.i.i.i:                                       ; preds = %bb24.lr.ph.i.i.i, %bb12.i.i.i
  %iter.sroa.14.022.i.i.i = phi i32 [ %_58.0.i.i.i, %bb12.i.i.i ], [ 0, %bb24.lr.ph.i.i.i ]
  %_58.0.i.i.i = add nuw nsw i32 %iter.sroa.14.022.i.i.i, 1
  %_3.i.i.i.i.i = getelementptr inbounds nuw [16 x i8], ptr %231, i32 %iter.sroa.14.022.i.i.i
  %_3.i1.i.i.i.i = getelementptr inbounds nuw i8, ptr %235, i32 %iter.sroa.14.022.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %id.i.i.i), !noalias !4620
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %id.i.i.i, ptr noundef nonnull readonly align 1 dereferenceable(16) %_3.i.i.i.i.i, i32 16, i1 false), !noalias !4621
  %valid.i.i.i = load i8, ptr %_3.i1.i.i.i.i, align 1, !alias.scope !4599, !noalias !4622, !noundef !1
  %_19.i.i.i = icmp ugt i8 %valid.i.i.i, 1
  br i1 %_19.i.i.i, label %bb1.i.i73.i, label %bb7.i.i.i

bb7.i.i.i:                                        ; preds = %bb24.i.i.i
  %251 = icmp eq i8 %valid.i.i.i, 1
  br i1 %251, label %bb8.i.i.i, label %bb12.i.i.i

bb8.i.i.i:                                        ; preds = %bb7.i.i.i
  %252 = call i32 @memcmp(ptr noundef nonnull dereferenceable(16) %id.i.i.i, ptr noundef nonnull dereferenceable(16) @alloc_c5ed243ef76953fbd5d669b214245e94, i32 16), !noalias !4620
  %253 = icmp eq i32 %252, 0
  br i1 %253, label %bb2.i20.i.i, label %bb10.i.i.i

bb12.i.i.i:                                       ; preds = %bb30.i.i.i, %bb7.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i.i.i), !noalias !4620
  %exitcond.not.i.i.i = icmp eq i32 %_58.0.i.i.i, %_32.i.i
  br i1 %exitcond.not.i.i.i, label %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i, label %bb24.i.i.i

bb10.i.i.i:                                       ; preds = %bb8.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !4623)
  call void @llvm.experimental.noalias.scope.decl(metadata !4626)
  %_4.val.i.i.i.i.i.i.i = load i64, ptr %id.i.i.i, align 1, !alias.scope !4629, !noalias !4632
  %_4.val1.i.i.i.i.i.i.i = load i64, ptr %245, align 1, !alias.scope !4629, !noalias !4632
  %254 = call noundef i64 @llvm.fshl.i64(i64 %_4.val1.i.i.i.i.i.i.i, i64 %_4.val1.i.i.i.i.i.i.i, i64 29)
  %255 = xor i64 %_4.val.i.i.i.i.i.i.i, %254
  %256 = xor i64 %255, -7046029254386353131
  %_15.i.i.i.i.i.i.i.i = lshr i64 %256, 30
  %_13.i.i.i.i.i.i.i.i = xor i64 %_15.i.i.i.i.i.i.i.i, %256
  %257 = mul i64 %_13.i.i.i.i.i.i.i.i, -4658895280553007687
  %_19.i.i.i.i.i.i.i.i = lshr i64 %257, 27
  %_17.i.i.i.i.i.i.i.i = xor i64 %_19.i.i.i.i.i.i.i.i, %257
  %258 = mul i64 %_17.i.i.i.i.i.i.i.i, -7723592293110705685
  %_23.i.i.i.i.i.i.i.i = lshr i64 %258, 31
  %_21.i.i.i.i.i.i.i.i = xor i64 %_23.i.i.i.i.i.i.i.i, %258
  %_19.i.i.i.i.i.i.i = lshr i64 %_21.i.i.i.i.i.i.i.i, 25
  %tag_hash.i.i.i.i.i.i.i = and i64 %_19.i.i.i.i.i.i.i, 127
  %_23.i.i.i.i.i.i.i56 = trunc i64 %_21.i.i.i.i.i.i.i.i to i32
  %_22.i.i.i.i.i.i.i = and i32 %bucket_mask.i.i.i.i.i.i.i, %_23.i.i.i.i.i.i.i56
  %_44.sroa.0.0.isplat.i.i.i.i.i.i.i = mul nuw nsw i64 %tag_hash.i.i.i.i.i.i.i, 72340172838076673
  br label %bb1.i.i.i.i.i.i.i57

bb1.i.i.i.i.i.i.i57:                              ; preds = %bb13.i.i.i.i.i.i.i, %bb10.i.i.i
  %probe_seq.sroa.9.0.i.i.i.i.i.i.i = phi i32 [ 0, %bb10.i.i.i ], [ %267, %bb13.i.i.i.i.i.i.i ]
  %probe_seq.sroa.0.0.i.i.i.i.i.i.i = phi i32 [ %_22.i.i.i.i.i.i.i, %bb10.i.i.i ], [ %269, %bb13.i.i.i.i.i.i.i ]
  %_25.i.i.i.i.i.i.i58 = getelementptr inbounds nuw i8, ptr %_27.i.i.i.i.i.i.i, i32 %probe_seq.sroa.0.0.i.i.i.i.i.i.i
  %_29.sroa.0.0.copyload.i.i.i.i.i.i.i = load i64, ptr %_25.i.i.i.i.i.i.i58, align 1, !noalias !4637
  %_36.i.i.i.i.i.i.i = xor i64 %_29.sroa.0.0.copyload.i.i.i.i.i.i.i, %_44.sroa.0.0.isplat.i.i.i.i.i.i.i
  %_40.i.i.i.i.i.i.i59 = add i64 %_36.i.i.i.i.i.i.i, -72340172838076673
  %_42.i.i.i.i.i.i.i = and i64 %_36.i.i.i.i.i.i.i, -9187201950435737472
  %_39.i.i.i.i.i.i.i = xor i64 %_42.i.i.i.i.i.i.i, -9187201950435737472
  %_38.i.i.i.i.i.i.i = and i64 %_39.i.i.i.i.i.i.i, %_40.i.i.i.i.i.i.i59
  %.not.i.not8.i.i.i.i.i.i = icmp eq i64 %_38.i.i.i.i.i.i.i, 0
  br i1 %.not.i.not8.i.i.i.i.i.i, label %bb7.i.i.i.i.i.i.i, label %bb6.i.i.i.i.i.i.i

bb6.i.i.i.i.i.i.i:                                ; preds = %bb1.i.i.i.i.i.i.i57, %bb10.i.i.i.i.i.i.i
  %iter.sroa.0.0.i9.i.i.i.i.i.i = phi i64 [ %_63.i.i.i.i.i.i.i, %bb10.i.i.i.i.i.i.i ], [ %_38.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i57 ]
  %259 = call range(i64 1, 65) i64 @llvm.cttz.i64(i64 %iter.sroa.0.0.i9.i.i.i.i.i.i, i1 true)
  %260 = trunc nuw nsw i64 %259 to i32
  %_5314.i.i.i.i.i.i.i = lshr i32 %260, 3
  %_13.i.i.i.i.i.i.i = add i32 %_5314.i.i.i.i.i.i.i, %probe_seq.sroa.0.0.i.i.i.i.i.i.i
  %index5.i.i.i.i.i.i.i = and i32 %_13.i.i.i.i.i.i.i, %bucket_mask.i.i.i.i.i.i.i
  %_18.i.i.i.i.i.i.i = sub nsw i32 0, %index5.i.i.i.i.i.i.i
  %261 = getelementptr inbounds { %"graphforge::UuidKey", i32 }, ptr %_27.i.i.i.i.i.i.i, i32 %_18.i.i.i.i.i.i.i
  %262 = getelementptr inbounds i8, ptr %261, i32 -20
  %263 = call i32 @memcmp(ptr noundef nonnull readonly dereferenceable(16) %id.i.i.i, ptr noundef nonnull readonly align 4 dereferenceable(20) %262, i32 16), !alias.scope !4644, !noalias !4651
  %264 = icmp eq i32 %263, 0
  br i1 %264, label %bb30.i.i.i, label %bb10.i.i.i.i.i.i.i, !prof !6

bb7.i.i.i.i.i.i.i:                                ; preds = %bb10.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i57
  %_71.i.i.i.i.i.i.i = shl i64 %_29.sroa.0.0.copyload.i.i.i.i.i.i.i, 1
  %_70.i.i.i.i.i.i.i = and i64 %_29.sroa.0.0.copyload.i.i.i.i.i.i.i, -9187201950435737472
  %self6.i.i.i.i.i.i.i = and i64 %_70.i.i.i.i.i.i.i, %_71.i.i.i.i.i.i.i
  %265 = icmp eq i64 %self6.i.i.i.i.i.i.i, 0
  br i1 %265, label %bb13.i.i.i.i.i.i.i, label %bb3.i18.i.i, !prof !4

bb10.i.i.i.i.i.i.i:                               ; preds = %bb6.i.i.i.i.i.i.i
  %266 = add i64 %iter.sroa.0.0.i9.i.i.i.i.i.i, -1
  %_63.i.i.i.i.i.i.i = and i64 %266, %iter.sroa.0.0.i9.i.i.i.i.i.i
  %.not.i.not.i.i.i.i.i.i = icmp eq i64 %_63.i.i.i.i.i.i.i, 0
  br i1 %.not.i.not.i.i.i.i.i.i, label %bb7.i.i.i.i.i.i.i, label %bb6.i.i.i.i.i.i.i

bb13.i.i.i.i.i.i.i:                               ; preds = %bb7.i.i.i.i.i.i.i
  %267 = add i32 %probe_seq.sroa.9.0.i.i.i.i.i.i.i, 8
  %268 = add i32 %probe_seq.sroa.0.0.i.i.i.i.i.i.i, %267
  %269 = and i32 %268, %bucket_mask.i.i.i.i.i.i.i
  br label %bb1.i.i.i.i.i.i.i57

bb30.i.i.i:                                       ; preds = %bb6.i.i.i.i.i.i.i
  %v.i.i.i.i.i = getelementptr inbounds i8, ptr %261, i32 -4
  %_12.i.i.i.i = load i32, ptr %v.i.i.i.i.i, align 4, !noalias !4654, !noundef !1
  %_11.i.i.i.i = zext i32 %_12.i.i.i.i to i64
  %_30.i.i.i = getelementptr inbounds nuw i64, ptr %239, i32 %iter.sroa.14.022.i.i.i
  store i64 %_11.i.i.i.i, ptr %_30.i.i.i, align 8, !noalias !4655
  %_31.i.i.i = getelementptr inbounds nuw i8, ptr %241, i32 %iter.sroa.14.022.i.i.i
  store i8 1, ptr %_31.i.i.i, align 1, !noalias !4655
  br label %bb12.i.i.i

_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i: ; preds = %bb12.i.i.i, %bb12.us.i.i.i
  %270 = ptrtoint ptr %239 to i32
  br label %bb20.i.i53

bb1.i.i73.i:                                      ; preds = %bb24.i.i.i, %bb24.us.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i.i.i), !noalias !4620
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %241, i32 noundef range(i32 0, 134217728) %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4656
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %239, i32 noundef %_32.0.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4659
  call void @llvm.lifetime.start.p0(ptr nonnull %_66.i.i), !noalias !4662
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4663
; call __rustc::__rust_alloc
  %271 = call noundef dereferenceable_or_null(32) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 32, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4663
  %272 = icmp eq ptr %271, null
  br i1 %272, label %bb9.i.i.i, label %bb10.i21.i.i

bb2.i20.i.i:                                      ; preds = %bb8.i.i.i, %bb8.us.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i.i.i), !noalias !4620
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %241, i32 noundef range(i32 0, 134217728) %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4656
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %239, i32 noundef %_32.0.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4659
  call void @llvm.lifetime.start.p0(ptr nonnull %_66.i.i), !noalias !4662
  call void @llvm.lifetime.start.p0(ptr nonnull %field.i.i.i.i), !noalias !4668
  store ptr @alloc_6a1cd3d11f17db4f9b9736d8df854438, ptr %field.i.i.i.i, align 4, !noalias !4669
  %273 = getelementptr inbounds nuw i8, ptr %field.i.i.i.i, i32 4
  store i32 11, ptr %273, align 4, !noalias !4669
  call void @llvm.lifetime.start.p0(ptr nonnull %_2.i.i.i.i), !noalias !4669
  call void @llvm.lifetime.start.p0(ptr nonnull %args.i.i.i.i), !noalias !4669
  %274 = ptrtoint ptr %field.i.i.i.i to i32
  %_7.sroa.0.sroa.4.0.insert.ext.i.i.i.i = zext i32 ptrtoint (ptr @"_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17h1f491e2c0cb9581eE" to i32) to i64
  %_7.sroa.0.sroa.4.0.insert.shift.i.i.i.i = shl nuw i64 %_7.sroa.0.sroa.4.0.insert.ext.i.i.i.i, 32
  %_7.sroa.0.sroa.0.0.insert.ext.i.i.i.i = zext i32 %274 to i64
  %_7.sroa.0.sroa.0.0.insert.insert.i.i.i.i = or disjoint i64 %_7.sroa.0.sroa.4.0.insert.shift.i.i.i.i, %_7.sroa.0.sroa.0.0.insert.ext.i.i.i.i
  store i64 %_7.sroa.0.sroa.0.0.insert.insert.i.i.i.i, ptr %args.i.i.i.i, align 4, !noalias !4669
  %275 = getelementptr inbounds nuw i8, ptr %_2.i.i.i.i, i32 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs8qIlIohfSgY_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([12 x i8]) align 4 captures(none) dereferenceable(12) %275, ptr noundef nonnull @alloc_153d62d021461a19fad1d5bc991f0b21, ptr noundef nonnull %args.i.i.i.i) #137, !noalias !4673
  call void @llvm.lifetime.end.p0(ptr nonnull %args.i.i.i.i), !noalias !4669
  %276 = getelementptr inbounds nuw i8, ptr %_2.i.i.i.i, i32 32
  store ptr @alloc_043d642a805b35924998976671176b07, ptr %276, align 4, !noalias !4669
  %277 = getelementptr inbounds nuw i8, ptr %_2.i.i.i.i, i32 36
  store i32 21, ptr %277, align 4, !noalias !4669
  store i32 0, ptr %_2.i.i.i.i, align 4, !noalias !4669
  %278 = getelementptr inbounds nuw i8, ptr %_2.i.i.i.i, i32 20
  store i32 -2147483648, ptr %278, align 4, !noalias !4669
  %279 = load ptr, ptr %field.i.i.i.i, align 4, !noalias !4669, !nonnull !1, !noundef !1
  %280 = load i32, ptr %273, align 4, !noalias !4669, !noundef !1
; call xyg_engine::graphforge::GfError::with_field
  call void @_ZN10xyg_engine10graphforge7GfError10with_field17h3bfba332006c675cE(ptr noalias noundef nonnull sret([40 x i8]) align 4 captures(none) dereferenceable(40) %_66.i.i, ptr noalias noundef nonnull align 4 captures(address) dereferenceable(40) %_2.i.i.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %279, i32 noundef %280) #137, !noalias !4674
  call void @llvm.lifetime.end.p0(ptr nonnull %_2.i.i.i.i), !noalias !4669
  call void @llvm.lifetime.end.p0(ptr nonnull %field.i.i.i.i), !noalias !4668
  %_12.sroa.0.0.copyload.pre.i.i = load i32, ptr %_66.i.i, align 4, !noalias !4662
  %_12.sroa.6.0._66.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 4
  %_12.sroa.6.sroa.0.0.copyload.pre.i.i = load i32, ptr %_12.sroa.6.0._66.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %_12.sroa.6.sroa.7.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 8
  %_12.sroa.6.sroa.7.0.copyload.pre.i.i = load i32, ptr %_12.sroa.6.sroa.7.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %_12.sroa.6.sroa.8.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 12
  %_12.sroa.6.sroa.8.0.copyload.pre.i.i = load i32, ptr %_12.sroa.6.sroa.8.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %_12.sroa.6.sroa.9.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 16
  %_12.sroa.6.sroa.9.0.copyload.pre.i.i = load i32, ptr %_12.sroa.6.sroa.9.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %_12.sroa.6.sroa.10.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 20
  %_12.sroa.6.sroa.10.0.copyload.pre.i.i = load ptr, ptr %_12.sroa.6.sroa.10.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %_12.sroa.6.sroa.11.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 24
  %_12.sroa.6.sroa.11.0.copyload.pre.i.i = load i32, ptr %_12.sroa.6.sroa.11.0._12.sroa.6.0._66.sroa_idx.sroa_idx.phi.trans.insert.i.i, align 4, !noalias !4662
  %281 = ptrtoint ptr %_12.sroa.6.sroa.10.0.copyload.pre.i.i to i32
  %_12.sroa.8.0._66.sroa_idx.i.phi.trans.insert.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 28
  %_39.sroa.19.28.copyload.pre.i = load i32, ptr %_12.sroa.8.0._66.sroa_idx.i.phi.trans.insert.i, align 4, !noalias !4675
  %_39.sroa.20.28._12.sroa.8.0._66.sroa_idx.i.sroa_idx.phi.trans.insert.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 32
  %_39.sroa.20.28.copyload.pre.i = load ptr, ptr %_39.sroa.20.28._12.sroa.8.0._66.sroa_idx.i.sroa_idx.phi.trans.insert.i, align 4, !noalias !4675
  %_39.sroa.21.28._12.sroa.8.0._66.sroa_idx.i.sroa_idx.phi.trans.insert.i = getelementptr inbounds nuw i8, ptr %_66.i.i, i32 36
  %_39.sroa.21.28.copyload.pre.i = load i32, ptr %_39.sroa.21.28._12.sroa.8.0._66.sroa_idx.i.sroa_idx.phi.trans.insert.i, align 4, !noalias !4675
  br label %bb2.i.i.i.i67.i.i

bb3.i18.i.i:                                      ; preds = %bb7.i.i.i.i.i.i.i, %bb10.us.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i.i.i), !noalias !4620
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %241, i32 noundef range(i32 0, 134217728) %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4656
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %239, i32 noundef %_32.0.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4659
  call void @llvm.lifetime.start.p0(ptr nonnull %_66.i.i), !noalias !4662
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4676
; call __rustc::__rust_alloc
  %282 = call noundef dereferenceable_or_null(56) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 56, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4676
  %283 = icmp eq ptr %282, null
  br i1 %283, label %bb14.i19.i.i, label %bb15.i.i.i

bb14.i19.i.i:                                     ; preds = %bb3.i18.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 56) #138, !noalias !4679
  unreachable

bb15.i.i.i:                                       ; preds = %bb3.i18.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(56) %282, ptr noundef nonnull align 1 dereferenceable(56) @alloc_dc2e1ef37772794eaef79409cc82e6ef, i32 56, i1 false), !noalias !4679
  %284 = ptrtoint ptr %282 to i32
  br label %bb2.i.i.i.i67.i.i

bb9.i.i.i:                                        ; preds = %bb1.i.i73.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 32) #138, !noalias !4679
  unreachable

bb10.i21.i.i:                                     ; preds = %bb1.i.i73.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(32) %271, ptr noundef nonnull align 1 dereferenceable(32) @alloc_1edd54dae2d2b1b4574119ad05e87b5f, i32 32, i1 false), !noalias !4679
  %285 = ptrtoint ptr %271 to i32
  br label %bb2.i.i.i.i67.i.i

bb20.i.i53:                                       ; preds = %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i, %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i"
  %286 = phi i32 [ %270, %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i ], [ 8, %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i" ]
  %287 = phi ptr [ %241, %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i ], [ inttoptr (i32 1 to ptr), %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i" ]
  %_4.sroa.10.0.i5.i116123145.i.i = phi ptr [ %235, %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i ], [ inttoptr (i32 1 to ptr), %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i" ]
  %_4.sroa.10.0.i10.i102114124144.i.i = phi ptr [ %231, %_ZN10xyg_engine10projection15resolve_parents17hf33190bbc0be90cbE.exit.i.i ], [ inttoptr (i32 1 to ptr), %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h616ba92dec26116cE.exit.i.i" ]
  %288 = inttoptr i32 %286 to ptr
; call xyg_engine::projection::validate_parent_forest
  %289 = call { i32, i32 } @_ZN10xyg_engine10projection22validate_parent_forest17ha107651ddfbbfbebE(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) %288, i32 noundef %_32.i.i, ptr noalias noundef nonnull readonly captures(address, read_provenance) %287, i32 noundef %_32.i.i) #137, !noalias !4674
  %290 = extractvalue { i32, i32 } %289, 0
  %.not.i72.i = icmp eq i32 %290, 2
  br i1 %.not.i72.i, label %bb23.i.i, label %bb22.i.i

bb22.i.i:                                         ; preds = %bb20.i.i53
  %291 = trunc nuw i32 %290 to i1
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4680
  br i1 %291, label %bb2.i26.i.i, label %bb3.i22.i.i

bb2.i26.i.i:                                      ; preds = %bb22.i.i
; call __rustc::__rust_alloc
  %292 = call noundef dereferenceable_or_null(37) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 37, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4683
  %293 = icmp eq ptr %292, null
  br i1 %293, label %bb8.i28.i.i, label %bb9.i27.i.i

bb3.i22.i.i:                                      ; preds = %bb22.i.i
; call __rustc::__rust_alloc
  %294 = call noundef dereferenceable_or_null(33) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 33, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4686
  %295 = icmp eq ptr %294, null
  br i1 %295, label %bb13.i.i.i, label %bb14.i23.i.i

bb13.i.i.i:                                       ; preds = %bb3.i22.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 33) #138, !noalias !4680
  unreachable

bb14.i23.i.i:                                     ; preds = %bb3.i22.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(33) %294, ptr noundef nonnull align 1 dereferenceable(33) @alloc_08093be51ab880dce08b96ca375124e4, i32 33, i1 false), !noalias !4680
  br label %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i"

bb8.i28.i.i:                                      ; preds = %bb2.i26.i.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 37) #138, !noalias !4680
  unreachable

bb9.i27.i.i:                                      ; preds = %bb2.i26.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(37) %292, ptr noundef nonnull align 1 dereferenceable(37) @alloc_ef52334eff0be2f056a1c7455e2dca45, i32 37, i1 false), !noalias !4680
  br label %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i"

"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i": ; preds = %bb9.i27.i.i, %bb14.i23.i.i
  %alloc_452a0e77dee55682d952e6dea9af0cb1.sink.i.i.i = phi ptr [ @alloc_452a0e77dee55682d952e6dea9af0cb1, %bb9.i27.i.i ], [ @alloc_6227f943eb00c3ef5da3abdbaa68cdde, %bb14.i23.i.i ]
  %.sink21.i.i.i = phi i32 [ 20, %bb9.i27.i.i ], [ 19, %bb14.i23.i.i ]
  %.sink19.i.i.i = phi i32 [ 37, %bb9.i27.i.i ], [ 33, %bb14.i23.i.i ]
  %.sink18.i.i.i = phi ptr [ %292, %bb9.i27.i.i ], [ %294, %bb14.i23.i.i ]
  %296 = ptrtoint ptr %.sink18.i.i.i to i32
  br i1 %230, label %bb46.i, label %bb2.i.i.i.i67.i.thread.i

bb2.i.i.i.i67.i.thread.i:                         ; preds = %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i"
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %287, i32 noundef %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4689
  %alloc_size.i.i.i.i.i.i.i54 = shl nuw i32 %_32.i.i, 3
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %288, i32 noundef %alloc_size.i.i.i.i.i.i.i54, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4692
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_4.sroa.10.0.i5.i116123145.i.i, i32 noundef %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4695
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_4.sroa.10.0.i10.i102114124144.i.i, i32 noundef %229, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4698
  br label %bb46.i

bb23.i.i:                                         ; preds = %bb20.i.i53
  %_98.i.i = getelementptr inbounds nuw i64, ptr %288, i32 %_32.i.i
  %297 = ptrtoint ptr %_98.i.i to i32
  %298 = sub nuw i32 %297, %286
  %299 = lshr exact i32 %298, 3
  %spec.store.select.i.i.i = call i32 @llvm.umin.i32(i32 %_32.i.i, i32 %299)
  %_32.0.i.i.i33.i.i = shl nuw i32 %spec.store.select.i.i.i, 3
  %_37.not.i.i.i34.i.i = icmp samesign ugt i32 %spec.store.select.i.i.i, 268435455
  br i1 %_37.not.i.i.i34.i.i, label %bb3.i.i38.i.i, label %bb15.i.i.i35.i.i, !prof !1792

bb15.i.i.i35.i.i:                                 ; preds = %bb23.i.i
  %300 = icmp eq i32 %spec.store.select.i.i.i, 0
  br i1 %300, label %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17hd181b022713ae0dbE.exit.i.i", label %bb3.i.i.i36.i.i

bb3.i.i.i36.i.i:                                  ; preds = %bb15.i.i.i35.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #137, !noalias !4701
; call __rustc::__rust_alloc
  %301 = call noundef align 8 ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %_32.0.i.i.i33.i.i, i32 noundef range(i32 1, 9) 8) #137, !noalias !4701
  %302 = icmp eq ptr %301, null
  br i1 %302, label %bb3.i.i38.i.i, label %bb6.i.i.i.i.i.i.i.i.i

bb3.i.i38.i.i:                                    ; preds = %bb3.i.i.i36.i.i, %bb23.i.i
  %_4.sroa.4.0.ph.i.i39.i.i = phi i32 [ 8, %bb3.i.i.i36.i.i ], [ 0, %bb23.i.i ]
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef %_4.sroa.4.0.ph.i.i39.i.i, i32 %_32.0.i.i.i33.i.i) #138, !noalias !4707
  unreachable

bb6.i.i.i.i.i.i.i.i.i:                            ; preds = %bb3.i.i.i36.i.i, %bb6.i.i.i.i.i.i.i.i.i
  %303 = phi i32 [ %304, %bb6.i.i.i.i.i.i.i.i.i ], [ 0, %bb3.i.i.i36.i.i ]
  %304 = add nuw nsw i32 %303, 1
  %_3.i.i.i.i.i.i.i.i.i.i55 = getelementptr inbounds nuw i64, ptr %288, i32 %303
  %_3.i5.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %287, i32 %303
  %_25.val.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i.i.i.i.i.i.i.i.i.i55, align 8, !noalias !4708, !noundef !1
  %_27.val.i.i.i.i.i.i.i.i.i = load i8, ptr %_3.i5.i.i.i.i.i.i.i.i.i, align 1, !noalias !4708, !noundef !1
  %305 = icmp eq i8 %_27.val.i.i.i.i.i.i.i.i.i, 1
  %spec.store.select.i.i.i.i.i.i.i.i.i.i.i = select i1 %305, i64 %_25.val.i.i.i.i.i.i.i.i.i, i64 -1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %301, i32 %303
  store i64 %spec.store.select.i.i.i.i.i.i.i.i.i.i.i, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !4727
  %exitcond.not.i.i.i.i.i.i.i.i.i = icmp eq i32 %304, %spec.store.select.i.i.i
  br i1 %exitcond.not.i.i.i.i.i.i.i.i.i, label %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17hd181b022713ae0dbE.exit.i.i", label %bb6.i.i.i.i.i.i.i.i.i

"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17hd181b022713ae0dbE.exit.i.i": ; preds = %bb6.i.i.i.i.i.i.i.i.i, %bb15.i.i.i35.i.i
  %_4.sroa.10.0.i.i209.i.i = phi ptr [ inttoptr (i32 8 to ptr), %bb15.i.i.i35.i.i ], [ %301, %bb6.i.i.i.i.i.i.i.i.i ]
  %306 = getelementptr inbounds nuw i8, ptr %_45, i32 140
  call void @llvm.experimental.noalias.scope.decl(metadata !4734)
  %_1.val1.i40.i.i = load i32, ptr %306, align 4, !range !67, !alias.scope !4737, !noalias !4545, !noundef !1
  %307 = icmp eq i32 %_1.val1.i40.i.i, 0
  br i1 %307, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17h3b24f963b78db204E.exit44.i.i", label %bb2.i.i.i.i41.i.i

bb2.i.i.i.i41.i.i:                                ; preds = %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17hd181b022713ae0dbE.exit.i.i"
  %308 = getelementptr inbounds nuw i8, ptr %_45, i32 144
  %_1.val2.i42.i.i = load ptr, ptr %308, align 4, !alias.scope !4737, !noalias !4545, !nonnull !1, !noundef !1
  %alloc_size.i.i.i.i.i43.i.i = shl nuw i32 %_1.val1.i40.i.i, 3
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i42.i.i, i32 noundef %alloc_size.i.i.i.i.i43.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4738
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17h3b24f963b78db204E.exit44.i.i"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17h3b24f963b78db204E.exit44.i.i": ; preds = %bb2.i.i.i.i41.i.i, %"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17hd181b022713ae0dbE.exit.i.i"
  store i32 %spec.store.select.i.i.i, ptr %306, align 4, !alias.scope !4544, !noalias !4545
  %_26.sroa.4.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_45, i32 144
  store ptr %_4.sroa.10.0.i.i209.i.i, ptr %_26.sroa.4.0..sroa_idx.i.i, align 4, !alias.scope !4544, !noalias !4545
  %_26.sroa.5.0..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_45, i32 148
  store i32 %spec.store.select.i.i.i, ptr %_26.sroa.5.0..sroa_idx.i.i, align 4, !alias.scope !4544, !noalias !4545
  br i1 %230, label %bb47.i, label %bb2.i.i.i.i59.i.i

bb2.i.i.i.i59.i.i:                                ; preds = %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17h3b24f963b78db204E.exit44.i.i"
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %287, i32 noundef %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4739
  %alloc_size.i.i.i.i.i52.i.i = shl nuw i32 %_32.i.i, 3
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %288, i32 noundef %alloc_size.i.i.i.i.i52.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4742
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_4.sroa.10.0.i5.i116123145.i.i, i32 noundef %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4745
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_4.sroa.10.0.i10.i102114124144.i.i, i32 noundef %229, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4748
  br label %bb47.i

bb2.i.i.i.i67.i.i:                                ; preds = %bb10.i21.i.i, %bb15.i.i.i, %bb2.i20.i.i
  %_39.sroa.21.28.copyload.i = phi i32 [ 26, %bb10.i21.i.i ], [ 22, %bb15.i.i.i ], [ %_39.sroa.21.28.copyload.pre.i, %bb2.i20.i.i ]
  %_39.sroa.20.28.copyload.i = phi ptr [ @alloc_636f9819f9a903d7b5a5510511d6f8fc, %bb10.i21.i.i ], [ @alloc_52064b5387a62a6369b2d57877500e53, %bb15.i.i.i ], [ %_39.sroa.20.28.copyload.pre.i, %bb2.i20.i.i ]
  %_39.sroa.19.28.copyload.i = phi i32 [ undef, %bb10.i21.i.i ], [ undef, %bb15.i.i.i ], [ %_39.sroa.19.28.copyload.pre.i, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.11.0.copyload.i.i = phi i32 [ undef, %bb10.i21.i.i ], [ undef, %bb15.i.i.i ], [ %_12.sroa.6.sroa.11.0.copyload.pre.i.i, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.10.0.copyload.i.i = phi i32 [ -2147483648, %bb10.i21.i.i ], [ -2147483648, %bb15.i.i.i ], [ %281, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.9.0.copyload.i.i = phi i32 [ 32, %bb10.i21.i.i ], [ 56, %bb15.i.i.i ], [ %_12.sroa.6.sroa.9.0.copyload.pre.i.i, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.8.0.copyload.i.i = phi i32 [ %285, %bb10.i21.i.i ], [ %284, %bb15.i.i.i ], [ %_12.sroa.6.sroa.8.0.copyload.pre.i.i, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.7.0.copyload.i.i = phi i32 [ 32, %bb10.i21.i.i ], [ 56, %bb15.i.i.i ], [ %_12.sroa.6.sroa.7.0.copyload.pre.i.i, %bb2.i20.i.i ]
  %_12.sroa.6.sroa.0.0.copyload.i.i = phi i32 [ undef, %bb10.i21.i.i ], [ undef, %bb15.i.i.i ], [ %_12.sroa.6.sroa.0.0.copyload.pre.i.i, %bb2.i20.i.i ]
  %_12.sroa.0.0.copyload.i.i = phi i32 [ 0, %bb10.i21.i.i ], [ 0, %bb15.i.i.i ], [ %_12.sroa.0.0.copyload.pre.i.i, %bb2.i20.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_66.i.i), !noalias !4662
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %235, i32 noundef %_32.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4695
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %231, i32 noundef %229, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4698
  %.not8.i = icmp eq i32 %_12.sroa.0.0.copyload.i.i, 2
  br i1 %.not8.i, label %bb47.i, label %bb46.i

bb44.i:                                           ; preds = %bb15.i
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef 1, i32 27) #138, !noalias !4455
  unreachable

bb45.i60:                                         ; preds = %bb15.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(27) %223, ptr noundef nonnull align 1 dereferenceable(27) @alloc_332812337bffea8d6fd3cdeadfa8b738, i32 27, i1 false), !noalias !4455
  store i32 0, ptr %_0, align 8, !alias.scope !4455, !noalias !4458
  %_37.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 27, ptr %_37.sroa.5.0._0.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  %_37.sroa.5.sroa.4.0._37.sroa.5.0._0.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store ptr %223, ptr %_37.sroa.5.sroa.4.0._37.sroa.5.0._0.sroa_idx.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %_37.sroa.5.sroa.5.0._37.sroa.5.0._0.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i32 27, ptr %_37.sroa.5.sroa.5.0._37.sroa.5.0._0.sroa_idx.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  br label %bb18.i

bb18.i:                                           ; preds = %bb46.i, %bb45.i60, %bb12.i
  %.sink = phi i32 [ 28, %bb46.i ], [ 20, %bb45.i60 ], [ 20, %bb12.i ]
  %_39.sroa.19.2165.i.sink = phi i32 [ %_39.sroa.19.2165.i, %bb46.i ], [ -2147483648, %bb45.i60 ], [ -2147483648, %bb12.i ]
  %_39.sroa.20.2166.i.sink = phi ptr [ %_39.sroa.20.2166.i, %bb46.i ], [ @alloc_3caa9f61d2ba77d78cbb25a9bd675554, %bb45.i60 ], [ @alloc_5a666425b67d3b87ed47810102d8319a, %bb12.i ]
  %_39.sroa.21.2167.i.sink = phi i32 [ %_39.sroa.21.2167.i, %bb46.i ], [ 13, %bb45.i60 ], [ 24, %bb12.i ]
  %_127.sroa.8.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 %.sink
  store i32 %_39.sroa.19.2165.i.sink, ptr %_127.sroa.8.0._0.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %_127.sroa.9.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store ptr %_39.sroa.20.2166.i.sink, ptr %_127.sroa.9.0._0.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  %_127.sroa.10.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_39.sroa.21.2167.i.sink, ptr %_127.sroa.10.0._0.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %309 = getelementptr inbounds nuw i8, ptr %_0, i32 124
  store i32 -2147483648, ptr %309, align 4, !alias.scope !4455, !noalias !4458
  call void @llvm.lifetime.end.p0(ptr nonnull %missing.i), !noalias !4460
; call core::ptr::drop_in_place<xyg_engine::graphforge::base::Collector>
  call fastcc void @"_ZN4core3ptr60drop_in_place$LT$xyg_engine..graphforge..base..Collector$GT$17h14c5511454e0be32E"(ptr noalias noundef nonnull align 8 dereferenceable(192) %_45) #137, !noalias !4455
  br label %_ZN10xyg_engine10graphforge4base9Collector6finish17h82c20417d69b28ccE.exit

bb46.i:                                           ; preds = %bb2.i.i.i.i67.i.i, %bb2.i.i.i.i67.i.thread.i, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i"
  %_39.sroa.21.2167.i = phi i32 [ %_39.sroa.21.28.copyload.i, %bb2.i.i.i.i67.i.i ], [ %.sink21.i.i.i, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ %.sink21.i.i.i, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.20.2166.i = phi ptr [ %_39.sroa.20.28.copyload.i, %bb2.i.i.i.i67.i.i ], [ %alloc_452a0e77dee55682d952e6dea9af0cb1.sink.i.i.i, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ %alloc_452a0e77dee55682d952e6dea9af0cb1.sink.i.i.i, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.19.2165.i = phi i32 [ %_39.sroa.19.28.copyload.i, %bb2.i.i.i.i67.i.i ], [ undef, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ undef, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.18.2164.i = phi i32 [ %_12.sroa.6.sroa.11.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ undef, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ undef, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.16.2163.i = phi i32 [ %_12.sroa.6.sroa.10.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ -2147483648, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ -2147483648, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.14.2162.i = phi i32 [ %_12.sroa.6.sroa.9.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ %.sink19.i.i.i, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ %.sink19.i.i.i, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.12.2161.i = phi i32 [ %_12.sroa.6.sroa.8.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ %296, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ %296, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.0.2160.i = phi i32 [ %_12.sroa.0.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ 0, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ 0, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.9.2159.i = phi i32 [ %_12.sroa.6.sroa.0.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ undef, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ undef, %bb2.i.i.i.i67.i.thread.i ]
  %_39.sroa.10.2158.i = phi i32 [ %_12.sroa.6.sroa.7.0.copyload.i.i, %bb2.i.i.i.i67.i.i ], [ %.sink19.i.i.i, %"_ZN10xyg_engine10graphforge4base9Collector17resolve_hierarchy28_$u7b$$u7b$closure$u7d$$u7d$17h856152857fbff748E.exit.i.i" ], [ %.sink19.i.i.i, %bb2.i.i.i.i67.i.thread.i ]
  store i32 %_39.sroa.0.2160.i, ptr %_0, align 8, !alias.scope !4455, !noalias !4458
  %_127.sroa.2.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_39.sroa.9.2159.i, ptr %_127.sroa.2.0._0.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %_127.sroa.3.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %_39.sroa.10.2158.i, ptr %_127.sroa.3.0._0.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  %_127.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store i32 %_39.sroa.12.2161.i, ptr %_127.sroa.4.0._0.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %_127.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i32 %_39.sroa.14.2162.i, ptr %_127.sroa.5.0._0.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  %_127.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 20
  store i32 %_39.sroa.16.2163.i, ptr %_127.sroa.6.0._0.sroa_idx.i, align 4, !alias.scope !4455, !noalias !4458
  %_127.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i32 24
  store i32 %_39.sroa.18.2164.i, ptr %_127.sroa.7.0._0.sroa_idx.i, align 8, !alias.scope !4455, !noalias !4458
  br label %bb18.i

bb47.i:                                           ; preds = %bb2.i.i.i.i67.i.i, %bb2.i.i.i.i59.i.i, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17h3b24f963b78db204E.exit44.i.i", %bb16.i48
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(144) %_0, ptr noundef nonnull align 8 dereferenceable(144) %158, i32 144, i1 false), !alias.scope !4460
  call void @llvm.lifetime.end.p0(ptr nonnull %missing.i), !noalias !4460
; call core::ptr::drop_in_place<alloc::vec::Vec<([u8; 16],[u8; 16],[u8; 16],core::option::Option<alloc::string::String>)>>
  call fastcc void @"_ZN4core3ptr182drop_in_place$LT$alloc..vec..Vec$LT$$LP$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$$u5b$u8$u3b$$u20$16$u5d$$C$core..option..Option$LT$alloc..string..String$GT$$RP$$GT$$GT$17haffcd81814c1a5f9E"(ptr noalias noundef align 4 dereferenceable(12) %155) #137, !noalias !4455
  %self.val.i = load ptr, ptr %_45, align 4, !alias.scope !4458, !noalias !4455
  %310 = getelementptr inbounds nuw i8, ptr %_45, i32 4
  %self.val12.i = load i32, ptr %310, align 4, !alias.scope !4458, !noalias !4455, !noundef !1
  %311 = icmp eq i32 %self.val12.i, 0
  br i1 %311, label %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i", label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %bb47.i
  %312 = mul i32 %self.val12.i, 20
  %_35.0.i.i.i.i.i.i.i = add i32 %312, 27
  %ctrl_offset.i.i.i.i.i.i.i = and i32 %_35.0.i.i.i.i.i.i.i, -8
  %rhs5.i.i.i.i.i.i.i = add i32 %self.val12.i, 9
  %_42.0.i.i.i.i.i.i.i = add i32 %rhs5.i.i.i.i.i.i.i, %ctrl_offset.i.i.i.i.i.i.i
  %_42.1.i.i.i.i.i.i.i = icmp uge i32 %_42.0.i.i.i.i.i.i.i, %ctrl_offset.i.i.i.i.i.i.i
  %_22.i.i.i.i.i.i76.i = icmp ult i32 %_42.0.i.i.i.i.i.i.i, 2147483641
  call void @llvm.assume(i1 %_42.1.i.i.i.i.i.i.i)
  call void @llvm.assume(i1 %_22.i.i.i.i.i.i76.i)
  %313 = icmp ne ptr %self.val.i, null
  call void @llvm.assume(i1 %313)
  %314 = icmp eq i32 %_42.0.i.i.i.i.i.i.i, 0
  br i1 %314, label %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i", label %bb1.i2.i.i.i.i.i.i

bb1.i2.i.i.i.i.i.i:                               ; preds = %bb2.i.i.i.i.i.i
  %_17.i.i.i.i.i.i50 = sub nsw i32 0, %ctrl_offset.i.i.i.i.i.i.i
  %ptr.i.i.i.i.i.i = getelementptr inbounds i8, ptr %self.val.i, i32 %_17.i.i.i.i.i.i50
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %ptr.i.i.i.i.i.i, i32 noundef %_42.0.i.i.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 8) #137, !noalias !4455
  br label %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i"

"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i": ; preds = %bb1.i2.i.i.i.i.i.i, %bb2.i.i.i.i.i.i, %bb47.i
  %315 = getelementptr inbounds nuw i8, ptr %_45, i32 172
  call void @llvm.experimental.noalias.scope.decl(metadata !4751)
  %_1.val1.i.i = load i32, ptr %315, align 4, !range !67, !alias.scope !4754, !noalias !4455, !noundef !1
  %316 = icmp eq i32 %_1.val1.i.i, 0
  br i1 %316, label %_ZN10xyg_engine10graphforge4base9Collector6finish17h82c20417d69b28ccE.exit, label %bb2.i.i.i.i.i51

bb2.i.i.i.i.i51:                                  ; preds = %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i"
  %317 = getelementptr inbounds nuw i8, ptr %_45, i32 176
  %_1.val2.i.i = load ptr, ptr %317, align 4, !alias.scope !4754, !noalias !4455, !nonnull !1, !noundef !1
  %alloc_size.i.i.i.i.i.i = mul nuw i32 %_1.val1.i.i, 17
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i.i, i32 noundef %alloc_size.i.i.i.i.i.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4755
  br label %_ZN10xyg_engine10graphforge4base9Collector6finish17h82c20417d69b28ccE.exit

bb7.sink.split.i:                                 ; preds = %bb7.i.i.i52.i, %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit.thread.i"
  call void @llvm.lifetime.end.p0(ptr nonnull %_19.i35), !noalias !4460
  br label %bb7.i

bb7.i:                                            ; preds = %bb7.sink.split.i, %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit63.i"
  %318 = add i64 %174, 1
  store i64 %318, ptr %missing.i, align 8, !noalias !4460
  switch i32 %_7.sroa.7.0.copyload.i, label %bb2.i.i.i.i.i.i.i [
    i32 -2147483648, label %bb10.i
    i32 0, label %bb10.i
  ]

bb2.i.i.i.i.i.i.i:                                ; preds = %bb7.i
  %319 = inttoptr i32 %_7.sroa.10.sroa.0.0.extract.trunc.i to ptr
  %320 = icmp ne i32 %_7.sroa.10.sroa.0.0.extract.trunc.i, 0
  call void @llvm.assume(i1 %320)
; call __rustc::__rust_dealloc
  call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %319, i32 noundef %_7.sroa.7.0.copyload.i, i32 noundef range(i32 1, -2147483647) 1) #137, !noalias !4756
  br label %bb10.i

bb9.i:                                            ; preds = %"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$3get17h05ee5c344068cbd5E.exit63.i"
  %v.i58.i = getelementptr inbounds i8, ptr %202, i32 -4
  %s3.i = load i32, ptr %v.i.i, align 4, !noalias !4455, !noundef !1
  %t4.i = load i32, ptr %v.i58.i, align 4, !noalias !4455, !noundef !1
  call void @llvm.lifetime.start.p0(ptr nonnull %_25.i), !noalias !4460
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_25.i, ptr noundef nonnull align 4 dereferenceable(16) %iter.sroa.4.0178.i, i32 16, i1 false), !noalias !4455
  %_26.i61 = load i32, ptr %159, align 4, !alias.scope !4458, !noalias !4455, !noundef !1
  %_54.i = icmp ult i32 %_26.i61, 134217728
  call void @llvm.assume(i1 %_54.i)
; call hashbrown::map::HashMap<K,V,S,A>::insert
  %321 = call fastcc i32 @"_ZN9hashbrown3map28HashMap$LT$K$C$V$C$S$C$A$GT$6insert17hb082db3341cae0f4E"(ptr noalias noundef align 4 dereferenceable(16) %_55.i, ptr noalias noundef readonly align 1 captures(address) dereferenceable(16) %_25.i, i32 noundef %_26.i61) #137
  call void @llvm.lifetime.end.p0(ptr nonnull %_25.i), !noalias !4460
  %_56.i = load i32, ptr %159, align 4, !alias.scope !4458, !noalias !4455, !noundef !1
  %_63.i = load i32, ptr %_4.i, align 4, !range !67, !alias.scope !4458, !noalias !4455, !noundef !1
  %_57.i = icmp eq i32 %_56.i, %_63.i
  br i1 %_57.i, label %bb25.i, label %bb28.i

bb25.i:                                           ; preds = %bb9.i
; call alloc::raw_vec::RawVec<T,A>::grow_one
  call void @"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17he99e6d2ead1780a6E"(ptr noalias noundef nonnull align 4 dereferenceable(8) %_4.i) #140, !noalias !4455
  br label %bb28.i

bb28.i:                                           ; preds = %bb25.i, %bb9.i
  %_64.i = load ptr, ptr %164, align 4, !alias.scope !4458, !noalias !4455, !nonnull !1, !noundef !1
  %_61.i = getelementptr inbounds nuw [16 x i8], ptr %_64.i, i32 %_56.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(16) %_61.i, ptr noundef nonnull align 1 dereferenceable(16) %id.i, i32 16, i1 false), !noalias !4455
  %322 = add i32 %_56.i, 1
  store i32 %322, ptr %159, align 4, !alias.scope !4458, !noalias !4455
  %_65.i = load i32, ptr %166, align 8, !alias.scope !4458, !noalias !4455, !noundef !1
  %_72.i = load i32, ptr %165, align 8, !range !67, !alias.scope !4458, !noalias !4455, !noundef !1
  %_66.i = icmp eq i32 %_65.i, %_72.i
  br i1 %_66.i, label %bb29.i, label %bb32.i

bb29.i:                                           ; preds = %bb28.i
; call alloc::raw_vec::RawVec<T,A>::grow_one
  call void @"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hc1445baf1fef70e1E"(ptr noalias noundef nonnull align 4 dereferenceable(8) %165) #140, !noalias !4455
  br label %bb32.i

bb32.i:                                           ; preds = %bb29.i, %bb28.i
  %_73.i62 = load ptr, ptr %167, align 4, !alias.scope !4458, !noalias !4455, !nonnull !1, !noundef !1
  %_70.i = getelementptr inbounds nuw i32, ptr %_73.i62, i32 %_65.i
  store i32 %s3.i, ptr %_70.i, align 4, !noalias !4455
  %323 = add i32 %_65.i, 1
  store i32 %323, ptr %166, align 8, !alias.scope !4458, !noalias !4455
  %_74.i63 = load i32, ptr %169, align 4, !alias.scope !4458, !noalias !4455, !noundef !1
  %_81.i = load i32, ptr %168, align 4, !range !67, !alias.scope !4458, !noalias !4455, !noundef !1
  %_75.i = icmp eq i32 %_74.i63, %_81.i
  br i1 %_75.i, label %bb33.i, label %bb36.i

bb33.i:                                           ; preds = %bb32.i
; call alloc::raw_vec::RawVec<T,A>::grow_one
  call void @"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hc1445baf1fef70e1E"(ptr noalias noundef nonnull align 4 dereferenceable(8) %168) #140, !noalias !4455
  br label %bb36.i

bb36.i:                                           ; preds = %bb33.i, %bb32.i
  %_82.i64 = load ptr, ptr %170, align 4, !alias.scope !4458, !noalias !4455, !nonnull !1, !noundef !1
  %_79.i = getelementptr inbounds nuw i32, ptr %_82.i64, i32 %_74.i63
  store i32 %t4.i, ptr %_79.i, align 4, !noalias !4455
  %324 = add i32 %_74.i63, 1
  store i32 %324, ptr %169, align 4, !alias.scope !4458, !noalias !4455
  %_83.i = load i32, ptr %172, align 8, !alias.scope !4458, !noalias !4455, !noundef !1
  %_90.i = load i32, ptr %171, align 8, !range !67, !alias.scope !4458, !noalias !4455, !noundef !1
  %_84.i = icmp eq i32 %_83.i, %_90.i
  br i1 %_84.i, label %bb37.i65, label %bb40.i

bb37.i65:                                         ; preds = %bb36.i
; call alloc::raw_vec::RawVec<T,A>::grow_one
  call void @"_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd5703ec2d748c60bE"(ptr noalias noundef nonnull align 4 dereferenceable(8) %171) #140, !noalias !4455
  br label %bb40.i

bb40.i:                                           ; preds = %bb37.i65, %bb36.i
  %_91.i = load ptr, ptr %173, align 4, !alias.scope !4458, !noalias !4455, !nonnull !1, !noundef !1
  %_88.i = getelementptr inbounds nuw %"core::option::Option<alloc::string::String>", ptr %_91.i, i32 %_83.i
  store i32 %_7.sroa.7.0.copyload.i, ptr %_88.i, align 4, !noalias !4455
  %_27.sroa.4.0._88.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_88.i, i32 4
  store i64 %_7.sroa.10.0.copyload.i, ptr %_27.sroa.4.0._88.sroa_idx.i, align 4, !noalias !4455
  %325 = add i32 %_83.i, 1
  store i32 %325, ptr %172, align 8, !alias.scope !4458, !noalias !4455
  br label %bb10.i

bb10.i:                                           ; preds = %bb40.i, %bb2.i.i.i.i.i.i.i, %bb7.i, %bb7.i
  %326 = phi i64 [ %318, %bb2.i.i.i.i.i.i.i ], [ %318, %bb7.i ], [ %318, %bb7.i ], [ %174, %bb40.i ]
  %_9.i13.i = icmp eq ptr %_23.i.i37, %_50214.i
  br i1 %_9.i13.i, label %bb6.loopexit.i, label %"_ZN103_$LT$alloc..vec..into_iter..IntoIter$LT$T$C$A$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h34261b4ed80d8452E.exit.i"

_ZN10xyg_engine10graphforge4base9Collector6finish17h82c20417d69b28ccE.exit: ; preds = %bb18.i, %"_ZN4core3ptr180drop_in_place$LT$std..collections..hash..map..HashMap$LT$xyg_engine..graphforge..UuidKey$C$usize$C$core..hash..BuildHasherDefault$LT$xyg_engine..graphforge..MixedHasher$GT$$GT$$GT$17h346a06a1abee6e22E.exit.i", %bb2.i.i.i.i.i51
  call void @llvm.lifetime.end.p0(ptr nonnull %id.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_45)
  br label %bb24

bb37.sink.split:                                  ; preds = %bb140.i, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219
  %_42.sroa.23.sroa.16.sroa.0.9218.ph = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ %_42.sroa.23.sroa.16.sroa.0.0519, %bb140.i ]
  %_42.sroa.23.sroa.0.9217.ph = phi i8 [ %_42.sroa.23.sroa.0.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ %_42.sroa.23.sroa.0.0517, %bb140.i ]
  %_42.sroa.68.9216.ph = phi i32 [ %_42.sroa.68.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ 14, %bb140.i ]
  %_42.sroa.65117.9215.ph = phi ptr [ %_42.sroa.65117.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ @alloc_5a31339c5067eb80f063480f80d2a06e, %bb140.i ]
  %_42.sroa.65.9214.ph = phi i64 [ %_42.sroa.65.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ %_42.sroa.65.0513, %bb140.i ]
  %_42.sroa.58.9213.ph = phi i32 [ %_42.sroa.58.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ -2147483648, %bb140.i ]
  %_42.sroa.50.9212.ph = phi i32 [ %_42.sroa.50.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ 62, %bb140.i ]
  %_42.sroa.42.9211.ph = phi i32 [ %_42.sroa.42.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ %86, %bb140.i ]
  %_42.sroa.34.9210.ph = phi i32 [ %_42.sroa.34.1.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ 62, %bb140.i ]
  %_42.sroa.0.8209.ph = phi i32 [ %_42.sroa.0.0.ph, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread219 ], [ 0, %bb140.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %id22.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_85.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val10.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val8.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %val6.i)
  br label %bb37

bb37:                                             ; preds = %bb37.sink.split, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit
  %_42.sroa.23.sroa.16.sroa.0.9218 = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.23.sroa.16.sroa.0.9218.ph, %bb37.sink.split ]
  %_42.sroa.23.sroa.0.9217 = phi i8 [ %_42.sroa.23.sroa.0.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.23.sroa.0.9217.ph, %bb37.sink.split ]
  %_42.sroa.68.9216 = phi i32 [ %_42.sroa.68.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.68.9216.ph, %bb37.sink.split ]
  %_42.sroa.65117.9215 = phi ptr [ %_42.sroa.65117.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.65117.9215.ph, %bb37.sink.split ]
  %_42.sroa.65.9214 = phi i64 [ %_42.sroa.65.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.65.9214.ph, %bb37.sink.split ]
  %_42.sroa.58.9213 = phi i32 [ %_42.sroa.58.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.58.9213.ph, %bb37.sink.split ]
  %_42.sroa.50.9212 = phi i32 [ %_42.sroa.50.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.50.9212.ph, %bb37.sink.split ]
  %_42.sroa.42.9211 = phi i32 [ %_42.sroa.42.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.42.9211.ph, %bb37.sink.split ]
  %_42.sroa.34.9210 = phi i32 [ %_42.sroa.34.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.34.9210.ph, %bb37.sink.split ]
  %_42.sroa.0.8209 = phi i32 [ %_42.sroa.0.0, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ], [ %_42.sroa.0.8209.ph, %bb37.sink.split ]
  %_42.sroa.23.sroa.16.0.insert.ext = zext i24 %_42.sroa.23.sroa.16.sroa.0.9218 to i32
  %_42.sroa.23.sroa.16.0.insert.shift = shl nuw i32 %_42.sroa.23.sroa.16.0.insert.ext, 8
  %_42.sroa.23.sroa.0.0.insert.ext = zext i8 %_42.sroa.23.sroa.0.9217 to i32
  %_42.sroa.23.sroa.0.0.insert.insert = or disjoint i32 %_42.sroa.23.sroa.16.0.insert.shift, %_42.sroa.23.sroa.0.0.insert.ext
  store i32 %_42.sroa.0.8209, ptr %_0, align 8
  %_105.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_42.sroa.23.sroa.0.0.insert.insert, ptr %_105.sroa.2.0._0.sroa_idx, align 4
  %_105.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %_42.sroa.34.9210, ptr %_105.sroa.3.0._0.sroa_idx, align 8
  %_105.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store i32 %_42.sroa.42.9211, ptr %_105.sroa.4.0._0.sroa_idx, align 4
  %_105.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i32 %_42.sroa.50.9212, ptr %_105.sroa.5.0._0.sroa_idx, align 8
  %_105.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 20
  store i32 %_42.sroa.58.9213, ptr %_105.sroa.6.0._0.sroa_idx, align 4
  %_105.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 24
  store i64 %_42.sroa.65.9214, ptr %_105.sroa.7.0._0.sroa_idx, align 8
  %_105.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store ptr %_42.sroa.65117.9215, ptr %_105.sroa.8.0._0.sroa_idx, align 8
  %_105.sroa.9.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_42.sroa.68.9216, ptr %_105.sroa.9.0._0.sroa_idx, align 4
  %327 = getelementptr inbounds nuw i8, ptr %_0, i32 124
  store i32 -2147483648, ptr %327, align 4
  br label %bb22

bb38:                                             ; preds = %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit
  %_42.sroa.23.sroa.16.sroa.0.9196 = phi i24 [ %_42.sroa.23.sroa.16.sroa.0.0519, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.23.sroa.16.sroa.0.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.23.sroa.0.9195 = phi i8 [ %_42.sroa.23.sroa.0.0517, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.23.sroa.0.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.68.9194 = phi i32 [ %_42.sroa.68.0516, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.68.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.65117.9193 = phi ptr [ %_42.sroa.65117.0515, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.65117.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.65.9192 = phi i64 [ %_42.sroa.65.0513, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.65.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.58.9191 = phi i32 [ %_42.sroa.58.0512, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.58.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.50.9190 = phi i32 [ %_42.sroa.50.0511, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.50.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.42.9189 = phi i32 [ %_42.sroa.42.0510, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.42.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_42.sroa.34.9188 = phi i32 [ %_42.sroa.34.0509, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit.thread ], [ %_42.sroa.34.1, %_ZN10xyg_engine10graphforge4base9Collector5table17h579ff94aedcae949E.exit ]
  %_99 = getelementptr inbounds nuw i8, ptr %iter2.sroa.0.0521, i32 40
  %_93 = icmp eq ptr %_99, %_86
  br i1 %_93, label %bb35, label %bb36

bb24:                                             ; preds = %_ZN10xyg_engine10graphforge4base9Collector6finish17h82c20417d69b28ccE.exit, %bb22
  call void @llvm.lifetime.end.p0(ptr nonnull %collector)
  ret void
}
