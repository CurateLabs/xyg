define internal fastcc void @"_ZN10xyg_engine10graphforge11interaction4wire67_$LT$impl$u20$xyg_engine..graphforge..interaction..GraphSession$GT$9candidate17he449507bf20c06e1E"(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(1512) %_0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(1512) %self, ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(32) %world) unnamed_addr #4 {
start:
  %_6 = alloca [200 x i8], align 8
  %next = alloca [1512 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %next)
; call <xyg_engine::graphforge::interaction::GraphSession as core::clone::Clone>::clone
  call fastcc void @"_ZN88_$LT$xyg_engine..graphforge..interaction..GraphSession$u20$as$u20$core..clone..Clone$GT$5clone17hf341db2cdb9f7818E"(ptr noalias noundef align 8 captures(none) dereferenceable(1512) %next, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(1512) %self) #143
  call void @llvm.lifetime.start.p0(ptr nonnull %_6)
  %0 = getelementptr inbounds nuw i8, ptr %world, i32 24
  %_17 = load ptr, ptr %0, align 8, !nonnull !1, !align !231, !noundef !1
; call <xyg_engine::graph_interaction_state::GraphInteractionState as core::clone::Clone>::clone
  call fastcc void @"_ZN97_$LT$xyg_engine..graph_interaction_state..GraphInteractionState$u20$as$u20$core..clone..Clone$GT$5clone17hd4bda24be48c9d11E"(ptr noalias noundef align 8 captures(none) dereferenceable(200) %_6, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(200) %_17) #143
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #144
; call __rustc::__rust_alloc
  %1 = tail call noundef align 8 dereferenceable_or_null(200) ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef 200, i32 noundef range(i32 1, -2147483647) 8) #144
  %2 = icmp eq ptr %1, null
  br i1 %2, label %bb2.i, label %_RNvNtCs8qIlIohfSgY_5alloc5boxed14box_new_uninit.exit, !prof !4

bb2.i:                                            ; preds = %start
; call alloc::alloc::handle_alloc_error
  tail call void @_RNvNtCs8qIlIohfSgY_5alloc5alloc18handle_alloc_error(i32 noundef 8, i32 noundef 200) #145
  unreachable

_RNvNtCs8qIlIohfSgY_5alloc5boxed14box_new_uninit.exit: ; preds = %start
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(200) %1, ptr noundef nonnull align 8 dereferenceable(200) %_6, i32 200, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  %3 = getelementptr inbounds nuw i8, ptr %next, i32 1368
; call core::ptr::drop_in_place<xyg_engine::graphforge::interaction::StateSlot>
  call fastcc void @"_ZN4core3ptr67drop_in_place$LT$xyg_engine..graphforge..interaction..StateSlot$GT$17h999a0e992c4566c6E"(ptr noalias noundef align 8 dereferenceable(16) %3) #144
  store ptr null, ptr %3, align 8
  %_4.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 1372
  store ptr %1, ptr %_4.sroa.4.0..sroa_idx, align 4
  %_10.sroa.0.0.copyload = load ptr, ptr %world, align 8
  %_10.sroa.3.0.world.sroa_idx = getelementptr inbounds nuw i8, ptr %world, i32 4
  %_10.sroa.3.sroa.0.0.copyload = load i32, ptr %_10.sroa.3.0.world.sroa_idx, align 4
  %_10.sroa.3.sroa.2.0._10.sroa.3.0.world.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %world, i32 8
  %_10.sroa.3.sroa.2.0.copyload = load ptr, ptr %_10.sroa.3.sroa.2.0._10.sroa.3.0.world.sroa_idx.sroa_idx, align 4
  %_10.sroa.3.sroa.3.0._10.sroa.3.0.world.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %world, i32 12
  %_10.sroa.3.sroa.3.0.copyload = load i32, ptr %_10.sroa.3.sroa.3.0._10.sroa.3.0.world.sroa_idx.sroa_idx, align 4
  %4 = getelementptr inbounds nuw i8, ptr %world, i32 16
  %_14 = load i64, ptr %4, align 8, !noundef !1
  %.not = icmp eq ptr %_10.sroa.0.0.copyload, null
  br i1 %.not, label %bb8, label %bb9

bb9:                                              ; preds = %_RNvNtCs8qIlIohfSgY_5alloc5boxed14box_new_uninit.exit
  %5 = icmp ne ptr %_10.sroa.3.sroa.2.0.copyload, null
  tail call void @llvm.assume(i1 %5)
  %_37.not.i.i = icmp slt i32 %_10.sroa.3.sroa.0.0.copyload, 0
  br i1 %_37.not.i.i, label %bb5.i, label %bb15.i.i, !prof !1829

bb15.i.i:                                         ; preds = %bb9
  %6 = icmp eq i32 %_10.sroa.3.sroa.0.0.copyload, 0
  br i1 %6, label %bb2.i2, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb15.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #144, !noalias !7564
; call __rustc::__rust_alloc
  %7 = tail call noundef ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %_10.sroa.3.sroa.0.0.copyload, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7564
  %8 = icmp eq ptr %7, null
  br i1 %8, label %bb5.i, label %bb1.i

bb5.i:                                            ; preds = %bb3.i.i, %bb9
  %_17.sroa.4.0.ph.i = phi i32 [ 1, %bb3.i.i ], [ 0, %bb9 ]
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef %_17.sroa.4.0.ph.i, i32 %_10.sroa.3.sroa.0.0.copyload) #145, !noalias !7570
  unreachable

bb2.i2:                                           ; preds = %bb1.i, %bb15.i.i
  %9 = phi ptr [ %7, %bb1.i ], [ inttoptr (i32 1 to ptr), %bb15.i.i ]
  %_37.not.i1.i = icmp slt i32 %_10.sroa.3.sroa.3.0.copyload, 0
  br i1 %_37.not.i1.i, label %bb10.i, label %bb15.i2.i, !prof !1829

bb15.i2.i:                                        ; preds = %bb2.i2
  %10 = icmp eq i32 %_10.sroa.3.sroa.3.0.copyload, 0
  br i1 %10, label %"_ZN4core3ptr88drop_in_place$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$17h9b4cf17365cdb9beE.exit", label %bb3.i3.i

bb3.i3.i:                                         ; preds = %bb15.i2.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsGIExRX8pES_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #144, !noalias !7571
; call __rustc::__rust_alloc
  %11 = tail call noundef ptr @_RNvCsGIExRX8pES_7___rustc12___rust_alloc(i32 noundef %_10.sroa.3.sroa.3.0.copyload, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7571
  %12 = icmp eq ptr %11, null
  br i1 %12, label %bb10.i, label %bb7.i

bb1.i:                                            ; preds = %bb3.i.i
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %7, ptr nonnull align 1 %_10.sroa.0.0.copyload, i32 %_10.sroa.3.sroa.0.0.copyload, i1 false), !noalias !7570
  br label %bb2.i2

bb10.i:                                           ; preds = %bb3.i3.i, %bb2.i2
  %_34.sroa.4.0.ph.i = phi i32 [ 1, %bb3.i3.i ], [ 0, %bb2.i2 ]
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8qIlIohfSgY_5alloc7raw_vec12handle_error(i32 noundef %_34.sroa.4.0.ph.i, i32 %_10.sroa.3.sroa.3.0.copyload) #145, !noalias !7570
  unreachable

bb7.i:                                            ; preds = %bb3.i3.i
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %11, ptr nonnull align 1 %_10.sroa.3.sroa.2.0.copyload, i32 %_10.sroa.3.sroa.3.0.copyload, i1 false), !noalias !7570
  br label %"_ZN4core3ptr88drop_in_place$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$17h9b4cf17365cdb9beE.exit"

"_ZN4core3ptr88drop_in_place$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$17h9b4cf17365cdb9beE.exit": ; preds = %bb15.i2.i, %bb7.i
  %13 = phi ptr [ %11, %bb7.i ], [ inttoptr (i32 1 to ptr), %bb15.i2.i ]
  %14 = getelementptr inbounds nuw i8, ptr %next, i32 832
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7574)
  %15 = load i32, ptr %14, align 8, !range !325, !alias.scope !7574, !noundef !1
  %16 = icmp eq i32 %15, -2147483648
  br i1 %16, label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit", label %bb2.i3

bb2.i3:                                           ; preds = %"_ZN4core3ptr88drop_in_place$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$17h9b4cf17365cdb9beE.exit"
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7577)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7580)
  %17 = icmp eq i32 %15, 0
  br i1 %17, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i", label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %bb2.i3
  %18 = getelementptr inbounds nuw i8, ptr %next, i32 836
  %_1.val2.i.i.i = load ptr, ptr %18, align 4, !alias.scope !7583, !nonnull !1, !noundef !1
; call __rustc::__rust_dealloc
  tail call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i.i.i, i32 noundef %15, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7583
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i"

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i": ; preds = %bb2.i.i.i.i.i.i, %bb2.i3
  %19 = getelementptr inbounds nuw i8, ptr %next, i32 844
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7584)
  %_1.val1.i1.i.i = load i32, ptr %19, align 4, !range !67, !alias.scope !7587, !noundef !1
  %20 = icmp eq i32 %_1.val1.i1.i.i, 0
  br i1 %20, label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit", label %bb2.i.i.i.i2.i.i

bb2.i.i.i.i2.i.i:                                 ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i"
  %21 = getelementptr inbounds nuw i8, ptr %next, i32 848
  %_1.val2.i3.i.i = load ptr, ptr %21, align 4, !alias.scope !7587, !nonnull !1, !noundef !1
; call __rustc::__rust_dealloc
  tail call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i3.i.i, i32 noundef %_1.val1.i1.i.i, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7587
  br label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit"

"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit": ; preds = %"_ZN4core3ptr88drop_in_place$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$17h9b4cf17365cdb9beE.exit", %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i", %bb2.i.i.i.i2.i.i
  store i32 %_10.sroa.3.sroa.0.0.copyload, ptr %14, align 8
  %_8.sroa.7.0..sroa_idx44 = getelementptr inbounds nuw i8, ptr %next, i32 836
  store ptr %9, ptr %_8.sroa.7.0..sroa_idx44, align 4
  %_8.sroa.9.0..sroa_idx46 = getelementptr inbounds nuw i8, ptr %next, i32 840
  store i32 %_10.sroa.3.sroa.0.0.copyload, ptr %_8.sroa.9.0..sroa_idx46, align 8
  %_8.sroa.11.0..sroa_idx48 = getelementptr inbounds nuw i8, ptr %next, i32 844
  store i32 %_10.sroa.3.sroa.3.0.copyload, ptr %_8.sroa.11.0..sroa_idx48, align 4
  %_8.sroa.13.0..sroa_idx50 = getelementptr inbounds nuw i8, ptr %next, i32 848
  store ptr %13, ptr %_8.sroa.13.0..sroa_idx50, align 8
  %_8.sroa.15.0..sroa_idx52 = getelementptr inbounds nuw i8, ptr %next, i32 852
  store i32 %_10.sroa.3.sroa.3.0.copyload, ptr %_8.sroa.15.0..sroa_idx52, align 4
  %_8.sroa.17.0..sroa_idx54 = getelementptr inbounds nuw i8, ptr %next, i32 856
  store i64 %_14, ptr %_8.sroa.17.0..sroa_idx54, align 8
  br label %bb5

bb8:                                              ; preds = %_RNvNtCs8qIlIohfSgY_5alloc5boxed14box_new_uninit.exit
  %22 = getelementptr inbounds nuw i8, ptr %next, i32 832
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7588)
  %23 = load i32, ptr %22, align 8, !range !325, !alias.scope !7588, !noundef !1
  %24 = icmp eq i32 %23, -2147483648
  br i1 %24, label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit22", label %bb2.i5

bb2.i5:                                           ; preds = %bb8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7591)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7594)
  %25 = icmp eq i32 %23, 0
  br i1 %25, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i8", label %bb2.i.i.i.i.i.i6

bb2.i.i.i.i.i.i6:                                 ; preds = %bb2.i5
  %26 = getelementptr inbounds nuw i8, ptr %next, i32 836
  %_1.val2.i.i.i7 = load ptr, ptr %26, align 4, !alias.scope !7597, !nonnull !1, !noundef !1
; call __rustc::__rust_dealloc
  tail call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i.i.i7, i32 noundef %23, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7597
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i8"

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i8": ; preds = %bb2.i.i.i.i.i.i6, %bb2.i5
  %27 = getelementptr inbounds nuw i8, ptr %next, i32 844
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7598)
  %_1.val1.i1.i.i9 = load i32, ptr %27, align 4, !range !67, !alias.scope !7601, !noundef !1
  %28 = icmp eq i32 %_1.val1.i1.i.i9, 0
  br i1 %28, label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit22", label %bb2.i.i.i.i2.i.i10

bb2.i.i.i.i2.i.i10:                               ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i8"
  %29 = getelementptr inbounds nuw i8, ptr %next, i32 848
  %_1.val2.i3.i.i11 = load ptr, ptr %29, align 4, !alias.scope !7601, !nonnull !1, !noundef !1
; call __rustc::__rust_dealloc
  tail call void @_RNvCsGIExRX8pES_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2.i3.i.i11, i32 noundef %_1.val1.i1.i.i9, i32 noundef range(i32 1, -2147483647) 1) #144, !noalias !7601
  br label %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit22"

"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit22": ; preds = %bb2.i.i.i.i2.i.i10, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17h4245f99070dcda74E.exit.i.i8", %bb8
  %_8.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 836
  store ptr inttoptr (i32 1 to ptr), ptr %_8.sroa.7.0..sroa_idx, align 4
  %_8.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 840
  store i32 0, ptr %_8.sroa.9.0..sroa_idx, align 8
  %_8.sroa.11.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 844
  store i32 0, ptr %_8.sroa.11.0..sroa_idx, align 4
  %_8.sroa.13.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 848
  store ptr inttoptr (i32 1 to ptr), ptr %_8.sroa.13.0..sroa_idx, align 8
  %_8.sroa.15.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 852
  store i32 0, ptr %_8.sroa.15.0..sroa_idx, align 4
  %_8.sroa.17.0..sroa_idx = getelementptr inbounds nuw i8, ptr %next, i32 856
  store i64 %_14, ptr %_8.sroa.17.0..sroa_idx, align 8
  store i32 -2147483648, ptr %22, align 8
  br label %bb5

bb5:                                              ; preds = %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit", %"_ZN4core3ptr116drop_in_place$LT$core..option..Option$LT$$LP$alloc..vec..Vec$LT$u8$GT$$C$alloc..vec..Vec$LT$u8$GT$$C$u64$RP$$GT$$GT$17hf17e0c801344d841E.exit22"
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(1512) %_0, ptr noundef nonnull align 8 dereferenceable(1512) %next, i32 1512, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %next)
  ret void
}
define internal fastcc noundef zeroext i1 @_ZN10xyg_engine17geo_spatial_index9candidate17h941b77470eeee83eE(i32 noundef %cell, i32 noundef %options, ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(64) %camera, ptr dead_on_return noalias noundef nonnull readonly align 8 captures(none) dereferenceable(40) %bounds) unnamed_addr #4 {
start:
  %0 = icmp ne i32 %cell, -1
  %1 = load i64, ptr %bounds, align 8, !range !1132
  %2 = trunc nuw i64 %1 to i1
  %or.cond3 = select i1 %0, i1 %2, i1 false
  br i1 %or.cond3, label %bb4, label %bb24

bb24:                                             ; preds = %bb1.i6, %bb1.i, %bb18, %bb5.i, %bb13.thread, %bb1.i32, %bb5.i43, %bb2.i36, %bb5, %start
  %_0.sroa.0.0.off0 = phi i1 [ true, %start ], [ false, %bb5 ], [ true, %bb1.i ], [ true, %bb13.thread ], [ true, %bb1.i6 ], [ false, %bb18 ], [ true, %bb5.i ], [ %24, %bb5.i43 ], [ %25, %bb2.i36 ], [ false, %bb1.i32 ]
  ret i1 %_0.sroa.0.0.off0

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds nuw i8, ptr %bounds, i32 8
  %4 = load double, ptr %3, align 8, !noundef !1
  %5 = getelementptr inbounds nuw i8, ptr %bounds, i32 24
  %6 = load double, ptr %5, align 8, !noundef !1
  %_11 = uitofp i32 %options to double
  %7 = fdiv double 0x41831BF8457C1093, %_11
  %_17 = icmp eq i32 %options, 0
  br i1 %_17, label %panic, label %bb5

bb5:                                              ; preds = %bb4
  %8 = getelementptr inbounds nuw i8, ptr %bounds, i32 32
  %y1 = load double, ptr %8, align 8, !noundef !1
  %9 = getelementptr inbounds nuw i8, ptr %bounds, i32 16
  %y0 = load double, ptr %9, align 8, !noundef !1
  %column = urem i32 %cell, %options
  %_15 = uitofp i32 %column to double
  %_14 = fmul double %7, %_15
  %left = fadd double %_14, 0xC1731BF8457C1093
  %_21 = udiv i32 %cell, %options
  %_20 = uitofp i32 %_21 to double
  %_19 = fmul double %7, %_20
  %bottom = fadd double %_19, 0xC1731BF8457C1093
  %_22 = fcmp ogt double %bottom, %y1
  %_24 = fadd double %7, %bottom
  %_23 = fcmp olt double %_24, %y0
  %or.cond = or i1 %_22, %_23
  br i1 %or.cond, label %bb24, label %bb9

panic:                                            ; preds = %bb4
; call core::panicking::panic_const::panic_const_rem_by_zero
  tail call void @_RNvNtNtCs3O6bguQwcd4_4core9panicking11panic_const23panic_const_rem_by_zero(ptr noalias noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_911cd85d732c6daa183d6e0d045b9fab) #146
  unreachable

bb9:                                              ; preds = %bb5
  %10 = getelementptr inbounds nuw i8, ptr %camera, i32 60
  %11 = load i8, ptr %10, align 4, !range !88, !noalias !33078, !noundef !1
  %_3.i = trunc nuw i8 %11 to i1
  br i1 %_3.i, label %bb5.i, label %bb1.i

bb1.i:                                            ; preds = %bb9
  %_4.i = fcmp ole double %left, %6
  %_6.i = fadd double %7, %left
  %12 = fcmp oge double %_6.i, %4
  %or.cond60 = and i1 %_4.i, %12
  br i1 %or.cond60, label %bb24, label %bb12

bb5.i:                                            ; preds = %bb9
  %_12.i = fsub double %4, %left
  %_11.i = fsub double %_12.i, %7
  %_10.i = fdiv double %_11.i, 0x41831BF8457C1093
  %13 = tail call double @llvm.ceil.f64(double %_10.i)
  %_17.i = fsub double %6, %left
  %_16.i = fdiv double %_17.i, 0x41831BF8457C1093
  %14 = tail call double @llvm.floor.f64(double %_16.i)
  %15 = fcmp ugt double %13, %14
  br i1 %15, label %bb12.thread, label %bb24

bb12:                                             ; preds = %bb1.i
  %16 = icmp eq i32 %column, 0
  br i1 %16, label %bb1.i6, label %bb18

bb12.thread:                                      ; preds = %bb5.i
  %17 = icmp eq i32 %column, 0
  br i1 %17, label %bb13.thread, label %bb18

bb13.thread:                                      ; preds = %bb12.thread
  %_3557 = fsub double 0x41731BF8457C1093, %7
  %_12.i20 = fsub double %4, %_3557
  %_11.i23 = fsub double %_12.i20, %7
  %_10.i24 = fdiv double %_11.i23, 0x41831BF8457C1093
  %18 = tail call double @llvm.ceil.f64(double %_10.i24)
  %_17.i27 = fsub double %6, %_3557
  %_16.i28 = fdiv double %_17.i27, 0x41831BF8457C1093
  %19 = tail call double @llvm.floor.f64(double %_16.i28)
  %20 = fcmp ugt double %18, %19
  br i1 %20, label %bb18, label %bb24

bb1.i6:                                           ; preds = %bb12
  %_35 = fsub double 0x41731BF8457C1093, %7
  %_4.i9 = fcmp ole double %_35, %6
  %_6.i13 = fadd double %7, %_35
  %21 = fcmp oge double %_6.i13, %4
  %or.cond61 = and i1 %21, %_4.i9
  br i1 %or.cond61, label %bb24, label %bb18

bb18:                                             ; preds = %bb1.i6, %bb13.thread, %bb12.thread, %bb12
  %_37 = add i32 %options, -1
  %_36 = icmp eq i32 %column, %_37
  br i1 %_36, label %bb19, label %bb24

bb19:                                             ; preds = %bb18
  br i1 %_3.i, label %bb5.i43, label %bb1.i32

bb1.i32:                                          ; preds = %bb19
  %_4.i35 = fcmp ult double %6, 0xC1731BF8457C1093
  br i1 %_4.i35, label %bb24, label %bb2.i36

bb5.i43:                                          ; preds = %bb19
  %_12.i46 = fadd double %4, 0x41731BF8457C1093
  %_11.i49 = fsub double %_12.i46, %7
  %_10.i50 = fdiv double %_11.i49, 0x41831BF8457C1093
  %22 = tail call double @llvm.ceil.f64(double %_10.i50)
  %_17.i53 = fadd double %6, 0x41731BF8457C1093
  %_16.i54 = fdiv double %_17.i53, 0x41831BF8457C1093
  %23 = tail call double @llvm.floor.f64(double %_16.i54)
  %24 = fcmp ole double %22, %23
  br label %bb24

bb2.i36:                                          ; preds = %bb1.i32
  %_6.i39 = fadd double %7, 0xC1731BF8457C1093
  %25 = fcmp oge double %_6.i39, %4
  br label %bb24
}