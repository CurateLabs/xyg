#!/usr/bin/env node
// Optimize and validate a separately compiled xyg-wasm browser artifact.
// Keeping this separate from js/build.mjs lets native/Python builds remain
// independent of the direct-browser target while CI verifies both paths.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { gzipSync } from "node:zlib";
import { optimizeWasm } from "./optimize-wasm.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");
const source = process.argv[2]
  ?? join(root, "target", "wasm32-unknown-unknown", "release", "xyg_wasm.wasm");
const output = join(root, "packages", "xy-client", "dist", "xyg-wasm.wasm");
const pythonWasmOutput = join(root, "python", "xyg", "static", "xyg-wasm.wasm");
const inlineOutput = join(root, "packages", "xy-client", "dist", "xyg-wasm-inline.js");
const pythonInlineOutput = join(root, "python", "xyg", "static", "xyg-wasm-inline.js");
const manifestOutput = join(root, "packages", "xy-client", "dist", "xyg-wasm.manifest.json");
const pythonManifestOutput = join(root, "python", "xyg", "static", "xyg-wasm.manifest.json");
const classicWorkerPath = join(root, "packages", "xy-client", "dist", "wasm-inline-worker.js");
// Fail early and name the producer step instead of an opaque ENOENT.
function requireInput(label, path, hint) {
  if (!existsSync(path)) {
    throw new Error(`cannot package xyg-wasm: ${label} is missing at ${path}. Run \`${hint}\` first ` +
      "(or the single producer step: `node js/build.mjs && npm run build:wasm`)");
  }
}
requireInput("raw wasm32 module", source, "cargo build -p xyg-wasm --release --target wasm32-unknown-unknown");
const manifest = JSON.parse(readFileSync(join(root, "spec", "wasm", "abi.json"), "utf8"));
const bytes = optimizeWasm(readFileSync(source));

function readU32(state) {
  let value = 0;
  let shift = 0;
  while (true) {
    if (state.offset >= state.bytes.length || shift > 28) {
      throw new Error("invalid unsigned LEB128 in xyg-wasm artifact");
    }
    const byte = state.bytes[state.offset++];
    value |= (byte & 0x7f) << shift;
    if ((byte & 0x80) === 0) return value >>> 0;
    shift += 7;
  }
}

function readName(state) {
  const length = readU32(state);
  const end = state.offset + length;
  if (end > state.bytes.length) throw new Error("truncated name in xyg-wasm artifact");
  const value = new TextDecoder().decode(state.bytes.subarray(state.offset, end));
  state.offset = end;
  return value;
}

function readVector(state, readItem) {
  return Array.from({ length: readU32(state) }, () => readItem(state));
}

function rawSignatures(input) {
  const state = { bytes: new Uint8Array(input), offset: 8 };
  const types = [];
  const functions = [];
  const exports = new Map();
  while (state.offset < state.bytes.length) {
    const id = state.bytes[state.offset++];
    const size = readU32(state);
    const end = state.offset + size;
    if (end > state.bytes.length) throw new Error("truncated section in xyg-wasm artifact");
    if (id === 8) {
      throw new Error("xyg-wasm must not contain a start function");
    }
    if (id === 1) {
      types.push(...readVector(state, (cursor) => {
        if (cursor.bytes[cursor.offset++] !== 0x60) {
          throw new Error("unsupported function type in xyg-wasm artifact");
        }
        return {
          params: readVector(cursor, (item) => item.bytes[item.offset++]),
          results: readVector(cursor, (item) => item.bytes[item.offset++]),
        };
      }));
    } else if (id === 3) {
      functions.push(...readVector(state, readU32));
    } else if (id === 7) {
      for (const item of readVector(state, (cursor) => ({
        name: readName(cursor),
        kind: cursor.bytes[cursor.offset++],
        index: readU32(cursor),
      }))) {
        exports.set(item.name, item);
      }
    }
    state.offset = end;
  }
  return { types, functions, exports };
}

function wasmType(rustType) {
  if (["i32", "u32", "usize"].includes(rustType)) return 0x7f;
  if (["i64", "u64"].includes(rustType)) return 0x7e;
  throw new Error(`unsupported Rust ABI type in manifest: ${rustType}`);
}

// Size budget (browser-wasm.md, "Artifact size"): growth past it must be a
// deliberate, recorded decision, not drift.
const WASM_SIZE_BUDGET_BYTES = 1882 * 1024;
// 1,504 KiB raw / 616 KiB gzip: the Scene v33 secondary-y decode/painter path
// (#1006) is a recorded +32 KiB raw / +8 KiB gzip over the previous 1,472 / 608 KiB
// (CI's pinned toolchain measures ~2.7 KiB gzip above a local build).
// Scene v34 straight-arrow vocabulary (#1006): +5.0 KB raw / +2.4 KB gzip; the gzip
// gate rose 616 -> 620 KiB (raw stays 1,504 KiB).
// 624 KiB gzip (raw unchanged): the static LOD tiers and their budget checks,
// layered/polar/mesh autorange admission, the XYWA exact polar wedge-arc
// encode/validate/SVG path, and the mesh overdraw bound (#1006) are a recorded
// +10,255 raw / +4,097 gzip bytes (1,538,122 / 635,040) over main's
// 1,527,867 / 630,943 after #1023/#1034/#1037, 160 bytes over the 620 KiB gate;
// 3,936 bytes of gzip and 1,974 bytes of raw headroom remain (local build).
// 1,507 KiB raw (gzip gate unchanged at 624 KiB): XYPB v17 (#1036) runs the Rust
// tick-label strategy layout in the painter writer, including per-side rotations.
// After merging main 4631927, the local build is 1,542,222 raw / 636,944 gzip
// (earlier merge-base: 1,539,454 / 635,754); raw headroom is 946 bytes.
// Composition v2 hierarchy (#36 S1): after measured sharing savings of
// 890 raw / 706 gzip bytes, the integrated module is 1,546,708 / 639,531.
// Record the functionality budget at the smallest next-KiB limits: 1,511 / 625,
// leaving 556 / 469 bytes. Compiler, optimizer and runtime validation stay fixed.
// Recovered S2 shared compound/temporal changes (#36): after two measured
// candidates, scratch-free forest validation retains 1,547,779 / 640,527 bytes.
// The smallest next-KiB functionality budget is 1,512 / 626, leaving 509 / 497
// bytes. No session WASM exports, profile changes, or validation removals.
// S3 parent decision (graph-s3-package-budget-2026-10-31): retain the measured
// #[inline] hint on CoordinationGate::validate (119 raw / 46 gzip bytes saved
// historically), then admit reachable shared coordination extraction at the
// smallest next-KiB RAW-only limit, 1,513 KiB. Gzip remains 626 KiB. Fresh final
// source must pass both gates; no session exports, profile or validation change.
// S4 explicit functionality decision (graph-s4-package-budget-2026-10-31): first
// reachability of shared session/render/pick/state/transaction machinery plus
// complete resolved paint and exact-ID transport. After correctness review and
// exactly two isolated size experiments, retain only the UUID hex writer.
// Final source measures 1,860,250 raw / 759,008 gzip6 (+311,860 / +118,299 over
// accepted S3). Smallest next-KiB limits: 1,817 / 742, headroom 358 / 800.
// Compiler/profile/optimizer/dependencies/exports/validation remain unchanged;
// future growth still fails these gates, without an automatic allowance.
// S5a explicit functionality decision (graph-s5a-package-budget-2026-11-03):
// Rust-owned GPU columns and authoritative operation/focus facts add 12,287 raw /
// 5,050 gzip6 bytes over accepted S4. Independently reviewed integrated module:
// 1,872,541 / 764,063. Smallest next-KiB limits: 1,829 / 747, headroom 355 / 865.
// No size experiment or compiler/profile/optimizer/dependency/export/guard change.
// Runtime arenas are unchanged; later growth still fails without automatic allowance.
// P1 explicit functionality decision (graph-session-p1-integration-2026-11-03):
// Complete resolvable selection/result-row snapshots and opt-in retained CoSE
// initialization add 8,940 raw / 4,055 gzip6 bytes over e91 S5a: 1,881,508 /
// 768,134. Independent assessment supports the smallest next-KiB limits:
// 1,838 / 751, headroom 604 / 890. No size experiment, compiler/profile/optimizer,
// dependency/export/guard or runtime-arena change; no automatic future allowance.
// Property-default explicit functionality decision (2026-11-03), after the
// m4_defaults_audit source approval and independent package assessment:
// retain the existing shared native home/label policy on the WASM property path.
// The reviewed 1,922,561 raw / 783,148 gzip6 module adds 41,053 / 15,014 over P1.
// Adopt the smallest whole-KiB gates, 1,878 / 765, leaving 511 / 212 bytes.
// Exact component costs are unmeasured. The old-gate failure remains historical.
// See graph-property-default-package-2026-11-03/README.md for fresh shipping proof.
// No compiler/profile/toolchain/optimizer/dependency/export/validation/runtime
// change, performance claim, or automatic allowance for future growth.
// #36 actual picked-target/provenance/typed-Leave explicit parent decision
// (2026-11-04), after completed m4_defaults_audit and s5a_final_review:
// retain R2 inline Option<PickReceipt>, shared CSR projection and borrowed refs.
// R2 measures 1,926,555 / 785,546: old 1,878/765 gates fail by 3,483/2,186.
// Exactly 1,882/768 KiB leaves 613/886 bytes; 1,881/767 still fails by 411/138.
// R2 reuse saves 1,022/380 over R1; rejected R3 Arc grows 1,768/55 over R2.
// Growth over the 207 baseline is 3,832/2,365. No further size experiments or
// automatic allowance. All guards, exports, toolchain and runtime caps stay fixed.
// See graph-picked-target-r5-2026-11-04/README.md for fresh production proof.
const WASM_GZIP_BUDGET_BYTES = 768 * 1024;
const gzipBytes = gzipSync(bytes).length;
if (gzipBytes > WASM_GZIP_BUDGET_BYTES) throw new Error(`xyg-wasm gzip is ${gzipBytes} bytes, over the ${WASM_GZIP_BUDGET_BYTES}-byte budget`);
if (bytes.length > WASM_SIZE_BUDGET_BYTES) {
  throw new Error(`xyg-wasm is ${bytes.length} bytes, over the ${WASM_SIZE_BUDGET_BYTES}-byte budget (spec/design/browser-wasm.md, "Artifact size")`);
}
const module = await WebAssembly.compile(bytes);
const imports = WebAssembly.Module.imports(module);
if (imports.length) {
  throw new Error(`xyg-wasm must not request ambient imports: ${JSON.stringify(imports)}`);
}
const actual = new Set(WebAssembly.Module.exports(module).map((item) => item.name));
const raw = rawSignatures(bytes);
for (const item of manifest.exports) {
  if (!actual.has(item.name)) throw new Error(`xyg-wasm missing manifest export ${item.name}`);
  const entry = raw.exports.get(item.name);
  if (!entry || entry.kind !== 0) {
    throw new Error(`xyg-wasm manifest export ${item.name} is not a function`);
  }
  const signature = raw.types[raw.functions[entry.index]];
  const expected = {
    params: item.params.map(wasmType),
    results: [wasmType(item.result)],
  };
  if (!signature
      || signature.params.join(",") !== expected.params.join(",")
      || signature.results.join(",") !== expected.results.join(",")) {
    throw new Error(`xyg-wasm artifact signature differs for ${item.name}`);
  }
}
if (!actual.has("memory")) throw new Error("xyg-wasm missing exported linear memory");
const instance = await WebAssembly.instantiate(module, {});
for (const [name, expected] of [
  ["xyg_wasm_abi_version", manifest.abi_version],
  ["xyg_wasm_scene_version", manifest.scene_version],
]) {
  const observed = instance.exports[name]() >>> 0;
  if (observed !== expected) {
    throw new Error(`xyg-wasm artifact version differs for ${name}: ${observed}, expected ${expected}`);
  }
}
// Every input is validated before the first byte is published, so a failure leaves
// no half-written asset set behind.
requireInput("classic inline worker", classicWorkerPath, "node js/build.mjs");
const classicWorker = readFileSync(classicWorkerPath, "utf8");
if (/\b(?:fetch\s*\(|importScripts\s*\(|import\.meta|type:\s*["']module)/.test(classicWorker)) {
  throw new Error("inline classic worker must not use fetch, module URLs, or importScripts");
}
mkdirSync(dirname(output), { recursive: true });
// Publish the exact optimized bytes compiled and signature-checked above; rereading the
// source path here would create a validate-then-copy race.
writeFileSync(output, bytes);
mkdirSync(dirname(pythonWasmOutput), { recursive: true });
writeFileSync(pythonWasmOutput, bytes);
// Classic standalone exports cannot fetch a sibling file from file: URLs or
// start a module Worker. Emit one deterministic, CSP-safe script payload that
// a future Blob Worker may import with `importScripts`-free classic code.
const base64 = bytes.toString("base64");
const digest = (await import("node:crypto")).createHash("sha256").update(bytes).digest("hex");
const inline = `/* generated by js/package-wasm.mjs; do not edit */\n` +
  `globalThis.__xygInlineWasm={sha256:${JSON.stringify(digest)},base64:${JSON.stringify(base64)},` +
  `classicWorkerSource:${JSON.stringify(classicWorker)}};\n`;
writeFileSync(inlineOutput, inline);
writeFileSync(pythonInlineOutput, inline);
// Version/hash metadata that every consumer verifies (scripts/verify_wasm_assets.py)
// before it trusts the packaged bytes; derived only from the validated artifact and
// the checked-in ABI manifest so repeated packaging is byte-identical (§33).
const metadata = `${JSON.stringify({
  schema_version: 1,
  artifact: "xyg-wasm.wasm",
  sha256: digest,
  bytes: bytes.length,
  abi_version: manifest.abi_version,
  scene_version: manifest.scene_version,
  painter_version: manifest.painter_version,
}, null, 2)}\n`;
writeFileSync(manifestOutput, metadata);
writeFileSync(pythonManifestOutput, metadata);
console.log(`packaged optimized xyg-wasm artifact at ${output}`);
console.log(`copied optimized xyg-wasm artifact to ${pythonWasmOutput}`);
console.log(`packaged deterministic inline WASM artifact at ${inlineOutput}`);
console.log(`wrote WASM version/hash manifest at ${manifestOutput}`);
