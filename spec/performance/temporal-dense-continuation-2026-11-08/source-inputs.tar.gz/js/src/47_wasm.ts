import {
  XYG_WASM_ABI_VERSION,
  XYG_WASM_MAX_ARENA_BYTES,
  XYG_WASM_SCENE_VERSION,
  XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS,
  XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS,
  XYG_WASM_AGGREGATE_STREAM_MAGIC,
  XYG_WASM_AGGREGATE_STREAM_VERSION,
  XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES,
  XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS,
  XYG_WASM_AGGREGATE_STREAM_CHUNK_POINTS,
} from "./wasm_abi_generated";
import type { XygWasmTypedSeriesRequest } from "./49_wasm_chart";
import type { XygWasmGraphCheckpoint } from "./49_wasm_graph";
import type { XygGeoScaleBridge } from "./63_geo_source";

export type XygWasmSource = string | URL | ArrayBuffer | Uint8Array | WebAssembly.Module;

export interface XygWasmWorkerOptions {
  /** Required static module-worker asset. XYG never guesses a path or creates a Blob URL. */
  workerUrl: string | URL;
  /** Explicit local URL, compiled Module, or bytes for the xyg-wasm artifact. */
  wasm: XygWasmSource;
  /** Logical staging bound. The Rust adapter also enforces its compile-time ceiling. */
  maxArenaBytes?: number;
  /** @internal Capability-gated browser lifecycle evidence; never runtime policy. */
  evidenceCapability?: string;
}

/** Checked bytes plus a generated classic Worker IIFE for a file: export. */
export interface XygInlineWasmWorkerOptions {
  inline: { base64: string; classicWorkerSource: string };
  maxArenaBytes?: number;
  /** @internal Evidence-only capability; never selected by normal runtime policy. */
  evidenceCapability?: string;
}

export interface XygWasmDiagnostics {
  abiVersion: number;
  sceneVersion: number;
  defaultPaletteVersion: number;
  defaultPaletteRows: number;
  defaultPaletteFirstRgba8: number;
  arenaBytes: number;
  arenaHighWaterBytes: number;
  memoryBytes: number;
  /** Current linear memory is also its high-water because WebAssembly memory cannot shrink. */
  memoryHighWaterBytes: number;
  copyCount: number;
  copyBytesLo: number;
  copyBytesHi: number;
  records: number;
  styles: number;
}

const DIAGNOSTIC_FIELDS = [
  "abiVersion", "sceneVersion", "defaultPaletteVersion", "defaultPaletteRows",
  "defaultPaletteFirstRgba8", "arenaBytes", "arenaHighWaterBytes", "memoryBytes",
  "memoryHighWaterBytes", "copyCount", "copyBytesLo", "copyBytesHi", "records", "styles",
] as const satisfies readonly (keyof XygWasmDiagnostics)[];

function diagnosticsSnapshot(value: unknown): XygWasmDiagnostics | null {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value as Record<string, unknown>;
  if (!DIAGNOSTIC_FIELDS.every((field) => Number.isFinite(candidate[field]))) return null;
  return Object.freeze(Object.fromEntries(
    DIAGNOSTIC_FIELDS.map((field) => [field, candidate[field]]),
  ) as unknown as XygWasmDiagnostics);
}

export interface XygWasmSceneValidation extends XygWasmDiagnostics {
  sequence: number;
}

export interface XygWasmScenePaint extends XygWasmSceneValidation {
  /** Rust-authored, checked-f32 painter columns and trace descriptors. */
  painter: ArrayBuffer;
  /** Frozen backing resolution, independent of the current browser display. */
  pixelRatio?: number;
}

export interface XygWasmDashboardPlan {
  retained: readonly boolean[];
  retainedBytes: bigint;
}

export interface XygWasmCompiledScene extends XygWasmSceneValidation {
  /** Canonical Scene batch bytes produced by Rust from typed columns. */
  scene: ArrayBuffer;
}

export interface XygWasmTask<T> {
  requestId: number;
  sequence: number;
  result: Promise<T>;
  cancel(): void;
}
export interface XygWasmCompileProgress { sequence: number; recordsProcessed: number; phase: number }
type SceneTaskOptions = { sequence?: number; transfer?: boolean; onProgress?: (progress: XygWasmCompileProgress) => void };

export interface XygWasmAggregateTaskOptions {
  sequence?: number;
  /** Aggregate ownership transfer is mandatory so browser-wide peak memory stays bounded. */
  transfer?: true;
}

export interface XygWasmAggregateStreamRequest {
  x0: number; x1: number; y0: number; y1: number; width: number; height: number;
}

/** Capability-gated observations from the production module Worker. */
export interface XygWasmStreamObservation {
  phase: "begin" | "push" | "cancelled" | "finish";
  requestId: number;
  sequence: number;
  pushes: number;
}

type AggregateTransferContract = Exclude<XygWasmAggregateTaskOptions["transfer"], undefined>;
type AssertTrue<T extends true> = T;
type AggregateTransferMustRemainTrue = AssertTrue<AggregateTransferContract>;

export class XygWasmError extends Error {
  readonly code: string;
  readonly status: number | null;
  /** Rust-owned counters captured at the failure boundary, when initialization completed. */
  readonly diagnostics: XygWasmDiagnostics | null;

  constructor(
    code: string,
    message: string,
    status: number | null = null,
    diagnostics: XygWasmDiagnostics | null = null,
  ) {
    super(message);
    this.name = "XygWasmError";
    this.code = code;
    this.status = status;
    this.diagnostics = diagnosticsSnapshot(diagnostics);
  }
}

type Pending = {
  temporal?:boolean;
  temporalFailure?:XygWasmError;
  resolve(value: any): void;
  reject(reason: XygWasmError): void;
  progress?(value: any): void;
  sequence?: number;
};

function workerError(value: any): XygWasmError {
  return new XygWasmError(
    typeof value?.code === "string" ? value.code : "XYG_WASM_WORKER_ERROR",
    typeof value?.message === "string" ? value.message : "XYG WASM worker failed",
    Number.isInteger(value?.status) ? value.status : null,
    value?.diagnostics,
  );
}

function sourceMessage(source: XygWasmSource): {
  source: any;
  transfer: Transferable[];
} {
  if (typeof source === "string" || source instanceof URL) {
    return { source: { kind: "url", value: String(source) }, transfer: [] };
  }
  if (source instanceof WebAssembly.Module) {
    return { source: { kind: "module", value: source }, transfer: [] };
  }
  if (source instanceof Uint8Array) {
    if (!(source.buffer instanceof ArrayBuffer)) {
      throw new TypeError("SharedArrayBuffer WASM sources are not supported by this foundation");
    }
    const bytes = source.byteOffset === 0 && source.byteLength === source.buffer.byteLength
      ? source.buffer
      : source.slice().buffer;
    return { source: { kind: "bytes", value: bytes }, transfer: [bytes] };
  }
  if (source instanceof ArrayBuffer) {
    return { source: { kind: "bytes", value: source }, transfer: [source] };
  }
  throw new TypeError("wasm must be an explicit URL, Module, ArrayBuffer, or Uint8Array");
}

function sceneMessage(scene: ArrayBuffer | Uint8Array, transfer: boolean) {
  if (scene instanceof Uint8Array) {
    if (!(scene.buffer instanceof ArrayBuffer)) {
      throw new TypeError("SharedArrayBuffer scene inputs are not supported by this foundation");
    }
    // A sub-view cannot be transferred without also exposing unrelated bytes.
    // Copy only that bounded view; an exact full-buffer view can transfer.
    if (scene.byteOffset !== 0 || scene.byteLength !== scene.buffer.byteLength) {
      const exact = scene.slice().buffer;
      return { buffer: exact, transfer: transfer ? [exact] : [] };
    }
    return { buffer: scene.buffer, transfer: transfer ? [scene.buffer] : [] };
  }
  if (!(scene instanceof ArrayBuffer)) {
    throw new TypeError("scene must be an ArrayBuffer or Uint8Array");
  }
  return { buffer: scene, transfer: transfer ? [scene] : [] };
}

/**
 * Thin lifecycle proxy for the direct-browser Rust worker foundation.
 *
 * Callers provide explicit static assets. Scene validate/prepare and typed
 * column compile/paint run in the Worker; unsupported work fails closed with
 * no JavaScript algorithm fallback.
 */
interface GeographicWorkerOrigin {
  worker: Worker;
  post(message: unknown, transfer?: Transferable[]): void;
  terminate(): void;
  ready: Promise<XygWasmDiagnostics> | null;
  maxArenaBytes: number;
  bridge: XygGeoScaleBridge;
  snapshotBridge: XygGeoScaleBridge;
  terminal: boolean;
  mutations:Map<number,{bridge:XygGeoScaleBridge;request:Uint8Array;token:object}>;
  captures:Set<GeoWorkerMutationCapture>;
}
// Issuers and dispatch are private. Numeric handles and public lookalike
// closures cannot identify the WASM registry which owns a retained frame.
const geographicWorkerOrigins = new WeakMap<XygWasmWorker, GeographicWorkerOrigin>();
type GeoWorkerCapturePurpose='mutation'|'known-member-data-retirement';
interface GeoWorkerMutationCapture {purpose:GeoWorkerCapturePurpose;bridge:XygGeoScaleBridge;request:ArrayBuffer;latest?:object;value?:object;reply?:Uint8Array;code?:string;status?:number|null;}
const geographicBridgeOrigins=new WeakMap<XygGeoScaleBridge,GeographicWorkerOrigin>();
const emptyMutationRequest=new ArrayBuffer(0);
/** @internal Only the latest genuine delivery in a currently active call grants authority. */
function geoWorkerOutcome(bridge:XygGeoScaleBridge,request:ArrayBuffer,value:unknown,purpose:GeoWorkerCapturePurpose){
 if(!(request instanceof ArrayBuffer)||request.byteLength<256||request.byteLength>304||typeof value!=='object'||value===null)return undefined;
 const origin=geographicBridgeOrigins.get(bridge);if(!origin)return undefined;const bytes=new Uint8Array(request);
 for(const context of origin.captures){
  if(context.purpose!==purpose||context.bridge!==bridge||context.value!==value||context.request.byteLength!==bytes.length||new Uint8Array(context.request).some((b,i)=>b!==bytes[i]))continue;
  if(context.reply){if(!(value instanceof ArrayBuffer)||value.byteLength!==256||new Uint8Array(value).some((b,i)=>b!==context.reply![i]))return undefined;return Object.freeze({reply:value,code:undefined,status:undefined});}
  return Object.freeze({reply:undefined,code:context.code,status:context.status});
 }
 return undefined;
}
/** @internal Ordinary mutation scopes never authenticate GeoScale operation6. */
export function getGeoWorkerMutationOutcome(bridge:XygGeoScaleBridge,request:ArrayBuffer,value:unknown){return geoWorkerOutcome(bridge,request,value,'mutation');}
function minimalMemberDataProbe(request:ArrayBuffer){if(!(request instanceof ArrayBuffer)||request.byteLength!==256)return false;const v=new DataView(request);return v.getUint32(0,true)===0x51475958&&v.getUint32(4,true)===1&&v.getUint32(8,true)===6&&v.getUint32(12,true)===0&&v.getBigUint64(16,true)!==0n&&v.getBigUint64(24,true)!==0n&&!new Uint8Array(request,32).some(b=>b!==0);}
function beginGeoWorkerCapture(bridge:XygGeoScaleBridge,canonical:ArrayBuffer,purpose:GeoWorkerCapturePurpose){
 const origin=geographicBridgeOrigins.get(bridge);
 if(!origin||origin.terminal||!(canonical instanceof ArrayBuffer)||canonical.byteLength<256||canonical.byteLength>304)throw new TypeError('Genuine bounded Worker mutation capture required');
 if(origin.captures.size>=16)throw new RangeError('Worker mutation capture capacity exceeded');
 const context:GeoWorkerMutationCapture={purpose,bridge,request:canonical};origin.captures.add(context);let closed=false;
 return Object.freeze({outcome(value:unknown){if(closed)return undefined;return context.value===value?geoWorkerOutcome(bridge,canonical,value,purpose):undefined;},close(){if(!closed){closed=true;origin.captures.delete(context);context.request=emptyMutationRequest;context.latest=context.value=context.reply=context.code=context.status=undefined;}}});
}
/** @internal One bounded call scope; clones/replays update every matching scope. */
export function beginGeoWorkerMutationCapture(bridge:XygGeoScaleBridge,canonical:ArrayBuffer){return beginGeoWorkerCapture(bridge,canonical,'mutation');}
/** @internal Only a known private MemberData receipt after unresolved attempted10 calls this probe. */
export async function withGeoWorkerMemberDataOutcome<T>(bridge:XygGeoScaleBridge,canonical:ArrayBuffer,run:(outcome:(value:unknown)=>ReturnType<typeof getGeoWorkerMutationOutcome>)=>Promise<T>,issuerExecute?:XygGeoScaleBridge['execute']):Promise<T>{
 if(geographicBridgeOrigins.get(bridge)?.bridge!==bridge||issuerExecute!==undefined&&issuerExecute!==bridge.execute||!minimalMemberDataProbe(canonical))throw new TypeError('Exact minimal known MemberData probe required');
 const capture=beginGeoWorkerCapture(bridge,canonical,'known-member-data-retirement');try{return await run(capture.outcome);}finally{capture.close();}
}
/** @internal Scope survives until the complete caller callback settles. */
export async function withGeoWorkerMutationOutcome<T>(bridge:XygGeoScaleBridge,canonical:ArrayBuffer,run:(outcome:(value:unknown)=>ReturnType<typeof getGeoWorkerMutationOutcome>)=>Promise<T>):Promise<T>{
 const capture=beginGeoWorkerMutationCapture(bridge,canonical);try{return await run(capture.outcome);}finally{capture.close();}
}
function geographicOrigin(owner: XygWasmWorker): GeographicWorkerOrigin {
  const origin = geographicWorkerOrigins.get(owner);
  if (!origin || origin.worker !== owner["worker"]) {
    throw new TypeError("Retained geographic Worker origin changed");
  }
  return origin;
}

export class XygWasmWorker {
  private worker: Worker;
  private pending = new Map<number, Pending>();
  private temporalPending:number|null=null;
  private nextRequestId = 1;
  private nextSequence = 1;
  private ownedGeoChain: Promise<void> = Promise.resolve();
  private geoTransportAdmission: Promise<void>|null=null;
  private geoTransportAdmitted=false;
  private ownedGeoBytes=0;
  private ownedGeoJobs=0;
  private ownedGeoCleanupJobs=0;
  private nextTickSequence = 1;
  private disposed = false;
  private disposal:Promise<void>|null=null;
  private readonly maxArenaBytes: number;
  private readonly inline: boolean;
  private readonly inlineBlobUrl: string | null;
  private readonly evidenceCapability: string | null;
  // This is deliberately populated only by an explicitly capability-gated
  // Worker.  It is evidence telemetry, never scheduling or render policy.
  private readonly streamObservations: XygWasmStreamObservation[] = [];
  readonly ready: Promise<XygWasmDiagnostics>;

  constructor(options: XygWasmWorkerOptions | XygInlineWasmWorkerOptions) {
    if (!options) throw new TypeError("worker options are required");
    const inline = "inline" in options;
    if (!inline && !options.workerUrl) {
      throw new TypeError("workerUrl is required; XYG does not guess worker asset paths");
    }
    if (inline && (typeof options.inline?.base64 !== "string" || !options.inline.base64
        || typeof options.inline.classicWorkerSource !== "string" || !options.inline.classicWorkerSource)) {
      throw new TypeError("inline worker requires generated base64 bytes and classic worker source");
    }
    // Validate and normalize the source before allocating a Worker so a bad
    // source cannot leak an otherwise unreachable worker process.
    const loaded = inline ? null : sourceMessage((options as XygWasmWorkerOptions).wasm);
    const maxArenaBytes = options.maxArenaBytes ?? 16 * 1024 * 1024;
    if (!Number.isInteger(maxArenaBytes) || maxArenaBytes <= 0 || maxArenaBytes > XYG_WASM_MAX_ARENA_BYTES) {
      throw new RangeError(`maxArenaBytes must be an integer in 1..${XYG_WASM_MAX_ARENA_BYTES}`);
    }
    this.maxArenaBytes = maxArenaBytes;
    this.inline = inline;
    this.evidenceCapability = typeof options.evidenceCapability === "string"
      ? options.evidenceCapability : null;
    const blobUrl = inline ? URL.createObjectURL(new Blob([(options as XygInlineWasmWorkerOptions).inline.classicWorkerSource], { type: "application/javascript" })) : null;
    this.inlineBlobUrl = blobUrl;
    this.worker = inline
      ? new Worker(blobUrl!, { name: "xyg-wasm-inline" })
      : new Worker(String((options as XygWasmWorkerOptions).workerUrl), { type: "module", name: "xyg-wasm" });
    const actualWorker = this.worker;
    const terminate = actualWorker.terminate.bind(actualWorker);
    const bridge = Object.freeze({
      execute: (request: ArrayBuffer) => geographicDispatch.transport.call(this, "geo.scale.execute", request),
      read: (request: ArrayBuffer) => geographicDispatch.transport.call(this, "geo.scale.read", request),
    });
    geographicWorkerOrigins.set(this, {
      worker: actualWorker, post: actualWorker.postMessage.bind(actualWorker), terminate,
      ready: null, maxArenaBytes, bridge, terminal: false, mutations:new Map(), captures:new Set(),
      snapshotBridge: Object.freeze({
        execute: (request: ArrayBuffer) => geographicDispatch.transport.call(this, "geo.snapshot.execute", request),
        read: (request: ArrayBuffer) => geographicDispatch.transport.call(this, "geo.snapshot.read", request),
      }),
    });
    const origin=geographicWorkerOrigins.get(this)!;geographicBridgeOrigins.set(origin.bridge,origin);geographicBridgeOrigins.set(origin.snapshotBridge,origin);
    // Installed before any public onmessage wrapper. Only genuine browser
    // Worker delivery can brand an outcome; later packet edits fail equality.
    actualWorker.addEventListener('message',(event:MessageEvent)=>{
      if(!event.isTrusted)return;
      const message=event.data,mutations=geographicWorkerOrigins.get(this)!.mutations,mutation=mutations.get(message?.requestId);
      if(!mutation||message.progress)return;
      mutations.delete(message.requestId);
      let snapshot:Uint8Array|undefined;
      for(const context of geographicWorkerOrigins.get(this)!.captures){
       if(context.bridge!==mutation.bridge||context.latest!==mutation.token)continue;
       if(message.ok&&message.value instanceof ArrayBuffer&&message.value.byteLength===256){snapshot??=new Uint8Array(message.value.slice(0));context.value=message.value;context.reply=snapshot;}
       else if(!message.ok&&message&&typeof message==='object'){context.value=message;context.code=typeof message.error?.code==='string'?message.error.code:'XYG_WASM_WORKER_ERROR';context.status=Number.isInteger(message.error?.status)?message.error.status:null;}
      }
    });
    this.worker.onmessage = (event) => geographicDispatch.onMessage.call(this, event.data);
    this.worker.onerror = (event) => {
      geographicDispatch.failAll.call(this,new XygWasmError("XYG_WASM_WORKER_TRAP", event.message || "worker trapped"));
      terminate();
      geographicWorkerOrigins.get(this)!.terminal = true;
      this.disposed = true;
    };
    this.worker.onmessageerror = () => {
      geographicDispatch.failAll.call(this,new XygWasmError(
        "XYG_WASM_MESSAGE_ERROR",
        "worker returned an unreadable message",
      ));
      terminate();
      geographicWorkerOrigins.get(this)!.terminal = true;
      this.disposed = true;
    };
    const requestId = geographicDispatch.allocateRequest.call(this);
    this.ready = geographicDispatch.promiseFor.call(this, requestId) as Promise<XygWasmDiagnostics>;
    geographicWorkerOrigins.get(this)!.ready = this.ready;
    try {
      geographicOrigin(this).post(
        {
          type: "init",
          requestId,
          ...(inline ? { base64: (options as XygInlineWasmWorkerOptions).inline.base64 } : { source: loaded!.source }),
          ...(this.evidenceCapability ? { evidenceCapability: this.evidenceCapability } : {}),
          maxArenaBytes,
          expectedAbiVersion: XYG_WASM_ABI_VERSION,
          expectedSceneVersion: XYG_WASM_SCENE_VERSION,
        },
        loaded?.transfer ?? [],
      );
    } catch (cause) {
      this.pending.delete(requestId);
      this.worker.terminate();
      this.disposed = true;
      throw new XygWasmError(
        "XYG_WASM_INIT_FAILED",
        cause instanceof Error ? cause.message : "could not initialize the WASM worker",
      );
    }
  }

  validateScene(
    scene: ArrayBuffer | Uint8Array,
    options: { sequence?: number; transfer?: boolean } = {},
  ): XygWasmTask<XygWasmSceneValidation> {
    return this.sceneTask("scene.validate", scene, options);
  }

  prepareScene(
    scene: ArrayBuffer | Uint8Array,
    options: { sequence?: number; transfer?: boolean } = {},
  ): XygWasmTask<XygWasmScenePaint> {
    return this.sceneTask("scene.paint", scene, options);
  }

  /** Admit the fixed geographic transport credit before copying/framing retained
   * product inputs. This Worker then uses the bounded retained execution mode. */
  acquireGeoTransport():Promise<void>{
    if (graphWorkerAttachments.has(this)) throw new XygWasmError("GF_INTERACTION_INVALID", "Close the attached graph session before acquiring geographic transport", -3);
    return this.geoTransportAdmission??=(async()=>{
      await geographicOrigin(this).ready;geographicDispatch.assertLive.call(this,true);const requestId=geographicDispatch.allocateRequest.call(this),result=geographicDispatch.promiseFor.call(this,requestId) as Promise<unknown>;
      try{geographicOrigin(this).post({type:'geo.transport.acquire',requestId});}
      catch(cause){this.pending.delete(requestId);throw cause;}
      await result;this.geoTransportAdmitted=true;
    })();
  }
  /** Paint only an immutable Rust-authorized retained frame, without a Scene
   * round trip or accepting arbitrary unaccounted Scene decoder allocations. */
  prepareGeoFrame(frameHandle:bigint,publicationSequence:bigint,tile=false):Pick<XygWasmTask<XygWasmScenePaint>,'result'|'cancel'>{
    if([frameHandle,publicationSequence].some(value=>typeof value!=='bigint'||value<0n||value>0xffffffffffffffffn))throw new TypeError('Retained frame identity requires u64 bigint');
    let cancelled=false;
    const result=geographicDispatch.queue.call(this,async()=>{
      await geographicDispatch.acquire.call(this);
      if(cancelled)throw new XygWasmError('XYG_WASM_CANCELLED','geographic preparation cancelled',6);
      geographicDispatch.assertLive.call(this,true);const sequence=this.nextSequence++,requestId=geographicDispatch.allocateRequest.call(this),result=geographicDispatch.promiseFor.call(this,requestId) as Promise<XygWasmScenePaint>;
      if(sequence>0xffffffff){this.pending.delete(requestId);throw new RangeError('Worker sequence exhausted');}
      try{geographicOrigin(this).post({type:tile?'geo.tile.frame.prepare':'geo.frame.prepare',requestId,sequence,frameHandle,publicationSequence});}
      catch(cause){this.pending.delete(requestId);throw cause;}
      const paint=await result;
      if(cancelled)throw new XygWasmError('XYG_WASM_CANCELLED','geographic preparation cancelled',6);
      return paint;
    },32);
    return {result,cancel:()=>{cancelled=true;}};
  }
  /** Charge synchronous framing temporaries to the same shared host credit.
   * Release after dropping those inputs and before handing off the framed request. */
  reserveGeoInput(bytes:number):()=>void{
    if(!this.geoTransportAdmitted)throw new XygWasmError("XYG_WASM_NOT_READY","Geographic transport must be admitted before framing");
    geographicDispatch.capacity.call(this,bytes);this.ownedGeoBytes+=bytes;
    let released=false;return ()=>{if(!released){released=true;this.ownedGeoBytes-=bytes;}};
  }
  private checkOwnedGeoCapacity(retainedBytes:number,cleanup=false){
    geographicDispatch.assertLive.call(this,true);const limit=Math.min(geographicOrigin(this).maxArenaBytes,32*1024*1024),reserve=Math.min(32768,Math.floor(limit/4));
    if(!Number.isSafeInteger(retainedBytes)||retainedBytes<0||this.ownedGeoBytes+retainedBytes>limit-(cleanup?0:reserve)||(cleanup?this.ownedGeoCleanupJobs>=64:this.ownedGeoJobs>=16))throw new XygWasmError('XYG_WASM_BUDGET_EXCEEDED','geographic ownership queue exceeds its bounded admission');
  }
  private queueOwnedGeo<T>(operation:()=>Promise<T>,retainedBytes:number,cleanup=false):Promise<T>{
    geographicDispatch.assertLive.call(this,true);
    geographicDispatch.capacity.call(this,retainedBytes,cleanup);
    this.ownedGeoBytes+=retainedBytes;if(cleanup)this.ownedGeoCleanupJobs++;else this.ownedGeoJobs++;
    const result=this.ownedGeoChain.then(operation).finally(()=>{this.ownedGeoBytes-=retainedBytes;if(cleanup)this.ownedGeoCleanupJobs--;else this.ownedGeoJobs--;});
    this.ownedGeoChain=result.then(()=>{},()=>{});return result;
  }

  /** Lower one complete canonical Scene with bounded Rust-projected XYAT/XYAL labels. */
  prepareSceneAnnotations(
    scene: ArrayBuffer | Uint8Array,
    annotations: ArrayBuffer | Uint8Array,
    options: SceneTaskOptions = {},
  ): XygWasmTask<XygWasmScenePaint> {
    this.assertLive();
    const sceneBytes = new Uint8Array(scene instanceof Uint8Array ? scene.buffer.slice(scene.byteOffset, scene.byteOffset + scene.byteLength) : scene);
    const annotationBytes = new Uint8Array(annotations instanceof Uint8Array ? annotations.buffer.slice(annotations.byteOffset, annotations.byteOffset + annotations.byteLength) : annotations);
    const length = 16 + sceneBytes.byteLength + annotationBytes.byteLength;
    if (!Number.isSafeInteger(length) || length > this.maxArenaBytes) {
      throw new RangeError("scene annotation envelope exceeds the worker arena byte budget");
    }
    const envelope = new Uint8Array(length);
    envelope.set([0x58, 0x59, 0x53, 0x41]); // XYSA
    new DataView(envelope.buffer).setUint32(4, 1, true);
    new DataView(envelope.buffer).setUint32(8, sceneBytes.byteLength, true);
    new DataView(envelope.buffer).setUint32(12, annotationBytes.byteLength, true);
    envelope.set(sceneBytes, 16);
    envelope.set(annotationBytes, 16 + sceneBytes.byteLength);
    return this.sceneTask("scene.paint_annotations", envelope, options);
  }

  /** Compile a packed `XYCC` typed-column request into canonical Scene bytes. */
  compileScene(
    request: ArrayBuffer | Uint8Array,
    options: SceneTaskOptions = {},
  ): XygWasmTask<XygWasmCompiledScene> {
    return this.sceneTask("scene.compile", request, options);
  }

  /** Compile packed typed columns and lower the Scene for browser paint. */
  compilePrepareScene(
    request: ArrayBuffer | Uint8Array,
    options: SceneTaskOptions = {},
  ): XygWasmTask<XygWasmScenePaint> {
    return this.sceneTask("scene.compile_paint", request, options);
  }

  /** Transfer typed columns without main-thread record expansion. */
  compilePrepareSeries(
    request: XygWasmTypedSeriesRequest,
    options: SceneTaskOptions = {},
  ): XygWasmTask<XygWasmScenePaint> {
    this.assertLive();
    if (!(request?.prefix instanceof ArrayBuffer) || !Array.isArray(request.columns)) {
      throw new TypeError("typed-series request is malformed");
    }
    if (!Number.isInteger(request.framedSeries) || request.framedSeries <= 0
        || request.mainThreadRecordVisits !== 0) {
      throw new TypeError("typed-series framing diagnostics are malformed");
    }
    const buffers = [request.prefix, ...request.columns];
    if (request.columns.some((column) => !(column instanceof ArrayBuffer))
        || new Set(buffers).size !== buffers.length) {
      throw new TypeError("typed-series request requires distinct ArrayBuffers");
    }
    const actualBytes = buffers.reduce((total, buffer) => total + buffer.byteLength, 0);
    if (!Number.isSafeInteger(actualBytes) || actualBytes !== request.byteLength) {
      throw new TypeError("typed-series buffers do not match byteLength");
    }
    if (!Number.isSafeInteger(request.byteLength) || request.byteLength <= 0
        || request.byteLength > this.maxArenaBytes) {
      throw new RangeError("typed-series request exceeds the worker arena byte budget");
    }
    if (!Number.isSafeInteger(request.peakBytes) || request.peakBytes < request.byteLength
        || request.peakBytes > this.maxArenaBytes) {
      throw new RangeError("typed-series request exceeds the worker peak byte budget");
    }
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) {
      throw new RangeError("sequence must be a nonzero u32");
    }
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest();
    if (options.onProgress !== undefined && typeof options.onProgress !== "function") throw new TypeError("onProgress must be a function");
    const result = new Promise<XygWasmScenePaint>((resolve, reject) => this.pending.set(requestId, { resolve, reject, progress: options.onProgress, sequence }));
    const transfer = options.transfer === true ? buffers : [];
    try {
      this.worker.postMessage(
        { type: "series.compile_paint", requestId, sequence, ...request },
        transfer,
      );
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer typed series");
    }
    return {
      requestId, sequence, result,
      cancel: () => {
        const pending = this.pending.get(requestId); if (!pending) return;
        this.pending.delete(requestId);
        pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "request was cancelled", 6));
        if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
      },
    };
  }

  /**
   * Bin a packed `XYAG` aggregate request. Returns a transferable `XYAO`
   * buffer; callers decode width/height/grid via `decodeWasmAggregateOutput`.
   */
  aggregateBin2d(
    request: ArrayBuffer | Uint8Array,
    options: XygWasmAggregateTaskOptions = {},
  ): XygWasmTask<XygWasmSceneValidation & { aggregate: ArrayBuffer }> {
    return this.sceneTask("aggregate.bin2d", request, options);
  }

  /**
   * Stream replayable host-owned canonical f64 columns through the bounded
   * `XYAS` seam. Each transferred chunk is at most one Rust checkpoint; the
   * source buffers themselves are never transferred or detached.
   */
  aggregateStream(source: { x: Float64Array; y: Float64Array }, request: XygWasmAggregateStreamRequest, options: XygWasmAggregateTaskOptions = {}): XygWasmTask<XygWasmSceneValidation & { aggregate: ArrayBuffer }> {
    this.assertLive();
    if (!(source?.x instanceof Float64Array) || !(source.y instanceof Float64Array)
        || source.x.length !== source.y.length || !source.x.length) throw new TypeError("aggregate stream requires matching non-empty f64 columns");
    if (![request?.x0, request?.x1, request?.y0, request?.y1].every(Number.isFinite)
        || !(request.x1 > request.x0) || !(request.y1 > request.y0)
        || !Number.isInteger(request.width) || !Number.isInteger(request.height) || request.width <= 0 || request.height <= 0) throw new TypeError("aggregate stream request is malformed");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<XygWasmSceneValidation & { aggregate: ArrayBuffer }>(requestId);
    const header = new ArrayBuffer(XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES), bytes = new Uint8Array(header), view = new DataView(header);
    bytes.set(new TextEncoder().encode(XYG_WASM_AGGREGATE_STREAM_MAGIC), 0);
    view.setUint32(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.version, XYG_WASM_AGGREGATE_STREAM_VERSION, true);
    view.setUint32(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.header_bytes, XYG_WASM_AGGREGATE_STREAM_HEADER_BYTES, true);
    view.setUint32(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.point_count, source.x.length, true);
    view.setUint32(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.width, request.width, true);
    view.setUint32(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.height, request.height, true);
    view.setFloat64(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.x0, request.x0, true); view.setFloat64(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.x1, request.x1, true);
    view.setFloat64(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.y0, request.y0, true); view.setFloat64(XYG_WASM_AGGREGATE_STREAM_HEADER_OFFSETS.y1, request.y1, true);
    try {
      this.worker.postMessage({ type: "aggregate.stream_begin", requestId, sequence, header }, [header]);
      let offset = 0;
      const push = () => {
        if (this.disposed || !this.pending.has(requestId)) return;
        if (offset >= source.x.length) { this.worker.postMessage({ type: "aggregate.stream_finish", requestId, sequence }); return; }
        const count = Math.min(XYG_WASM_AGGREGATE_STREAM_CHUNK_POINTS, source.x.length - offset);
        // `slice` is the bounded transfer copy. It preserves the canonical
        // split payload for later view replay and never exposes a whole source
        // buffer to the Worker.
        const chunk = new Uint8Array(count * 16);
        chunk.set(new Uint8Array(source.x.buffer, source.x.byteOffset + offset * 8, count * 8), 0);
        chunk.set(new Uint8Array(source.y.buffer, source.y.byteOffset + offset * 8, count * 8), count * 8);
        offset += count;
        this.worker.postMessage({ type: "aggregate.stream_push", requestId, sequence, chunk: chunk.buffer }, [chunk.buffer]);
        setTimeout(push, 0);
      };
      // The evidence capability deliberately leaves one bounded turn between
      // stream declaration and first source copy.  That makes an observed
      // Worker cancellation testable even for a one-chunk source; normal
      // production streams retain their immediate replay cadence.
      setTimeout(push, this.evidenceCapability ? 25 : 0);
    } catch (cause) { this.pending.delete(requestId); throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not start aggregate stream"); }
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "aggregate was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /** @internal Strict-CSP evidence only; returns actual Worker observations. */
  evidenceStreamObservations(): readonly XygWasmStreamObservation[] {
    return this.evidenceCapability ? this.streamObservations.map((entry) => ({ ...entry })) : [];
  }

  /** @internal Whether capability-gated evidence telemetry is active. */
  evidenceEnabled(): boolean { return this.evidenceCapability !== null; }

  /** Gated test-only worker boundary used by the strict-CSP lifecycle proof. */
  evidenceLifecycle(action: "malformed" | "resource" | "trap" | "stream_resource", sequence?: number): Promise<never> {
    this.assertLive(true);
    if (!this.evidenceCapability) {
      throw new XygWasmError("XYG_WASM_EVIDENCE_DISABLED", "lifecycle evidence is not enabled");
    }
    if (action === "stream_resource" && (!Number.isInteger(sequence) || !sequence || sequence > 0xffffffff)) {
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", "stream lifecycle evidence requires a nonzero sequence");
    }
    const requestId = this.allocateRequest();
    const result = this.promiseFor<never>(requestId);
    this.worker.postMessage({ type: "evidence.lifecycle", requestId, capability: this.evidenceCapability, action, sequence });
    return result;
  }

  /** Allocate a globally monotonic sequence for the tick-only lane. */
  allocateTickSequence(): number {
    this.assertLive();
    const sequence = this.nextTickSequence++;
    if (sequence > 0xffff_ffff) {
      throw new XygWasmError("XYG_WASM_RESOURCE_LIMIT", "tick sequence space is exhausted", 3);
    }
    return sequence;
  }

  /** Submit one atomic XYTK batch on the tick-only sequence lane. */
  resolveTicks(request: ArrayBuffer, options: { sequence: number }): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 32
        || request.byteLength > this.maxArenaBytes) {
      throw new TypeError("tick request must be a bounded ArrayBuffer");
    }
    const sequence = options?.sequence;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffff_ffff) {
      throw new RangeError("tick sequence must be a nonzero u32");
    }
    if (new DataView(request).getUint32(12, true) !== sequence) {
      throw new TypeError("tick request header sequence must match the task sequence");
    }
    this.nextTickSequence = Math.max(this.nextTickSequence, sequence + 1);
    const requestId = this.allocateRequest();
    const result = new Promise<ArrayBuffer>((resolve, reject) => {
      this.pending.set(requestId, { resolve, reject, sequence });
    });
    try {
      this.worker.postMessage({ type: "ticks.resolve", requestId, sequence, request }, [request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError(
        "XYG_WASM_INVALID_ARGUMENT",
        cause instanceof Error ? cause.message : "could not post the tick request",
      );
    }
    return {
      requestId,
      sequence,
      result,
      cancel: () => {
        const pending = this.pending.get(requestId);
        if (!pending) return;
        this.pending.delete(requestId);
        pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "tick request was cancelled", 6));
        if (!this.disposed) this.worker.postMessage({ type: "ticks.cancel", requestId, sequence });
      },
    };
  }

  /** Submit one packed Rust-owned `XYDP` dashboard resource plan. */
  dashboardPlan(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 32 || request.byteLength > this.maxArenaBytes) {
      throw new TypeError("dashboard plan must be a bounded ArrayBuffer");
    }
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest();
    const result = this.promiseFor<ArrayBuffer>(requestId);
    this.worker.postMessage({ type: "dashboard.plan", requestId, sequence, request }, [request]);
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "dashboard plan was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /** Submit one packed Rust-owned `XYGC` compound disclosure transition. */
  compoundTransition(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 58 || request.byteLength > this.maxArenaBytes) throw new TypeError("compound transition must be a bounded ArrayBuffer");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<ArrayBuffer>(requestId);
    this.worker.postMessage({ type: "compound.transition", requestId, sequence, request }, [request]);
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "compound transition was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /**
   * Submit one `XYGQ` GraphForge composition request; resolves with the
   * `XYGF` document (compositions and error documents alike, byte-identical
   * to the native host's).
   */
  graphforgeCompose(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 32 || request.byteLength > this.maxArenaBytes) throw new TypeError("graphforge request must be a bounded ArrayBuffer");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<ArrayBuffer>(requestId);
    this.worker.postMessage({ type: "graphforge.compose", requestId, sequence, request }, [request]);
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "graphforge composition was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /** Submit `XYGD` f64 source planes; resolves with shared `XYGM` metadata. */
  geoColumnIngest(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 64 || request.byteLength > this.maxArenaBytes) throw new TypeError("geographic descriptor must be a bounded ArrayBuffer");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<ArrayBuffer>(requestId);
    try {
    this.worker.postMessage({ type: "geo.ingest", requestId, sequence, request }, [request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer geographic request");
    }
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "geographic ingestion was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /** Compile `XYGP` frozen-camera point/outline input into canonical `XYGS`. */
  geoSceneCompile(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 192 || request.byteLength > this.maxArenaBytes) throw new TypeError("geographic Scene request must be a bounded ArrayBuffer");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<ArrayBuffer>(requestId);
    try {
    this.worker.postMessage({ type: "geo.scene", requestId, sequence, request }, [request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer geographic request");
    }
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "geographic Scene compilation was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  temporalSceneCompile(request:ArrayBuffer,options:{sequence?:number;onProgress?:(reply:ArrayBuffer)=>void;session?:{lifetime?:number;disposed?:boolean}}={}):XygWasmTask<ArrayBuffer>{
    if(!(request instanceof ArrayBuffer)||request.byteLength<128||new DataView(request).getUint32(4,true)!==2)return this.temporalSceneCommand(request,options);
    this.assertLive();if(this.temporalPending!==null)throw new Error("temporal operation already in flight");if(request.byteLength>this.maxArenaBytes)throw new RangeError('temporal request exceeds arena');
    if(options.session?.disposed)throw new Error('temporal composition disposed');
    const sequence=options.sequence??this.nextSequence++;
    if(!Number.isInteger(sequence)||sequence<=0||sequence>0xffffffff)throw new RangeError('sequence must be a nonzero u32');
    this.nextSequence=Math.max(this.nextSequence,sequence+1);
    const requestId=this.allocateRequest(),result=this.promiseFor<ArrayBuffer>(requestId);
    this.temporalPending=requestId;let cancelled=false;
    result.then(()=>{if(this.temporalPending===requestId)this.temporalPending=null;},()=>{if(this.temporalPending===requestId)this.temporalPending=null;});
    const pending=this.pending.get(requestId)!;const resolve=pending.resolve;
    pending.resolve=value=>{if(cancelled)pending.reject(new XygWasmError('XYG_WASM_CANCELLED','temporal scan cancelled',6));else resolve(value);};pending.sequence=sequence;pending.progress=options.onProgress;pending.temporal=true;
    if(options.session&&!options.session.lifetime)options.session.lifetime=this.allocateRequest();
    try{this.worker.postMessage({type:'temporal.scene',requestId,sequence,request,lifetime:options.session?.lifetime??0},[request]);}
    catch(cause){this.pending.delete(requestId);this.temporalPending=null;throw cause;}
    return {requestId,sequence,result,cancel:()=>{cancelled=true;if(!this.disposed&&this.pending.has(requestId))this.worker.postMessage({type:'cancel',requestId,sequence});}};
  }
  temporalScenePreview(source:ArrayBuffer):XygWasmTask<ArrayBuffer>{
    const b=new ArrayBuffer(64+source.byteLength),v=new DataView(b);new Uint8Array(b).set([88,89,84,74]);v.setUint32(4,1,true);v.setUint32(8,6,true);new Uint8Array(b,64).set(new Uint8Array(source));return this.temporalSceneCommand(b);
  }
  temporalSceneRelease(session:{lifetime?:number;disposed?:boolean;disposal?:Promise<void>}):Promise<void>{
    if(session.disposal)return session.disposal;session.disposed=true;
    if(this.disposed||!session.lifetime)return session.disposal=Promise.resolve();
    const requestId=this.allocateRequest(),result=this.promiseFor<void>(requestId);session.disposal=result;
    result.catch(()=>{});
    try{this.worker.postMessage({type:'temporal.release',requestId,lifetime:session.lifetime});}catch(cause){const pending=this.pending.get(requestId);this.pending.delete(requestId);pending?.reject(cause);}
    return result;
  }

  temporalSceneCommand(request: ArrayBuffer, options: { sequence?: number } = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < (request.byteLength>=64&&new DataView(request).getUint32(0,true)===0x4a545958?64:128) || request.byteLength > this.maxArenaBytes) throw new TypeError("temporal Scene request must be a bounded ArrayBuffer");
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest(), result = this.promiseFor<ArrayBuffer>(requestId);
    try {
    this.worker.postMessage({ type: "temporal.scene", requestId, sequence, request }, [request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer temporal request");
    }
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "temporal Scene compilation was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  /** Execute one sequenced Rust-owned geographic camera command. */
  geoViewportExecute(request: ArrayBuffer, options: {sequence?:number} = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 128 || request.byteLength > this.maxArenaBytes) throw new TypeError("camera request must be a bounded ArrayBuffer");
    const sequence=options.sequence??this.nextSequence++;
    if(!Number.isInteger(sequence)||sequence<=0||sequence>0xffffffff)throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence=Math.max(this.nextSequence,sequence+1);
    const requestId=this.allocateRequest(), result=this.promiseFor<ArrayBuffer>(requestId);
    try {
      this.worker.postMessage({type:"geo.viewport",requestId,sequence,request},[request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer camera request");
    }
    return {requestId,sequence,result,cancel:()=>{const pending=this.pending.get(requestId);if(!pending)return;this.pending.delete(requestId);pending.reject(new XygWasmError("XYG_WASM_CANCELLED","camera command was cancelled",6));if(!this.disposed)this.worker.postMessage({type:"cancel",requestId,sequence});}};
  }

  /** Execute one sequenced Rust-owned geographic layer catalog. */
  geoCatalogCompile(request: ArrayBuffer, options: {sequence?:number} = {}): XygWasmTask<ArrayBuffer> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength < 128 || request.byteLength > this.maxArenaBytes) throw new TypeError("catalog request must be a bounded ArrayBuffer");
    const sequence=options.sequence??this.nextSequence++;
    if(!Number.isInteger(sequence)||sequence<=0||sequence>0xffffffff)throw new RangeError("sequence must be a nonzero u32");
    this.nextSequence=Math.max(this.nextSequence,sequence+1);
    const requestId=this.allocateRequest(), result=this.promiseFor<ArrayBuffer>(requestId);
    try {
      this.worker.postMessage({type:"geo.catalog",requestId,sequence,request},[request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer catalog request");
    }
    return {requestId,sequence,result,cancel:()=>{const pending=this.pending.get(requestId);if(!pending)return;this.pending.delete(requestId);pending.reject(new XygWasmError("XYG_WASM_CANCELLED","catalog command was cancelled",6));if(!this.disposed)this.worker.postMessage({type:"cancel",requestId,sequence});}};
  }

  /** Stable transport issuer for independently owned geographic data/indexes.
   * This exposes no layout, projection, LOD or chart-building policy. */
  geoScaleBridge(): XygGeoScaleBridge { return geographicOrigin(this).bridge; }

  /** Retained geographic lifecycle mutations always return their ownership reply.
   * Cancellation is an explicit Rust protocol command, never a dropped transport. */
  geoScaleExecute(request: ArrayBuffer): Promise<ArrayBuffer> {
    return this.geoScaleTransport("geo.scale.execute", request);
  }
  /** Read an immutable retained packet or author one bounded canonical chunk. */
  geoScaleRead(request: ArrayBuffer): Promise<ArrayBuffer> {
    return this.geoScaleTransport("geo.scale.read", request);
  }
  geoTileExecute(request:ArrayBuffer):Promise<ArrayBuffer>{return this.geoScaleTransport('geo.tile.execute',request);}
  geoTileRead(request:ArrayBuffer):Promise<ArrayBuffer>{return this.geoScaleTransport('geo.tile.read',request);}
  geoSnapshotExecute(request:ArrayBuffer):Promise<ArrayBuffer>{return this.geoScaleTransport('geo.snapshot.execute',request);}
  geoSnapshotRead(request:ArrayBuffer):Promise<ArrayBuffer>{return this.geoScaleTransport('geo.snapshot.read',request);}
  private async geoScaleTransport(type: "geo.scale.execute" | "geo.scale.read" | "geo.tile.execute" | "geo.tile.read" | "geo.snapshot.execute" | "geo.snapshot.read", request: ArrayBuffer): Promise<ArrayBuffer> {
    geographicDispatch.assertLive.call(this,true);
    const minimum=type.startsWith("geo.tile.")?128:256;
    if (!(request instanceof ArrayBuffer) || request.byteLength < minimum || request.byteLength > Math.min(geographicOrigin(this).maxArenaBytes,32*1024*1024)) {
      throw new TypeError("retained geographic request must be a bounded ArrayBuffer");
    }
    if(request.byteLength<minimum||request.byteLength>Math.min(geographicOrigin(this).maxArenaBytes,32*1024*1024))throw new TypeError('retained request changed before admission');
    if(!this.geoTransportAdmitted)await geographicDispatch.acquire.call(this);geographicDispatch.assertLive.call(this,true);
    // Transfer ownership without a second allocation; waiting in the
    // FIFO must not expose mutable authoring bytes to a later caller.
    const length=request.byteLength,header=new DataView(request),command=header.getUint32(8,true);
    const mixedCleanup=type==="geo.tile.execute" && header.getUint32(0,true)===0x584d5958 && length===256 && (command===4||command===5);
    const cleanup=mixedCleanup || (type.startsWith("geo.tile.")?[5,8,9,10]:type.startsWith("geo.snapshot.")?[3,7]:[8,9,10,24,31,47]).includes(command)&&length<=(type.startsWith("geo.scale.")?384:352);
    geographicDispatch.capacity.call(this,length,cleanup);
    const capture=(type==='geo.snapshot.execute'&&[6,7].includes(command)&&length===256)||(type==='geo.scale.execute'&&([35,36,43].includes(command)&&length===264||[19,44].includes(command)&&length===304||command===47&&length===272&&[19,35,36,43,44].includes(header.getUint32(256,true))));
    const issuer=type==='geo.snapshot.execute'?geographicOrigin(this).snapshotBridge:geographicOrigin(this).bridge;
    let memberProbe=false;
    if(type==='geo.scale.execute'&&minimalMemberDataProbe(request)){for(const context of geographicOrigin(this).captures){if(context.purpose==='known-member-data-retirement'&&context.bridge===issuer&&context.request.byteLength===length&&new Uint8Array(context.request).every((b,i)=>b===new Uint8Array(request)[i])){memberProbe=true;break;}}}
    const mutation=capture||memberProbe?{bridge:issuer,purpose:(memberProbe?'known-member-data-retirement':'mutation') as GeoWorkerCapturePurpose,request:new Uint8Array(request.slice(0)),token:{}}:undefined;
    if(mutation){const origin=geographicOrigin(this);for(const context of origin.captures){const bytes=new Uint8Array(context.request);if(context.purpose===mutation.purpose&&context.bridge===mutation.bridge&&bytes.length===mutation.request.length&&bytes.every((b,i)=>b===mutation.request[i])){context.latest=mutation.token;context.value=context.reply=context.code=context.status=undefined;}}}
    const owned=structuredClone(request,{transfer:[request]});
    return geographicDispatch.queue.call(this,async()=>{
      await geographicDispatch.acquire.call(this);geographicDispatch.assertLive.call(this,true);const sequence=this.nextSequence++;
      if(sequence>0xffffffff)throw new RangeError("Worker sequence exhausted");
      const requestId=geographicDispatch.allocateRequest.call(this),result=geographicDispatch.promiseFor.call(this,requestId) as Promise<ArrayBuffer>;
      if(mutation)geographicOrigin(this).mutations.set(requestId,mutation);
      try{geographicOrigin(this).post({type,requestId,sequence,request:owned},[owned]);}
      catch(cause){this.pending.delete(requestId);geographicWorkerOrigins.get(this)!.mutations.delete(requestId);throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT",cause instanceof Error?cause.message:"could not transfer retained geographic request");}
      return await result;
    },length,cleanup);
  }

  /** Submit one packed filter command to the shared Rust state machine. */
  filterCommand(command: ArrayBuffer): Promise<ArrayBuffer> {
    this.assertLive();
    if (!(command instanceof ArrayBuffer) || command.byteLength < 1
        || command.byteLength > this.maxArenaBytes) {
      throw new TypeError("filter command must be a bounded ArrayBuffer");
    }
    const requestId = this.allocateRequest();
    const result = this.promiseFor<ArrayBuffer>(requestId);
    try {
      this.worker.postMessage({ type: "filter.command", requestId, command }, [command]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError(
        "XYG_WASM_INVALID_ARGUMENT",
        cause instanceof Error ? cause.message : "could not post filter command",
      );
    }
    return result;
  }

  /** Submit one packed temporal command to the shared Rust state machine. */
  temporalCommand(command: ArrayBuffer): Promise<ArrayBuffer> {
    this.assertLive();
    if (!(command instanceof ArrayBuffer) || command.byteLength < 16
        || command.byteLength > this.maxArenaBytes) {
      throw new TypeError("temporal command must be a bounded ArrayBuffer");
    }
    const requestId = this.allocateRequest();
    const result = this.promiseFor<ArrayBuffer>(requestId);
    try {
      this.worker.postMessage({ type: "temporal.command", requestId, command }, [command]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError(
        "XYG_WASM_INVALID_ARGUMENT",
        cause instanceof Error ? cause.message : "could not post temporal command",
      );
    }
    return result;
  }

  /** Submit one packed Rust-owned temporal graph create/frame command. */
  temporalGraphCommand(command: ArrayBuffer): Promise<ArrayBuffer> {
    this.assertLive();
    if (!(command instanceof ArrayBuffer) || command.byteLength < 32
        || command.byteLength > this.maxArenaBytes) {
      throw new TypeError("temporal graph command must be a bounded ArrayBuffer");
    }
    const requestId = this.allocateRequest();
    const result = this.promiseFor<ArrayBuffer>(requestId);
    try {
      this.worker.postMessage({ type: "temporal_graph.command", requestId, command }, [command]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not post temporal graph command");
    }
    return result;
  }

  /** Export/import immutable frozen graphs through the shared Rust protocol. */
  frozenGraphCommand(command:ArrayBuffer):Promise<ArrayBuffer> {
    this.assertLive();
    if(this.pending.size)throw new XygWasmError('XYG_WASM_BUSY','Frozen export requires a drained Worker');
    if(!(command instanceof ArrayBuffer)||command.byteLength<64||command.byteLength>this.maxArenaBytes)throw new RangeError('bounded XYFX required');
    const requestId=this.allocateRequest(),result=this.promiseFor<ArrayBuffer>(requestId);
    try{this.worker.postMessage({type:'frozen_graph.command',requestId,command},[command]);}
    catch(cause){this.pending.delete(requestId);throw cause;}return result;
  }

  /** Run one Rust CoSE job progressively inside this dedicated Worker. */
  layoutCose(
    request: ArrayBuffer,
    options: {
      revision: number;
      sequence?: number;
      chunkSteps?: number;
      maxWallMs?: number;
      onUpdate?: (checkpoint: XygWasmGraphCheckpoint) => void;
    },
  ): XygWasmTask<XygWasmGraphCheckpoint> {
    this.assertLive();
    if (!(request instanceof ArrayBuffer) || request.byteLength <= 0 || request.byteLength > this.maxArenaBytes) throw new RangeError("graph request exceeds the worker byte budget");
    const revision = Number(options?.revision), sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(revision) || revision <= 0 || revision > 0xffffffff) throw new RangeError("revision must be a nonzero u32");
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) throw new RangeError("sequence must be a nonzero u32");
    const chunkSteps = options.chunkSteps ?? XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS;
    const maxWallMs = options.maxWallMs ?? XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS;
    if (!Number.isInteger(chunkSteps) || chunkSteps <= 0 || chunkSteps > 1000) throw new RangeError("chunkSteps must be an integer in 1..1000");
    if (!Number.isFinite(maxWallMs) || maxWallMs <= 0 || maxWallMs > 300_000) throw new RangeError("maxWallMs must be in (0, 300000]");
    if (options.onUpdate !== undefined && typeof options.onUpdate !== "function") throw new TypeError("onUpdate must be a function");
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const requestId = this.allocateRequest();
    const result = new Promise<XygWasmGraphCheckpoint>((resolve, reject) => this.pending.set(requestId, { resolve, reject, progress: options.onUpdate, sequence }));
    try {
      this.worker.postMessage({ type: "graph.cose", requestId, sequence, revision, request, chunkSteps, maxWallMs }, [request]);
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT", cause instanceof Error ? cause.message : "could not transfer graph request");
    }
    return { requestId, sequence, result, cancel: () => {
      const pending = this.pending.get(requestId); if (!pending) return;
      this.pending.delete(requestId); pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "graph layout was cancelled", 6));
      if (!this.disposed) this.worker.postMessage({ type: "cancel", requestId, sequence });
    } };
  }

  private sceneTask<T extends XygWasmSceneValidation>(
    type:
      | "scene.validate"
      | "scene.paint"
      | "scene.paint_annotations"
      | "scene.compile"
      | "scene.compile_paint"
      | "aggregate.bin2d",
    scene: ArrayBuffer | Uint8Array,
    options: SceneTaskOptions,
  ): XygWasmTask<T> {
    this.assertLive();
    if (type === "aggregate.bin2d") {
      if (options.transfer === false) {
        throw new XygWasmError(
          "XYG_WASM_INVALID_ARGUMENT",
          "aggregate requests must transfer ownership; transfer: false is not supported",
          2,
        );
      }
    }
    const transfer = options.transfer !== false;
    const requestId = this.allocateRequest();
    const sequence = options.sequence ?? this.nextSequence++;
    if (!Number.isInteger(sequence) || sequence <= 0 || sequence > 0xffffffff) {
      throw new RangeError("sequence must be a nonzero u32");
    }
    this.nextSequence = Math.max(this.nextSequence, sequence + 1);
    const payload = sceneMessage(scene, transfer);
    if (options.onProgress !== undefined && typeof options.onProgress !== "function") throw new TypeError("onProgress must be a function");
    const result = new Promise<T>((resolve, reject) => this.pending.set(requestId, { resolve, reject, progress: options.onProgress, sequence }));
    try {
      this.worker.postMessage(
        this.inline && type === "aggregate.bin2d"
          ? { type, requestId, sequence, request: payload.buffer }
          : { type, requestId, sequence, scene: payload.buffer },
        payload.transfer,
      );
    } catch (cause) {
      this.pending.delete(requestId);
      throw new XygWasmError(
        "XYG_WASM_INVALID_ARGUMENT",
        cause instanceof Error ? cause.message : "could not post the scene to the worker",
      );
    }
    return {
      requestId,
      sequence,
      result,
      cancel: () => {
        const pending = this.pending.get(requestId);
        if (!pending) return;
        this.pending.delete(requestId);
        pending.reject(new XygWasmError("XYG_WASM_CANCELLED", "request was cancelled", 6));
        if (!this.disposed) {
          this.worker.postMessage({ type: "cancel", requestId, sequence });
        }
      },
    };
  }

  dispose(): Promise<void> {
    if(this.disposal)return this.disposal;
    const graph = graphWorkerAttachments.get(this);
    if (graph) return graph.close().catch(() => {}).then(() => this.dispose());
    this.disposed = true;
    return this.disposal=(async()=>{
    const disposedError = new XygWasmError("XYG_WASM_DISPOSED", "worker was disposed");
    // Reject application work before waiting for the worker acknowledgement;
    // a short synchronous WASM operation must not win disposal's lifecycle race.
    geographicDispatch.failAll.call(this,disposedError);
    // Drain every retained closure/reference before Rust releases the persistent
    // transport credit. New ownership admission is already disabled.
    await this.ownedGeoChain;
    const requestId = geographicDispatch.allocateRequest.call(this);
    const complete = geographicDispatch.promiseFor.call(this,requestId) as Promise<void>;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      geographicWorkerOrigins.get(this)!.post({ type: "dispose", requestId });
      // A trapped or wedged worker must not make application teardown hang.
      await Promise.race([
        complete,
        new Promise<void>((resolve) => {
          timeout = setTimeout(resolve, 1_000);
        }),
      ]);
    } catch {
      // Termination below is the bounded fallback when messaging is broken.
    } finally {
      if (timeout !== undefined) clearTimeout(timeout);
    geographicWorkerOrigins.get(this)!.terminate();
    geographicWorkerOrigins.get(this)!.terminal = true;
    if (this.inlineBlobUrl) URL.revokeObjectURL(this.inlineBlobUrl);
      geographicDispatch.failAll.call(this,disposedError);
    }
    })();
  }

  private allocateRequest(): number {
    const requestId = this.nextRequestId++;
    if (!Number.isSafeInteger(requestId)) throw new Error("XYG WASM request id exhausted");
    return requestId;
  }

  private promiseFor<T>(requestId: number): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.pending.set(requestId, { resolve, reject });
    });
  }

  private onMessage(message: any) {
    if (message?.type === "aggregate.stream_observation") {
      if (this.evidenceCapability && (message.phase === "begin" || message.phase === "push"
          || message.phase === "cancelled" || message.phase === "finish")
          && Number.isSafeInteger(message.requestId) && Number.isSafeInteger(message.sequence)
          && Number.isSafeInteger(message.pushes) && message.pushes >= 0) {
        // Bound evidence bookkeeping even if a deliberately hostile page
        // submits many streams while its diagnostic capability is enabled.
        if (this.streamObservations.length === 256) this.streamObservations.shift();
        this.streamObservations.push({ phase: message.phase, requestId: message.requestId,
          sequence: message.sequence, pushes: message.pushes });
      }
      return;
    }
    const pending = this.pending.get(message?.requestId);
    if (!pending) return;
    if (message.progress && message.ok) {
      try {
        pending.progress?.(message.value);
      } catch (cause) {
        if(pending.temporal){
          pending.progress=undefined;pending.temporalFailure=new XygWasmError('XYG_WASM_PROGRESS_CALLBACK_FAILED',cause instanceof Error?cause.message:'worker progress callback failed');
          if(!this.disposed)this.worker.postMessage({type:'cancel',requestId:message.requestId,sequence:pending.sequence});return;
        }
        this.pending.delete(message.requestId);
        pending.reject(new XygWasmError(
          "XYG_WASM_PROGRESS_CALLBACK_FAILED",
          cause instanceof Error ? cause.message : "worker progress callback failed",
        ));
        if (!this.disposed && pending.sequence !== undefined) {
          this.worker.postMessage({
            type: "cancel",
            requestId: message.requestId,
            sequence: pending.sequence,
          });
        }
      }
      return;
    }
    this.pending.delete(message.requestId);
    geographicWorkerOrigins.get(this)?.mutations.delete(message.requestId);
    if(pending.temporalFailure){pending.reject(pending.temporalFailure);return;}
    if (message.ok) {
      pending.resolve(message.value);
    } else {
      const error=workerError(message.error);
      for(const context of geographicWorkerOrigins.get(this)!.captures){if(context.value===message)context.value=error;}
      pending.reject(error);
    }
  }

  private failAll(error: XygWasmError) {
    // Lifetime faults must reach an attached presenter even between commands.
    graphWorkerAttachments.get(this)?.fail(error);
    geographicWorkerOrigins.get(this)?.mutations.clear();
    for (const pending of this.pending.values()) pending.reject(error);
    this.pending.clear();
  }

  private assertLive(retained=false) {
    if (retained) geographicOrigin(this);
    if (this.disposed) throw new XygWasmError("XYG_WASM_DISPOSED", "worker was disposed");
    if (graphWorkerAttachments.has(this)) throw new XygWasmError("GF_INTERACTION_INVALID", "Close the attached graph session before using another Worker product lane", -3);
    if(!retained&&this.geoTransportAdmission)throw new XygWasmError("XYG_WASM_INVALID_ARGUMENT","Ordinary operations require a separate Worker from retained geographic transport");
  }
}

// Capture at module initialization, before application code can replace public
// or TypeScript-private dispatch methods. No mutable method lookup can retag an
// issued bridge to another Worker after a ready/queue await.
const geographicDispatch = Object.freeze({
  transport: XygWasmWorker.prototype["geoScaleTransport"],
  acquire: XygWasmWorker.prototype.acquireGeoTransport,
  prepare: XygWasmWorker.prototype.prepareGeoFrame,
  reserve: XygWasmWorker.prototype.reserveGeoInput,
  queue: XygWasmWorker.prototype["queueOwnedGeo"],
  capacity: XygWasmWorker.prototype["checkOwnedGeoCapacity"],
  assertLive: XygWasmWorker.prototype["assertLive"],
  allocateRequest: XygWasmWorker.prototype["allocateRequest"],
  promiseFor: XygWasmWorker.prototype["promiseFor"],
  onMessage: XygWasmWorker.prototype["onMessage"],
  failAll: XygWasmWorker.prototype["failAll"],
});
/** @internal Stable exact issuer for geographic typed owners. */
export function getGeoWorkerBridge(worker: XygWasmWorker): XygGeoScaleBridge {
  return geographicOrigin(worker).bridge;
}
/** @internal Weak provenance, never structural/numeric handle equivalence. */
export function isGeoWorkerBridge(worker: XygWasmWorker, bridge: XygGeoScaleBridge): boolean {
  const origin = geographicWorkerOrigins.get(worker);
  return !!origin && origin.worker === worker["worker"] && origin.bridge === bridge;
}
/** @internal Admission through the same immutable issuer dispatch. */
export function acquireGeoWorkerTransport(worker: XygWasmWorker, bridge: XygGeoScaleBridge): Promise<void> {
  if (!isGeoWorkerBridge(worker, bridge)) throw new TypeError("Overview requires its issuing Worker");
  return geographicDispatch.acquire.call(worker);
}
/** @internal Prepare only through the producer's original Worker dispatch. */
export function prepareGeoWorkerFrame(worker: XygWasmWorker, bridge: XygGeoScaleBridge, handle: bigint, sequence: bigint) {
  if (!isGeoWorkerBridge(worker, bridge)) throw new TypeError("Overview requires its issuing Worker");
  return geographicDispatch.prepare.call(worker, handle, sequence);
}
/** @internal Snapshot transport is issued by the same exact retained producer. */
export function getGeoWorkerSnapshotTransport(worker: XygWasmWorker, bridge: XygGeoScaleBridge) {
  if (!isGeoWorkerBridge(worker, bridge)) throw new TypeError("Snapshot requires its issuing Worker");
  const origin = geographicOrigin(worker);
  return Object.freeze({bridge: origin.snapshotBridge, budgetBytes: Math.min(origin.maxArenaBytes, 128 * 1024 * 1024)});
}
/** @internal Only actual termination by the captured lifecycle grants local teardown. */
export function isGeoWorkerTerminated(worker: XygWasmWorker, bridge: XygGeoScaleBridge): boolean {
  const origin = geographicWorkerOrigins.get(worker);
  return !!origin && origin.bridge === bridge && origin.terminal;
}
/** @internal Charge controller framing before it copies queued queries. */
export function reserveGeoWorkerInput(worker: XygWasmWorker, bridge: XygGeoScaleBridge, bytes: number): () => void {
  if (!isGeoWorkerBridge(worker, bridge)) throw new TypeError("Overview requires its issuing Worker");
  return geographicDispatch.reserve.call(worker, bytes);
}

export function createXygWasmWorker(options: XygWasmWorkerOptions | XygInlineWasmWorkerOptions): XygWasmWorker {
  return new XygWasmWorker(options);
}

/** @internal One non-cancellable retained byte lane, issued only to the explicit
 * graph controller. Not exported through 60_entries.ts. Request bytes survive
 * the transfer until resolution; op_seq belongs to Rust, not this transport. */
type GraphSessionExport = "open" | "update" | "render" | "interact";
type GraphTemporalExport = "temporal-create" | "temporal-frame" | "freeze";
interface GraphWorkerAttachment {
  fail(error: XygWasmError): void;
  temporalCreate(request: Uint8Array): Promise<ArrayBuffer>;
  temporalFrame(request: Uint8Array): Promise<ArrayBuffer>;
  freeze(request:Uint8Array):Promise<ArrayBuffer>;
  execute(operation: GraphSessionExport, request: Uint8Array): Promise<ArrayBuffer>;
  close(): Promise<void>;
}
const graphWorkerAttachments = new WeakMap<XygWasmWorker, GraphWorkerAttachment>();
let nextGraphLifetime = 1;
export function claimGraphWorker(worker: XygWasmWorker, onFailure: (error: XygWasmError) => void): GraphWorkerAttachment {
  if (!(worker instanceof XygWasmWorker)) throw new TypeError("A packaged WASM Worker is required");
  const origin = geographicOrigin(worker);
  if (worker["inline"] || worker["disposed"] || worker["geoTransportAdmission"] || graphWorkerAttachments.has(worker)) {
    throw new XygWasmError("GF_INTERACTION_INVALID", "Graph attachment requires an available packaged Worker", -3);
  }
  const lifetime = nextGraphLifetime++;
  if (!Number.isSafeInteger(lifetime)) throw new RangeError("Graph attachment lifetime exhausted");
  let chain: Promise<unknown> = Promise.resolve(), closing = false, opened = false, closePromise: Promise<void> | null = null;
  let queued = 0, bytesHeld = 0;
  let failure: XygWasmError | null = null;
  const live = () => {
    if (origin.terminal || worker["disposed"] || graphWorkerAttachments.get(worker) !== attachment) {
      throw failure ?? new XygWasmError("XYG_WASM_DISPOSED", "Graph Worker lifetime ended");
    }
  };
  const terminal = (cause: unknown) => {
    const error = cause instanceof XygWasmError ? cause : new XygWasmError("XYG_WASM_WORKER_ERROR", String(cause));
    origin.terminal = true; worker["disposed"] = true;
    origin.terminate(); geographicDispatch.failAll.call(worker, error);
    return failure ?? error;
  };
  const send = async (operation: GraphSessionExport | GraphTemporalExport | "close", retained?: Uint8Array): Promise<ArrayBuffer> => {
    await origin.ready; live();
    // No pre-existing deferred job may later stage over the retained instance.
    if (operation === "open" && !opened && worker["pending"].size) {
      throw new XygWasmError("GF_INTERACTION_INVALID", "Graph attachment requires a drained Worker", -3);
    }
    const sequence = worker["nextSequence"]++, requestId = geographicDispatch.allocateRequest.call(worker);
    if (sequence > 0xffffffff) throw new RangeError("Worker sequence exhausted");
    const response = geographicDispatch.promiseFor.call(worker, requestId) as Promise<any>;
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      // The retained exact bytes are never transferred or mutated. An ambiguous
      // lost reply ends this Worker lifetime; it is never treated as cancellation.
      const request = retained?.slice().buffer;
      origin.post({ type: `graph.session.${operation}`, requestId, sequence, lifetime, request }, request ? [request] : []);
      const reply = await Promise.race([response, new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(terminal(new XygWasmError("XYG_WASM_GRAPH_REPLY_LOST", "Graph reply timed out; mutation outcome is unknown"))), 60_000);
      })]);
      if (reply?.sequence !== sequence || reply?.lifetime !== lifetime || !(reply?.bytes instanceof ArrayBuffer)) {
        throw terminal(new XygWasmError("XYG_WASM_MESSAGE_ERROR", "Graph reply does not match its issued request lifetime"));
      }
      if (operation === "open") opened = true;
      return reply.bytes;
    } catch (cause) {
      if (!(cause instanceof XygWasmError) || !cause.code.startsWith("GF_INTERACTION_")) throw terminal(cause);
      throw cause;
    } finally {
      if (timer !== undefined) clearTimeout(timer);
      worker["pending"].delete(requestId);
    }
  };
  function enqueue(operation: GraphSessionExport | GraphTemporalExport, request: Uint8Array) {
      live();
      if (closing) throw new XygWasmError("XYG_WASM_DISPOSED", "Graph attachment is closing");
      if (!(request instanceof Uint8Array) || !request.byteLength || request.byteLength > origin.maxArenaBytes) throw new RangeError("Graph request exceeds Worker arena");
      if (queued >= 8 || bytesHeld + request.byteLength > origin.maxArenaBytes) throw new RangeError("Graph command lane is busy");
      const retained = request.slice(); queued++; bytesHeld += retained.byteLength;
      const result = chain.then(() => send(operation, retained));
      chain = result.catch(() => {});
      return result.finally(() => { queued--; bytesHeld -= retained.byteLength; });
  }
  const attachment: GraphWorkerAttachment = Object.freeze({
    fail(error: XygWasmError) {
      if (failure) return;
      failure = error;
      try { onFailure(error); } catch { /* isolate presenter notification */ }
    },
    execute: enqueue,
    temporalCreate: (request: Uint8Array) => enqueue("temporal-create", request),
    temporalFrame: (request: Uint8Array) => enqueue("temporal-frame", request),
    freeze: (request:Uint8Array)=>enqueue("freeze",request),
    close() {
      if (closePromise) return closePromise;
      closing = true;
      closePromise = (async () => {
        try { await chain; if (opened && !origin.terminal && !worker["disposed"]) await send("close"); }
        finally { if (graphWorkerAttachments.get(worker) === attachment) graphWorkerAttachments.delete(worker); }
      })();
      return closePromise;
    },
  });
  graphWorkerAttachments.set(worker, attachment);
  return attachment;
}
