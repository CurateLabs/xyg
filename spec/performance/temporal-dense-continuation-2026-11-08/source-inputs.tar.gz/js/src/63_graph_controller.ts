import {XygFrozenTemporalGraph,issuedFrozenGraph} from './67_frozen_graph';
import type { XygTemporalState, XygWasmTemporalController } from "./49_wasm_temporal";
import { encodeWasmTemporalGraphCreate, encodeWasmTemporalGraphFrame, decodeWasmTemporalGraphFrame,
  type XygWasmTemporalGraphBinding, type XygWasmTemporalGraphFrame } from "./49_wasm_temporal_graph";
/** Experimental explicit retained WASM graph attachment (#36 bounded S5b).
 * Rust owns every graph decision; this module owns pointer/keyboard/DOM/lifetime only.
 * See spec/design/graph-interaction.md “Bounded explicit S5b attachment”. */
import { XYG_WASM_TEMPORAL_GRAPH_FRAME_CONTEXT as FRAME_CONTEXT, XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS, XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS } from "./wasm_abi_generated";
import { claimGraphWorker, XygWasmError, type XygWasmWorker } from "./47_wasm";
import { createGraphGpuPainter, decodeGraphGpu } from "./63_graph_gpu";
import { decodeGraphSessionAck, decodeGraphSessionResult, encodeGraphSessionRequest,
  type GraphSessionCamera, type GraphSessionLoad, type GraphSessionResult,
  type GraphSessionRequest } from "./63_graph_session_wire";

/** @experimental Bounded S5b preparation; broader graph interactions remain open. */
export type XygWasmGraphCamera = GraphSessionCamera;
/** @experimental Bounded S5b preparation; broader graph interactions remain open. */
export type XygWasmGraphLoad = GraphSessionLoad;
/** @experimental Bounded S5b preparation; broader graph interactions remain open. */
export type XygWasmGraphSnapshot = Omit<GraphSessionResult, "sections"> & { camera: XygWasmGraphCamera; temporal: XygWasmTemporalGraphFrame | null };
/** @experimental Bounded S5b preparation; broader graph interactions remain open. */
export interface XygWasmGraphSessionOptions {
  el: HTMLElement;
  /** Borrowed. Await attachment.dispose() before disposing an owned Worker. */
  worker: XygWasmWorker;
  instanceId: bigint;
  /** Complete XYGF bytes, for example composeWasmGraphForge(...).result.bytes. */
  document: Uint8Array | ArrayBuffer;
  load?: XygWasmGraphLoad;
  /** Canonical UUID planes; controller uses its own Worker. Bind before first paint. */
  temporal?: { controller: XygWasmTemporalController; binding: XygWasmTemporalGraphBinding; budget: bigint };
  /** Exact Rust session order: scale_x, scale_y, offset_x, offset_y, width, height, DPR. */
  camera: XygWasmGraphCamera;
}
/** @experimental Bounded S5b preparation; broader graph interactions remain open. */
export interface XygWasmGraphSession {
  readonly ready: Promise<XygWasmGraphSnapshot>;
  refreshRender(camera?: XygWasmGraphCamera): Promise<XygWasmGraphSnapshot>;
  snapshot(): XygWasmGraphSnapshot | null;
  whenIdle(): Promise<void>;
  freeze(options:{timezone:string;window?:readonly [bigint,bigint]|null;budgetBytes?:bigint}):Promise<XygFrozenTemporalGraph>;
  pinFocused(pinned: boolean): Promise<XygWasmGraphSnapshot>;
  dispose(): Promise<void>;
}

/** Attach one initially Owned, unlinked session to one packaged Worker.
 * @experimental S5b subset; bounded temporal binding; no link/update/hover/gesture API. */
export function attachWasmGraphSession(options: XygWasmGraphSessionOptions): XygWasmGraphSession {
  if (!options || !(options.el instanceof HTMLElement)) throw new TypeError("A graph container is required");
  // Frame immutable ingress synchronously before asynchronous application work.
  const instanceId = options.instanceId, load = options.load === undefined ? undefined : { ...options.load };
  let opening: Uint8Array | null = encodeGraphSessionRequest({ instanceId, opSeq: 1n, revision: 0,
    operation: 19, document: options.document, load });
  const progressive = load?.progressive === true;
  const temporal = options.temporal;
  if (temporal && load?.pinned && Array.from(load.pinned).some(value => value !== 0)) {
    throw new TypeError("Temporal binding starts with Rust-owned empty interaction state; use pinFocused after ready");
  }
  // Encode before async work, so later author-buffer mutation cannot alter bindings.
  let temporalCreate = temporal ? new Uint8Array(encodeWasmTemporalGraphCreate(temporal.binding)) : null;
  const temporalBudget = temporal?.budget;
  let temporalFrame: XygWasmTemporalGraphFrame | null = null, acceptedMembership: XygWasmTemporalGraphFrame | null = null, sessionRevision = 0, timeRevision = 0n;
  let pendingTime: XygTemporalState | null = null, timeKey: string | null = null, intent = 0;
  let temporalTask: Promise<void> = Promise.resolve(), initialized = false, temporalPumping = false;
  let unsubscribeTime: (() => void) | null = null;
  const idleWaiters = new Set<() => void>();
  let terminalFailure: XygWasmError | null = null;
  const cameraCopy = (camera: XygWasmGraphCamera): XygWasmGraphCamera => {
    if (!camera || camera.length !== 7 || Array.from(camera).some(v => typeof v !== "number")) throw new TypeError("An explicit seven-f64 session camera is required");
    return Object.freeze([...camera]) as unknown as XygWasmGraphCamera;
  };
  let camera = cameraCopy(options.camera);
  const lane = claimGraphWorker(options.worker, report), doc = options.el.ownerDocument;
  let disposed = false, terminal = false, busy = true, needsRefresh = false, sequence = 2n, output: GraphSessionResult | null = null;
  let continuation = progressive, frame: number | null = null, deadline: ReturnType<typeof setTimeout> | null = null;
  let disposal: Promise<void> | null = null, page = 0;
  const surface = doc.createElement("div"), companion = doc.createElement("div"), live = doc.createElement("div");
  const previous = doc.createElement("button"), next = doc.createElement("button"), table = doc.createElement("table"), body = doc.createElement("tbody");
  const surfaceAttributes = new Map(["tabindex", "role", "aria-label", "aria-busy"].map(name => [name, surface.getAttribute(name)]));
  surface.dataset.xyGraphSession = "experimental";
  surface.setAttribute("role", "application"); surface.tabIndex = 0;
  surface.setAttribute("aria-label", "Graph. Arrow keys move focus; Enter selects; Control or Command Enter toggles; Escape clears selection.");
  companion.setAttribute("aria-label", "Graph companion"); live.setAttribute("aria-live", "polite"); live.setAttribute("aria-atomic", "true");
  previous.type = next.type = "button"; previous.textContent = "Previous"; next.textContent = "Next";
  previous.setAttribute("aria-label", "Previous graph companion page"); next.setAttribute("aria-label", "Next graph companion page");
  const head = doc.createElement("thead"), header = doc.createElement("tr");
  for (const label of ["Kind", "Identity", "Label", "Relationship", "Selected", "Action"]) {
    const cell = doc.createElement("th"); cell.scope = "col"; cell.textContent = label; header.append(cell);
  }
  head.append(header); table.append(head, body); companion.append(table, previous, next, live);
  let painter: ReturnType<typeof createGraphGpuPainter>;
  try { painter = createGraphGpuPainter(surface); options.el.append(surface, companion); }
  catch (error) { surface.remove(); companion.remove(); void lane.close(); throw error; }
  function snapshot(): XygWasmGraphSnapshot | null {
    if (!output) return null;
    const { sections: _sections, ...semantic } = output;
    return structuredClone({ ...semantic, camera, temporal: temporalFrame });
  }
  function dispatch(name: string, detail: unknown) {
    if (disposed) return;
    // Observer failures cannot roll back an already accepted Rust transition.
    try { surface.dispatchEvent(new CustomEvent(`xy:graph-${name}`, { bubbles: true, detail })); } catch { /* observer isolation */ }
  }
  function report(error: unknown) {
    if (disposed) return;
    stopContinuation();
    if (error instanceof XygWasmError && error.code.startsWith("XYG_WASM_")) {
      if (terminalFailure) return;
      terminal = true; terminalFailure = error;
      intent++; pendingTime = null; unsubscribeTime?.(); unsubscribeTime = null;
      for (const resolve of idleWaiters) resolve(); idleWaiters.clear();
    }
    if (error instanceof XygWasmError && error.code === "GF_INTERACTION_STALE") {
      needsRefresh = true; dispatch("stale", { code: error.code, revision: output?.revision ?? 0 });
    } else dispatch("error", { code: error instanceof XygWasmError ? error.code : "GF_INTERACTION_INVALID", message: error instanceof Error ? error.message : String(error) });
  }
  function stopContinuation() {
    continuation = false;
    if (frame !== null) cancelAnimationFrame(frame);
    if (deadline !== null) clearTimeout(deadline);
    frame = null; deadline = null;
  }
  function scheduleContinuation() {
    if (!continuation || disposed || terminal || needsRefresh || pendingTime || temporalPumping || frame !== null) return;
    if (output?.relayout?.done) { stopContinuation(); return; }
    frame = requestAnimationFrame(() => {
      frame = null;
      if (!continuation || disposed || terminal || needsRefresh) return;
      if (busy) { scheduleContinuation(); return; }
      // One bounded Rust operation per presentation opportunity. Worker replies
      // are accepted immediately; no transport ACK is held to pace the force.
      void run({ operation: 15, steps: XYG_WASM_GRAPH_DEFAULT_CHUNK_STEPS }, "render").catch(() => {});
    });
  }
  function setBusy(value: boolean) {
    busy = value;
    if (!value) { pumpTemporal(); scheduleContinuation(); }
    if (disposed || terminal || (!busy && !pendingTime && !temporalPumping)) {
      for (const resolve of idleWaiters) resolve(); idleWaiters.clear();
    }
    if (disposed) return;
    surface.setAttribute("aria-busy", String(value));
    for (const button of companion.querySelectorAll("button")) {
      const unavailable = button === previous ? page === 0 : button === next ? !output || (page + 1) * 50 >= output.companion.total : false;
      button.setAttribute("aria-disabled", String(value || unavailable || needsRefresh));
    }
  }
  function install(bytes: ArrayBuffer, candidateCamera: XygWasmGraphCamera, candidatePage: number, requireProgress = false): XygWasmGraphSnapshot {
    // Validate the entire reply and all GPU sections before any upload/DOM/state.
    let candidate: GraphSessionResult, gpu: ReturnType<typeof decodeGraphGpu>;
    try { candidate = decodeGraphSessionResult(bytes);
      if (requireProgress && !candidate.relayout) throw new XygWasmError("GF_INTERACTION_INVALID", "Relayout reply omitted its Rust progress report", -3);
      gpu = decodeGraphGpu(candidate.sections); }
    catch (error) { needsRefresh = true; throw error; }
    const fragment = doc.createDocumentFragment();
    candidate.companion.rows.forEach((cells, index) => {
      const row = doc.createElement("tr");
      for (const value of cells) { const cell = doc.createElement("td"); cell.textContent = value; row.append(cell); }
      const cell = doc.createElement("td"), button = doc.createElement("button"); button.type = "button";
      button.textContent = "Select"; button.dataset.graphRow = String(index);
      // Ref is the ALIGNED Rust candidate; no parsing labels/identities/source rows.
      button.addEventListener("click", () => {
        if (disposed || busy || needsRefresh || output !== candidate) return;
        submit({ operation: 11, mode: 0, refs: [candidate.companion.refs[index]!] }, "select");
      });
      cell.append(button); row.append(cell); fragment.append(row);
    });
    if (disposed || terminal) throw new XygWasmError("XYG_WASM_DISPOSED", "Graph attachment lifetime ended");
    const focusedRow = doc.activeElement instanceof HTMLElement && body.contains(doc.activeElement) ? doc.activeElement.dataset.graphRow : undefined;
    // Painter stages a complete picture before presentation. Validation/refusal
    // leaves the preceding camera/revision/picture/selection/companion intact.
    try { painter.paint(gpu, candidateCamera); } catch (error) { needsRefresh = true; throw error; }
    body.replaceChildren(fragment); output = candidate; camera = candidateCamera; page = candidatePage; needsRefresh = false;
    // Keep navigation buttons mounted and focusable at a page boundary. Native
    // disabled on a currently focused button can blur it while rows rebuild.
    previous.setAttribute("aria-disabled", String(page === 0));
    next.setAttribute("aria-disabled", String((page + 1) * 50 >= candidate.companion.total));
    live.textContent = candidate.summary;
    if (focusedRow !== undefined) {
      const target = body.querySelector<HTMLButtonElement>(`button[data-graph-row="${focusedRow}"]`) ?? (page === 0 ? next : previous);
      target.focus({ preventScroll: true });
    }
    return snapshot()!;
  }
  function request(input: Pick<GraphSessionRequest, "operation"> & Partial<GraphSessionRequest>, candidateCamera = camera, candidatePage = page) {
    if (sequence > 0xffffffffffffffffn) throw new RangeError("Graph op_seq exhausted");
    const currentIntent = intent;
    const bytes = encodeGraphSessionRequest({ ...input, instanceId, opSeq: sequence++, revision: sessionRevision });
    return lane.execute(input.operation === 21 ? "render" : "interact", bytes).then(async bytes => {
      sessionRevision = decodeGraphSessionAck(bytes).revision;
      if (input.operation === 15 && candidatePage !== 0) {
        // Step replies carry page zero. Preserve the user's companion page by
        // coalescing that checkpoint with a same-state Rust render, never by
        // manufacturing rows or retaining obsolete row/ref alignments.
        const checkpoint = decodeGraphSessionResult(bytes);
        if (!checkpoint.relayout) throw new XygWasmError("GF_INTERACTION_INVALID", "Relayout reply omitted progress", -3);
        if (sequence > 0xffffffffffffffffn) throw new RangeError("Graph op_seq exhausted");
        bytes = await lane.execute("render", encodeGraphSessionRequest({ instanceId, opSeq: sequence++, revision: checkpoint.revision,
          operation: 21, camera: candidateCamera, page: candidatePage, pageSize: 50 }));
      }
      sessionRevision = decodeGraphSessionAck(bytes).revision;
      if (temporal && currentIntent !== intent) { needsRefresh = true; throw new XygWasmError("GF_INTERACTION_STALE", "Temporal intent superseded the graph reply", -1); }
      const prior = temporalFrame;
      if (acceptedMembership) temporalFrame = acceptedMembership;
      try { return install(bytes, candidateCamera, input.operation === 17 || input.operation === 21 || input.operation === 15 ? candidatePage : 0, input.operation === 15); }
      catch (error) { temporalFrame = prior; throw error; }
    });
  }
  async function computeTime() {
    const state = pendingTime!, current = intent; pendingTime = null;
    const revision = ++timeRevision;
    const baseFrame=new Uint8Array(encodeWasmTemporalGraphFrame(revision,state.cursor,[state.rangeStart,state.rangeEnd],temporalBudget!));
    const contextualFrame=new Uint8Array(FRAME_CONTEXT.header_bytes);contextualFrame.set(baseFrame);const contextView=new DataView(contextualFrame.buffer);contextView.setUint32(4,FRAME_CONTEXT.version,true);contextView.setUint32(8,FRAME_CONTEXT.header_bytes,true);contextView.setBigInt64(FRAME_CONTEXT.window_offset,state.window,true);contextView.setBigUint64(FRAME_CONTEXT.revision_offset,state.revision,true);
    const bytes=await lane.temporalFrame(contextualFrame);
    const membership = decodeWasmTemporalGraphFrame(bytes);
    if (membership.revision !== revision) throw new XygWasmError("GF_INTERACTION_STALE", "Temporal frame revision mismatch", -1);
    // Rust may have advanced while the previous picture stays mounted. Until a
    // matching render is installed, old picking stamps must not be admitted.
    acceptedMembership = membership; needsRefresh = true;
    return { membership, current };
  }
  async function renderTime({ membership, current }: { membership: XygWasmTemporalGraphFrame; current: number }): Promise<XygWasmGraphSnapshot | null> {
    if (disposed || current !== intent) return null;
    const rendered = await lane.execute("render", encodeGraphSessionRequest({ instanceId, opSeq: sequence++,
      revision: sessionRevision, operation: 21, camera, page, pageSize: 50 }));
    sessionRevision = decodeGraphSessionAck(rendered).revision;
    if (disposed || current !== intent) return null;
    const prior = temporalFrame;
    temporalFrame = membership;
    try {
      const value = install(rendered, camera, page);
      if (progressive) {
        continuation = true;
        if (deadline !== null) clearTimeout(deadline);
        deadline = setTimeout(() => report(new XygWasmError("XYG_WASM_TIMEOUT", "Graph continuation exceeded the scheduler wall limit")), XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS);
      }
      return value;
    }
    catch (error) { temporalFrame = prior; throw error; }
  }
  async function applyTime() { return renderTime(await computeTime()); }
  function pumpTemporal() {
    if (!initialized || !pendingTime || busy || temporalPumping || disposed || terminal) return;
    temporalPumping = true; setBusy(true);
    temporalTask = (async () => {
      try {
        while (pendingTime && !disposed && !terminal) {
          const current = intent;
          try { const value = await applyTime(); if (value && !disposed) dispatch("render", value); }
          catch (error) {
            // Transport lifetime failure outranks time-intent supersession.
            if (!disposed && error instanceof XygWasmError && error.code.startsWith("XYG_WASM_")) report(error);
            else if (!disposed && current === intent) { timeKey = null; report(error); }
          }
        }
      } finally { temporalPumping = false; setBusy(false); }
    })();
  }
  function acceptTime(state: XygTemporalState) {
    if (disposed || terminal) return;
    if (state.disposed) { void dispose(); return; }
    const key = `${state.cursor}/${state.rangeStart}/${state.rangeEnd}/${state.window}`;
    if (timeKey === key) return;
    timeKey = key; pendingTime = state; intent++;
    // No checkpoint built for older membership may paint while intent is newer.
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null;
    pumpTemporal();
  }
  // Framing and lane admission happen synchronously. No event is retained by
  // asynchronous work, and no observer runs between choosing a Rust fact and
  // accepting its command locally. Applicability is not a Rust reservation.
  function admit(input: Pick<GraphSessionRequest, "operation"> & Partial<GraphSessionRequest>, kind: "focus" | "select" | "render", candidateCamera = camera, candidatePage = page): Promise<XygWasmGraphSnapshot> {
    if (disposed) throw new XygWasmError("XYG_WASM_DISPOSED", "Graph attachment was disposed");
    if (terminal) throw new XygWasmError("XYG_WASM_DISPOSED", "Graph Worker lifetime ended; mutation outcome may be unknown");
    if (pendingTime || temporalPumping || busy) throw new XygWasmError("XYG_WASM_GRAPH_BUSY", "One graph UI action is already outstanding");
    if (needsRefresh && input.operation !== 21) throw new XygWasmError("GF_INTERACTION_STALE", "Refresh the graph publication before further input", -1);
    const pending = request(input, candidateCamera, candidatePage);
    setBusy(true);
    return pending.then(value => {
      if (!disposed) dispatch(kind, value);
      return value;
    }).catch(error => { report(error); throw error; }).finally(() => setBusy(false));
  }
  function run(input: Pick<GraphSessionRequest, "operation"> & Partial<GraphSessionRequest>, kind: "focus" | "select" | "render", candidateCamera = camera, candidatePage = page): Promise<XygWasmGraphSnapshot> {
    try { return admit(input, kind, candidateCamera, candidatePage); }
    catch (error) { return Promise.reject(error); }
  }
  function submit(input: Pick<GraphSessionRequest, "operation"> & Partial<GraphSessionRequest>, kind: "focus" | "select" | "render") {
    void run(input, kind).catch(() => {});
  }
  const keyDown = (event: KeyboardEvent) => {
    if (disposed || terminal || busy || needsRefresh || !output || event.defaultPrevented || event.repeat || event.altKey || event.shiftKey) return;
    if (["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key) && !event.ctrlKey && !event.metaKey) {
      event.preventDefault(); submit({ operation: 5, direction: ["ArrowRight", "ArrowDown"].includes(event.key) ? 1 : -1 }, "focus");
    } else if (event.key === "Enter") {
      event.preventDefault(); submit({ operation: 7, mode: event.ctrlKey || event.metaKey ? 2 : 0 }, "select");
    } else if (event.key === "Escape" && !event.ctrlKey && !event.metaKey) {
      const applicable = output.clearAction.applicable;
      try {
        const accepted = admit({ operation: 4 }, "select");
        if (applicable) event.preventDefault();
        void accepted.catch(() => {});
      } catch (error) { report(error); }
    }
  };
  // Native dispatch-local coordinates are authoritative at browser precision.
  // Rust alone picks. Public ancestry guards are conservative, not proof that
  // closed shadow roots contain no transforms.
  function clickCoordinates(event: MouseEvent): readonly [number, number] | null {
    const canvas = painter.canvas, win = doc.defaultView;
    if (!event.isTrusted || event.target !== canvas || !win || !canvas.isConnected || canvas.scrollLeft || canvas.scrollTop) return null;
    const zoom = (canvas as HTMLCanvasElement & { readonly currentCSSZoom?: number }).currentCSSZoom;
    const offsetX = event.offsetX, offsetY = event.offsetY;
    if (!Number.isFinite(zoom) || zoom !== 1 || !Number.isFinite(offsetX) || !Number.isFinite(offsetY)) return null;
    for (let element: Element | null = canvas; element;) {
      const style = win.getComputedStyle(element);
      // Motion-path distance/rotation/anchor are separate from transform's
      // matrix. Reject every active path, including on shadow ancestors.
      if (style.offsetPath !== "none") return null;
      if (style.perspective !== "none" || style.rotate !== "none" || style.scale !== "none" || style.translate !== "none") return null;
      if (style.transform !== "none") {
        const matrix = new DOMMatrixReadOnly(style.transform);
        if (!matrix.is2D || matrix.b !== 0 || matrix.c !== 0 || matrix.a <= 0 || matrix.d <= 0) return null;
      }
      const root = element.getRootNode();
      // Slots supply displayed ancestors before the light-DOM parent does.
      element = element.assignedSlot ?? element.parentElement ?? (root instanceof ShadowRoot ? root.host : null);
    }
    const style = win.getComputedStyle(canvas);
    if (style.objectFit !== "fill") return null;
    const left = parseFloat(style.paddingLeft);
    const top = parseFloat(style.paddingTop);
    const horizontal = parseFloat(style.borderLeftWidth) + left + parseFloat(style.borderRightWidth) + parseFloat(style.paddingRight);
    const vertical = parseFloat(style.borderTopWidth) + top + parseFloat(style.borderBottomWidth) + parseFloat(style.paddingBottom);
    const width = parseFloat(style.width), height = parseFloat(style.height);
    const borderWidth = width + (style.boxSizing === "border-box" ? 0 : horizontal);
    const borderHeight = height + (style.boxSizing === "border-box" ? 0 : vertical);
    const contentWidth = borderWidth - horizontal, contentHeight = borderHeight - vertical;
    if (![left, top, borderWidth, borderHeight, contentWidth, contentHeight].every(Number.isFinite) ||
        contentWidth <= 0 || contentHeight <= 0) return null;
    // offsetX/Y originate at the padding edge, excluding the border already.
    // Never infer zoom or invert a transformed bounding rectangle here.
    const x = offsetX - left, y = offsetY - top;
    if (x < 0 || y < 0 || x >= contentWidth || y >= contentHeight) return null;
    return [x * camera[4] / contentWidth, y * camera[5] / contentHeight];
  }
  const primaryClick = (event: MouseEvent) => {
    if (disposed || terminal || busy || needsRefresh || !output || event.defaultPrevented || event.altKey ||
        event.button !== 0 || event.buttons !== 0 || event.detail !== 1) return;
    const coordinates = clickCoordinates(event);
    if (!coordinates) return;
    const mode = event.ctrlKey || event.metaKey ? 2 : event.shiftKey ? 1 : 0;
    try {
      const accepted = admit({ operation: 1, coordinates, mode }, "select");
      event.preventDefault(); surface.focus({ preventScroll: true });
      void accepted.catch(() => {});
    } catch (error) { report(error); }
  };
  const previousPage = () => { if (!disposed && !busy && !needsRefresh && page > 0) void run({ operation: 17, page: page - 1, pageSize: 50 }, "render", camera, page - 1).catch(() => {}); };
  const nextPage = () => { if (!disposed && !busy && !needsRefresh && output && (page + 1) * 50 < output.companion.total) void run({ operation: 17, page: page + 1, pageSize: 50 }, "render", camera, page + 1).catch(() => {}); };
  painter.canvas.addEventListener("click", primaryClick);
  surface.addEventListener("keydown", keyDown); previous.addEventListener("click", previousPage); next.addEventListener("click", nextPage);
  if (temporal) {
    try { unsubscribeTime = temporal.controller.subscribeState(acceptTime); acceptTime(temporal.controller.state); }
    catch (error) { void dispose(); throw error; }
  }
  setBusy(true);
  if (progressive) deadline = setTimeout(() => {
    report(new XygWasmError("XYG_WASM_TIMEOUT", "Graph continuation exceeded the scheduler wall limit"));
  }, XYG_WASM_GRAPH_DEFAULT_MAX_WALL_MS);
  const ready = (async () => {
    const ack = await lane.execute("open", opening!); opening = null; decodeGraphSessionAck(ack);
    if (disposed) throw new XygWasmError("XYG_WASM_DISPOSED", "Graph attachment was disposed");
    if (temporalCreate) {
      await lane.temporalCreate(temporalCreate); temporalCreate = null;
      // Bind itself renders in Rust. Publish initial membership first so even
      // its unpainted layout/pick construction sees the temporal world.
      const initialTime = await computeTime();
      const bound = await lane.execute("interact", encodeGraphSessionRequest({ instanceId, opSeq: sequence++, revision: sessionRevision, operation: 18, temporal: true }));
      sessionRevision = decodeGraphSessionAck(bound).revision;
      const initial = await renderTime(initialTime); if (initial) return initial;
      while (pendingTime && !disposed) {
        const value = await applyTime(); if (value) return value;
      }
      throw new XygWasmError("XYG_WASM_DISPOSED", "Temporal graph closed before initial paint");
    }
    return await request({ operation: 21, camera, page: 0, pageSize: 50 });
  })().then(value => { if (!disposed) dispatch("render", value); return value; }).catch(async error => { report(error); await dispose(); throw error; }).finally(() => {
    initialized = true; setBusy(false);
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null;
    if (continuation && !disposed) frame = requestAnimationFrame(() => { frame = null; scheduleContinuation(); });
  });
  // Do not await ready in cleanup: its failure path itself awaits disposal.
  function dispose(): Promise<void> {
    if (disposal) return disposal;
    disposed = true; intent++; pendingTime = null; unsubscribeTime?.(); unsubscribeTime = null; stopContinuation();
    for (const resolve of idleWaiters) resolve(); idleWaiters.clear();
    painter.canvas.removeEventListener("click", primaryClick);
    surface.removeEventListener("keydown", keyDown); previous.removeEventListener("click", previousPage); next.removeEventListener("click", nextPage);
    for (const [name, value] of surfaceAttributes) { if (value === null) surface.removeAttribute(name); else surface.setAttribute(name, value); }
    // Suppress DOM/events immediately, drain commands before CLOSE and release.
    output = null; opening = null;
    painter.dispose(); surface.remove(); companion.remove();
    disposal = lane.close(); return disposal;
  }
  return Object.freeze({ ready, snapshot, dispose,
    async freeze(freezeOptions:{timezone:string;window?:readonly [bigint,bigint]|null;budgetBytes?:bigint}) {
      if(disposed||terminal||busy||pendingTime||temporalPumping||needsRefresh||!output||!acceptedMembership)throw new XygWasmError('GF_INTERACTION_STALE','Freeze requires an idle accepted temporal publication',-1);
      const zone=new TextEncoder().encode(freezeOptions.timezone);if(zone.length>128)throw new RangeError('timezone too long');
      const color=painter.focusRgba();
      const request=new Uint8Array(64+zone.length+16),v=new DataView(request.buffer);request.set([88,89,70,88]);v.setUint32(4,1,true);v.setUint32(12,sessionRevision,true);
      v.setBigUint64(24,acceptedMembership.revision,true);if(freezeOptions.window){if(freezeOptions.window.length!==2||freezeOptions.window.some(n=>typeof n!=='bigint'||n<-(1n<<63n)||n>=(1n<<63n)))throw new RangeError('window requires exact i64 endpoints');v.setUint32(20,1,true);v.setBigInt64(32,freezeOptions.window[0],true);v.setBigInt64(40,freezeOptions.window[1],true);}
      v.setBigUint64(48,freezeOptions.budgetBytes??384n*1024n*1024n,true);v.setBigUint64(56,BigInt(zone.length),true);request.set(zone,64);for(let i=0;i<4;i++)v.setFloat32(64+zone.length+i*4,Number(color[i]),true);
      setBusy(true);
      try{return issuedFrozenGraph(new Uint8Array(await lane.freeze(request)));}finally{setBusy(false);}
    },
    async whenIdle() {
      await ready;
      while (!disposed && !terminal && (busy || pendingTime || temporalPumping)) await new Promise<void>(resolve => idleWaiters.add(resolve));
      if (terminalFailure) throw terminalFailure;
      await temporalTask;
    },
    pinFocused(pinned: boolean) {
      if (typeof pinned !== "boolean" || !output?.focusAction.pinEligible || output.focusAction.refs.length !== 1) return Promise.reject(new TypeError("A pinnable focused node and boolean are required"));
      return run({ operation: 13, pinned, refs: output.focusAction.refs }, "render");
    },
    refreshRender(nextCamera?: XygWasmGraphCamera) {
      const target = nextCamera === undefined ? camera : cameraCopy(nextCamera);
      return run({ operation: 21, camera: target, page, pageSize: 50 }, "render", target);
    },
  });
}
