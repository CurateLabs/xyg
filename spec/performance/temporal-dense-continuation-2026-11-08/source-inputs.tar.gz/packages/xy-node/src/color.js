/**
 * Minimal CSS / numeric color helpers for Node host composition.
 * Ships constant CSS strings, packed RGBA8 for direct_rgba, or continuous
 * unit-f32 channels for numeric encodings (Python `_ship_channels` parity).
 */
import { pointer, xyCssCheck, xyCssColorRgba, xySceneArtistAlphaCss, xyCssIsFunctional, xyContinuousDomain, xyDirectRgbaAdmit, xyClipQuantizeU8, xyQuantizeUnitU8, xyPaletteRowsRgba8, xyLiteralColorRgbaF64, xyCategoricalPalette, xyCategoricalPaletteMapResolve, xyColorChannelDirectRgbaF64Continuous, xyColorChannelDirectRgbaF64Categorical, xyColormapIsBuiltin, xyColormapResolvedStopsAdmit, xyColormapCustomStopsResolveGradient, xyColormapCustomStopsResolveList, xySizeRangeAdmit, xyArrayIsCategorical, xyRealNumericDtypeAdmit } from "./native.js";
import { DEFAULT_MARK_COLOR, DEFAULT_PALETTE, colormapNamedStops } from "./encode.js";
import { factorizeCategories } from "./factorize.js";

function u8Ptr(view) {
  return pointer(view, "uint8_t *");
}

function f64Ptr(view) {
  return pointer(view, "double *");
}

/**
 * Resolve a CSS color to RGBA8 via `xyg_css_color_rgba`. Named colors,
 * `hsl()`, `none`, and the never-invisible fallback match Python Scene/raster.
 *
 * @param {string} css
 * @param {number} [opacity]
 * @returns {Uint8Array}
 */
export function cssColorRgba8(css, opacity = 1) {
  const encoded = new TextEncoder().encode(String(css ?? ""));
  const out = new Uint8Array(4);
  const code = xyCssColorRgba(
    encoded.length ? u8Ptr(encoded) : null,
    BigInt(encoded.length),
    Number(opacity),
    u8Ptr(out),
  );
  if (code !== 0) throw new RangeError("native css color resolver rejected the color");
  return out;
}

/**
 * Apply an artist alpha to one authored CSS paint via
 * `xyg_scene_artist_alpha_css` (ABI 385): the paint's RGBA8 with its alpha
 * replaced by `artist`; `none` / `transparent` stay absent.
 *
 * @param {string} css
 * @param {number} artist
 * @returns {Uint8Array}
 */
export function sceneArtistAlphaCss(css, artist) {
  const encoded = new TextEncoder().encode(String(css ?? ""));
  const out = new Uint8Array(4);
  const code = xySceneArtistAlphaCss(
    encoded.length ? u8Ptr(encoded) : null,
    BigInt(encoded.length),
    Number(artist),
    u8Ptr(out),
  );
  if (code !== 0) throw new RangeError("native artist-alpha resolver rejected the paint");
  return out;
}

/**
 * Parse `#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, or `rgb(a)(...)` into
 * `[r,g,b,a]` in 0..1. Returns null when unrecognized. Named colors, `hsl()`,
 * and `none` go through `cssColorRgba8` / `xyg_css_color_rgba`.
 *
 * @param {string} css
 * @returns {[number, number, number, number]|null}
 */
export function parseCssColor(css) {
  if (css == null) return null;
  const s = String(css).trim();
  if (s.startsWith("#")) {
    const hex = s.slice(1);
    let r;
    let g;
    let b;
    let a = 255;
    if (hex.length === 3 || hex.length === 4) {
      r = parseInt(hex[0] + hex[0], 16);
      g = parseInt(hex[1] + hex[1], 16);
      b = parseInt(hex[2] + hex[2], 16);
      if (hex.length === 4) a = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 6 || hex.length === 8) {
      r = parseInt(hex.slice(0, 2), 16);
      g = parseInt(hex.slice(2, 4), 16);
      b = parseInt(hex.slice(4, 6), 16);
      if (hex.length === 8) a = parseInt(hex.slice(6, 8), 16);
    } else {
      return null;
    }
    if (![r, g, b, a].every((v) => Number.isFinite(v))) return null;
    return [r / 255, g / 255, b / 255, a / 255];
  }
  const m = /^rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)(?:\s*,\s*([0-9.]+))?\s*\)$/i.exec(
    s,
  );
  if (m) {
    const r = Number(m[1]);
    const g = Number(m[2]);
    const b = Number(m[3]);
    const a = m[4] == null ? 1 : Number(m[4]);
    if (![r, g, b, a].every((v) => Number.isFinite(v))) return null;
    return [
      Math.min(255, Math.max(0, r)) / 255,
      Math.min(255, Math.max(0, g)) / 255,
      Math.min(255, Math.max(0, b)) / 255,
      Math.min(1, Math.max(0, a)),
    ];
  }
  return null;
}

/**
 * Pack CSS colors into a contiguous RGBA8 buffer (one pixel per color).
 *
 * @param {string[]} colors
 * @returns {Uint8Array}
 */
export function cssColorsToRgba8(colors) {
  const out = new Uint8Array(colors.length * 4);
  for (let i = 0; i < colors.length; i += 1) {
    out.set(cssColorRgba8(colors[i]), i * 4);
  }
  return out;
}

/** Unambiguous `#` / `rgb()` / `hsl()` paint syntax (ABI 213). */
export function cssIsFunctional(css) {
  const encoded = new TextEncoder().encode(String(css ?? ""));
  const code = Number(
    xyCssIsFunctional(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code < 0) throw new RangeError("invalid css-is-functional request");
  return code === 1;
}

/** Continuous color/size domain (ABI 213). */
export function continuousDomain(values) {
  const xv = values instanceof Float64Array ? values : Float64Array.from(values, Number);
  const lo = new Float64Array(1);
  const hi = new Float64Array(1);
  const code = Number(
    xyContinuousDomain(
      xv.length ? f64Ptr(xv) : 0,
      BigInt(xv.length),
      f64Ptr(lo),
      f64Ptr(hi),
    ),
  );
  if (code !== 0) throw new RangeError("invalid continuous-domain request");
  return [lo[0], hi[0]];
}

/** Admit scatter size pixel range endpoints (ABI 350). */
export function sizeRangeAdmit(lo, hi) {
  const outLo = new Float64Array(1);
  const outHi = new Float64Array(1);
  const code = Number(
    xySizeRangeAdmit(Number(lo), Number(hi), f64Ptr(outLo), f64Ptr(outHi)),
  );
  if (code === -1) {
    throw new RangeError("size_range must contain exactly two finite pixel values");
  }
  if (code === -2 || code === -3) {
    throw new RangeError("size_range must be non-negative and ordered low-to-high");
  }
  if (code !== 0) throw new RangeError("invalid size-range-admit request");
  return [outLo[0], outHi[0]];
}

/** Whether a column uses categorical color resolution (ABI 351). */
export function arrayIsCategorical(dtypeKind, objectRealNumeric = -1) {
  const code = Number(xyArrayIsCategorical(Number(dtypeKind) & 0xff, Number(objectRealNumeric)));
  if (code < 0) throw new RangeError("invalid array-is-categorical request");
  return code === 1;
}

/** Reject boolean/complex dtype kinds before real f64 coercion (ABI 352). */
export function realNumericDtypeAdmit(dtypeKind) {
  const code = Number(xyRealNumericDtypeAdmit(Number(dtypeKind) & 0xff));
  if (code === -1) {
    throw new RangeError("values must be real numeric, not boolean");
  }
  if (code === -2) {
    throw new RangeError("values must be real numeric");
  }
  if (code !== 0) throw new RangeError("invalid real-numeric-dtype-admit request");
}

/** Admit per-point RGB/RGBA in `[0, 1]` as contiguous Nx4 (ABI 213). */
export function directRgbaAdmit(values, components) {
  const xv = values instanceof Float64Array ? values : Float64Array.from(values, Number);
  const nComp = Number(components);
  if (nComp !== 3 && nComp !== 4) {
    throw new RangeError("direct RGB/RGBA colors must be 3 or 4 components");
  }
  if (xv.length % nComp !== 0) {
    throw new RangeError("direct RGB/RGBA colors must be a multiple of the component count");
  }
  const n = xv.length / nComp;
  const probed = xyDirectRgbaAdmit(n ? f64Ptr(xv) : 0, BigInt(n), BigInt(nComp), 0, 0);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  if (probed === USIZE_MAX_64) {
    throw new RangeError("direct RGB/RGBA colors must contain finite values between 0 and 1");
  }
  const count = Number(probed);
  if (count === 0) return new Float64Array(0);
  const out = new Float64Array(count);
  const written = xyDirectRgbaAdmit(
    n ? f64Ptr(xv) : 0,
    BigInt(n),
    BigInt(nComp),
    f64Ptr(out),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("direct RGB/RGBA colors must contain finite values between 0 and 1");
  }
  return out;
}

/** Clip unit f64 to `[0, 1]`, scale by 255, and quantize to u8 (ABI 251). */
export function clipQuantizeU8(values) {
  const xv = values instanceof Float64Array ? values : Float64Array.from(values ?? [], Number);
  const out = new Uint8Array(xv.length);
  const code = Number(
    xyClipQuantizeU8(
      xv.length ? f64Ptr(xv) : 0,
      BigInt(xv.length),
      out.length ? u8Ptr(out) : 0,
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid clip-quantize-u8 request");
  if (code !== 1) return null;
  return out;
}

/** Normalize over `[lo, hi]` then ABI 341 clip-quantize (Python `quantize_unit_u8`). */
export function quantizeUnitU8(values, lo, hi) {
  const n = values == null ? 0 : values.length;
  const out = new Uint8Array(n);
  if (n === 0) {
    return out;
  }
  const src = values instanceof Float64Array ? values : Float64Array.from(values);
  const code = xyQuantizeUnitU8(f64Ptr(src), BigInt(n), lo, hi, u8Ptr(out));
  if (code === -2) throw new RangeError("invalid quantize-unit-u8 request");
  if (code !== 1) throw new RangeError("invalid quantize-unit-u8 request");
  return out;
}

function packUtf8Strings(texts) {
  const encoded = texts.map((text) => new TextEncoder().encode(String(text)));
  const lens = Uint32Array.from(encoded.map((item) => item.length));
  const total = lens.reduce((sum, len) => sum + len, 0);
  const packed = new Uint8Array(total);
  let at = 0;
  for (const item of encoded) {
    packed.set(item, at);
    at += item.length;
  }
  return { lens, packed };
}

function unpackUtf8Strings(lens, packed, count) {
  const dec = new TextDecoder();
  const out = [];
  let at = 0;
  for (let i = 0; i < count; i += 1) {
    const length = Number(lens[i]);
    out.push(dec.decode(packed.subarray(at, at + length)));
    at += length;
  }
  return out;
}

function u32Ptr(view) {
  return pointer(view, "uint32_t *");
}

/** Indexed palette rows as straight-alpha RGBA8 (ABI 342). */
export function paletteRowsRgba8(palette, rows) {
  const src = palette?.length ? palette.map((entry) => String(entry)) : [];
  if (!src.length) {
    throw new RangeError("paletteRowsRgba8 requires at least one entry");
  }
  const n = Math.max(1, Math.floor(Number(rows)));
  const { lens, packed } = packUtf8Strings(src);
  const out = new Uint8Array(n * 4);
  const unresolved = new Uint32Array(1);
  const entryFlags = new Uint8Array(src.length);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyPaletteRowsRgba8(
    lens.length ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(src.length),
    BigInt(n),
    u8Ptr(out),
    BigInt(out.length),
    u32Ptr(unresolved),
    u8Ptr(entryFlags),
    BigInt(entryFlags.length),
  );
  if (written === USIZE_MAX_64) {
    throw new RangeError("invalid palette-rows-rgba8 request");
  }
  return out;
}

/** Functional CSS color column to canonical f64 RGBA rows (ABI 344). */
export function literalColorRgbaF64(colors) {
  const src = colors?.length ? colors.map((entry) => String(entry)) : [];
  if (!src.length) {
    return null;
  }
  const { lens, packed } = packUtf8Strings(src);
  const out = new Float64Array(src.length * 4);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyLiteralColorRgbaF64(
    lens.length ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(src.length),
    f64Ptr(out),
    BigInt(out.length),
  );
  if (written === USIZE_MAX_64) {
    return null;
  }
  return out;
}

/** Repeat base palette colors for categorical wire specs (ABI 347). */
export function categoricalPalette(palette, nCategories) {
  const src = palette?.length ? palette.map((entry) => String(entry)) : [];
  if (!src.length) {
    throw new RangeError("categoricalPalette requires at least one entry");
  }
  const n = Math.floor(Number(nCategories));
  if (!(n > 0)) {
    throw new RangeError("categoricalPalette requires a positive category count");
  }
  const { lens, packed } = packUtf8Strings(src);
  const outLens = new Uint32Array(n);
  const outCap = src.reduce((sum, entry) => sum + entry.length, 0) * n;
  const outTexts = new Uint8Array(Math.max(outCap, 1));
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyCategoricalPalette(
    lens.length ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(src.length),
    BigInt(n),
    u32Ptr(outLens),
    u8Ptr(outTexts),
    BigInt(outTexts.length),
  );
  if (written === USIZE_MAX_64) {
    throw new RangeError("invalid categorical-palette request");
  }
  return unpackUtf8Strings(outLens, outTexts, n);
}

/** Resolve one shipped color per category from a label→color map (ABI 347). */
export function categoricalPaletteMapResolve(categories, paletteMap, defaultPalette = DEFAULT_PALETTE) {
  const catTexts = categories?.length ? categories.map((entry) => String(entry)) : [];
  const n = catTexts.length;
  if (n === 0) {
    return { colors: [], unmappedCount: 0, mapExhausted: false };
  }
  const { lens: catLens, packed: catPacked } = packUtf8Strings(catTexts);
  const mapKeys = paletteMap ? Object.keys(paletteMap) : [];
  const mapValues = mapKeys.map((key) => String(paletteMap[key]));
  const { lens: keyLens, packed: keyPacked } = packUtf8Strings(mapKeys);
  const { lens: valueLens, packed: valuePacked } = packUtf8Strings(mapValues);
  const defaults = defaultPalette?.length ? defaultPalette.map((entry) => String(entry)) : [];
  const { lens: defLens, packed: defPacked } = packUtf8Strings(defaults);
  const outLens = new Uint32Array(n);
  const outCap = [...catTexts, ...mapValues, ...defaults].reduce((sum, entry) => sum + entry.length, 0) + 64;
  const outTexts = new Uint8Array(Math.max(outCap, 1));
  const unmapped = new Uint32Array(1);
  const exhausted = new Uint32Array(1);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyCategoricalPaletteMapResolve(
    u32Ptr(catLens),
    catPacked.length ? u8Ptr(catPacked) : 0,
    BigInt(catPacked.length),
    BigInt(n),
    mapKeys.length ? u32Ptr(keyLens) : 0,
    keyPacked.length ? u8Ptr(keyPacked) : 0,
    BigInt(keyPacked.length),
    mapValues.length ? u32Ptr(valueLens) : 0,
    valuePacked.length ? u8Ptr(valuePacked) : 0,
    BigInt(valuePacked.length),
    BigInt(mapKeys.length),
    defaults.length ? u32Ptr(defLens) : 0,
    defPacked.length ? u8Ptr(defPacked) : 0,
    BigInt(defPacked.length),
    BigInt(defaults.length),
    u32Ptr(outLens),
    u8Ptr(outTexts),
    BigInt(outTexts.length),
    u32Ptr(unmapped),
    u32Ptr(exhausted),
  );
  if (written === USIZE_MAX_64) {
    throw new RangeError("invalid categorical-palette-map-resolve request");
  }
  return {
    colors: unpackUtf8Strings(outLens, outTexts, n),
    unmappedCount: Number(unmapped[0]),
    mapExhausted: Boolean(exhausted[0]),
  };
}

/** Sample a continuous color channel to canonical f64 RGBA rows (ABI 348). */
export function colorChannelDirectRgbaF64Continuous(values, domain, colormap) {
  const vals = values instanceof Float64Array ? values : Float64Array.from(values, Number);
  const lo = Number(domain[0]);
  const hi = Number(domain[1]);
  let stops;
  if (typeof colormap === "string") {
    stops = colormapNamedStops(colormap);
  } else {
    stops = Uint8Array.from(colormap);
  }
  const out = new Float64Array(vals.length * 4);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyColorChannelDirectRgbaF64Continuous(
    f64Ptr(vals),
    BigInt(vals.length),
    lo,
    hi,
    u8Ptr(stops),
    BigInt(stops.length / 3),
    f64Ptr(out),
    BigInt(out.length),
  );
  if (written === USIZE_MAX_64) {
    throw new RangeError("invalid color-channel-direct-rgba-f64-continuous request");
  }
  return out;
}

/** Sample a categorical color channel to canonical f64 RGBA rows (ABI 348). */
export function colorChannelDirectRgbaF64Categorical(codes, palette) {
  const src = palette?.length ? palette.map((entry) => String(entry)) : [];
  if (!src.length) {
    throw new RangeError("colorChannelDirectRgbaF64Categorical requires a palette");
  }
  const codeArr = codes instanceof Uint32Array ? codes : Uint32Array.from(codes, Number);
  const { lens, packed } = packUtf8Strings(src);
  const out = new Float64Array(codeArr.length * 4);
  const USIZE_MAX_64 = (1n << 64n) - 1n;
  const written = xyColorChannelDirectRgbaF64Categorical(
    u32Ptr(codeArr),
    BigInt(codeArr.length),
    u32Ptr(lens),
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(src.length),
    f64Ptr(out),
    BigInt(out.length),
  );
  if (written === USIZE_MAX_64) {
    throw new RangeError("invalid color-channel-direct-rgba-f64-categorical request");
  }
  return out;
}

/** True when `name` is a built-in colormap, including `_r` variants (ABI 349). */
export function colormapIsBuiltin(name) {
  const encoded = new TextEncoder().encode(String(name ?? ""));
  const ok = Number(xyColormapIsBuiltin(encoded.length ? u8Ptr(encoded) : null, BigInt(encoded.length)));
  if (ok < 0) throw new RangeError("colormapIsBuiltin requires a UTF-8 name");
  return ok === 1;
}

function unpackRgbStops(flat, count) {
  const rows = [];
  for (let i = 0; i < count; i += 1) {
    const base = i * 3;
    rows.push([flat[base], flat[base + 1], flat[base + 2]]);
  }
  return rows;
}

/** Resolve custom colormap stops from CSS linear-gradient (ABI 349). */
export function colormapCustomStopsResolveGradient(css) {
  const encoded = new TextEncoder().encode(String(css ?? ""));
  const out = new Uint8Array(256 * 3);
  const code = Number(
    xyColormapCustomStopsResolveGradient(
      encoded.length ? u8Ptr(encoded) : null,
      BigInt(encoded.length),
      u8Ptr(out),
      BigInt(out.length),
    ),
  );
  if (code <= 0) throw new RangeError(`colormap gradient resolve failed (${code})`);
  return unpackRgbStops(out, code);
}

/** Resolve custom colormap stops from CSS color strings (ABI 349). */
export function colormapCustomStopsResolveList(colors, positions) {
  const css = colors.map((color) => String(color));
  const pos = Float64Array.from(positions, (value) => (value == null ? Number.NaN : Number(value)));
  const { lens, packed } = packUtf8Strings(css);
  const out = new Uint8Array(256 * 3);
  const code = Number(
    xyColormapCustomStopsResolveList(
      u32Ptr(lens),
      packed.length ? u8Ptr(packed) : null,
      BigInt(packed.length),
      f64Ptr(pos),
      BigInt(css.length),
      u8Ptr(out),
      BigInt(out.length),
    ),
  );
  if (code <= 0) throw new RangeError(`colormap list resolve failed (${code})`);
  return unpackRgbStops(out, code);
}

/** Return stop count when `stops` is canonical wire RGB, else 0 (ABI 349). */
export function colormapResolvedStopsAdmit(stops) {
  const flat = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (!flat.length || flat.length % 3 !== 0) return 0;
  return Number(xyColormapResolvedStopsAdmit(u8Ptr(flat), BigInt(flat.length / 3)));
}

export const CSS_ERROR_REASONS = {
  [-1]: "is empty",
  [-2]: "contains an unsafe character (';', '{', '}', '</', or a control character)",
  [-3]: "has unbalanced quotes or parentheses",
  [-4]: "is not a valid hex color (use #rgb, #rgba, #rrggbb, or #rrggbbaa)",
  [-5]: "is not valid color syntax",
  [-6]: "is not a recognized CSS color name",
  [-7]: "has an invalid number",
  [-8]: "has an unknown unit",
  [-9]: "uses an unknown function",
  [-10]: "is not a valid CSS property name",
};

const CSS_KIND_COLOR = 1;

/**
 * Strictly admit one CSS `<color>` through the shared native grammar (Python
 * `_validate.css_color` parity, same wording). Returns the trimmed string.
 */
export function cssColorAdmit(value, label) {
  if (typeof value !== "string") throw new RangeError(`${label} must be a CSS color string`);
  const bytes = new TextEncoder().encode(value);
  const status = Number(
    xyCssCheck(CSS_KIND_COLOR, 0, 0n, bytes.length ? u8Ptr(bytes) : 0, BigInt(bytes.length), new Float32Array(4)),
  );
  if (status <= 0) {
    throw new RangeError(`${label} '${value}' ${CSS_ERROR_REASONS[status] ?? "is not valid CSS"}`);
  }
  return value.trim();
}

/**
 * Resolve a colormap authoring input (Python `channels.resolve_colormap`
 * parity): a built-in name (kept as the name), a `linear-gradient(...)`
 * string, a sequence of 2-256 CSS colors (optionally `[position, color]`
 * pairs), or canonical RGB stop rows. Rust (ABI 349) owns every admission and
 * resampling decision; this only dispatches to it.
 *
 * @param {string|Array} value
 * @param {string} [label]
 * @returns {string|number[][]}
 */
export function resolveColormap(value, label = "colormap") {
  if (typeof value === "string" && colormapIsBuiltin(value)) return value;
  if (typeof value === "string") {
    if (!value.trim().toLowerCase().startsWith("linear-gradient(")) {
      throw new RangeError(
        `unknown colormap ${JSON.stringify(value)}; expected a built-in name, a 'linear-gradient(...)' string, or a sequence of CSS colors`,
      );
    }
    return colormapCustomStopsResolveGradient(value);
  }
  if (!Array.isArray(value) && !ArrayBuffer.isView(value)) {
    throw new RangeError(
      `${label} must be a built-in name, a 'linear-gradient(...)' string, or a sequence of CSS colors`,
    );
  }
  const items = [...value];
  const numericRows = items.length > 0
    && items.every((row) => (Array.isArray(row) || ArrayBuffer.isView(row))
      && row.length === 3 && [...row].every((c) => typeof c === "number"));
  if (numericRows) {
    // Reject before packing: Uint8Array.from would wrap 256 -> 0 or 1.5 -> 1.
    const flatRows = items.flatMap((row) => [...row]);
    for (const c of flatRows) {
      if (!Number.isInteger(c) || c < 0 || c > 255) {
        const text = Number.isNaN(c) ? "nan" : !Number.isFinite(c) ? (c > 0 ? "inf" : "-inf") : String(c);
        throw new RangeError(`${label} stops must be integers in 0..255, got ${text}`);
      }
    }
    const flat = Uint8Array.from(flatRows);
    if (colormapResolvedStopsAdmit(flat) > 0) return items.map((row) => [...row].map(Number));
  }
  if (items.length < 2 || items.length > 256) {
    throw new RangeError(`${label} must have between 2 and 256 color stops, got ${items.length}`);
  }
  const colors = [];
  const positions = [];
  for (const item of items) {
    if (Array.isArray(item)) {
      if (item.length !== 2) throw new RangeError(`${label} stops must be a color or [position, color]`);
      positions.push(item[0]);
      colors.push(item[1]);
    } else {
      positions.push(null);
      colors.push(item);
    }
  }
  return colormapCustomStopsResolveList(colors, positions);
}

function flattenRgbRows(raw, n) {
  if (raw.length !== n) return null;
  const first = raw[0];
  if (!Array.isArray(first) && !ArrayBuffer.isView(first)) return null;
  const components = first.length;
  if (components !== 3 && components !== 4) return null;
  const flat = new Float64Array(n * components);
  for (let i = 0; i < n; i += 1) {
    const row = raw[i];
    if (row == null || row.length !== components) return null;
    for (let c = 0; c < components; c += 1) flat[i * components + c] = Number(row[c]);
  }
  return { flat, components };
}

/**
 * Resolve a color encoding to a wire color channel for the Node figure MVP.
 *
 * @param {string|string[]|number[]|TypedArray|null|undefined} color
 * @param {number} n
 * @param {string} [fallback]
 * @returns {{mode: string, constant?: string, rgba?: Uint8Array, values?: Float64Array, domain?: number[], colormap?: string, codes?: Uint8Array|Uint32Array, categories?: string[], palette?: string[]}|null}
 */
export function resolveColorChannel(color, n, fallback = DEFAULT_MARK_COLOR) {
  if (color == null) {
    return { mode: "constant", constant: fallback };
  }
  if (typeof color === "string") {
    return { mode: "constant", constant: color };
  }
  if (typeof color === "number") {
    if (!Number.isFinite(color)) {
      throw new RangeError("color scalar must be finite");
    }
    const values = Float64Array.from({ length: n }, () => color);
    return {
      mode: "continuous",
      values,
      domain: continuousDomain(new Float64Array([color])),
      colormap: "viridis",
    };
  }
  if (Array.isArray(color) || ArrayBuffer.isView(color)) {
    const raw = Array.isArray(color) ? color : [...color];
    const rgb = flattenRgbRows(raw, n);
    if (rgb) {
      const packed = directRgbaAdmit(rgb.flat, rgb.components);
      return { mode: "direct_rgba", rgba: clipQuantizeU8(packed) };
    }
    if (raw.length !== n) {
      throw new RangeError(`color length ${raw.length} != n=${n}`);
    }
    const numeric = raw.every((v) => typeof v !== "string" && Number.isFinite(Number(v)));
    if (numeric) {
      const values = Float64Array.from(raw, Number);
      return {
        mode: "continuous",
        values,
        domain: continuousDomain(values),
        colormap: "viridis",
      };
    }
    if (raw.every((v) => typeof v === "string" && cssIsFunctional(v))) {
      const packed = literalColorRgbaF64(raw);
      if (packed) {
        return { mode: "direct_rgba", rgba: clipQuantizeU8(packed) };
      }
    }
    return factorizeCategories(raw);
  }
  return { mode: "constant", constant: String(color) };
}
