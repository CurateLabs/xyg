"""Thin binary adapters for Rust-owned retained geographic sources and sessions.

This internal module exposes framing and lifecycle helpers, not a chart API.
SceneData views/copies and painters must be dropped before disposing their lease.
"""

from __future__ import annotations

import asyncio
import ctypes
import struct
import threading
import traceback
import weakref
from collections.abc import Awaitable, Callable
from contextlib import contextmanager, suppress
from typing import Any, Protocol

import numpy as np

HEADER = 256
MAX_PACKET = 32 * 1024 * 1024
MAX_PROCESSOR = 128 * 1024 * 1024

# Bounded active calls observe matching native dispatches across threads and
# nested wrappers; no response history survives a closed capture.
_ACTIVE_NATIVE_MUTATION_CAPTURES = 0
_NATIVE_MUTATION_CAPTURE_LOCK = threading.Lock()
_NATIVE_MUTATION_CAPTURES: set = set()


class _NativeMutationCapture:
    def __init__(self, request, purpose):
        self.purpose = purpose
        self.request: bytes | None = bytes(request)
        self.reply = self.error = self.status = None
        self.latest = None

    def begin(self, request):
        if request == self.request:
            self.latest = object()
            self.reply = self.error = self.status = None
            return self.latest
        return None

    def record(self, token, *, reply=None, error=None, status=None):
        if token is not None and token is self.latest:
            self.reply, self.error, self.status = reply, error, status

    def outcome(self, returned):
        with _NATIVE_MUTATION_CAPTURE_LOCK:
            if self.reply is not None and isinstance(returned, bytes) and returned == self.reply:
                return dict(reply=self.reply)
            if returned is self.error and self.error is not None:
                return dict(status=self.status)
            return None


def scene_version() -> int:
    """The Rust-owned canonical Scene schema version; readers never restate it."""
    from . import _native

    return _native.scene_version()


@contextmanager
def _capture_native_mutation(request):
    """Exact per-call native outcome, held through settlement and reset in finally."""
    command = struct.unpack_from("<I", request, 8)[0] if len(request) >= 12 else 0
    if not (
        (len(request) == 264 and command in (35, 36, 43))
        or (len(request) == 304 and command == 19)
        or (
            len(request) == 272
            and command == 47
            and struct.unpack_from("<I", request, 256)[0] in (19, 35, 36, 43)
        )
    ):
        raise ValueError("bounded selected mutation request required")
    with _capture_native_outcome(request, "mutation") as capture:
        yield capture


@contextmanager
def _capture_native_member_data(request):
    """Private known46 Data probe after attempted10; never Query-birth evidence."""
    if not (
        isinstance(request, bytes)
        and len(request) == 256
        and struct.unpack_from("<4sIII", request) == (b"XYGQ", 1, 6, 0)
        and all(struct.unpack_from("<QQ", request, 16))
        and not any(request[32:])
    ):
        raise ValueError("exact minimal known MemberData probe required")
    with _capture_native_outcome(request, "known-member-data-retirement") as capture:
        yield capture


@contextmanager
def _capture_native_outcome(request, purpose):
    global _ACTIVE_NATIVE_MUTATION_CAPTURES
    with _NATIVE_MUTATION_CAPTURE_LOCK:
        if _ACTIVE_NATIVE_MUTATION_CAPTURES >= 16:
            raise RuntimeError("Selected mutation capture capacity exhausted")
        _ACTIVE_NATIVE_MUTATION_CAPTURES += 1
    capture = None
    try:
        capture = _NativeMutationCapture(request, purpose)
        with _NATIVE_MUTATION_CAPTURE_LOCK:
            _NATIVE_MUTATION_CAPTURES.add(capture)
        yield capture
    finally:
        with _NATIVE_MUTATION_CAPTURE_LOCK:
            if capture is not None:
                _NATIVE_MUTATION_CAPTURES.discard(capture)
                capture.request = capture.reply = capture.error = capture.status = None
                capture.latest = None
            _ACTIVE_NATIVE_MUTATION_CAPTURES -= 1


def _uint(value: int, bits: int = 64) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, np.integer))
        or not 0 <= value < 1 << bits
    ):
        raise TypeError(f"expected u{bits}")
    return int(value)


def _i64(value: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, np.integer))
        or not -(1 << 63) <= value < 1 << 63
    ):
        raise TypeError("expected i64")
    return int(value)


def _budget(value: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not HEADER <= value <= MAX_PROCESSOR
    ):
        raise ValueError("invalid processor budget")
    return value


def _bytes(value: bytes | bytearray | memoryview) -> memoryview:
    if not isinstance(value, (bytes, bytearray, memoryview)):
        raise TypeError("expected raw bytes")
    view = memoryview(value)
    if not view.c_contiguous:
        raise TypeError("bytes must be contiguous")
    return view.cast("B")


def _backing_bytes(view: memoryview) -> int:
    value = view.obj
    while isinstance(value, memoryview) or (
        isinstance(value, np.ndarray) and value.base is not None
    ):
        value = value.obj if isinstance(value, memoryview) else value.base
    if value is None:
        raise TypeError("read storage has no owning buffer")
    return memoryview(value).nbytes


def encode_request(input: dict[str, Any]) -> bytes:
    """Frame one fixed-header request; Rust validates every product decision."""
    command = _uint(input["command"], 32)
    if command not in (*range(1, 22), 23, 24, 25, 26, 32, 33, 34, 35, 36):
        raise ValueError("unknown geographic command")
    payload = _bytes(input.get("payload", b""))
    length = HEADER + len(payload)
    budget = input.get("budget")
    if length > MAX_PACKET or (budget and length > _budget(budget["processor_bytes"])):
        raise ValueError("request exceeds framing budget")
    if (
        ("query" in input and command not in (5, 18, 35, 36))
        or ("generation" in input and command != 3)
        or (
            "sequence" in input
            and command not in (5, 6, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 24, 25, 26, 32, 35, 36)
        )
    ):
        raise ValueError("field does not belong to command")
    out = bytearray(length)
    struct.pack_into("<4sII", out, 0, b"XYGQ", 1, command)
    struct.pack_into("<QQ", out, 16, _uint(input.get("handle", 0)), _uint(input.get("sequence", 0)))
    if budget is not None:
        struct.pack_into(
            "<QQQII",
            out,
            32,
            _budget(budget["processor_bytes"]),
            _uint(budget["max_rows_examined"]),
            _uint(budget["max_read_bytes"]),
            _uint(budget["max_chunks"], 32),
            _uint(budget["page_rows"], 32),
        )
    if command == 3:
        struct.pack_into("<Q", out, 144, _uint(input.get("generation", 0)))
    if command in (5, 18, 35, 36):
        query = input["query"]
        camera = query["camera"]
        if not isinstance(camera["world_wrap"], bool) or not isinstance(
            query["previous_direct"], bool
        ):
            raise TypeError("query flags must be explicit booleans")
        digest = _bytes(query["source_digest"])
        if len(digest) != 8:
            raise ValueError("source digest must have eight bytes")
        struct.pack_into("<I", out, 12, camera["world_wrap"])
        struct.pack_into(
            "<4I",
            out,
            64,
            _uint(camera["crs"], 32),
            _uint(query["reduced_kind"], 32),
            _uint(query["max_cells"], 32),
            query["previous_direct"],
        )
        struct.pack_into(
            "<7d",
            out,
            80,
            *(
                camera[k]
                for k in ("center_x", "center_y", "zoom", "width", "height", "bearing", "pitch")
            ),
        )
        out[136:144] = digest
        struct.pack_into(
            "<7Q",
            out,
            144,
            *(
                _uint(query[k])
                for k in (
                    "generation",
                    "layer_id",
                    "camera_revision",
                    "time_revision",
                    "layer_revision",
                    "style_revision",
                    "state_revision",
                )
            ),
        )
        time = query["time"]
        kind = _uint(time["kind"], 32)
        if kind not in (0, 1, 2):
            raise ValueError("unknown time predicate")
        struct.pack_into("<I", out, 200, kind)
        if kind == 1:
            struct.pack_into("<q", out, 208, _i64(time["instant"]))
        elif kind == 2:
            struct.pack_into("<qq", out, 208, _i64(time["start"]), _i64(time["end"]))
        struct.pack_into("<Q", out, 224, _uint(query["max_projected_vertices"]))
    struct.pack_into("<Q", out, 232, len(payload))
    out[HEADER:] = payload
    return bytes(out)


def encode_style(style: dict[str, Any]) -> bytes:
    out = bytearray(48)
    for name, at in (("fill", 0), ("stroke", 4)):
        paint = _bytes(style[name])
        if len(paint) != 4:
            raise ValueError("paint must be RGBA8")
        out[at : at + 4] = paint
    struct.pack_into("<3d", out, 8, style["stroke_width"], style["diameter"], style["opacity"])
    out[32] = _uint(style["symbol"], 8)
    return bytes(out)


def _reply(data: bytes | bytearray | memoryview, *, selected=False) -> memoryview:
    b = _bytes(data)
    if (
        not HEADER <= len(b) <= MAX_PACKET
        or bytes(b[:4]) != b"XYGZ"
        or struct.unpack_from("<I", b, 4)[0] not in ((1, 2) if selected else (1,))
    ):
        raise ValueError("invalid geographic reply")
    return b


def _zero(data: memoryview, start: int, end: int) -> None:
    if any(data[start:end]):
        raise ValueError("nonzero reserved bytes")


def _ticket(data: memoryview) -> dict[str, Any]:
    kind = struct.unpack_from("<I", data, 28)[0]
    if kind > 3:
        raise ValueError("invalid geographic ticket kind")
    _zero(data, 72, 96)
    session_id, read_id, sequence, pass_ = struct.unpack_from("<QQQI", data)
    generation, chunk_index, rows, first_row, encoded_bytes = struct.unpack_from("<QIIQQ", data, 32)
    if encoded_bytes > (65536 if kind >= 2 else 16 * 1024 * 1024):
        raise ValueError("read ticket exceeds framing")
    if kind == 1 and (pass_ != 0 or read_id != chunk_index):
        raise ValueError("invalid index source ticket")
    if kind >= 2:
        _zero(data, 32, 56)
        if encoded_bytes < 64 or (kind == 2 and pass_ not in (1, 2)) or (kind == 3 and pass_ != 0):
            raise ValueError("invalid leaf ticket")
    return dict(
        kind=kind,
        page=read_id,
        raw=data,
        session_id=session_id,
        read_id=read_id,
        sequence=sequence,
        pass_=pass_,
        generation=generation,
        chunk_index=chunk_index,
        rows=rows,
        first_row=first_row,
        encoded_bytes=encoded_bytes,
        digest=data[64:72],
    )


def decode_reply(data: bytes | bytearray | memoryview) -> dict[str, Any]:
    b = _reply(data)
    code = struct.unpack_from("<I", b, 8)[0]
    if len(b) != HEADER or code > 12:
        raise ValueError("mutation reply must be fixed size")
    _zero(b, 12, 16)
    if code == 4:
        if struct.unpack_from("<Q", b, 160)[0] > 4096 or struct.unpack_from("<I", b, 168)[0] > 1:
            raise ValueError("invalid membership reply")
        _zero(b, 176, 256)
    elif code == 12:
        if struct.unpack_from("<I", b, 184)[0] not in (1, 2):
            raise ValueError("invalid indexed pass count")
        _zero(b, 188, 256)
    else:
        _zero(b, 160, 256)
    if code == 10:
        if struct.unpack_from("<I", b, 48)[0] not in (1, 2):
            raise ValueError("invalid indexed fallback reason")
        _zero(b, 52, 160)
    ticket = _ticket(b[64:160]) if code in (1, 2, 7, 8) else None
    if ticket and ((ticket["kind"] != 3) if code in (7, 8) else ticket["kind"] == 3):
        raise ValueError("ticket does not match step")
    handle, sequence, data_length, source_handle, source_rows = struct.unpack_from("<5Q", b, 16)
    geometry, crs = struct.unpack_from("<II", b, 56)
    return dict(
        code=code,
        fallback_reason_code=struct.unpack_from("<I", b, 48)[0] if code == 10 else None,
        handle=handle,
        sequence=sequence,
        data_length=data_length,
        source_handle=source_handle,
        source=dict(
            generation=data_length, digest=b[40:48], rows=source_rows, geometry=geometry, crs=crs
        ),
        ticket=ticket,
        index_stats=(
            dict(
                zip(
                    ("pages_read", "bytes_read", "candidate_vertices", "passes"),
                    struct.unpack_from("<QQQI", b, 160),
                    strict=True,
                )
            )
            if code == 12
            else None
        ),
    )


def encode_chunk_request(input: dict[str, Any], budget: int) -> bytes:
    """Encode exact XYGD/i64/f64 planes for Rust's canonical XYGK encoder."""
    _budget(budget)
    descriptor, rows = _bytes(input["descriptor"]), _uint(input["rows"], 32)
    if rows > 65536:
        raise ValueError("chunk row count exceeds framing")
    intervals, values = input.get("intervals"), input.get("values")
    planes = []
    if intervals is not None:
        planes.extend(
            (intervals[name], dtype)
            for name, dtype in (
                ("starts", "<i8"),
                ("ends", "<i8"),
                ("start_validity", "u1"),
                ("end_validity", "u1"),
            )
        )
    if values is not None:
        planes.append((values, "<f8"))
    for plane, dtype in planes:
        if (
            not isinstance(plane, np.ndarray)
            or plane.ndim != 1
            or plane.dtype != np.dtype(dtype)
            or not plane.flags.c_contiguous
            or len(plane) != rows
        ):
            raise TypeError("chunk requires exact contiguous typed planes")
    size = (
        32
        + len(descriptor)
        + rows * ((18 if intervals is not None else 0) + (8 if values is not None else 0))
    )
    if size > 16 * 1024 * 1024 or 6 * size + 32768 + HEADER > budget:
        raise ValueError("chunk exceeds peak framing budget")
    payload = bytearray(size)
    struct.pack_into(
        "<QI",
        payload,
        0,
        len(descriptor),
        (1 if intervals is not None else 0) | (2 if values is not None else 0),
    )
    struct.pack_into("<Q", payload, 16, rows)
    payload[32 : 32 + len(descriptor)] = descriptor
    at = 32 + len(descriptor)
    for plane, _ in planes:
        payload[at : at + plane.nbytes] = memoryview(plane).cast("B")
        at += plane.nbytes
    return encode_request(dict(command=20, payload=payload))


def parse_selection_footer(packet, at, *, rows):
    """Borrow complete XYSE authority; never authorize using fingerprints alone."""
    b = _bytes(packet)
    version = struct.unpack_from("<I", b, 4)[0]
    size = struct.unpack_from("<Q", b, 248)[0]
    if version == 1:
        if size or at != len(b):
            raise ValueError("unexpected selection footer")
        return None
    if version != 2 or size < 128 or at + size != len(b):
        raise ValueError("missing selected authority")
    raw = b[at:]
    flags = struct.unpack_from("<I", raw, 8)[0]
    namespace, ids, cells, visible = struct.unpack_from("<4Q", raw, 16)
    if (
        bytes(raw[:4]) != b"XYSE"
        or struct.unpack_from("<I", raw, 4)[0] != 1
        or flags != (1 if rows else 3)
        or ids > 10000
        or cells > 196608
        or size != 128 + 8 * (ids + cells)
        or any(raw[12:16])
        or any(raw[52:56])
        or any(raw[120:128])
    ):
        raise ValueError("invalid selection planes")
    pairs = (
        ((56, 88), (64, 96), (72, 120), (80, 136), (88, 104))
        if rows
        else ((56, 144), (64, 152), (72, 160), (80, 200), (88, 232))
    )
    if any(raw[a : a + 8] != b[z : z + 8] for a, z in pairs) or (
        rows and raw[96:104] != b[112:120]
    ):
        raise ValueError("selection source binding")
    if not rows and raw[96:104] != b[240:248]:
        raise ValueError("selection geometry binding")
    id_plane = np.frombuffer(raw, dtype="<u8", count=ids, offset=128)
    counts = np.frombuffer(raw, dtype="<u8", count=cells, offset=128 + ids * 8)
    previous = -1
    for value in id_plane:
        if int(value) <= previous:
            raise ValueError("selection IDs must be canonical")
        previous = int(value)
    if (
        (rows and (cells or visible))
        or (
            not rows
            and (
                visible > struct.unpack_from("<Q", b, 48)[0]
                or (
                    cells
                    and (
                        cells
                        != struct.unpack_from("<I", b, 64)[0] * struct.unpack_from("<I", b, 68)[0]
                        or sum(int(n) for n in counts) != visible
                    )
                )
                or (struct.unpack_from("<I", b, 8)[0] == 0 and cells)
            )
        )
        or (not ids and (cells or visible))
    ):
        raise ValueError("selection count binding")
    return dict(
        raw=raw,
        namespace=namespace,
        ids=id_plane,
        counts=counts,
        fill=raw[48:52],
        visible_vertices=None if rows else visible,
    )


class SceneData:
    """Borrowed binary views of a Rust Scene plus exact direct/reduced metadata."""

    def __init__(self, packet: bytes | bytearray | memoryview) -> None:
        b = _reply(packet, selected=True)
        footer_len = struct.unpack_from("<Q", b, 248)[0]
        aggregate, self.dropped_channels = struct.unpack_from("<II", b, 8)
        (
            session_handle,
            sequence,
            scene_len,
            metadata_len,
            self.visible_vertices,
            self.projected_vertices,
        ) = struct.unpack_from("<6Q", b, 16)
        self.columns, self.rows, capped = struct.unpack_from("<III", b, 64)
        time_kind, reduced_kind = struct.unpack_from("<II", b, 208)
        if (
            aggregate > 1
            or capped > 1
            or time_kind > 2
            or reduced_kind > 1
            or self.dropped_channels & ~7
            or HEADER + scene_len + metadata_len + footer_len != len(b)
            or scene_len < 160
        ):
            raise ValueError("malformed SceneData framing")
        _zero(b, 76, 80)
        if struct.unpack_from("<I", b, 4)[0] == 1:
            _zero(b, 248, 256)
        self.selection = parse_selection_footer(b, HEADER + scene_len + metadata_len, rows=False)
        self.packet, self.scene = b, b[HEADER : HEADER + scene_len]
        if (
            bytes(self.scene[:4]) != b"XYGS"
            or struct.unpack_from("<I", self.scene, 4)[0] != scene_version()
        ):
            raise ValueError("invalid Scene packet")
        self.aggregate, self.grid_capped = bool(aggregate), bool(capped)
        self._stride = 24 if aggregate else 40
        self.metadata = b[HEADER + scene_len : HEADER + scene_len + metadata_len]
        self.length = metadata_len // self._stride
        if metadata_len % self._stride or (aggregate and self.columns * self.rows != self.length):
            raise ValueError("invalid provenance framing")
        for i in range(self.length):
            at = i * self._stride
            if aggregate:
                if not all(
                    np.isfinite(x) for x in struct.unpack_from("<dd", self.metadata, at + 8)
                ):
                    raise ValueError("invalid reduced coordinates")
            else:
                _zero(self.metadata, at + 28, at + 40)
        if self.selection is not None:
            ids = self.selection["ids"]
            counts = self.selection["counts"]
            if aggregate and len(ids) and len(counts) != self.length:
                raise ValueError("selected grid extent mismatch")
            selected = 0
            for i in range(self.length):
                value = struct.unpack_from("<Q", self.metadata, i * self._stride)[0]
                if aggregate:
                    if len(counts) and int(counts[i]) > value:
                        raise ValueError("selected count exceeds cell")
                else:
                    pos = int(np.searchsorted(ids, np.uint64(value)))
                    selected += pos < len(ids) and int(ids[pos]) == value
            if (not aggregate and selected != self.selection["visible_vertices"]) or (
                aggregate and len(ids) and len(counts) != self.length
            ):
                raise ValueError("selected visible count mismatch")
        crs, wrap = struct.unpack_from("<II", b, 80)
        camera_values = struct.unpack_from("<7d", b, 88)
        geometry, source_crs = struct.unpack_from("<II", b, 240)
        if (
            crs not in (4326, 3857)
            or source_crs not in (4326, 3857)
            or wrap > 1
            or not all(np.isfinite(x) for x in camera_values)
        ):
            raise ValueError("invalid camera/source framing")
        if time_kind == 0:
            _zero(b, 216, 232)
            time = dict(kind=0)
        elif time_kind == 1:
            _zero(b, 224, 232)
            time = dict(kind=1, instant=struct.unpack_from("<q", b, 216)[0])
        else:
            start, end = struct.unpack_from("<qq", b, 216)
            time = dict(kind=2, start=start, end=end)
        camera = dict(
            zip(
                ("center_x", "center_y", "zoom", "width", "height", "bearing", "pitch"),
                camera_values,
                strict=True,
            ),
            crs=crs,
            world_wrap=bool(wrap),
        )
        self.identity = dict(
            session_handle=session_handle,
            sequence=sequence,
            camera=camera,
            source_digest=b[144:152],
            time=time,
            reduced_kind=reduced_kind,
            source_rows=struct.unpack_from("<Q", b, 232)[0],
            geometry=geometry,
            source_crs=source_crs,
        )
        self.identity.update(
            zip(
                (
                    "generation",
                    "layer_id",
                    "camera_revision",
                    "time_revision",
                    "layer_revision",
                    "style_revision",
                    "state_revision",
                ),
                struct.unpack_from("<7Q", b, 152),
                strict=True,
            )
        )

    def record(self, index: int) -> dict[str, Any]:
        if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < self.length:
            raise IndexError("provenance index")
        at = index * self._stride
        if self.aggregate:
            count, x, y = struct.unpack_from("<Qdd", self.metadata, at)
            return dict(count=count, x=x, y=y)
        feature_id, source_row, chunk_index, chunk_row, vertex = struct.unpack_from(
            "<QQIII", self.metadata, at
        )
        return dict(
            feature_id=feature_id,
            source_row=source_row,
            chunk_index=chunk_index,
            chunk_row=chunk_row,
            vertex=vertex,
        )


def parse_scene_data(packet: bytes | bytearray | memoryview) -> SceneData:
    return SceneData(packet)


def execute(request: bytes) -> bytes:
    """One mutation, always with fixed output capacity (never a size probe)."""
    from . import _native

    if not isinstance(request, bytes) or not HEADER <= len(request) <= MAX_PACKET:
        raise ValueError("invalid geographic request size")
    # Every exact canonical dispatch updates all active scopes, including a
    # nested context or thread which did not inherit this caller's ContextVar.
    with _NATIVE_MUTATION_CAPTURE_LOCK:
        captures = [(c, c.begin(request)) for c in _NATIVE_MUTATION_CAPTURES]
    source, out = ctypes.create_string_buffer(request), ctypes.create_string_buffer(HEADER)
    code = _native._lib.xyg_geo_scale_execute(source, len(request), out, HEADER)
    if code:
        error = _native.GeoNativeError(code)
        with _NATIVE_MUTATION_CAPTURE_LOCK:
            for capture, token in captures:
                capture.record(token, error=error, status=int(code))
        raise error
    reply = out.raw
    with _NATIVE_MUTATION_CAPTURE_LOCK:
        for capture, token in captures:
            capture.record(token, reply=reply)
    return reply


def read(request: bytes, budget: int) -> bytes:
    """Pure two-call read; size discovery consumes no retained Data read slot."""
    from . import _native

    _budget(budget)
    if not isinstance(request, bytes) or not HEADER <= len(request) <= min(MAX_PACKET, budget):
        raise ValueError("invalid geographic read request size")
    source, length = ctypes.create_string_buffer(request), ctypes.c_size_t()
    function = _native._lib.xyg_geo_scale_read
    code = function(source, len(request), budget, None, 0, ctypes.byref(length))
    if code:
        raise _native.GeoNativeError(code)
    if length.value > MAX_PACKET or 4 * length.value > budget:
        raise _native.GeoNativeError(-9)
    out = ctypes.create_string_buffer(length.value)
    code = function(source, len(request), budget, out, len(out), ctypes.byref(length))
    if code:
        raise _native.GeoNativeError(code)
    if length.value != len(out):
        raise ValueError("read length changed")
    return out.raw


class GeoScaleBridge(Protocol):
    async def execute(self, request: bytes) -> bytes: ...
    async def read(self, request: bytes) -> bytes: ...


class NativeGeoScaleBridge:
    def __init__(self, budget: int) -> None:
        self.budget = _budget(budget)

    async def execute(self, request: bytes) -> bytes:
        return execute(request)

    async def read(self, request: bytes) -> bytes:
        return read(request, self.budget)


async def _settle(
    task: asyncio.Future, on_cancel: Callable[[], Any] | None = None
) -> tuple[Any, bool]:
    """Wait even through repeated outer cancellation; never cancel transport."""
    interrupted = False
    while True:
        try:
            return await asyncio.shield(task), interrupted
        except asyncio.CancelledError:
            if task.cancelled():
                raise
            interrupted = True
            if on_cancel is not None:
                on_cancel()
            if task.done():
                # A plain executor Future can hold CancelledError as an
                # exception without being cancelled. Retrieve it once; a
                # successful completion still transfers its owned result.
                return task.result(), interrupted


async def drive_session(
    bridge: GeoScaleBridge,
    *,
    handle: int,
    sequence: int,
    budget: dict[str, Any],
    read_chunk: Callable[[dict[str, Any]], Awaitable[bytes | bytearray | memoryview]],
    cancel_event: asyncio.Event | None = None,
) -> dict[str, Any]:
    """Service Rust-issued tickets; caller explicitly creates/begins operations.

    Read and transport tasks settle before cancellation releases their charges.
    Callbacks must return exact-size owning storage and not retain other copies.
    """
    cancellation: asyncio.Task | None = None

    def cancel_now() -> asyncio.Task:
        nonlocal cancellation
        if cancellation is None:
            cancellation = asyncio.create_task(
                bridge.execute(encode_request(dict(command=9, handle=handle, sequence=sequence)))
            )
        return cancellation

    async def cancel() -> None:
        await _settle(cancel_now())

    async def watch() -> None:
        assert cancel_event is not None
        await cancel_event.wait()
        await cancel()

    watcher = asyncio.create_task(watch()) if cancel_event is not None else None
    try:
        while True:
            if cancel_event is not None and cancel_event.is_set():
                await cancel()
                raise asyncio.CancelledError
            step = asyncio.create_task(
                bridge.execute(
                    encode_request(dict(command=6, handle=handle, sequence=sequence, budget=budget))
                )
            )
            raw, interrupted = await _settle(step, cancel_now)
            reply = decode_reply(raw)
            if reply["handle"] != handle or reply["sequence"] != sequence:
                raise ValueError("mismatched session reply")
            ticket = reply["ticket"]
            if reply["code"] in (3, 4, 5, 6):
                if interrupted or (cancel_event is not None and cancel_event.is_set()):
                    await cancel()
                    raise asyncio.CancelledError
                return reply
            if reply["code"] != 1 or ticket is None:
                raise ValueError("unowned outstanding read")
            borrowed = chunk = payload = supply = None
            try:
                if interrupted or (cancel_event is not None and cancel_event.is_set()):
                    await cancel()
                    raise asyncio.CancelledError

                async def read_owned_chunk(
                    authority: dict[str, Any],
                ) -> bytes | bytearray | memoryview:
                    return await read_chunk(authority)

                read_task = asyncio.create_task(read_owned_chunk(dict(ticket)))
                borrowed, interrupted = await _settle(read_task, cancel_now)
                read_task = None
                if interrupted:
                    await cancel()
                    raise asyncio.CancelledError
                chunk = _bytes(borrowed)
                if (
                    len(chunk) != ticket["encoded_bytes"]
                    or _backing_bytes(chunk) > ticket["encoded_bytes"]
                ):
                    raise ValueError("read callback must return exact bounded storage")
                if cancel_event is not None and cancel_event.is_set():
                    await cancel()
                    raise asyncio.CancelledError
                if 3 * (352 + len(chunk)) > budget["processor_bytes"]:
                    raise ValueError("read transfer exceeds peak budget")
                payload = bytearray(96 + len(chunk))
                payload[:96], payload[96:] = ticket["raw"], chunk
                supply = encode_request(dict(command=7, handle=handle, payload=payload))
                payload = None
                mutation = asyncio.create_task(bridge.execute(supply))
                _, interrupted = await _settle(mutation, cancel_now)
                mutation = None
                if interrupted:
                    raise asyncio.CancelledError
            except BaseException as error:
                # Exceptions retain completed callback/decoder frames. Clear their
                # local buffer references before acknowledging the Rust charge.
                borrowed = chunk = payload = supply = read_task = mutation = None
                traceback.clear_frames(error.__traceback__)
                # Preserve the primary error; release is still required.
                with suppress(Exception):
                    await cancel()
                raise
            finally:
                borrowed = chunk = payload = supply = None
                try:
                    if cancellation is not None:
                        await _settle(cancellation)
                finally:
                    _, interrupted = await _settle(
                        asyncio.create_task(
                            bridge.execute(
                                encode_request(
                                    dict(command=8, handle=handle, payload=ticket["raw"])
                                )
                            )
                        ),
                        cancel_now,
                    )
                    if interrupted:
                        await cancel()
                        raise asyncio.CancelledError
    finally:
        if watcher is not None:
            if not watcher.done():
                watcher.cancel()
            await asyncio.gather(watcher, return_exceptions=True)
        if cancellation is not None:
            _, interrupted = await _settle(cancellation)
            if interrupted:
                raise asyncio.CancelledError


_SCENE_AUTHORITIES = weakref.WeakKeyDictionary()


def scene_data_authority(owner):
    """Private issuing transport/owner captured by a successful prepare."""
    return _SCENE_AUTHORITIES.get(owner)


class SceneDataLease:
    """Explicit retained-data owner. Drop borrowed copies/painters before dispose."""

    def __init__(self, bridge: GeoScaleBridge, handle: int, data: SceneData) -> None:
        self._bridge, self.handle, self._data = bridge, handle, data
        self._disposal: asyncio.Task | None = None

    @property
    def data(self) -> SceneData:
        if self._data is None:
            raise RuntimeError("SceneData disposed")
        return self._data

    async def dispose(self) -> None:
        _SCENE_AUTHORITIES.pop(self, None)
        self._data = None
        if self._disposal is None:
            self._disposal = asyncio.create_task(
                self._bridge.execute(encode_request(dict(command=10, handle=self.handle)))
            )
        try:
            _, interrupted = await _settle(self._disposal)
        except BaseException:
            if self._disposal.done():
                self._disposal = None
            raise
        if interrupted:
            raise asyncio.CancelledError


async def prepare_scene_data(
    bridge: GeoScaleBridge, *, handle: int, sequence: int, budget: dict[str, Any], style: bytes
) -> SceneDataLease:
    if not isinstance(style, bytes) or len(style) != 48:
        raise ValueError("style must be exact 48-byte Rust framing")
    issuer = bridge
    limits = dict(budget)
    captured = encode_request(
        dict(command=11, handle=handle, sequence=sequence, budget=limits, payload=style)
    )
    task = asyncio.create_task(issuer.execute(captured))
    raw, interrupted = await _settle(task)
    reply = decode_reply(raw)
    data_handle = reply["handle"]
    packet = data = None
    try:
        if interrupted:
            raise asyncio.CancelledError
        if (
            reply["source_handle"] != handle
            or reply["sequence"] != sequence
            or reply["data_length"] > MAX_PACKET
            or 4 * reply["data_length"] > budget["processor_bytes"]
        ):
            raise ValueError("invalid leased data reply")
        task = asyncio.create_task(
            bridge.read(encode_request(dict(command=23, handle=data_handle)))
        )
        packet, interrupted = await _settle(task)
        if interrupted:
            raise asyncio.CancelledError
        if len(packet) != reply["data_length"]:
            raise ValueError("mismatched leased data size")
        data = parse_scene_data(packet)
        if data.identity["session_handle"] != handle or data.identity["sequence"] != sequence:
            raise ValueError("mismatched leased data identity")
        owner = SceneDataLease(issuer, data_handle, data)
        _SCENE_AUTHORITIES[owner] = (
            issuer,
            data_handle,
            sequence,
            handle,
            captured,
            bytes(data.packet[:256]),
            data.selection is not None,
        )
        return owner
    except BaseException as error:
        packet = data = task = None
        traceback.clear_frames(error.__traceback__)
        await _settle(
            asyncio.create_task(
                bridge.execute(encode_request(dict(command=10, handle=data_handle)))
            )
        )
        raise
