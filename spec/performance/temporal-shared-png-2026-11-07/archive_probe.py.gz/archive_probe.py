from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
root=Path.cwd(); dest=Path('/home/ubuntu/.t3-owned/1cafa70d/png-next'); stage=sys.argv[1]; paths=[p for p in root.joinpath('crates').rglob('*') if p.is_file() and p.suffix in {'.rs','.toml'}]+[root/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
paths += [p for p in root.joinpath('vendor').rglob('*') if p.is_file()]
probe=dest/'png-capability-probe';files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};files.update({'EXTERNAL-PROBE/png/'+str(p.relative_to(probe)):hashlib.sha256(p.read_bytes()).hexdigest() for p in probe.rglob('*') if p.is_file()})
(dest/(stage+'-source.json')).write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':files,'externalPatch':'EXTERNAL-PROBE/png; Cargo CLI patch as recorded in build command'},indent=2)+'\n')
with tarfile.open(dest/(stage+'-source.tar.gz'),'w:gz') as tar:
 for p in paths:tar.add(p,arcname=str(p.relative_to(root)))
 tar.add(probe,arcname='EXTERNAL-PROBE/png')
(dest/(stage+'-source.patch')).write_bytes(subprocess.check_output(['git','diff','--no-ext-diff','--no-textconv','--binary','--full-index']))
