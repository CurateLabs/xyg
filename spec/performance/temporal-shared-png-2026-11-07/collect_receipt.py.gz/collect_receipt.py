from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
D=Path('/home/ubuntu/.t3-owned/1cafa70d/png-next');R=Path('spec/performance/temporal-shared-png-2026-11-07');R.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gz(p,d):d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
for p in D.glob('*.log'):gz(p,R/(p.name+'.gz'))
for name in ['commands.jsonl','environment.json','profile-abba.json','final-wasm-size.json','final-wasm-sections.json','final-data.json','foundation-final.json']:
 p=D/name
 if p.exists():
  if p.suffix=='.jsonl':gz(p,R/(name+'.gz'))
  else:shutil.copyfile(p,R/name)
for name in ['run_logged.py','archive_probe.py','collect_receipt.py','parity.mjs','data.mjs']:
 p=D/name
 if p.exists():gz(p,R/(name+'.gz'))
for p in D.glob('*source.tar.gz'):shutil.copyfile(p,R/p.name)
for p in D.glob('*source.json'):shutil.copyfile(p,R/p.name)
for p in D.glob('*source.patch'):shutil.copyfile(p,R/p.name)
for p in D.glob('*.wasm'):gz(p,R/'artifacts/probes'/(p.name+'.gz'))
for directory in ['png-inline-probe','png-capability-probe']:
 with tarfile.open(R/(directory+'.tar.gz'),'w:gz') as tar:tar.add(D/directory,arcname=directory)
for name in ['index.js','standalone.js','wasm-worker.js','wasm-inline-worker.js','xyg-wasm-inline.js','xyg-wasm.manifest.json','xyg-wasm.wasm']:
 gz(Path('packages/xy-client/dist')/name,R/'artifacts/client'/(name+'.gz'))
gz(D/'qualified-native/libxyg_core.so',R/'artifacts/libxyg_core.so.gz')
for folder in ['foundation-final.json.frozen-graph']:
 for p in (D/folder).iterdir():
  out=R/'artifacts/worker'/p.name;out.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix in ['.png','.xyfg','.json']:shutil.copyfile(p,out)
  else:gz(p,out.with_name(out.name+'.gz'))
for p in D.glob('foundation-final.json.retained-temporal*'):
 if p.is_file():
  if p.suffix=='.png':shutil.copyfile(p,R/p.name)
  else:gz(p,R/(p.name+'.gz'))
# Exact final build inputs; excludes diagnostics/receipts and unused external probe overrides.
paths=[p for p in Path('crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.toml']]+[p for p in Path('vendor').rglob('*') if p.is_file()]+[Path(p) for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
inputs={str(p):sha(p) for p in sorted(paths)}
source={'schemaVersion':1,'gitParent':'44bf73390b3d949797755d8637e3aeca0a60d7b5','cargoPatch':'checked-in vendor/png and vendor/crc32fast; no external CLI override','files':inputs,'sha256':hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
(R/'compiled-source-inputs.json').write_text(json.dumps(source,indent=2)+'\n')
with tarfile.open(R/'compiled-source.tar.gz','w:gz') as tar:
 for p in paths:tar.add(p,arcname=str(p))
artifacts={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((R/'artifacts').rglob('*')) if p.is_file()}
(R/'artifact-bindings.json').write_text(json.dumps({'schemaVersion':1,'sourceInputsSha256':source['sha256'],'native':{'path':str(D/'qualified-native/libxyg_core.so'),'sha256':sha(D/'qualified-native/libxyg_core.so'),'abi':404,'symbols':546},'wasm':json.loads((D/'final-wasm-size.json').read_text()),'artifacts':artifacts},indent=2)+'\n')
# Existing complete bindings, including historical binary receipt hashes, stay immutable.
p=R/'current-bindings.json';j=json.loads(p.read_text());j['sourceSha256']={name:sha(Path(name)) for name in j['sourceSha256']};p.write_text(json.dumps(j,indent=2)+'\n')
