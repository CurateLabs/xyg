import{chromium}from'/home/ubuntu/.t3/worktrees/xyg/t3-1cafa70d/node_modules/playwright/index.mjs';
const b=await chromium.launch({executablePath:'/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome',args:['--no-sandbox']});const p=await b.newPage();
p.on('console',m=>console.log('console',m.type(),m.text().slice(0,1200)));p.on('pageerror',e=>console.log('pageerror',String(e)));p.on('worker',w=>{console.log('worker',w.url());w.on('close',()=>console.log('worker close'));});
await p.addInitScript(()=>{const O=Worker;window.Worker=class extends O{constructor(...a){super(...a);this.addEventListener('error',e=>console.log('workererr',e.message));this.addEventListener('message',e=>console.log('worker-message',e.data?.type,e.data?.requestId,e.data?.ok,JSON.stringify(e.data?.error)));console.log('worker constructor');}}});
await p.goto('file:///var/tmp/pg45-1c/pytest-of-ubuntu/pytest-0/test_real_worker_capture_impor0/inline-worker-png.html');
try{await p.waitForFunction(()=>window.offlinePng,undefined,{timeout:5000});}catch(e){console.log(String(e));}
console.log(await p.evaluate(()=>({xy:typeof xy,inline:!!globalThis.__xygInlineWasm,result:window.offlinePng})));await b.close();
