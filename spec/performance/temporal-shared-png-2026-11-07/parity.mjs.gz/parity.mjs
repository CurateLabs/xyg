import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {FrozenTemporalGraph} from '/home/ubuntu/.t3/worktrees/xyg/t3-1cafa70d/packages/xy-node/src/index.js';
const dir='/home/ubuntu/.t3-owned/1cafa70d/png-next';
const {instance}=await WebAssembly.instantiate(readFileSync(process.argv[2]),{}),x=instance.exports;
const h=x.xyg_wasm_instance_new(384*1024*1024);assert.ok(h);mkdirSync(`${dir}/oracle`,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const tag of ['shape-0','shape-1','shape-2','shape-3','shape-4','shape-5','shape-5-parent'])for(const scale of [1,2]){
 const data=readFileSync(`/home/ubuntu/.t3-owned/1cafa70d/exact-worker/${tag}.xyfg`);
 const f=FrozenTemporalGraph.fromBytes(data);const expected=Buffer.from(f.export('png',{scale}));f.close();
 const p=new Uint8Array(64+data.length),v=new DataView(p.buffer);p.set([88,89,70,88]);v.setUint32(4,1,true);v.setUint32(8,1,true);v.setUint32(12,1,true);v.setFloat64(24,scale,true);v.setBigUint64(32,BigInt(data.length),true);v.setBigUint64(48,384n*1024n*1024n,true);p.set(data,64);
 assert.equal(x.xyg_wasm_arena_resize(h,p.length),0);new Uint8Array(x.memory.buffer,x.xyg_wasm_arena_ptr(h),p.length).set(p);const status=x.xyg_wasm_frozen_graph_execute(h,0,p.length);
 const error=new TextDecoder().decode(new Uint8Array(x.memory.buffer,x.xyg_wasm_last_error_ptr(h),x.xyg_wasm_last_error_len(h)));assert.equal(status,0,error);
 const actual=Buffer.from(new Uint8Array(x.memory.buffer,x.xyg_wasm_output_ptr(h),x.xyg_wasm_output_len(h)));writeFileSync(`${dir}/oracle/${tag}-${scale}.png`,actual);assert.deepEqual(actual,expected);
 const recovered=FrozenTemporalGraph.fromArtifact(actual);assert.deepEqual(Buffer.from(recovered.toBytes()),data);recovered.close();console.log(JSON.stringify({tag,scale,bytes:actual.length,sha256:sha(actual),xyfg:sha(data),equal:true}));
}assert.equal(x.xyg_wasm_instance_dispose(h),0);
