from pathlib import Path
import datetime,json,os,subprocess,time
D=Path('/home/ubuntu/.t3-owned/1cafa70d/png-next')
args=['node','benchmarks/bench_wasm_profiles.mjs','/home/ubuntu/.t3-owned/1cafa70d/qualified-o2.wasm','packages/xy-client/dist/xyg-wasm.wasm',str(D/'profile-inputs'),str(D/'profile-abba-observed.json')]
samples=[]
with (D/'profile-observed-raw.log').open('wb') as log:
 child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
 while child.poll() is None:
  rows=subprocess.check_output(['ps','-eo','pid,comm,pcpu,rss'],text=True).splitlines()
  relevant=[r for r in rows if any(s in r for s in ['node','rustc','cargo','python','chrome','codex'])]
  samples.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadAverage':os.getloadavg(),'processColumns':'pid comm lifetime-average-pcpu rssKiB','processes':relevant})
  time.sleep(1)
(D/'profile-shared-vm.json').write_text(json.dumps({'argv':args,'returncode':child.returncode,'scope':'Shared VM activity samples; no CPU isolation or speed-win claim','samples':samples},indent=2)+'\n')
assert child.returncode==0,child.returncode
print('observed ABBA passed',len(samples),'shared VM samples')
