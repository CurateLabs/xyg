import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
root=Path.cwd();base=Path('/home/ubuntu/.t3-owned/1cafa70d/png-next');label,*command=sys.argv[1:]
record={'label':label,'argv':command,'cwd':str(root),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'environment':{k:os.environ[k] for k in ['PATH','TMPDIR','XYG_NATIVE_LIB','XYG_CHROMIUM','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'] if k in os.environ}}
for name,path in [('native',os.environ.get('XYG_NATIVE_LIB')),('wasm','packages/xy-client/dist/xyg-wasm.wasm')]:
 if path and Path(path).is_file():record[name]={'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}
log=base/(label+'.log')
with log.open('wb') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
record.update(returncode=result.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),logSha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (base/'commands.jsonl').open('a') as out:out.write(json.dumps(record)+'\n')
print(label,result.returncode);sys.exit(result.returncode)
