use crate::raster;
#[derive(Clone,Copy)]
pub(crate) enum PngError { Size, Raster }
fn rasterize_png_policy<const RETAINED:bool>(
    cmds: &[u8],
    width: usize,
    height: usize,
) -> Result<Vec<u8>, PngError> {
    if RETAINED && !raster::retained_commands_valid(cmds) {return Err(PngError::Raster);}
    let raw = width
        .checked_mul(height)
        .and_then(|count| count.checked_mul(4))
        .ok_or(PngError::Size)?;
    let cap = raw.checked_add(raw / 8).and_then(|n|n.checked_add(65_536)).ok_or(PngError::Size)?;
    let mut out = vec![0u8; cap.max(1)];
    let written = if RETAINED {raster::rasterize_retained_png_into(cmds,width,height,&mut out)}else{raster::rasterize_png_into(cmds,width,height,&mut out)}
        .ok_or(PngError::Raster)?;
    if written > out.len() {
        return Err(PngError::Raster);
    }
    out.truncate(written);
    Ok(out)
}

pub(crate) fn rasterize_png(cmds:&[u8],w:usize,h:usize)->Result<Vec<u8>,PngError>{rasterize_png_policy::<true>(cmds,w,h)}
#[cfg(feature="raster")]
pub(crate) fn rasterize_png_full(cmds:&[u8],w:usize,h:usize)->Result<Vec<u8>,PngError>{rasterize_png_policy::<false>(cmds,w,h)}
