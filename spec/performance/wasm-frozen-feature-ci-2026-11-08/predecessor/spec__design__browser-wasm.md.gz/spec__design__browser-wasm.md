# Direct-browser Rust/WASM boundary

## Dynamic viewport ticks (`XYTK` to `XYTO`)

The tick operation introduced in WASM ABI 23 is carried by current WASM ABI 31
and makes tick resolution one bounded Rust-owned Worker operation.
Axes carry explicit scale family and `automatic`, `authored_values`, or
`authored_empty` provenance; symlog constants, log masking, angular units,
UTC-time semantics, category tables, and bounded formats are versioned input,
never inferred from packed bytes. Authored values and labels always win, and an
explicitly empty authored set remains distinct from automatic provenance.

The low-level TypeScript codec submits an atomic axis batch and strictly decodes
the echoed sequence, axis identity, revision, provenance, f64 values/step, and
UTF-8 labels. The Worker owns a tick-specific FIFO and cancellation watermark,
so a cancelled or disposed request cannot publish a result.

Tick work is independent and therefore does not cancel compile, density,
graph, or temporal work. Each axis is capped
at 200 output positions and 65,536 source categories; label/category text is
capped at 65,536 UTF-8 bytes per axis. Embedded NUL, nonfinite input, and
category/label/format planes irrelevant to the declared family or request
provenance are rejected before output across every host.

`attachWasmTicks(view, { worker })` installs the bounded ChartView product
cutover for automatic, authored-value, and authored-empty primary and secondary
Cartesian axes; angular/radial polar axes; authored minor-axis slots; and
eligible major/minor colorbar slots. Linear, log, symlog, category, UTC-time,
angular-radian, and angular-degree families are explicit `XYTK` input. Rust
exclusively chooses positions and labels. Eligibility excludes category axes
without a non-empty NUL-free string table, Scene-placed axes/colorbars (already
Rust-owned via painter tick descriptors/`XYCB`), and log domains that are not
strictly positive. An axis
is *covered* only after an admitted Rust cache exists for that eligible slot
and still matches its current family, category table, format, and provenance;
newly eligible slots or family/provenance switches after mount paint no tick
positions or labels until that cache arrives. An admitted `authored_empty`
cache is a real empty result, not that pre-admission fail-close. The first
current `XYTO` result is
admitted before the attachment becomes authoritative; later pan/zoom/resize
requests cancel older work and retain only the last admitted Rust cache until
a matching sequence and axis revision returns. Admission reconciles the
Rust-produced label metrics through ChartView's complete forced resize path so
plot, mark canvas, chrome, titles, and interaction geometry move atomically;
it never calls `_layout()` alone. An unchanged screen-bounded target
deduplicates, while a changed target may schedule one current follow-up batch.
The browser foundation proves formatted/title, category/time, and authored-label
attachments settle without revision churn. A stale, cancelled, destroyed, or
replaced attachment cannot publish. No ChartView tick slot calls a TypeScript ladder or axis
formatter, even
after a Worker failure. Failed snapshots emit one coalesced
`xy:wasm_ticks_error` and remain eligible to retry.

This cutover is deliberately explicit and bounded. Missing, malformed,
unattached, or not-yet-admitted WASM fails closed with a stable diagnostic and
paints no synthetic ticks. A canonical Rust Scene may instead carry tagged
resolved tick descriptors, which ChartView consumes without recomputation.
Self-contained
Blob-worker HTML remains ineligible. Hosted `to_html()`, notebook widgets, and
application-host embeds attach when they explicitly serve the packaged `wasm-worker.js` and
`xyg-wasm.wasm` files at explicit same-origin URLs (`workerUrl` stays required;
there is no path guessing or CDN). The srcdoc notebook iframe cannot load those
siblings and fails closed for dynamic ticks. The M2-claimed delivery and its
deferred/follow-up boundaries are recorded below. Related to #59; dedicated
follow-up issues track work outside that claimed subset.

M2 #869 makes `xyg-engine::packed_ticks` the single packed resolver called by
current WASM ABI 30 and native ABI 361 `xyg_tick_resolve_packed`. The boundary
was introduced in WASM ABI 23/native ABI 360. The native function
uses the capacity-aware probe/write contract and returns `usize::MAX` for an
invalid `XYTK`. `packed_ticks_cross_host.json` proves byte-identical `XYTO`
positions, labels, provenance, angular filtering, minor ticks, and failure
behavior through Python/native, Node/native, and a real browser/WASM Worker.

## Tier-2 aggregate seam (`XYAG` to `XYAO`)

WASM ABI 5 adds a resumable Rust-owned density aggregate operation. TypeScript
only frames the generated `XYAG` request, transfers it to the static Worker,
schedules bounded checkpoints, and decodes the generated `XYAO` output header.
The shared Rust `bin_2d` and mean-color kernels own binning policy and numeric
behavior; standalone density refinement now uses this path exclusively, while
broader hosted evidence is tracked by [#886: packaged ticks and density no-refinement proof](https://github.com/CurateLabs/xyg/issues/886).

The generated ABI manifest is authoritative for request/output offsets, aligned
strides, copy factors, the 32,768-point checkpoint, and the 64 MiB aggregate
peak. The peak includes the retained transferred request and WASM staging copy,
the accumulator, one decode checkpoint, and both Rust-owned and transferred
output copies. Aggregate calls require ownership transfer; clone mode fails
closed. A newer sequence cancels an active aggregate only after stale-sequence
validation, and every scene operation clears older aggregate state.

**Status:** bounded lifecycle, canonical Scene paint, and packed typed-column
compile (`XYCC`) for scatter/polyline/rect/band, plus transferable series
descriptors (`XYTS`) whose record expansion and defaults run in Rust.
This is **not** yet a complete direct-browser chart host. Broader aggregate
production and release-matrix conformance continue under
[#54](https://github.com/CurateLabs/xyg/issues/54). The delivered M2 foundation
is related to [#59](https://github.com/CurateLabs/xyg/issues/59).
Canonical scene dependency: [Scene IR](scene-ir.md).

WASM ABI 24 also exposes `xyg_wasm_density_first_paint_plan`, an
allocation-free policy diagnostic over the shared Rust payload orchestrator.
It accepts a split-u64 source count plus grid dimensions and packs the tier,
screen-bounded mark count, pyramid/WASM eligibility, sample attachment, and
source-shipment flags into one u32. `0xffffffff` is the fail-closed result;
the exact bit layout is generated from `spec/wasm/abi.json`. This is not an
alternate aggregator or permission to ship canonical f64: the strict-CSP
browser gate queries it at 1M and 100M and requires source shipment to remain
false at both sizes.

### Supported ChartView density refinement

`attachWasmDensity(view, { worker, input })` is the first supported product
path for an already-painted Cartesian density trace, including one explicitly
attached kernel-backed scatter workload. `input` supplies canonical
`Float64Array` x/y source columns and, optionally, resolved straight-alpha
RGBA8 colors. For an explicit multi-trace attachment, pass `inputs` with
distinct trace ids. The one resumable WASM aggregate slot processes these
sources in supplied order; each retains its own axes and emits one bounded
Rust-owned `XYAG`/`XYAO` pair. On every ChartView viewport refinement it asks
Rust for typed output and uploads that grid through ChartView's ordinary
density texture path. It neither serializes data as JSON nor implements
binning, color aggregation, representation policy, or resource accounting in
TypeScript.

The attachment cancels the active request on a newer view, retains the current
surface until a current result arrives, and admits a result only when its
monotonic viewport sequence, handle, ChartView, and GL lifecycle all still
match. `destroy()` cancels any request; an explicitly owned Worker is then
disposed. Worker failures emit the `wasm_density_error` chart event with the
stable error code, corrective message, and resource/copy diagnostics, never
user data. Its event detail includes the failed `traceId` for a multi-trace
attachment. Normal Python/Node kernel-backed ChartViews do not include
canonical f64 in the ordinary split first-paint payload. They retain the
screen-bounded overview and use the host kernel route for later views. A
dedicated Worker/WASM replay journey must explicitly request the replay source
(`wasm_source=True` in Python, `wasmSource: true` in Node); true direct-browser
callers already own their typed source locally and stage it through the same
XYAG/XYAO adapter. This does not apply TypeScript aggregation. Unsupported
kernel-less sources retain their overview and dispatch an explicit
no-refinement diagnostic.
This is automatic source provisioning only after that explicit opt-in; the
default split payload never retains replay columns.

The first full host vertical is deliberately one Cartesian linear count-only
trace. An explicitly replay-enabled split payload retains canonical f64 x/y
columns in ChartView so a later pan can replay them; ordinary split first paint
does not. Each viewport sends an `XYAS` declaration followed
by transferable raw chunks of at most 32,768 points; no Worker retains a whole
source and no TypeScript scans, bins, grids, derives domains, or chooses LOD.
Rust owns `XYAS`-to-`XYAO` aggregation. The capacity is the generated ABI
aggregate limit (8,000,000 rows); source/chunk policy beyond one million rows,
colors, multiple traces, and nonlinear axes remain out of this vertical and
emit `XYG_WASM_SOURCE_UNSUPPORTED` when no refinement is available. There is
no JavaScript aggregation fallback.

An `XYAO` reply that passes Worker transport but fails its generated header,
length, or typed-plane validation reports `XYG_WASM_MALFORMED_OUTPUT`, rather
than a caller argument error. The error retains the Worker accounting snapshot,
leaves the last painted density surface intact, and clears the failed attempt
before an owned Worker is disposed. A corrupt aggregate therefore cannot retain
a pending task, upload a new texture, or expose source values.

## Runtime taxonomy

Direct-browser WASM is the safe `xyg-engine` compiled for
`wasm32-unknown-unknown` and hosted in a static module Worker. It is distinct
from both:

- the native Python/Node C ABI (`xyg-core`); and
- the Pyodide/PyEmscripten Python wheel, which runs CPython in the browser.

There is no separate “WASM implementation.” Rust owns engine decisions, the
Worker adapter owns memory/lifecycle/status transport, and the existing
TypeScript/WebGL client retains paint, pick, gestures, accessibility, and DOM
chrome.

## Explicit retained graph attachment (bounded S5b)

The experimental `attachWasmGraphSession` path takes complete XYGF bytes,
existing load inputs and an explicit seven-f64 session camera. It opens initially
Owned, unlinked state and exposes `ready`, `refreshRender`, `snapshot` and async
`dispose`. It borrows one drained packaged Worker and owns its serialized,
non-cancellable graph lane through CLOSE. Ordinary compiler/job/temporal/geo
acquisition is rejected before staging while attached; a geographic transition
must not implicitly revoke that controller. Caller-owned Worker disposal follows
attachment disposal. XYGR does not echo instance identity: response admission
uses the issued Worker request and attachment lifetime, with separate outer
Worker sequence, exact-u64 operation sequence and render revision.

`63_graph_session_wire.ts` uses the factored raw named-section decoder without
eager CPU geometry planes. `63_graph_gpu.ts` validates all 33 GPU-v1 sections
before direct f32/u8/style/index upload through existing `GLHost` lifecycle and
paint conventions. GPU coordinates already are CSS screen coordinates; only
offset/scale reconstruction and viewport/DPR presentation apply. Every success
repaints even at the same revision. Complete semantic/GPU validation precedes
publication; refusal retains the last accepted picture. A stale reply requires
Render recovery before more input. The path never calls canonicalScene,
`prepareScene`, `layoutWasmCose` or legacy graph-mark compilation. Existing
`renderWasmGraphForge` canonicalScene behavior remains unchanged.

The controller owns primary-click/keyboard capture, DOM focus, ARIA, text-only Rust companion
pages and event dispatch. Rust owns focus order, selection, identities,
provenance, summary and aligned row refs. Hover/gestures/link/temporal/update/
force scheduling and the rest of S5b/S6/S7 remain open. The legacy CSR path is
retained for ordinary `spec.graph` until S6 supplies its attachment/identity
migration; the explicit attachment never reaches it or generic CPU selection.
Primary clicks use existing SelectAt1 with raw two-f64 CSS content-box
coordinates: Replace, Shift Add, Ctrl/Meta Toggle (Toggle wins with Shift).
Trusted native clicks must target the owned canvas. Finite dispatch-time
`offsetX`/`offsetY` originate at the padding edge: subtract padding, not border,
reject outside content, and scale only to accepted viewport dimensions.
Native reported coordinates are authoritative at browser precision, with no
subpixel promise or bounding-rectangle inversion. Public effective
`canvas.currentCSSZoom` must be finite and strictly1, without tolerance;
missing/invalid/nonunit values refuse without commands/cancellation. No DPR,
data-camera or guessed zoom division is applied. Borders/padding/offsets,
ordinary CSS matrix scales and net-unit nested zoom remain supported.
Available `assignedSlot` precedes DOM parent then shadow host. Unsupported
transforms and active motion paths on **inspectable visited** elements remain
conservatively refused. Closed slots hide assignments, so this walk does not
certify absence of hidden transforms; hidden rotations/motion may be eligible
using browser-local offsets with the effective-zoom guard. See the
[native input repair receipt](../performance/graph-s5b-pointer-native-input-repair-2026-11-04/README.md)
for fresh mouse/full-byte parity evidence and precision/capability limits.
Input is synchronously admitted only while live/idle/nonstale, without replay.
Blank Replace preserves highlights; SelectAt preserves Rust logical focus.
Exact hover/picked ref publication remains a Rust wire gap. No ABI, arena,
package gate, compiler/profile/optimizer/dependency or guard changes accompany
this TypeScript/Worker vertical. It implies no performance or release acceptance.
The [full design contract](graph-interaction.md#bounded-explicit-s5b-attachment),
[helper API](../api/browser-wasm.md#experimental-retained-graph-session) and
[append-only receipt](../performance/graph-s5b-attachment-2026-11-04/README.md)
record the bounded contract and actual proof.

## Foundation artifacts

| Artifact | Role |
| --- | --- |
| `crates/xyg-wasm` | Minimal raw-export adapter over `xyg-engine`; no `wasm-bindgen`, browser framework, renderer, or host algorithm |
| `spec/wasm/abi.json` | Versioned raw-export/status manifest |
| `js/src/wasm_abi_generated.ts` | Generated export validator and typed declarations |
| `js/src/wasm_worker.ts` | Static strict-CSP module Worker |
| `js/src/47_wasm.ts` | Main-thread lifecycle proxy; requires explicit worker and WASM assets |
| `js/src/48_wasm_scene.ts` | Thin display-list adapter into the existing WebGL painter |
| `js/src/49_wasm_columns.ts` | Packed `XYCC` typed-column framing; no Scene policy in TypeScript |
| `js/src/49_wasm_semantic_graph.ts` | Packed direct-tier `XYGG` semantic planes; Rust emits styles, primitives, and legend |
| `js/src/49_wasm_graphforge.ts` | GraphForge `XYGQ` framing, `XYGF` decoding, Scene stable-ID → UUID identity, text-only tables; no joins or policy |
| `js/src/63_graph_controller.ts` | Experimental explicit retained graph keyboard, DOM, ARIA and lifetime controller |
| `js/src/63_graph_session_wire.ts` | Internal XYGI framing and complete semantic XYGR decoding; no graph policy |
| `js/src/63_graph_gpu.ts` | GPU-v1 trust-boundary validation and raw buffer presentation through existing GLHost |
| `js/src/49_wasm_chart.ts` | Bounded O(series) validation/framing and lifecycle handle; no record expansion or mark defaults |
| `js/src/49_wasm_ticks.ts` | XYTK/XYTO codec plus latest-wins primary Cartesian ChartView attachment |
| `dist/xyg-wasm.wasm` | Separately built direct-browser engine adapter; never copied into the Python static tree |

The WASM adapter disables `xyg-engine`'s default full `raster` feature and enables
its shared `frozen-raster` capability for retained graph PNG. Native full-scene
formats remain unchanged; frozen Scene/XYPB/SVG/HTML/PNG share Rust lowering,
and HTML uses the shipped painter. The raw module must request no ambient WebAssembly imports.

**Historical artifact size.** Through ABI35, `dist/xyg-wasm.wasm` used the workspace release
profile (`opt-level = 3`, fat LTO, one codegen unit, stripped) and is about
921 KiB raw and 336 KiB gzipped at WASM ABI 27. ABI 28 with GeoColumn
ingestion measures 968137 raw bytes and 352160 gzip bytes (level 9), within
the unchanged 1 MiB raw artifact budget. ABI 29 with frozen geographic
Scene lowering measures 994525 raw bytes and 362640 gzip bytes (level 9).
GraphForge compositions
(composition, views, request/base decoding) and the Arrow IPC reader account
for about 224 KiB of code; there is no single outlier. A size-optimized
profile was measured and rejected, since the module's compute is on users'
interactive path:

| profile | raw | gzip | GraphForge compose, 10k / 100k nodes |
|---|---:|---:|---:|
| `opt-level = 3` (shipped) | 943 KB | 344 KB | 15.6 / 156 ms |
| `opt-level = "s"` | 877 KB | 311 KB | 21.1 / 203 ms |
| `opt-level = "z"` | 777 KB | 280 KB | 38.3 / 363 ms |

The S1 packaging gates were **1,511 KiB raw / 625 KiB gzip6**, a recorded
composition-v2 hierarchy decision for #36 S1. On the validated combined graph
base, the module measured 1,540,374 raw / 637,276 gzip bytes. Hierarchy UUID
resolution, forest validation and hidden-parent reattachment raised this to
1,547,598 / 640,237. Four measured sharing candidates retained a direct parent
resolver and compact ancestor memo, recovering 890 raw / 706 gzip bytes without
changing output bytes, validation, or the deterministic `<=2n` work bound.
The resulting module is **1,546,708 raw / 639,531 gzip bytes**, a net addition
of 6,334 / 2,255 bytes over the combined base. The smallest next-KiB limits are
1,547,264 / 640,000 bytes, leaving **556 / 469 bytes**. These limits admit the
reachable hierarchy functionality; the native session skeleton is not yet
WASM-exported. They reserve no capacity for later interaction slices and make
no runtime-performance claim. Rust 1.96.0, release O3/fat LTO/codegen1/strip,
inline threshold 100, pinned Binaryen 132 and `-O3 --all-features` remain fixed.
The earlier failed gates and all four candidate measurements remain in the
[sharing receipt](../performance/graph-s1-size-repair-2026-10-31/README.md);
the [packaging decision receipt](../performance/graph-s1-package-budget-2026-10-31/README.md)
records the subsequent package validation separately.

Recovered #36 S2 measured **1,547,915 raw / 640,615 gzip6 bytes** and failed
both unchanged S1 gates. A bounded two-candidate follow-up retained only
scratch-free parent-forest validation, reducing it to **1,547,779 / 640,527**
(136 / 88 bytes saved). Outlining the shared compound-flags helper saved no
additional bytes and was reverted. The final module still exceeds the gates
by **515 / 527 bytes**; this is a failed package result, with no budget or
profile change. Exact source/artifact hashes, error-order preservation tests,
and raw measurements are in the
[S2 size-repair receipt](../performance/graph-s2-size-repair-2026-10-31/README.md).

The S2 packaging gates were **1,512 KiB raw / 626 KiB gzip6**, a separate
recorded #36 S2 functionality decision after those two measured candidates.
The retained module adds **1,071 raw / 996 gzip bytes** over S1 through
reachable shared changes, including compound flag propagation and temporal
state changes; S2 session rendering has no new WASM export. The smallest
next-KiB limits are **1,548,288 / 641,024 bytes**, leaving **509 / 497 bytes**
for the measured **1,547,779 / 640,527-byte** module. Compiler, optimizer,
dependencies, signatures, validation, and linear-work guarantees remain fixed.
The independent policy/patch assessment recommended this minimal pair and no
further speculative optimization. These limits reserve no capacity for later
slices and establish no runtime-performance or milestone acceptance. The
historical failed receipts remain unchanged; real packaging, paired assets
and strict-CSP browser validation are recorded separately in the
[S2 packaging decision receipt](../performance/graph-s2-package-budget-2026-10-31/README.md).

**Historical S3 packaging gates were 1,513 KiB raw / 626 KiB gzip6**
(**1,549,312 / 641,024 bytes**), the parent's separate S3 raw-only functionality
decision. The prior S3 child rejected both measured codegen hints because neither
met the then-unchanged raw gate; that historical failure remains intact in the
[S3 repair receipt](../performance/graph-s3-review-repair-2026-10-31/README.md).
After an independent policy review, the parent retained only `#[inline]` on
`CoordinationGate::validate` as a Pareto improvement (historically −119 raw /
−46 gzip bytes), then authorized the smallest next-KiB raw limit. All guards,
guard order, atomicity, profiles, dependencies, flags, signatures and exports stay
unchanged; there is no third size candidate or runtime-performance claim.

Fresh final geometry source is rebuilt and really packaged at **1,548,390 raw /
640,709 gzip6 bytes**, with **922 / 315 bytes** headroom and optimized SHA-256
`db698663bb9db02e50001af58e45c538cbdd9644c778d52ae82aebd6a3baa61a`.
This is **+611 raw / +182 gzip bytes** over the S2 module, attributed to reachable
shared coordination-gate extraction. Typed graph sessions remain unexported;
finite outline-span admission is local S3 Rust policy, not new browser behavior.
The new [S3 package decision receipt](../performance/graph-s3-package-budget-2026-10-31/README.md)
binds the fresh source, actual Node 22 compression, real paired assets and
manifests, parity, native temporal regressions and original full strict-CSP
foundation. Earlier S1/S2/S3 receipts and fixtures remain byte-unchanged. Final
independent review and CI remain pending; packaging establishes no #36, M4,
hardware, ABI-slice or release completion. Further growth must still fail these
limits, without another automatic raise.

**S4 local session boundary.** WASM ABI 35 adds five real session exports
(open/update/render/interact/close), executing the same Rust XYGI/XYGR codec as
native ABI 398 (the named-signature CI repair). Scene 34 and painter 17 are unchanged. One instance retains one
session; all reply planes and retry bytes count toward its existing arena
budget, together with temporal ownership, staging and admitted speculative
work. Temporal replacement/disposal or geographic acquisition revokes the old
owner; an outstanding Arc cannot keep it usable. Ordinary compile/jobs require
closing the session; compatible temporal frames and replacements remain
pre-admitted. Wire status numbers, fixed exact-ID refs, capacity, retries and
transactional publication are specified in [graph interaction §3](graph-interaction.md#3-abi--wasm).
The original 1,513/626-KiB S3 gates rejected S4. Those package attempts
and diagnostic functional proofs are recorded separately in
[S4 local evidence](../performance/graph-s4-local-2026-10-31/README.md); source
checkout tests do not establish shipping-asset acceptance. Historical S3
measurements above continue to describe their own source, not this ABI.

**Historical S4 packaging gates were 1,817 KiB raw / 742 KiB gzip6**
(1,860,608 / 759,808 bytes). After complete-paint, exact-identity, live-owner
stamp and default-arena admission repairs, independent correctness and policy
review approved the source and a separately recorded functionality decision.
Exactly two size candidates were measured; only the fixed UUID hex writer is
retained (73 raw / 37 gzip bytes saved). The reviewed budget-decision module measured
1,860,250 raw / 759,008 gzip6, leaving 358 / 800 bytes. This is 311,860 raw /
118,299 gzip bytes above accepted S3 because the complete session machinery is
first reachable through WASM, including resolved CPU paint and atomic state.
There is no compiler/profile/toolchain/dependency/optimizer/export or validation
change. Both gates remain hard limits with no automatic allowance for later
growth. The [S4 package decision receipt](../performance/graph-s4-package-budget-2026-10-31/README.md)
records the separate real shipping build, paired-asset verification and full
strict-CSP foundation. Historical FAIL/diagnostic records remain unchanged.
The 16 MiB browser default and 384 MiB maximum are unchanged. This package
decision establishes no runtime speed, S5–S7, #36, M4 or release acceptance.

The S4 CI repair preserves standalone XYTG staging behavior: temporal retention
is added to `arena_resize` only alongside a retained GraphSession, matching
co-owned temporal/session pre-admission. Standalone entity/work/output bounds
remain unchanged; no new standalone total-residency guarantee is claimed. The
40,000-node default-arena frame/replacement regression and native ABI 398 policy
repair, with its fresh 1,860,254 raw / 759,013 gzip6-byte module (354 / 795 bytes
headroom under the unchanged gates), are recorded in the [CI repair receipt](../performance/graph-s4-ci-repair-2026-10-31/README.md).

Current native/WASM conformance harnesses compare the module ABI against the
committed generated `spec/wasm/abi.json`, preserving strict equality instead of
pinning the previous ABI literal. Overview reports record the loaded native and
WASM versions. The [foundation contract repair](../performance/graph-s4-foundation-contract-2026-10-31/README.md)
records the ABI-34 assertion failure and the actual geographic conformance rerun
on ABI 398/35; runtime, payload, resource and package contracts are unchanged.

**S5a bounded Rust GPU/result foundation.** The existing XYGR session replies
now add a version-1, exactly 33-section GPU view over already published CPU
`PaintGeometry`, with no new export, Scene/painter ABI, source style resolution,
layout, routing or LOD path. The exact names/indices/counts, flags, reserved
fields, fail-closed validation and action/outcome facts are normative in
[the S5a interaction contract](graph-interaction.md#s5a-rust-gpu-publication-and-controller-result-foundation).
Section starts retain the container's 8-byte alignment. GPU `Bytes` columns are
raw little-endian f32 values at four-byte stride; style records retain the exact
60-byte resolved f32/u8 layout. F64 x/y/dash `[offset,scale]` metadata stays
CPU-side; Rust uses the established offset/scale kernels to produce every
coordinate and attribute. Hosts must not upload CPU f64 paint geometry or narrow
it themselves. All simultaneous focus/highlight and membership state bits remain
available independently of visual-state precedence.

Every successful post-Open publication contains the complete GPU and
`OpOutcome`/focused-action sections, including style-only changes at the same
revision. Open and Poll remain control replies without those sections. Aggregate
focused stops retain stamped aggregate identity even for singleton membership;
their UUID focus stand-in never enables singular move/pin/disclosure actions.
Before cloning a candidate, admission adds `16,384 + 2,048n + 8,192m` bytes to
the existing per-document source/text envelope, including Update's full new
envelope; retained request/reply caches still charge three times actual bytes.
Encoding failure rejects the complete candidate without advancing the successful
publication, owner, operation sequence or retry cache. Browser default 16 MiB,
maximum 384 MiB, native/WASM signatures and export sets, WASM ABI 35,
Scene 34 and painter 17 are unchanged by S5a.

The new [S5a local receipt](../performance/graph-s5a-local-2026-10-31/README.md)
records bounded proof and the failed real optimized shipping measurement:
1,872,537 raw / 764,058 gzip6 bytes, versus the unchanged 1,860,608 / 759,808
limits (11,929 / 4,250 bytes over). Optimized SHA-256 is
`4f27f5d20485ef5b63942c017ffb583191478fe74ecf78b9d94b1e7507f531a6`.
The same production optimizer produces a separately labelled diagnostic module
for native/WASM functional replay; it establishes no shipping acceptance. No
limits, optimizer/profile/dependencies, validation or exports are relaxed, and
there is no size experiment in this slice. Historical S4 asset measurements
remain historical. No new shipping assets/full foundation success is claimed. This foundation adds no browser session transport/controller,
shader, DOM/ARIA or visual emphasis pass; S5b, S6/S7, M4 and all #108 acceptance
remain outstanding before PyPI/npm publishing.

**Historical S5a packaging gates are 1,829 KiB raw / 747 KiB gzip6**
(1,872,896 / 764,928 bytes). Accepted-main integration measures 1,872,541 raw /
764,063 gzip6 bytes, with optimized SHA-256
`355a31bc7f949070251e73dbeebdd7f466d55e9a242a14f7c85bf29fdec59c50`.
The previous hard gates fail by 11,933 / 4,255 bytes. The parent explicitly
retains the independently reviewed Rust GPU/result functionality at its measured
cost: +12,287 / +5,050 bytes over accepted S4. These are the smallest next-KiB
limits, leaving 355 / 865 bytes; no automatic future allowance is introduced.
No size experiment, compiler/profile/toolchain/optimizer/dependency/export,
validation or runtime-arena change accompanies this decision. The repeated
mechanical 60-byte style writer remains unchanged; no unmeasured saving is
assumed. `gpu::validate` remains the Rust inspection/test helper; the bounded explicit
S5b attachment now applies the same trust-boundary checks before host upload. The separate
[S5a package decision receipt](../performance/graph-s5a-package-budget-2026-11-03/README.md)
records real producer, paired-asset and full strict-CSP verification; the
[integration receipt](../performance/graph-s5a-integration-2026-11-03/README.md)
retains the failed old-gate producer and diagnostic replay. Historical failures
remain immutable. This decision establishes no runtime speed, graph scale,
S5b/S6/S7, issue/milestone or release acceptance.

The subsequent S5a binding-count repair builds the reply outcome from the
adopted temporal selection under the existing destination world lock. Its
fresh production module measures **1,872,568 raw / 764,079 gzip6 bytes**,
SHA-256 `862a04c4053dc32f2757a35e8a39d79e837ea276ab0b2a14cd380bfbfb89b820`.
It adds 27 / 16 bytes over the initial S5a artifact and passes the unchanged
1,829/747-KiB gates with 328 / 849 bytes of headroom. No ABI, export, compiler,
optimizer, dependency or runtime-budget change accompanies the correction.
The [binding repair receipt](../performance/graph-s5a-bind-outcome-repair-2026-11-03/README.md)
retains failing-before and passing-after count tests plus actual package proof;
the earlier source/artifact receipts remain historical and unchanged.

**Historical P1 packaging gates were 1,838 KiB raw / 751 KiB gzip6**
(1,882,112 / 769,024 bytes). The combined repaired P1 source measures
1,881,508 raw / 768,134 gzip6 bytes, optimized SHA-256
`717440524b63cf87e0127161c128c4f81efdca87e5112f9b05a42e820b456fde`.
Complete resolvable per-composition selection/result-row snapshots and opt-in
progressive initialization/retained CoSE add 8,940 / 4,055 bytes over the e91
S5a binding repair. The unchanged previous shipping producer failed by
8,612 / 3,206 bytes; that failure and diagnostic replay remain retained.
After independent source, measurement and package assessment, the parent
explicitly adopts the smallest next-KiB functionality limits, leaving
604 / 890 bytes. Borrowed one-pass descriptors and two bounded sparse row
passes provide exact allocation without host identity/provenance policy or a
second force-layout algorithm. No size experiment, compiler/profile/toolchain,
optimizer, dependency, export, guard or runtime-arena change accompanies this
decision. No future capacity is reserved. The
[P1 integration receipt](../performance/graph-session-p1-integration-2026-11-03/README.md)
separates the failed old-gate run, diagnostic validation, decision and subsequent
actual shipping/paired-asset/full strict-CSP proof. Shipping qualification still
requires those fresh production checks and final integrated-diff review.
Runtime arenas remain 16 MiB default / 384 MiB maximum; conservative graph
admission still prevents the required massive-graph ladder. This establishes no
scale, speed, public host/controller/notebook, issue, M4 or #108 acceptance.

**Historical property-default functionality gates (parent decision 2026-11-03):
1,878 KiB raw / 765 KiB gzip6 (1,923,072 / 783,360 bytes).** After completed
independent source review (`m4_defaults_audit`, approved `2ed544dc`) and package
assessment, the parent explicitly retains zero-layer property presentation
through the existing shared native home-domain and label authorities. The
reviewed production candidate measures 1,922,561 raw / 783,148 gzip6 bytes,
SHA-256 `e8011f779e70f58416a751f0067f279d1b9aa9515004c246e2f44c95af192651`,
leaving 511 / 212 bytes under the smallest whole-KiB gates. Growth over accepted
P1 is 41,053 raw / 15,014 gzip6 bytes. The shared home/label policy is newly
reachable on this WASM path; exact component attribution is unmeasured, and
generic cartesian ticks were already reachable. The prior 1,838/751-KiB
producer failure and rejected-candidate functional proof stay immutable
historical failures; they are not retroactively shipping passes.
The [new package receipt](../performance/graph-property-default-package-2026-11-03/README.md)
records the explicit decision and fresh combined CSS/property production
qualification, including normal shipping packaging, paired manifests/inline
assets, full unfiltered strict-CSP foundation, and unmasked property images.
Native ABI 399, WASM ABI 35, Scene 34 and painter 17 stay unchanged. No
compiler/profile/toolchain/optimizer/dependency/export/validation or 16/384-MiB
runtime-arena change, automatic future allowance, performance win, or broad
issue/milestone/publication acceptance accompanies this decision. Future
growth beyond either gate fails until separately decided and reviewed.

The raw gate previously moved from 1,504 to 1,507 KiB for XYPB v17 (#1036): the painter
writer now runs the Rust tick-label strategy layout, including per-side rotations.
After merging main `4631927`, the local optimized build measures **1,542,222 raw
bytes** and **636,944 gzip bytes** (Node `gzipSync`, default level 6), compared with
the earlier merge-base build's 1,539,454 raw / 635,754 gzip. The gates remain
1,507 KiB raw / 624 KiB gzip, with 946 / 2,032 bytes of headroom respectively.

The #934 property-graph recovery onto accepted main `ec90340c` keeps those
same gates and the existing compiler/optimizer profile. Local packaging with
Rust 1.96.0, Node 24.21.0 and pinned Binaryen 132 (`npm run build:wasm`) measures
**1,543,118 raw / 638,560 gzip bytes** (Node `gzipSync`, level 6), SHA-256
`907551f3a16fbe7127ea243d0226c7e3a552595cf663190a0b0ac5482002ad15`.
Headroom is **50 raw / 416 gzip bytes**. The caption decoder merges candidates
one at a time, short-UUID captions use the same eight hex digits directly, and
the shared class-ranking helper reuses its code vector to track assigned ranks.
These preserve output semantics and fit the existing gates; no runtime speedup
is claimed. Native ABI 396 and the WASM/Scene/painter versions are unchanged.
The actual packaged WASM is checked against native for all GraphForge parity
fixtures. Combined milestone changes must rerun packaging after integration;
this measurement covers the isolated recovery only.


ABI 30 camera transport and closed polygon caches make the default O3 artifact
1,060,579 raw bytes. The target-specific `.cargo/config.toml` keeps O3, fat LTO,
one codegen unit and stripping; ABI30 set LLVM's inline threshold to 150.
Native builds remain unchanged. The ABI30 artifact was 1,028,586 raw bytes and
376,783 gzip bytes, below the unchanged 1 MiB gate. This is a measured size/runtime
tradeoff, not a claim of a speedup: four ABBA pairs at 100/10,000/100,000 rows
produced byte-identical outputs across GraphForge composition, geographic Scene
compile and camera-column projection. At 10k/100k rows, median candidate costs
were 0.8–4.8% above baseline (about 1.89ms at the largest GraphForge case); the
100-row GraphForge case costs about 4.5µs more. These synthetic Arrow contracts
measure XYG composition, not GraphForge algorithm execution, browser paint or
massive-data behavior. Raw samples, environment, input generator and reproduction
commands are recorded in `spec/benchmarks/wasm-inline-150-local.json`.
The earlier global size-optimized profiles remain rejected.


ABI31's complete geographic catalog and interactions use the same O3 profile,
with a target-specific inline threshold of 100 and a build-only pinned
Binaryen132.0.0 `wasm-opt -O3 --all-features` post-link pass. Packaging reads the
source once, optimizes an isolated temporary copy, validates the exact optimized
export/import/signature and ABI/Scene version contract (start functions are rejected; painter version is verified by the real painter conformance tests), applies the recorded raw and gzip size gates, then
publishes those validated bytes and their deterministic inline digest. The
optimizer is an Apache2.0 npm devDependency; no Binaryen code or dependency
enters the browser runtime. Native builds remain unchanged.

The measured artifact is 1,034,845 raw / 418,362 level9 gzip bytes. The
same-source inline150 raw baseline is 1,172,316 / 431,903 bytes. Four ABBA
pairs compare byte-identical admitted GraphForge, Scene, camera, catalog and
interaction results at 100/10k/100k rows. Geographic medians range from 6.0%
faster to unchanged. GraphForge costs about 9µs more at100 rows, 0.067ms more
at10k and 1.64ms more at100k (+3.6%). Both artifacts explicitly reject the
100k interaction request under the existing processor peak policy; no latency
is assigned to that rejected operation. Fresh-process Node startup medians
were 27.73ms versus26.92ms, with compilation1.09ms versus1.01ms. These local
measurements do not establish browser paint, production or massive-scale wins.
Raw samples, hashes, environment, source files and commands are committed in
`spec/benchmarks/wasm-geographic-profile-local.json`.

The original raw artifact gate was 1 MiB. The retained geographic source,
resumable membership, certified simplification, tile cache, frozen snapshots,
and transport credit introduced in ABI 33 require an explicit budget decision:
The initial gates were **1,310,720 raw bytes (1.25 MiB), plus 524,288 gzip
bytes (512 KiB)**. They are historical and superseded by the linked-state and
temporal-overview functionality decision below; the combined hierarchy/selected snapshot decision below supersedes them;
packaging now enforces 1,882 KiB raw / 768 KiB gzip6 limits (including the recorded S1 hierarchy, S2 shared-functionality, S3 raw-only, S4 session-functionality, S5a GPU/result-functionality, P1 selection/progressive-functionality property-default shared-presentation and #36 picked-target functionality decisions). The Scene v33 secondary-y axis (#1006) raised them from 1,472 / 608 KiB to 1,504 / 616 KiB (measured 1,520,523 raw / 625,159 gzip6 bytes locally and 627,899 gzip6 on CI, previously 1,505,822 / 618,706). The #1006 straight-arrow vocabulary (Scene v34) then raised the gzip limit to 620 KiB (+5.0 KB raw / +2.4 KB gzip; raw stays 1,504 KiB). The static-export LOD tiers and their budget checks, layered/polar/mesh autorange admission, the `XYWA` exact polar wedge-arc encode/validate/SVG path, and the triangle-mesh overdraw bound (#1006, scene-ir.md "Public static LOD tiers" and "Polar wedge SVG arcs"; the SVG dense-fill rasterizer itself is behind the `raster` feature the WASM adapter disables) then raised only the gzip limit to 624 KiB: 1,538,122 raw / 635,040 gzip6 bytes against main's 1,527,867 / 630,943 after #1023, #1034 and #1037, measured with the same local toolchain (+10,255 raw / +4,097 gzip), which exceeds the 620 KiB gzip limit by 160 bytes and leaves 3,936 bytes of gzip headroom; the raw limit keeps 1,974 bytes of headroom. WASM compiles and decodes the same Rust Scene, so dropping the sidecar from WASM would break native/WASM Scene parity. The release compiler and pinned Binaryen 132 `-O3
--all-features` profile remain unchanged; this decision admits functionality,
not a compiler optimization or performance win.

The local ABI 33 candidate is 1,230,703 raw / 502,593 gzip bytes, SHA-256
`b4ef252d2acb7ab0c916cd8e91d966bb3e7c1b1b64d2ec79887bce47cfdf2f72`.
The ABI 32 predecessor was 1,034,845 raw / 418,362 gzip bytes. This growth is
18.9% raw and 20.1% gzip. Three fresh-browser-process/profile retained Worker
startup samples are 28.3, 25.9, and 34.7 ms (median 28.3 ms), accompanied by
actual five-view GL painting, strict offline CSP, cancellation/ownership, and
malformed-receipt regressions. [Raw reports and reproduction commands](../performance/geo-scale-browser-2026-10-08/README.md)
record the artifact, environment, and verified output contracts. Startup is
Worker construction to ready over raw loopback HTTP with a warm OS file cache;
it excludes main ESM parsing and was measured under uncontrolled development
load. These are local samples, not a paired profile comparison, cold disk/WAN
latency, or massive-scale paint/interaction evidence. Further growth beyond
either gate requires another recorded decision rather than silent drift.

`XYTS` magic, header and descriptor offsets, flags, and mark-kind codes are
owned by `spec/wasm/abi.json` and emitted into generated TypeScript and Rust
contract modules. The thin framer and Rust decoder both consume those generated
values, while schema validation rejects missing, unknown, overlapping,
misaligned, or out-of-range fields before either module can be emitted. This keeps wire
mechanics host-visible while leaving identities, mark defaults, geometry, and
all per-record decisions exclusively in Rust.

`XYGG` v3 is the bounded semantic-graph compile ingress. Its source count is
limited to a combined 1,024 direct-tier nodes and edges (`n + e <= 1,024`),
and Rust separately enforces the
1,024 emitted-painter-trace ceiling after expanding resolved halo, dash, and
arrow primitives. The framer validates the direct tier, combined element
count, viewport dimensions, bounded string labels, finite coordinates, exact
codes and flags, compound-plane shape/representation, and final aligned buffer
length. Rust owns semantic interpretation, domains, state precedence, light/dark
paint, legend ordering, final node/edge label placement and truncation,
transitive compound/collapse resolution, and all screen-space expansion. The
thin framer requires exact node-count parent, parent-validity, and collapse
planes together; omitted planes encode one flat forest. Aggregate
LOD must omit source-indexed semantic planes and is rejected explicitly.

The compiler preserves source-edge IDs through parallel routes, self-loops,
semantic layers, dash spans, and arrowheads; run grouping is independent of
pick identity. Viewports are bounded to 16,384 px per side, peak storage is
charged before owned column allocation, and each expanded primitive is charged
before append. Light/dark backgrounds and axis/label chrome are Scene bytes,
not CSS defaults.

## Memory and copy contract

An ordinary JavaScript `ArrayBuffer` cannot alias wasm32 linear memory. The
default contract is therefore:

1. Canonical typed source stays in JavaScript-owned buffers.
2. Moving a buffer to the Worker uses `postMessage` transfer by default, so it
   does not clone the payload between main thread and Worker.
   The high-level chart handle is intentionally safer: its default
   `dataOwnership: "preserve"` path uses structured cloning, copying caller
   buffers into the Worker without detaching them. This differs from the
   low-level API's default transfer; `dataOwnership: "transfer"` explicitly
   selects that zero-clone, detaching handoff for the high-level handle.
3. The Worker copies only the bounded operation slice into a reusable WASM
   staging arena. The Rust adapter enforces the per-instance logical bound and
   a 384 MiB compile-time ceiling.
4. Rust validates or computes from that slice. Outputs remain bounded scene/LOD
   records and are copied or transferred back as their contracts require.
5. The arena's logical length returns to zero. wasm32 pages may remain reserved
   because WebAssembly memory cannot shrink; the budget prevents unbounded
   ratcheting.

Future full-data algorithms must stream bounded chunks through the arena or use
an explicitly measured alternative. They must not claim zero-copy JS→WASM
aliasing. `SharedArrayBuffer` is an optional future optimization that requires
an isolated context; this foundation rejects it explicitly rather than
silently cloning or changing ownership.

The foundation diagnostics report every non-empty JS→WASM staging copy at the
successful arena-resize boundary, before validation can reject a stale,
cancelled, malformed, or incompatible request. They include copy count,
split-u64 copied bytes, current logical arena length, scene record/style counts,
arena high-water bytes, current WASM linear-memory bytes (also its high-water
because WebAssembly memory cannot shrink), ABI version, and scene version.
The Worker normalizes semantically unsigned wasm32 results before exposing
them, so a set high bit in either copied-byte half remains a non-negative u32.
They never log user values.
Successful results expose this snapshot directly. Worker-reported failures
after instance initialization attach the same snapshot to
`XygWasmError.diagnostics`; locally rejected or pre-initialization failures use
`null`. The error snapshot is captured after
fail-closed staging cleanup, so `arenaBytes` is zero while cumulative copy and
high-water counters remain inspectable. Rust tests and the strict-CSP Worker
test pin the typed-series fragmentation boundary at 1,025 line-series painter
traces: the request returns `RESOURCE_LIMIT` with the stable
`XYG_PAINTER_TRACE_LIMIT` diagnostic (see Painter admission), publishes no
painter output, and reports the one staging copy and exact copied byte count
without host-side inference. 1,025 single-point scatter series are one packed
kind-8 trace and succeed.
`XYTS` is the canonical authoring/compile ingress, not the live §29 paint wire
and not an `XYBF` transport envelope. Its column attachments are exact raw
`Float64Array` source values, matching the CPU-side f64 authority. The main
thread only validates bounded descriptor shape and transfers (or, under the
explicit preserve policy, clones) those source buffers to the Worker. The
Worker performs one bounded byte copy into WASM linear memory. Rust then
validates, expands mark records/defaults, and is the sole layer that narrows
canonical f64 geometry to offset painter f32/u8 output. TypeScript never scans,
converts, or re-encodes per-record values. The resulting `XYPB` painter buffer
is the live WebGL-consumed format governed by §29's raw-f32/u8 rule.
Painter output is attempt-local instance state. Arena resize, validation,
cancellation, the start of another prepare, any failed prepare, and disposal
clear it; the Worker copies a successful output into one transferable
ArrayBuffer before resetting the arena. A prior success can therefore never be
observed after a later failure or non-paint operation.
`prepareScene` clears the staging arena after a successful `SceneDocument`
decode and before painter lowering, so staging bytes and painter output never
both retain the per-instance byte budget at once. The combined live staging
plus painter buffers must always stay within `max_arena_bytes`.

## Version and scene contract

`WASM_ABI_VERSION` is 30. ABI 30 adds the stateless typed camera protocol
(`xyg_wasm_geo_viewport_execute`; [contract](geo-viewport-protocol.md)). ABI 29 adds frozen geographic `XYGP` → `XYGS` compilation
(`xyg_wasm_geo_scene_compile`). ABI 28 adds sequenced single-use GeoColumn
ingestion (`xyg_wasm_geo_column_ingest`) and `xyg_wasm_geo_metadata_version`.
ABI 27 adds `xyg_wasm_graphforge_compose` and
`xyg_wasm_graphforge_composition_version`: one staged GraphForge `XYGQ`
request in, the native host's byte-identical `XYGF` document out
([graphforge-compositions.md](graphforge-compositions.md) §6.3). ABI 23 introduced the bounded `XYTK`/`XYTO` tick
resolver and its independent Worker sequence lane; ABI 26 added the
default-palette and stricter packed-tick validation cuts that ABI 27 keeps.
ABI 22 retains the bounded `XYSA` v1 envelope and
accepts `XYAD` v2 annotation decorations: existing `XYAT`/`XYAL`/`XYAR` slices
plus bounded `XYAC` v1 Cartesian callouts. Rust decodes the complete canonical
`XYGS` Scene first, then validates and projects raw Cartesian anchors through
its already validated layout/scales, applies the bounded screen-space offset,
and emits the ordinary painter output. TypeScript only frames/transfers byte
slices; it does not derive callout geometry or placement. ABI 13 adds exact compound planes to `XYGG` v3 and
routes them through the canonical Rust compound Scene compiler while retaining
the Scene v16/painter v11 contract. ABI 12 added the bounded `XYDP` dashboard
resource planner. Earlier revisions added Scene
paint, packed typed-column compile, transferable `XYTS` series descriptors,
resumable Tier-2 aggregation, and packed `XYTC`/`XYTR` temporal-controller
commands and snapshots. ABI 8 adds
packed `XYTG` temporal-graph binding/frame commands and Rust-produced `XYTF`
visibility, UUID membership, and remapped visible topology for layout.
ABI 14 adds packed `XYGC` → `XYCO` disclosure transitions. Stable IDs
(`u64[n]`), parents (`u64[n]`), validity (`u8[n]`), and collapse state
(`u8[n]`) are exact and bounded to 1,024 nodes. Rust alone validates the group,
forest, action, and Direct-LOD eligibility and computes the atomic next state.
The public `transitionWasmCompound` helper performs strict structural framing
and delegates the transition to that worker export. The strict-CSP browser
evidence expands and recollapses a real semantic graph, proving descendant
identity appears and disappears together in GPU traces and the single current
accessibility label layer.
The temporal subprotocol is version 2: its variable tail is a bounded raw-u64
stable-ID selection owned and canonicalized by Rust, while all temporal samples
remain raw i64. A range/cursor/window/selection snapshot is decoded and committed as
one Worker response; TypeScript neither sorts IDs nor applies partial state.
`SCENE_VERSION` remains independently versioned and is 34 for this contract.
`scripts/gen_wasm_abi.py --check` rejects parameter/result drift among
the manifest, raw Rust exports, generated TypeScript declarations, and the Rust
scene constant, including aggregate and temporal lifecycle exports. `js/package-wasm.mjs` parses the compiled module's type,
function, and export sections and rejects artifact-level signature drift.

`validateScene` remains the allocation-free validation seam. `prepareScene`
validates the same bytes and asks `xyg-engine::SceneDocument` to lower them to
bounded painter-ready f32/u32 columns plus a fixed trace descriptor table.
`renderWasmScene` creates only descriptor-sized views over that transferred
buffer and hydrates the existing WebGL painter. The exported lower-level
`hydrateWasmPainter` accepts only already-prepared painter output and applies
the same complete fail-closed validation before allocating browser paint state.
TypeScript does not scan Scene
records, map data, decide clipping or grouping, narrow f64 geometry, copy
columns, or run a fallback algorithm. Stable u64 IDs remain split lo/hi binary
columns and are exposed by `view.sceneStableId(traceIndex, rowIndex)`.
Scene v25 retains record metadata byte 3 explicitly: `0` retains legacy
trace/run identity, `1..6` identifies the bounded annotation kinds (with `5`
for Rust-projected straight arrows and `6` for Rust-resolved Cartesian
callout leaders), and `128`
marks literal per-row identity whose value must never classify annotations or
split connected line/area geometry. Painter v14 retains only the annotation tag
in descriptor byte 2. TypeScript therefore never interprets an authored u64 as
an internal namespace, while pick identity round-trips unchanged.

Painter contract v17 begins with `XYPB`, independent painter version 17, canonical
Scene v34 (`SCENE_VERSION = 34`), a 420-byte header (v16 inserted the 88-byte y2 axis
block at 264, a 32-byte y2 chrome-text record at 352, and moves the length words to 384;
see `scene-ir.md` for the full map), 64-byte trace descriptors, viewport/plot f32
bounds, bounded trace and tick counts, and absolute offsets to the tick and
UTF-8 label tables. Header bytes 64–263 are the exact validated Scene v23
chrome style input (backgrounds plus x/y side, masks, paints, and major/minor
geometry); bytes 264–275 carry the bounded figure-title/x-label/y-label UTF-8
lengths and bytes 276–279 are reserved zeros. The shared string table stores
those three authored texts before formatted tick labels. Header bytes 280–283
carry the exact appended legend byte length, 284–287 the bounded literal `XYCB`
colorbar length, and 288–291 the bounded `XYLB` label-block length. The
validated trailer order after tick-label strings is `XYLG` → `XYRG` → `XYCB` →
`XYRG` → `XYCT` → `XYLB`: Rust resolves the geometry of each optional legend/colorbar
record before the following decoration. `XYCB` v2 carries only bounded literal
stops, optional major values, and a minor-tick request; the following `XYCT` v1
contains Rust-resolved major/minor values, screen positions, and major-label UTF-8
tables. Rust writes the frame bounds, title and row baselines,
and literal line/marker/rectangle swatch geometry. TypeScript validates and
projects those coordinates; it does not position, wrap, scroll, or fit the
authored legend. `XYLB` stores Rust-final graph-label screen coordinates, font,
RGBA, UTF-8 text, and source u64 identity; v2 additionally carries a
Rust-owned text-anchor. Version 3 additionally carries a Rust-resolved optional
callout-label background rectangle and RGBA fill. TypeScript projects that exact
box before its label and marks it `aria-hidden`; it does not measure or reposition it.
Version 6 (112-byte record) adds an authored `f64` rotation at record offset 104
(degrees, clockwise-negative, matplotlib convention; the upright 104-byte v5
layout otherwise). TypeScript draws it as a CSS rotation about the label anchor
point, matching the static SVG `rotate(-deg x y)`. The browser painter carries
XYLB v1 through v6 only; v7 (annotation provenance) is Scene-wire only and Rust
normalizes provenance before painter encoding. Both ceilings are pinned:
`BROWSER_PAINTER_XYLB_MAX_VERSION` in `scene.rs` and `XYLB_PAINTER_VERSIONS` in
`js/src/48_wasm_scene.ts` (#1040).

XYPB v17 (#1036) carries each axis's Rust-resolved tick-label layout in the x, y and y2
axis blocks. Byte 5 (formerly reserved) uses bits 0-2 for the mode Rust applied
to the kept labels (Scene strategy codes: `2` rotate, `3` stagger, `4` preserve,
`5` none, `6` off;
auto, hide and preserve all arrive as `4` because Rust has already thinned them).
Bits 3-4 and 5-6 carry the bottom/left and top/right display anchors
(`0` start, `1` center, `2` end); bit 7 is reserved zero. Bytes 6-7 are an
`i16` bottom/left label rotation in hundredths of a degree.
The top/right rotations use the same encoding at header bytes 416-417 (x),
418-419 (y), and 378-379 (y2; formerly reserved in its chrome-text record). Labels
the layout drops (and all labels under `none`/`off`) arrive as empty strings.
The browser applies exactly that for `tick_resolution: "rust_scene"` axes: it skips blank labels, rotates
by the carried angle for each label side, puts alternate labels on a second row
for stagger, and never re-runs its own auto/downsample logic; `none` hides ticks
and labels while the frame spines stay, like the static SVG. Rust resolves both label sides independently,
so default rotation has the same side-specific sign as static SVG, while an explicit
rotation applies to both sides. Rust reduces equivalent full turns into the
`[-180, 180]` degree range before hundredth-degree encoding, while resolving
each display anchor from the original angle and any authored anchor. Thus
`350` degrees paints as `-10` degrees with its original anchor, rather than
clamping to the wire limit or deriving alignment from the reduced sign. The
browser applies those anchors literally.

At the resolved-Scene consumer boundary, the decoder privately carries the exact
Rust-final plot rectangle from XYPB into ChartView. `_layout()` uses that bound
directly: decoded padding is not an ordinary responsive padding floor, and
browser title/tick/secondary-axis gutter measurements must not add room to it.
This private bound does not change ordinary host padding or layout semantics;
setting an axis's tick discriminator alone does not supply a final plot.

For `tick_resolution: "rust_scene"` axes, Cartesian spine coordinates are stroke
centerlines on the Rust plot boundary. The public HTML `axis_line` slot box has
perpendicular origin `boundary - axis_width/2` and canonical segment length.
The browser honors finite nonnegative resolved widths, including zero and
subpixel values, on all four sides and resolved secondary/extra axes, without
rounding, pixel snapping or DPR offsets. Paint, alpha, visibility and ticks stay
Rust-owned. Ordinary axes keep their existing interior-aligned HTML boxes,
minimum 1px thickness, CSS paint and layout.

Undecorated solid resolved boxes paint through genuine SVG `line` strokes in
the existing labels layer, with flat ends. The HTML slot remains the class and
inline cascade authority. An undecorated reference box of the already-resolved
geometry distinguishes CSS used-value quantization from authored geometry
changes, without a rounding rule: when the used rectangles match, SVG keeps
the original decoded coordinates and width literally (for example width .3,
not the DOM box's .296875). When authored CSS changes that rectangle, its actual
paint box mechanically maps to the SVG segment and thickness. Its solid
background maps to stroke color, and
its opacity, visibility and stacking level carry across. Authored width/height
or position overrides retain that CSS box's footprint; they do not change Rust
layout or re-center the public box around a newly resolved width. The private
SVG carries no duplicate public slot. The HTML box is clipped only while its
SVG paints, so solid alpha is not painted twice and public computed background
and box measurements remain available.

Plain-CSS chrome compatibility (§36) also includes box effects. The adapter
conservatively keeps HTML paint, with no SVG copy, for background images
(including gradients), borders/border images, padding, rounded corners,
shadows, painted outlines, filters/backdrop filters, transforms (including
individual translate/rotate/scale or zoom), supported non-`none` motion paths,
supported non-`none` `-webkit-box-reflect` on the box, masks, clipping, non-normal blend
mode, non-border-box background clipping, non-visible overflow, generated
pseudo-element content, animations or nonzero transitions. Non-absolute,
non-block or content-hidden boxes also stay HTML. Effective `pointer-events`
other than `none` also retains HTML: clipping the public slot and substituting
a pointer-transparent SVG must not remove an authored hit/click/hover region,
including important class overrides. Transformed/zoomed/motion-path ancestors
or a labels layer with top/left border or padding retain HTML because a screen
rectangle cannot faithfully invert that CSS geometry. An authored important
clip rule that prevents suppressing the old box also retains HTML. This is a
narrow solid-box projection, not a general CSS-to-SVG renderer. Motion-path
and reflection checks require a nonempty supported computed value other than
`none`; an absent/unsupported property does not make every spine ineligible.
The CSS cascade is evaluated again on each chrome draw. Resolved spines also
re-evaluate their existing public boxes after discrete pointer enter/leave,
press/release/cancel, focus and keyboard state changes (including ancestor
`:hover`, `:focus-within`, `:active` and control `:active` selected through
`:has()`). One coalesced animation-frame callback updates only those
projections; it neither redraws/replaces the public slots nor polls at idle.
The existing theme mutation observer also watches authored class/style edits
on resolved public slots, ignoring private SVG and its own suppression writes.
`refreshTheme()` and ancestor class/style theme changes retain the existing
chrome redraw path. Switching between solid, border and gradient styles
removes the previous copy and suppression before selecting one paint path.
Destruction cancels a pending state update and removes its input listeners.
Ordinary charts install no resolved-spine input watch or subtree observation.

Private SVG wrappers and lines have inline important implementation styles,
including resets limited to those private nodes. Host `svg` / `svg line` rules,
normal or important, cannot override their paint, width, transforms or other
presentation. The resolved coordinates remain attributes, with CSS geometry
and transforms reset; paint/opacity/visibility/stacking come only from the
public HTML slot. The public slot receives no reset and retains normal class,
inline and important cascade authority. As for the existing canvas token
bridge (§36), stylesheet replacement or non-color-scheme media flips that
have no observed state event can still require `refreshTheme()`.

Default/solid resolved stroke coverage is checked against actual independent
native SVG exports and actual browser screenshots. Authored box-effect
fallback promises browser/CSS appearance, with no invented native export
parity. Native raster strokes still have round caps while canonical SVG and
browser SVG/HTML spines have flat ends; arbitrary endpoint pixel equality is
not asserted. The #1089 consumer receipts retain the historical native
property-graph initial home-view, caption and theme failures. The subsequent
[property-default qualification](../performance/graph-property-default-package-2026-11-03/README.md)
records all six unmasked image pairs passing for the current property source;
broader #935 intent/digest/safe-pair scope remains open. The [consumer repair receipt](../performance/graph-resolved-scene-consumer-repair-2026-11-03/README.md)
records the fresh all-pixel default-property comparisons; the [R4 eligibility
repair receipt](../performance/graph-resolved-axis-eligibility-repair-2026-11-03/README.md)
records pointer/motion-path/reflection reproductions and compatibility repair.
The [live CSS repair receipt](../performance/graph-resolved-axis-live-css-2026-11-03/README.md)
records actual pointer/focus/active input, unrelated normal/important host SVG
rules, and a controlled centered-HTML diagnosis with the Rust-final plot.
These preserve the unchanged historical failures, including the [earlier projection receipt](../performance/graph-resolved-axis-repair-2026-11-03/README.md).

The resolved Scene plot/axis and live CSS repairs merged as #1089 at
`a0636c27ec48c50eb1eafa2c99122d165d266c28` on 2026-11-04 at 02:22:11Z.
The accepted main tree is byte-exact to reviewed `46c2573c`; the
[property main-sync receipt](../performance/graph-property-default-main-sync-2026-11-04/README.md)
records that identity and preservation of the subsequent ABI399 property
presentation source. The bounded experimental S5b primary-click/keyboard/GPU/companion
attachment is implemented above; broader S5b runtime/visual acceptance remains open.

The subsequent property-default presentation merged as #1090 at
`7c751db1ba216005fe0f3eaf81922d44b4d01157` on 2026-11-04 at 03:26:23Z.
Its accepted main tree is byte-exact to reviewed property head `68ee59f1`;
the [controller main-sync receipt](../performance/graph-s5b-attachment-main-sync-2026-11-04/README.md)
records that identity while preserving the separately reviewed R2 controller
source. That base explicit keyboard/GPU/companion attachment merged through
main's queue as #1091 at `d6fcacfd482d425a731c5b1ebd492e32dc8a15b4` on
2026-11-04 at 04:35:11Z. Its entire accepted tree is byte-exact to reviewed
controller head `c3013b30`; the [pointer accepted-main sync receipt](../performance/graph-s5b-pointer-accepted-main-sync-2026-11-04/README.md)
records the normal squash-history merge while preserving the separately
reviewed native-input pointer source and qualified runtime evidence. The bounded
primary-click/keyboard/GPU/companion attachment is implemented and independently
reviewed on this branch; #1092 main acceptance, final accepted-main sync review
and broader S5b/S6/S7 acceptance remain open.

The authored collision header at bytes 76-79 is zeroed in the painter. The client accepts exactly
one painter version, so an older XYPB fails closed (`Rust painter contract version is
incompatible`) and the Rust constant `BROWSER_PAINTER_VERSION` and `XYG_WASM_PAINTER_VERSION` move together.
TypeScript validates and materializes those decisions
without positioning or collision policy. Legends whose intrinsic width or height exceeds the plot fail
closed before encoding so SVG, raster, and browser consumers share one policy.
The strict-CSP foundation proof also fetches the v23-schema authored Scene
fixture generated by the public Python `Figure`; its paired Node public-API
test reconstructs the same declarative Cartesian authoring and requires the
same Scene SHA-256. The browser consumes the bytes only through the WASM
worker, then verifies chart/plot backgrounds, top/right axes and labels,
legend, literal colorbar ticks, and the callout-label background. This keeps
browser chrome consumption structural rather than host-layout-derived.
Each 64-byte trace descriptor starts with kind/symbol/annotation/reserved bytes,
then a u32 primitive count. Kinds 0–4 retain their prior scatter/polyline/rect/
band/three-vertex polygon layouts. All offsets are absolute and all data planes
are emitted contiguously in the order below; metadata views consume the planes
without JavaScript gathering, sorting, triangulation, color resolution, or size
normalization. Canonical Image records are consumed rather than omitted.

| Derived kind | Coordinate offsets | Identity offsets | Additional planes |
| --- | --- | --- | --- |
| 5, Image (`count=1`) | 8/12/16/20: one f32 x0/y0/x1/y1 | 24/28: u32 low/high | 48/52: width/height values; 56: raw RGBA8 offset; 60: exact byte length `width*height*4` |
| 7, triangle instances | 8/12/16/20/48/52: f32 x0/y0/x1/y1/x2/y2 | 24/28: u32 low/high per triangle | 56: RGBA8 fill plane; 60: byte length `count*4` |
| 8, marker instances | 8/12: f32 x/y; 16: u32 source style refs; 20: zero | 24/28: u32 low/high per marker | 48: raw f32 CSS diameter; 52/56: RGBA8 fill/stroke; 60: four-f32 CSS style rows |
| 9, segment instances | 8/12/16/20: f32 x0/y0/x1/y1 | 24/28: u32 low/high per segment | 48: RGBA8 stroke; 52: four-f32 CSS style rows; 56: u32 source style refs; 60: zero |

Kinds 5/8/9 reserve bytes 32–47 as zero. Kind 7 reserves its scalar fill
32–35 as zero and retains common stroke RGBA/width at 36–43, with zero diameter.
New kinds have zero symbol and annotation bytes. Kind 7 batches only explicit
Scene Triangle primitives, splitting on a visible primitive of another kind,
an invisible source boundary, annotation tag, or differing stroke paint/width.
Each instance carries its own resolved fill and complete u64 identity. Kind 8
batches adjacent ordinary visible Scatter records across color, width, diameter,
and symbol changes. Kind 9 batches only explicit Scene Segment primitives;
an arbitrary Polyline is never reinterpreted as independent segments. Paint
order is retained. Marker/segment planes use 48 bytes per instance; triangles
use 36. Rust includes every plane and image byte in preallocation admission.

The CSS style row is `[1,-1,resolved_width,symbol]` (segment symbol is -1).
The marker width includes Rust's line-only-symbol default. The existing GPU
program applies only CSS-to-device width conversion through
`u_instanceStyleCss` and `u_dpr`; the client uploads the exact plane, never
rebakes it on DPR changes. Raw marker diameters use the existing size channel
with unit range `[0,1]`, preserving the Rust float values for paint and picking.
Packed canonical segments retain the native round-cap policy within the
existing segment program, including DPR scaling. Generic authored channels and
segments keep their existing units and behavior.

Image pixels are straight-alpha RGBA8 in image-top-first order. They upload
directly into the existing nearest-filtered true-color texture program. The
image's screen y range anchors row zero at its top; no host pixel transform is
performed. Positive dimensions, positive bounds, exact byte length, kind-specific
reserved fields, count, and contiguous offsets fail closed before hydration.
Per-instance planes retain complete identities, with no synthesized feature IDs.

Rust derives default numeric
ticks or consumes bounded authored major/minor positions, formats major labels,
maps positions to painter coordinates, and emits fixed 16-byte records whose
last u32 distinguishes major from minor. TypeScript validates the three chrome
texts and supplies them to the existing title, axis-title, and accessibility
surfaces. Figure-title paint is the authored label RGBA and its size is the
authored label font size plus two pixels, matching Rust SVG and raster output.
It creates descriptor-sized views and hands
those painter-ready values to the existing canvas/DOM chrome surfaces; it does
not generate ticks, format labels, or choose layout. Reserved fields, exact
offsets, finite geometry, known kinds and symbols, valid UTF-8, and exact final
length fail closed before hydration.

For a Band descriptor, byte 1 is the Rust-owned Scene v25 outline mode
(`None`, `Top`, or `Perimeter`). TypeScript projects that mode into the existing
area painter only: `Top` draws the top boundary, `Perimeter` additionally draws
the base and both endpoint faces, and `None` allocates no outline buffers. It
does not infer topology from paint alpha or reconstruct a closed path from
host defaults.

### Painter admission

The descriptor graph has an independent Rust-enforced ceiling of 1,024 trace
runs, recorded as `painter_max_traces` in the generated WASM contract. A valid
Scene can still split a run on every record: a Polyline, Rect, Band, or
PolyFill run breaks on run identity or style, annotated Scatter records
(`annotation_tag` 1–6) are one descriptor each, and any visibility or kind
change ends the current run. Without this ceiling that compact input could
expand into O(records) `ChartView` and GL objects on the main thread. Rust
stops while discovering run 1,025 and returns the stable trace-limit rejection
before allocating or transferring a descriptor table. TypeScript repeats the
generated ceiling as defense in depth. Callers may reduce fragmentation or
split work into explicitly managed views; the browser never silently merges
runs because that would change line breaks, styles, symbols, or stable
identity. Static export admission does not imply painter admission (#1006):
for example a triangle mesh above 1,024 faces with per-face `stroke_width`
exports to SVG/PNG/PDF, but the browser painter on that Scene returns
`XYG_PAINTER_TRACE_LIMIT`.

Per-instance batches are not fragmentation (#945). Kinds 8 and 9 carry every
marker's or segment's resolved paint, width, symbol, diameter, and complete
identity in their own planes, and kind 7 carries per-triangle fill and
identity, so those per-instance changes never create runs (only the split
rules listed in the kind table above do): a
Scene or typed-series request of 1,025 single-point alternating-color or
alternating-symbol scatter series is one kind-8 trace and renders. The
adversarial fragmentation evidence therefore uses distinct-identity Polyline
runs (for example 1,025 two-point line series), never scatter series.

Admission order and accounting are deterministic and identical on every host
(#1007):

1. Run discovery happens first and is bounded by the ceiling, so an input over
   1,024 runs is a trace-limit rejection under any byte budget.
2. Bounded painter tables are checked before their O(records) construction;
   glyph-marker labels are counted against `MAX_SCENE_LABELS` (128 including
   authored labels) before any label is allocated.
3. The exact output length is summed with checked arithmetic. Overflow, a
   total above the caller's byte budget, or a total above `u32::MAX` (painter
   offsets are u32) is a byte-limit rejection. Exactly the budget is admitted.
4. Only then is the single output buffer allocated; its final length equals
   the admitted total. No partial painter bytes or state are ever published.

Every rejection maps through one Rust table, `scene::PainterRejection`, to a
stable `CODE: detail` diagnostic that contains no user values:

| Code | Cause | Worker status |
| --- | --- | --- |
| `XYG_PAINTER_TRACE_LIMIT` | more than 1,024 trace runs | `RESOURCE_LIMIT` (3) |
| `XYG_PAINTER_BYTE_LIMIT` | exact output over the byte budget or `u32::MAX`, accounting overflow, or a bounded painter table over its ceiling | `RESOURCE_LIMIT` (3) |
| `XYG_SCENE_VERSION` | non-canonical Scene version | `SCENE_VERSION` (4) |
| `XYG_SCENE_MALFORMED` | malformed or unlowerable Scene bytes | `MALFORMED_SCENE` (5) |

The Worker's `XygWasmError.message` is that diagnostic (annotated prepares keep
their own malformed-input text under the same code). The native
`xyg_scene_browser_painter` seam returns `usize::MAX` and writes the same
NUL-terminated diagnostic into `out` when `out_cap` can hold it; Python raises
`ScenePainterError(ValueError)` and Node raises a `RangeError`, both carrying
`.code`. For the same Scene bytes and budget the native seam and the Worker
publish byte-identical painter output or the same diagnostic. A failed,
cancelled, or stale prepare clears any earlier output; a retry needs a fresh
sequence and is byte-identical to a first success.
`tests/fixtures/painter_admission_cross_host.json` is generated by
`crates/xyg-wasm/tests/painter_admission_parity.rs` (which runs both seams) and
pins just-below, exact, and just-above cases for both ceilings plus packed
scatter, trace-before-byte precedence, malformed, and version cases. Python
(`tests/test_painter_admission_cross_host.py`), Node with the real wasm32
artifact (`packages/xy-node/test/painter-admission-wasm-parity.test.mjs`), and
the strict-CSP Worker test consume it.

This is the public direct-browser entry for the stable Scene v20
subset with canonical solid chart/plot backgrounds and authored Cartesian grid,
spine, major/minor tick, side, visibility, label paint, and bounded primary
static legends, plain-text annotations, bounded Rust-projected straight
arrows, bounded Rust-resolved Cartesian callouts, and their optional
Rust-resolved literal label backgrounds. Scene v14 adds bounded
authored Cartesian major tick-label strings:
the host frames only `XYTL` v1 length-prefixed UTF-8, while Rust validates pairing
with explicit major positions, measures gutters, and emits SVG/raster/painter text.
No custom fonts, rotation, collision policy, markup, or automatic-label override is
encoded. Scene v14 also carries bounded, unlabeled axis-aligned rules and
bands plus built-in markers with literal solid paint, opacity, finite width/size,
reserved stable identity, Rust-owned clipping/order, and a visually hidden
`role=note` browser projection that names each reference without presenting
projected pixel coordinates as authored data values. `frameWasmChart`
performs bounded descriptor validation and transfers exact full-buffer
`Float64Array` columns as canonical compile ingress. Rust expands
scatter/line/bar/area and performs the only f64-to-offset-f32 lowering,
assigns or preserves stable identities, and owns default diameter, line width,
bar width/baseline, area baseline, colors, domains, and margins. The XYTS v2
descriptor predates an explicit Band topology field, so Rust preserves its
established contract deterministically: an area with positive stroke width and
nontransparent stroke paint uses `Perimeter`; otherwise it uses canonical
`None`. TypeScript does not infer that topology. The default
bar width is 80% of the minimum positive spacing between sorted x values. A
singleton or all-coincident series uses 80% of the absolute authored x-domain
span (including reversed domains); invalid or degenerate fallback domains fail
closed rather than inventing data-space geometry. The returned
`XygWasmChartHandle` owns update cancellation, diagnostics, painter teardown,
and its own painter resources. Caller arrays and the caller-supplied Worker are
preserved by default. `dataOwnership: "transfer"` explicitly opts into buffer
detachment, while `workerOwnership: "own"` explicitly delegates Worker disposal
to the handle. Aggregate
production beyond the current density/Scene vertical is tracked by
[#885: direct-browser authoring and aggregate completion](https://github.com/CurateLabs/xyg/issues/885); release-level cross-host conformance remains under
[#54](https://github.com/CurateLabs/xyg/issues/54). The two version numbers are
checked independently so rebasing the axis/chrome work cannot silently widen
this consumer.

The cross-host closure fixture is generated by
`cargo run -p xyg-wasm --bin xyts_conformance` beside this Rust decoder. It
covers scatter, line, bar, and area; generated and authored arbitrary u64
identities (including the legacy annotation-prefix range); reversed and
singleton bar defaults; explicit area bounds; incompatible versions,
unsupported kinds, nonfinite geometry, and identity overflow. The committed
request, exact Scene v25 bytes, and exact painter v14 bytes are checked by the
strict-CSP direct-WASM runtime. Native Python, native Node, and real Pyodide
consume the same generated Scene bytes through the shared native
`xyg_scene_browser_painter` ABI and byte-compare its painter-v14 result with the
Rust-generated golden. They do
not decode XYTS: XYTS is the direct-browser authoring ingress, while Scene is
the portable cross-host output contract. Exact Scene and painter bytes are
portable for the pinned little-endian IEEE-754 targets; SVG text/raster pixels
remain consumer outputs and are tested structurally rather than as byte
goldens.

`XYTS` version 2 adds an optional exact `BigUint64Array` stable-ID column. The
main thread validates only its type, length, ownership, and distinct buffer;
Rust consumes the transferred values, preserves arbitrary identities, and
advances later generated IDs beyond the greatest authored identity. The column
is mutually exclusive with `stableIdBase`, and overflow fails with the stable
resource-limit status. Version 1 requests fail closed rather than being
reinterpreted with the wider descriptor contract.

## Lifecycle and failure model

- Instance handles carry a generation and fail closed after disposal; stale
  handles cannot access a reused slot.
- Worker initialization enters an exclusive `initializing` state before its
  first asynchronous module-loading boundary. Concurrent or repeated init
  messages fail closed. Disposal may win while module loading or instantiation
  is pending; every post-await continuation rechecks disposal, cleans up any
  attempt-local Rust handle, and never publishes a late ready response.
- At most 64 instances exist per module. Each instance has an explicit arena
  budget no greater than 384 MiB, and the sum of declared budgets for live
  instances in one module cannot exceed that same 384 MiB ceiling. Before any
  O(N) expansion, `XYTS` computes a
  conservative total logical peak covering input retention, expansion vectors,
  repacking, canonical Scene output, and allocator slack; requests above the
  instance budget fail with `RESOURCE_LIMIT` and clear prior output. Starting
  new staging drops the prior output allocation, and each validate, prepare, or
  compile call consumes staging up front. Success and every error exit
  (including stale, cancelled, bad-range, malformed, and bounded rejection)
  therefore drop the staging allocation rather than retaining either `Vec`
  capacity across operations; a large rejected request cannot inflate a later
  small request's unaccounted resident baseline.
- Sequence zero is reserved. Lower/repeated sequences fail as stale. Worker
  aggregate-stream begin participates in the same operation watermark as
  geographic/camera, scene, aggregate, and graph requests. Deferred operations
  recheck admission before cancelling lanes or staging bytes, so a stale or
  zero camera call preserves a newer stream and a current camera supersedes it.
  Cancelled
  sequences fail with a stable cancelled status. ABI 11 starts `XYTS`/`XYCC`
  compiles with `xyg_wasm_scene_compile_begin` and advances real Rust geometry
  decode/validation in 4,096-record Worker checkpoints. Progress reports the
  completed record count and phase; it is not inferred from elapsed bytes.
  Cancellation, a newer sequence,
  or disposal can therefore retire a compile after work has begun, before it
  publishes Scene/painter output; each exit clears staging and suppresses late
  paint. The final canonical Scene lowering remains one Rust-owned operation,
  so no TypeScript policy or record expansion is introduced. The scheduler
  yields once more after all records validate and before canonical build/lower,
  including requests smaller than the old byte checkpoint. Each compile runs
  in a short-lived, same-origin static module Worker with its own Rust/WASM
  instance. The lifecycle Worker remains responsive while canonical expansion,
  Scene encode/decode, or painter lowering is executing and can terminate that
  instance immediately on cancel, supersession, or disposal. Termination is
  the cancellation boundary inside those otherwise synchronous engine loops;
  it drops all partial Rust/WASM memory and cannot publish a late response.
  Progress phase 1 reports bounded record decoding, phase 2 is the yield after
  all records decode, and phase 3 is emitted immediately before entering
  canonical expansion/Scene encode/painter lowering in the isolated instance.
- Traps invalidate and dispose the Worker-side Rust instance. Callers must
  create a fresh Worker rather than continue with uncertain engine state.
- Invalid sources fail before Worker allocation. Initialization-send failures
  and unreadable Worker messages terminate immediately; disposal waits at most
  one second for cooperative cleanup before terminating the Worker.
- Unsupported operations, incompatible versions, malformed scenes, invalid
  ranges, and resource bounds return stable error codes. Initialization
  mismatches are distinct: `XYG_WASM_ABI_MISMATCH` (WASM ABI differs from the
  client's), `XYG_WASM_SCENE_MISMATCH` (Scene version), `XYG_WASM_PALETTE_MISMATCH`
  (default palette contract), `XYG_WASM_EXPORT_MISMATCH` (a required export is
  absent or has another signature at the same versions),
  `XYG_WASM_IMPORTS_REJECTED` (the module requests ambient imports),
  `XYG_WASM_BUDGET_EXCEEDED` (`maxArenaBytes` above the adapter bound), and
  `XYG_WASM_INSTANCE_EXHAUSTED`; asset loading failures (fetch, redirect,
  compile) stay `XYG_WASM_INIT_FAILED`. The self-contained HTML inline worker
  embeds its WASM bytes beside its own source, so a version skew cannot occur
  there and it reports `XYG_WASM_INIT_FAILED`. There is no silent
  JavaScript algorithm or remote-service fallback.

## CSP, offline, and asset loading

Both assets are explicit:

```js
const engine = createXygWasmWorker({
  workerUrl: new URL("./wasm-worker.js", import.meta.url),
  wasm: compiledModule, // or explicit local URL / bytes
});
const view = await renderWasmScene({
  el: document.querySelector("#chart"),
  scene: canonicalSceneBytes,
  worker: engine,
});
// Or transferable typed series (Rust owns expansion/defaults/domain/Scene):
const chartView = await renderWasmChart({
  el: document.querySelector("#chart"),
  worker: engine,
  chart: {
    width: 640,
    height: 400,
    series: [{ kind: "scatter", x: xs, y: ys }],
  },
});
// Or cut a normal ChartView's supported primary Cartesian ticks to Rust.
// These are deployed same-origin files copied from one @curatelabs/xyg release.
const tickWorker = createXygWasmWorker({
  workerUrl: "/assets/xyg/wasm-worker.js",
  wasm: "/assets/xyg/xyg-wasm.wasm",
  maxArenaBytes: 1024 * 1024,
});
const tickHandle = await attachWasmTicks(existingChartView, {
  worker: tickWorker,
  workerOwnership: "own",
});
// `update()` is sequence-safe; cancel an in-flight compile without disposing
// the caller-owned Worker.
const pendingUpdate = chartView.update(nextChart);
chartView.cancel();
await pendingUpdate; // rejects with XygWasmError code XYG_WASM_CANCELLED
// Or progressive Rust CoSE. `onUpdate` receives the one-tick initial placement
// and later coalescible checkpoints; only revision 42 may update this view.
const layout = layoutWasmCose(engine, {
  nNodes: 3,
  sources: new BigUint64Array([0n, 1n]),
  targets: new BigUint64Array([1n, 2n]),
  totalSteps: 300,
  cose: { idealEdgeLength: 0.4 },
}, { revision: 42, onUpdate: paintPositions });
const finalPositions = await layout.result;
```

The library never uses `Blob`, `eval`, a CDN, default URL, or path probing.
URL-based WASM loading performs one non-redirecting fetch of the exact
caller-provided URL; redirects fail initialization rather than changing the
asset authority. `Module`/bytes loading performs no WASM fetch. A strict policy needs
`script-src 'self' 'wasm-unsafe-eval'`, `worker-src 'self'`, and
`connect-src 'self'` when a local WASM URL is used. `wasm-unsafe-eval` permits
WebAssembly compilation; it does not permit JavaScript `eval`.

The browser-package tick asset contract is the ESM client plus the exported
`./wasm-worker` and `./xyg-wasm.wasm` files from one package version. A host
must deploy the Worker and WASM at explicit same-origin URLs (or pass checked
WASM bytes/`WebAssembly.Module`) and must not mix versions. Release
`ASSET-MANIFEST.json` records every shipped filename's byte length and SHA-256
alongside the wire, WASM ABI, Scene, and painter versions; release staging and
the published-package smoke verify those hashes before deployment. There is no
runtime Worker-byte hash helper—the Worker URL is loaded directly so a
fetch-then-Worker check would introduce a time-of-check/time-of-use gap.
Initialization still fails closed on the generated ABI/Scene version check
before `attachWasmTicks` mounts. A missing asset emits
`xy:wasm_ticks_error` and rejects the attachment; a failure after mounting
retains the last Rust-produced cache and never starts JavaScript generation.
This contract does not authorize Blob/data Workers or synchronous main-thread
WASM.

`scripts/wasm_foundation_smoke.mjs` serves an allowlisted local-only asset set
under that CSP and tests explicit Module/bytes/URL loading, transfer and copy
diagnostics, lifecycle, cancellation, stale sequence, malformed module/scene,
resource bounds, redirect rejection, a real runtime trap, public Scene paint,
existing-painter hydration, and disposal. It
also starts large `XYTS` work before exercising task and chart-handle cancel,
newer-update supersession, disposal, stable errors, and no-late-paint cleanup. It
waits for the real Rust record phase and the pre-lowering phase heartbeat, then
terminates the isolated compile instance while expensive lowering is eligible
to run. A fragmented request below 256 KiB separately proves the old byte-sized
zero-cancellation window is gone.
also exercises progressive CoSE initial/update/completion phases, pins,
revision-safe supersession, and two concurrent graph workers. It
also verifies unsigned split-u64 accounting across the `0x80000000` boundary
and that an invalid source is rejected before a Worker is allocated.

## Build and evidence

The repository pins Rust 1.96.0 and CI installs the
`wasm32-unknown-unknown` target explicitly:

```bash
cargo build -p xyg-wasm --release --target wasm32-unknown-unknown
node js/build.mjs
node js/package-wasm.mjs
node scripts/wasm_foundation_smoke.mjs
node scripts/wasm_html_ticks_smoke.mjs
node benchmarks/bench_wasm_scene.mjs
```

Both the primary full-suite job and the Python 3.11 floor build that real WASM
payload before running browser probes. The generated Worker alone is not a
valid fixture: its missing paired payload must retain the production
fail-closed diagnostic instead of silently selecting a JavaScript tick path.
The polar phase 6/7 live-example smoke copies that exact packaged pair, serves
it beside each page over same-origin HTTP under a strict CSP, and captures only
after `ticks_ready`; categorical polar labels therefore prove Rust admission
instead of passing through a timing-dependent or canonical JavaScript ladder.
The interaction-stress benchmark uses the same hosted packaged pair and waits
for admitted primary axes before timing gestures or auditing label overlap;
its measurements use real time rather than a Worker-incompatible virtual-time
controller.
The dashboard reliability benchmark likewise waits for one admitted primary
axis pair per successfully created chart before measuring the complete page;
its 10/20/50/60-chart rows cannot pass with blank fail-closed chrome.
The direct-browser foundation independently exercises natural asynchronous
attachment and resize reconciliation without the legacy probe helper's manual
layout boundary. HTTP-backed browser probes preserve an explicit Chromium
device-scale-factor request in their Playwright page context, so moving those
probes off `file:` URLs does not silently reduce high-DPI coverage to DPR 1.

The opt-in Chromium benchmark reports 10k/100k/1M mixed scatter/line/rect
worker preparation, hydration/upload, two-frame first paint, Scene/painter
bytes, and JS heap delta when Chromium exposes it. It asserts three grouped
traces and stable-ID survival. Results are environmental measurements, not a
committed win claim. The hosted Rust benchmark isolates typed-series conversion
at 100, 10k, 100k, and 1M records. The existing changed-main nightly/manual
CodSpeed workflow runs those simulation rows and a separate strict-CSP Chromium
job at the same four sizes. The browser job validates the zero-record-visit
contract and copy/memory metrics, then uploads SHA-keyed raw JSON. It is not PR
CI. This slice makes no startup, throughput, memory, bundle-size, or
competitive-win claim before a hosted artifact is available; raw local timings
are not performance evidence.

The same changed-main browser-evidence job also runs the self-contained
strict-CSP density ChartView journey at 100, 10k, 100k, and 1m points. Its
SHA-keyed `hosted-density-browser-<sha>.json` records browser first paint,
newest-viewport supersession, cancellation, malformed/resource/trap recovery,
disposal, typed `XYAO` payload bytes, Rust copy/memory counters, and an actual
home-viewport canvas comparison. `verify_inline_density_benchmark.py` rejects
absent or placeholder rows. This remains nightly/manual-only evidence, never
PR CI or a CodSpeed simulation claim.

## M2 #59 disposition and follow-up work

The claimed M2 subset is delivered: the Worker/WASM foundation and strict-CSP
contract; packaged WASM tick assets (#258); authored ChartView ticks (#257);
ChartView colorbar ticks (#262); the historical, now removed Reflex attach
implementation (#260); and interpreted Wave B evidence (#263).

Angular/polar and secondary-axis ChartView cutovers subsequently shipped under
#869 through the Rust packed tick resolver described above. Real-browser
packaged Reflex application evidence is retained below as historical
pre-removal evidence. [#1063](https://github.com/CurateLabs/xyg/issues/1063) supersedes
the Reflex-specific requirement and retargets #886 to supported Python/
Streamlit and Node/vanilla-TypeScript consumers. The bounded installed-host
qualification below covers secondary/polar tick admission and module failures
and completes the named #886 consumer cases with the shared density proofs.
Replacement application coverage follows [application-consumers.md](application-consumers.md).

Work outside that claimed subset is tracked independently:

- supported-consumer packaged tick-asset qualification after Reflex retirement:
  [#886](https://github.com/CurateLabs/xyg/issues/886) and
  [#1063](https://github.com/CurateLabs/xyg/issues/1063);
- direct-browser aggregate production paths beyond the current density/Scene
  vertical: [#885: direct-browser authoring and aggregate completion](https://github.com/CurateLabs/xyg/issues/885); and
- post-Wave-A current-`main` SHA-keyed hosted artifacts, a green CodSpeed
  simulation, interpreted competitive budgets, and hosted visual evidence for
  the explicit no-refinement degradation boundary:
  [#886: packaged ticks and density no-refinement proof](https://github.com/CurateLabs/xyg/issues/886).

The delivered hosted-artifact interpretation subset is recorded in
[`spec/benchmarks/results.md`](../benchmarks/results.md). Related to #59;
the follow-up issues above track the remaining work independently.

## Density no-refinement gate

Unsupported or kernel-less sources must retain the already-painted
Rust-authored overview and dispatch `xy:wasm_density_no_refinement`. There is
no JavaScript aggregator fallback.

| Surface | Location | Status |
|---|---|---|
| Adapter policy | `js/src/49_wasm_density.ts` | shipped: missing/invalid inline artifact and unsupported sources fail closed |
| Kernel dispatch | `js/src/54_kernel.ts` (`wasm_density_no_refinement`) | shipped |
| Observer phase | `js/src/60_entries.ts` (`density_no_refinement`) | shipped |
| Standalone missing WASM | `tests/test_density_pan_no_rebin.py` | green when Chromium is present |
| Packaged ESM/IIFE overview retention | `scripts/wasm_foundation_smoke.mjs` | three bounded generated-file cases per entry, actual packaged Rust aggregate, exact pixel/grid retention, zoom/home, no new Worker or texture upload, and disposal |
| Installed supported consumers | `scripts/consumer_apps_smoke.py` / `packaged_consumer_browser.mjs` | hosted Python HTML and Node/vanilla TypeScript secondary/polar tick admission, missing/corrupt tick modules, and one native Node split unsupported-density zoom/home/lifecycle case; bounded receipts below |
| Bundle / contract probes | `tests/test_static_client_security.py`, `tests/test_wasm_density_chartview_contract.py`, `tests/test_wasm_full_density_source.py` | green |
| Hosted SHA-keyed visual evidence of this boundary | nightly `hosted-density-browser-<sha>.json` | tracked by [#886: packaged ticks and density no-refinement proof](https://github.com/CurateLabs/xyg/issues/886); current artifacts prove refinement lifecycle, not no-refinement |

Stable codes: `XYG_WASM_UNAVAILABLE`, `XYG_WASM_SOURCE_UNAVAILABLE`, and
`XYG_WASM_SOURCE_UNSUPPORTED`.


The existing strict-CSP foundation smoke also runs the bounded #886 density
cases against both the ESM and standalone IIFE entry points. A real local WASM
Worker first produces an `XYAO` overview from canonical typed coordinates; the
fixture only frames that grid and optional source columns for the painter.
The generated-file cases remove the inline bootstrap, supply a malformed
bootstrap rejected before Worker allocation, or omit the retained source.
They assert the first explicit reason, unchanged Rust grid and texture,
byte-identical presented home pixels before/after attempted refinement,
nonblank zoom pixels, exact home restoration, zero replacement uploads, no
new Worker allocation, and no post-destruction publication. A missing retained
source initially reports `XYG_WASM_SOURCE_UNAVAILABLE`; a subsequent viewport
request also reports the general `XYG_WASM_UNAVAILABLE` boundary.

`XYG_BROWSER_DIST` points at an unpacked staged `@curatelabs/xyg` package, whose
asset manifest is checked before execution. `XYG_WASM_FOUNDATION_REPORT` writes
runtime/CSP details, asset and harness SHA-256 values, each event and pixel/grid
hash, and six PNG captures beside the JSON report. Optional
`XYG_RELEASE_COMMIT` records the artifact source declaration; package hashes
remain the binding to the tested bytes. The harness commit and individual
harness hashes are separate from that artifact declaration. For a focused
reproduction against an already retained package:

```bash
XYG_BROWSER_DIST=/absolute/path/to/unpacked/package \
XYG_WASM_FOUNDATION_ONLY=density-no-refinement \
XYG_WASM_FOUNDATION_REPORT=artifacts/density-no-refinement.json \
node scripts/wasm_foundation_smoke.mjs
```

Omitting `XYG_WASM_FOUNDATION_ONLY` preserves the complete existing foundation
gate, including fixture parity. The focused mode proves these six cases only;
it cannot establish current-source fixture parity or the complete #54 matrix.
It does not prove the full application-consumer matrix, a validly framed corrupt
inline WASM module, every unsupported source family, or large-scale hosted
performance. Those remaining #886/#885 and release requirements stay open.

### Pre-removal Reflex and shared public HTML journeys (#886 / #1063)

The six Reflex cases retained in
[`spec/performance/packaged-reflex-2026-10-23`](../performance/packaged-reflex-2026-10-23/README.md)
qualify the pre-removal adapter only. #1063 retires that surface and supersedes
its #886 requirement. These are historical migration records, not qualification
of the replacement consumers. The old runner verified one exact installed
wheel, compiled an actual `XYChart` fixture, and checked primary, secondary and
polar tick caches, missing/corrupt tick modules, live unsupported density
refinement, strict CSP and React unmount cleanup. Its package/harness hashes,
frontend lockfiles, process tree, source ledgers and compile/runtime/browser
logs retain their original meaning. The adapter app and runners are removed.

The required `scripts/consumer_apps_smoke.py` gate preserves the framework-free
public HTML portion using `tests/fixtures/packaged_density_export.py` and
`scripts/packaged_density_export_browser.mjs`. It exercises the installed
wheel's unmodified public `Chart.to_html()` document at a `file:` URL. A CDP
bootstrap setter withholds the optional inline module or replaces only its
base64 WASM bytes with `00 01 02 03`, preserving valid classic-worker framing,
generated CSP, client, metadata and Rust grid. The latter reaches actual
`WebAssembly.compile` rejection. Both cases require unchanged overview/grid/
texture, zero replacement uploads, colored distinct zoom pixels, exact home
ranges, and no live Worker or object URL after rejection/destruction. The home
display comparison records changed channels and requires a maximum difference
of one integer channel value for Canvas2D presentation/readback rounding;
grid bytes and texture identity remain exact.
Zoom pixels must differ by more than that same rounding tolerance, preventing
unchanged home output plus readback rounding from satisfying the zoom oracle.
They do not synthesize split-only unsupported-source descriptors into packed
HTML. The generated file retains its own CSP and rejects all HTTP requests.
The runner records SwiftShader arguments and uses a bounded completed
presentation before reading pixels. Reports, screenshots and a compressed
copy of the generated document remain under the existing consumer evidence
upload; generated bundles are not committed (dossier §33).

These two shared file-export cases alone do not qualify amended #886; the
installed-host cases below complete its named consumer requirements. The #54
matrix, final-candidate cohort reuse and hosted performance remain separate. Supported
application coverage follows [application-consumers.md](application-consumers.md).

### Installed supported-consumer qualification (#886)

The existing clean installed consumer gate now reuses one shared browser case
set for Python-hosted public HTML and the installed Node/vanilla TypeScript
mount. Each admits primary plus `y2` secondary caches or polar degree/radial
`x`/`y` caches and their Rust-formatted labels. Each also proves both HTTP-404
module rejection and actual `WebAssembly.compile` rejection of HTTP-200 bytes
`00 01 02 03`, retaining chart pixels with empty fail-closed tick slots and
`XYG_WASM_INIT_FAILED`. Explicit same-origin paired assets, generated/host CSP,
request allowlists, fetched module hashes, Worker termination and full view
destruction are asserted. Python hosting runs without Node on PATH; Streamlit's
stock iframe gains no automatic attachment or callback promise.

The one additional density case uses an installed Node native split payload
directly through the public kernel-less `ChartView` boundary. Actual viewport
zoom/home and `_scheduleViewRequest` consume its native unsupported-source
descriptor and report `XYG_WASM_SOURCE_UNSUPPORTED` with the native reason and
trace IDs. The original Rust grid and texture survive with no replacement
upload, density attachment or extra Worker; distinct colored zoom pixels and
restored home ranges/pixels reject blank/stale paint. Home readback permits
only one integer channel value of presentation rounding; source identity is
exact. Disposal releases the texture, GL context, listeners, frame and tick
Worker without late diagnostics. This supplements the existing installed
Python missing/corrupt optional-inline-density cases, without repeating all
failure branches on every host or inserting split-only policy into packed HTML.

Receipts, package/harness/input hashes, screenshots and reproduction commands:
[`application-consumers-886`](../performance/application-consumers-886/README.md).
This is bounded correctness evidence for amended
[#886](https://github.com/CurateLabs/xyg/issues/886), following
[#1063](https://github.com/CurateLabs/xyg/issues/1063) and
[#869](https://github.com/CurateLabs/xyg/issues/869). Together with the reused
standalone and installed Python failure cases, it satisfies the named #886
correctness requirements. Exhaustive unsupported-source/axis combinations and
final-candidate #54 reuse remain outside this proof. It does not establish
complete #108 acceptance, release readiness or a performance result.

Public chart ergonomics (`frameWasmChart` / `renderWasmChart`) transfer exact
typed columns without main-thread record expansion. `FLAG_AUTO_DOMAIN` keeps
domain scans in Rust inside the Worker.

## GeoColumn descriptor ingestion (`XYGD` to `XYGM`)

WASM ABI 28 exposes `xyg_wasm_geo_column_ingest(handle, sequence, offset,
length) -> i32`. It reads one `XYGD` v1 typed descriptor and returns the shared
engine's byte-identical `XYGM` v1 metadata through the instance output. The
column is temporary: neither whole source nor canonical geometry is retained
past the call. All six two-dimensional geometry kinds, null features, polygon holes, exact
f64 coordinates, and full u64 identities use `GeoColumn` validation. There is
no Arrow dependency or TypeScript geometry/topology engine.

`XYGD` is little-endian with a 64-byte header: magic at 0, version u32 at 4,
geometry u32 at 8, CRS u32 at 12, flags u32 at 16 (bit 0: explicit identities),
reserved zero u32 at 20, feature count u64 at 24, vertex count u64 at 32, and
three offset-plane lengths u64 at 40/48/56. Planes follow in order: interleaved
f64 coordinates, per-feature u8 validity, optional u64 identities, then three
u32 offset planes. Every plane is padded with zero bytes to eight-byte
alignment. Unknown flags, nonzero reserved/padding bytes, truncation, overflow,
and trailing bytes fail closed. This canonical authoring ingress carries raw
f64; it is never a live painter payload (§29).

`encodeWasmGeoDescriptor` frames typed arrays without interpreting CRS or
geometry. `XygWasmWorker.geoColumnIngest` transfers the resulting request and
returns metadata; original typed source buffers stay with the caller because
the encoder copies them. The worker defers one task turn so immediate cancel
can suppress execution. Requests share the worker's operation sequence lane;
zero/stale/cancelled sequences fail, and disposal rejects pending tasks. A
synchronous call cannot be interrupted mid-validation; shared geometry and
hole-work ceilings bound its work. Frozen geographic point/outline Scene lowering
is specified below; live camera transitions use XYVC/XYVR. Map layer/fill programs
remain #49, and LOD/export #50.

Rust rejects before allocating typed planes when simultaneous transferred JS
request bytes, staging capacity,
decoded numeric planes, retained canonical planes (including generated IDs and
ring winding), plus 8192 fixed scratch/metadata bytes exceed the instance
budget. Retained staging capacity outside the request is subtracted too.
`GeoLimits` also enforces feature/vertex/canonical-byte limits. Accepted sequences release staging capacity on success or geometry/framing
failure and clear previous output. Rejected zero/stale/cancelled sequences
preserve an active newer operation and its staging; idle rejections release it. Only the
small metadata output survives until the next operation or disposal; linear
WASM memory itself cannot shrink. Resource failures return WASM status 3;
geometry/framing failures status 2 with the exact value-safe `XYG_GEO_*` code
in `last_error`; lifecycle statuses keep their existing meanings.

Evidence: `packages/xy-node/test/geo-wasm-parity.test.mjs` sends the committed
Python/GraphForge goldens through the actual wasm32 artifact and native ABI,
comparing metadata bytes and stable failures for six kinds, nulls, holes,
3857, exact f64 and u64 identity planes. It also proves allocation admission,
nonzero request offsets, malformed framing, cancellation, stale sequences,
recovery, and disposal. `crates/xyg-wasm/src/geo.rs` tests generated-identity
peak accounting and released backing allocations. The strict-CSP browser
probe is `scripts/geo_wasm_smoke.mjs`.

### Frozen geographic Scene ingress (WASM ABI 29, #47)

`xyg_wasm_geo_scene_compile(handle, sequence, offset, length)` runs the shared
`xyg-engine::geo_scene::compile_geo_scene` processor. Its `XYGP` v1 authoring
frame contains a frozen camera, a single point/outline style, and a checked
`XYGD` descriptor. Output is ordinary canonical `XYGS`, consumed by the
existing Rust Scene preparation and WebGL paint/pick path. No geographic
geometry policy is implemented in TypeScript.

The 128-byte little-endian header contains: magic at 0, version u32 at 4,
header length u32 at 8, flags u32 at 12 (world wrap bit 0, authored fill bit 1,
authored stroke bit 2), camera CRS u32 at 16, zero reserved u32 at 20; nine f64
values at 24 through 88 (center x/y, zoom, width/height, bearing/pitch in degrees,
point diameter, stroke width); fill/stroke RGBA8 at 96/100; descriptor length
u64 at 104; zero reserved bytes 112–127. The exact descriptor follows at 128.
Camera and source CRS must agree. NaN diameter/width select Rust defaults 6/1;
otherwise styles must be finite, nonnegative, and representable as finite f32.
Canvas dimensions must likewise narrow to finite f32, and satisfy GeoViewport
validation. Missing paints select the engine default palette row. Unknown
flags, reserved bytes, framing errors and non-paintable fields fail atomically.

Points retain the shared projected origin before lowering to screen-space
Scatter records. Offscreen centers are culled by the canonical marker bounds,
including diameter/stroke extent. Outlines use GeoViewport's dateline splitting
and viewport segment clipping. A transparent zero-size offscreen Scatter record
separates clipped Polyline runs, without nonfinite authoring coordinates or
connections between independent segments. Both segment endpoints and the
invisible separator retain the source u64 identity with literal Scene metadata;
annotation-shaped identities and u64::MAX have no alternate interpretation.
Null geometry contributes no marks. Polygon holes are outline rings; fills are
not part of this ingress. Screen identity axes preserve projection orientation.
Chrome has explicitly empty major ticks and transparent axis/label paints.

Admission precedes variable engine allocations. At most one point record per
source vertex or six outline records per source vertex is admitted, also capped
by `MAX_SCENE_MARKS`. The conservative simultaneous peak ceiling is three times
request bytes + 16 bytes per feature + 512 bytes per maximum record + 32768 bytes
fixed scratch. This covers transfer/staging, canonical planes, projection,
compact input columns, prepared marks and encoded Scene, including capacity
slack. Additional retained arena capacity is subtracted by the lifecycle shell.
Only output survives execution; no canonical source is retained indefinitely.
The native `geo_scene_conformance` executable bounds stdin to budget + 1 before
reading and uses exactly the same processor. Resource failures use status 3 and
`XYG_GEO_RESOURCE_LIMIT`; invalid geometry/framing/style uses status 2 and the
shared `XYG_GEO_*` code. Pitch within the certified −60°..60° ground-plane
range uses the shared frustum processor; out-of-range pitch fails admission.
Zero/stale/cancelled sequences preserve newer active
operations; accepted calls supersede them and release staging on every outcome.

`packages/xy-node/test/geo-scene-wasm-parity.test.mjs` compares native executable
output with the actual wasm32 export for all six geometry kinds, nulls, holes,
EPSG:3857, f64 source precision, full u64 identities, independent wrapped
segments, framing and allocation failures. Scene structure, IDs, paints and
sidecars are byte-identical; projected coordinates permit at most 1e-6 CSS pixel
cross-target difference. The offscreen-first zoom-24 regression independently
requires the expected 2.386092942 CSS-pixel separation. The strict-CSP
`scripts/geo_wasm_smoke.mjs` submits transferred requests through the packaged
Worker, hydrates ordinary Scene paint, verifies painted pixels, GPU picks and
full u64 identity, independent outline runs, cancellation and recovery. The
hydrated deep-zoom upload independently retains the same separation within
1e-4 CSS pixel (the existing painter stores screen coordinates as f32).

The bounded frozen point/outline path supplies #47's actual derived Scene parity
evidence. ABI 30 also supports certified perspective pitch through the same
GeoViewport frustum processor; live transitions use XYVC/XYVR below;
MapLibre/catalog/fills/interaction use the ABI31 catalog below; geographic LOD and frozen massive-source export remain #50.


The camera protocol is a separate sequenced geographic command in the existing
Worker lane. `XygWasmWorker.geoViewportExecute` transfers `XYVC` and resolves
with aligned `XYVR` typed planes. The shared Rust processor owns normalization,
transitions, inverse/projection, visible IDs/bounds, and closed ring topology.
[The exact byte and allocation contract](geo-viewport-protocol.md) is normative.
Actual wasm32/native/C-ABI parity is `geo-viewport-wasm-parity.test.mjs`.


The immutable linked-state and exact temporal-overview extension requires a
recorded functionality decision: its initial packaging limits were **1,441,792 raw bytes
(1,408 KiB) and 589,824 gzip bytes (576 KiB, level 6)**. Compiler and pinned
Binaryen O3 settings remain unchanged. The combined candidate measures
1,326,010 raw / 543,366 gzip bytes; three fresh Chromium Worker-ready samples
are 35.5, 17.4 and 18.7 ms under uncontrolled local load. This is bounded
functionality headroom and local startup evidence, without a performance win
or massive-scale claim. Both gates remain hard packaging failures.
[Raw hashes, environment, contracts and reproduction commands](../performance/geo-overview-artifact-2026-10-09/README.md)
record the decision and its limits. Future growth requires separate evidence.


The camera parity harness sends each exact binary request to the bounded native
oracle through an owned temporary input-file descriptor. This avoids an OS pipe
`EPIPE` race when an invalid oracle budget rejects before stdin is consumed.
Exit status, stable error, complete output and all native/WASM parity assertions
remain unchanged; temporary descriptors/files are closed and removed per call.


The paged hierarchy protocol and complete selected ordinary/mixed snapshots
require a combined functionality decision. Each extension fit the prior gates
alone, but their combined unchanged-profile artifact measures **1,454,428 raw /
597,662 gzip bytes (level 6)**, SHA-256
`ad68147eb89bbc8b4f1d6039642ee3068e3484243b48ccf6cb4d6359d9780b15`.
It exceeds the historical gates by12,636 raw and7,838 gzip bytes. The current
hard packaging limits are **1,523,712 raw bytes (1,488 KiB) and626,688 gzip bytes
(612 KiB, level 6)**; runtime source, Data, handle, processor and transfer limits
remain unchanged. Rust release O3/inline100 and pinned Binaryen132 O3 remain
unchanged. An O3 shrink-level1 experiment produced identical bytes; Oz reduced
raw size to1,434,576 but increased gzip to598,701, so neither solves the gates.
No alternate compiler profile is adopted and no runtime speedup is claimed.

**Graph hierarchy composition (#36 S1), recovered on the current integration base.**
Composition version 2 carries `parent_uuid` resolution, forest validation and
hidden-parent re-attachment in the shared Rust compose path. The old branch's
historical 1,480 KiB / 612 KiB allowance is superseded by the current limits
above: **1,543,168 raw bytes / 638,976 gzip6 bytes**. Recovery does not raise
these gates or change the pinned Rust/Binaryen profile. The retained interaction
session has no WASM exports; the current interaction slice table assigns that
ABI work to S4. The combined optimized build measures
**1,547,598 raw / 640,237 gzip6 bytes**, exceeding the unchanged gates by
**4,430 raw / 1,261 gzip bytes**. Packaging fails; diagnostic functional tests do
not waive that failure. Source/artifact hashes, reproduction commands and narrow
sharing candidates are in [S1 recovery evidence](../performance/graph-s1-recovery-2026-10-31/README.md). The separate
[bounded size repair](../performance/graph-s1-size-repair-2026-10-31/README.md)
retains shared parent-UUID validation, removes hierarchy intermediates and uses
one sentinel-coded ancestor memo table. Its unchanged-profile build measures
**1,546,708 raw / 639,531 gzip6 bytes**, saving **890 / 706 bytes** from the
recovered S1 tree. It still exceeds the unchanged limits by **3,540 / 555 bytes**;
the package gate remains **FAIL**. Rejected boundary candidates and their hashes
are retained separately; the historical failed S1 receipt is unchanged.

**Historical retained session render (#36 S2) size check (old branch).** S2 adds the Rust-only session
render pipeline and `TemporalGraph::world_parts`; no WASM export changed, so
the session code is not linked. The packaged artifact measures 1,514,304 raw
bytes (1,216 under the unchanged 1,515,520-byte gate; +1,686 over S1) and
622,593 level-6 gzip bytes (4,095 under the 626,688-byte gate; −1,452 against
S1's 624,045). Neither budget is raised; the raw margin is thin, and the
session ABI slice owns the next size decision. This old-branch measurement is
not evidence for the recovered integration tree. At recovery the S1 limits were
1,511 KiB raw / 625 KiB gzip6, with the unchanged profile; see
[S2 recovery evidence](../performance/graph-s2-recovery-2026-10-31/README.md)
for the actual recovered package result. Recovery does not raise either limit.
The recovered unchanged-profile module measures **1,547,915 raw / 640,615
gzip6 bytes** on Node 22.23.4, SHA-256
`544d97c615a96e31cdca66cac0d577b954ee337e50e2e589690dc348d7c852bc`.
It exceeds the accepted S1 gates by **651 raw / 615 gzip bytes**. The real
package command rejects the gzip gate before publishing any assets; an
independent measurement records both exceeded limits. Diagnostic native/WASM
parity does not waive this package failure. A separate deliberate decision is
required before packaging can be accepted. The subsequent bounded repair and
separate minimal S2 decision are recorded in the current artifact-size section
above; neither changes these historical failure measurements.

Bounded native/WASM selected snapshot and hierarchy membership checks, exact
artifact hashes, four fresh-process startup ABBA pairs and reproduction commands
are recorded in
[combined package evidence](../performance/geo-combined-package-2026-10-09/README.md).
These local startup measurements exclude browser painting, network delivery and
massive-source interaction. Future functionality growth still requires a separate
recorded decision; package checks continue to fail above either current limit.

### Straight-arrow vocabulary size decision (#1006)

Scene v34's bounded arrow vocabulary (`crates/xyg-engine/src/scene_arrow.rs`: open
heads, tails, shrink and label clearance, one geometry shared by encode, document
lowering, batch validation and the XYST arrow-metric pass) adds about 5 KB raw and
2.4 KB gzip to the module. On top of the Scene v33 secondary-y axis the packaged
module measures **1,527,224 raw bytes** (inside the 1,504 KiB = 1,540,096-byte gate)
and **627,891 gzip bytes**. Measurement: Rust 1.96.0 release profile, pinned
Binaryen 132.0.0, Node 22.22.1, `node js/package-wasm.mjs`, whose gate counts
`zlib.gzipSync` at its default level 6 (GNU `gzip -6 -n` gives 628,161 on the same
bytes); an independent measurement of the same change reported 627,878, a 13-byte
spread from its checkout. CI's toolchain adds about 2.7 KB gzip over a local build,
which leaves under 0.5 KB below the former 616 KiB gate. The gzip gate is therefore
raised to **620 KiB (634,880 bytes)**; the raw gate is unchanged (the #1006
static-export decision under "Artifact size" later raised gzip to 624 KiB). Duplicate paint
projection was folded into one out-of-line function and the paint buffer is a fixed
array to keep the addition at that size; the browser consumes the same Rust vertices
rather than a second arrow renderer. The painter contract is unchanged (XYPB v16,
WASM ABI 34): arrow runs are ordinary line and triangle traces.


R2 retained graph publications require the independent `clear.action.u32` v1
`[1, applicable]` fact from Rust's actual owner state. The browser uses it only
after synchronous local admission to cancel an applicable Escape default; a
later Rust refusal remains possible and is reported without replay or state
replacement. Missing/malformed facts fail closed, including old same-ABI modules.
The shared GLHost resets sampler and texture state on units 0–2 so the graph
reference texture cannot inherit a neighbor's LINEAR sampler. See the
[R2 receipt](../performance/graph-s5b-attachment-r2-2026-11-04/README.md).


### Rust picked-target/typed-leave checkpoint (#36)

The Rust-only query-scoped [receipt contract](graph-interaction.md#212-rust-only-query-receipt-checkpoint-not-integrated-hover)
adds optional `pick.*` XYGR sections for Hover/SelectAt and action-1 Hover Leave
with coordinates absent. No export/signature, ABI, GPU-v1 or TypeScript public
interface changes. The current semantic decoder permits these additive named
sections without projecting them into a public hover result. Browser scheduling,
controller hover/events/tooltips and broader acceptance remain deferred. The
unchanged production optimizer and explicitly adopted 1,882/768-KiB gates remain mandatory.

R4 uses the existing explicit `XYG_SESSION_WASM` test override to replay the
archived, rejected R2 module from a new `target/` diagnostic directory, against
the exact R2 native core. No rejected bytes are copied into either shipping asset
set. Passing the [diagnostic receipt](../performance/graph-picked-target-r4-2026-11-04/README.md)
provides scoped correctness evidence only. The historical 1,878/765-KiB producer
failure remains; R4 tests adopted no larger functionality allowance.


**Current #36 functionality gates (explicit parent decision 2026-11-04):
1,882 KiB raw / 768 KiB gzip6 (1,927,168 / 786,432 bytes).** Completed independent
`m4_defaults_audit` assessment and `s5a_final_review` of the exact R4 patch
`5383a32d4077dea01d8b9342068c1f20c0eaff6d5a7d7b5e4ef3580a637d3ef8`
precede the separate parent decision. R2 inline actual-target receipts retain all
five sections, source/group identity, provenance and no-query typed Leave.
Measured R2 is 1,926,555 / 785,546 bytes: headroom 613 / 886; previous limits
failed by 3,483 / 2,186 and 1,881/767 still fails by 411 / 138. R2 shared CSR and
borrowed refs saved 1,022 / 380 over R1; R3 Arc was worse by 1,768 / 55 and is
rejected. Growth over 207 is 3,832 / 2,365. No further optimization search or
automatic allowance is authorized. Compiler/profile/optimizer/dependencies,
exports, guards, tolerances and existing 16/384-MiB arenas remain unchanged.
The [R5 decision and production receipt](../performance/graph-picked-target-r5-2026-11-04/README.md)
records fresh normal shipping producers and remaining qualification. Historical
failures and diagnostic-only proofs are not retroactive shipping passes.
The controller still ignores additive receipt sections; no public hover API or
browser scheduling change is included. #36/M4/#108 and the 685 preparation gaps
remain open; baseline freeze remains UNACCEPTED. Independent final source and
policy review remains required before integration.


The [R6 current-golden and shipping qualification receipt](../performance/graph-picked-target-r6-2026-11-04/README.md)
records a fresh actual shipping-browser capture after inheriting reviewed Node
Buffer exact-span decoding from eb9ea4c7. It preserves all historical captures,
the R5 25/1 failure, and all R1–R5 receipts. All 19 request bytes are unchanged;
17 SelectAt replies add only the five versioned pick sections, with every
pre-existing dtype/index/count/raw payload byte preserved. Open/Render remain
full-byte exact. The existing full native/WASM replay defaults to this current
browser golden; it does not ignore sections or expose a public hover result.
Verified identical R5 producer inputs and all 15 relevant artifacts permit reuse
of recorded production/CSP proof; fresh browser capture, shipping receipt parity
and inline-file startup results are recorded separately. The exact 1,882/768-KiB
gates and 613/886-byte measured headroom are unchanged. No additional allowance,
optimizer search, arena/guard/validator change, integration or broad acceptance.
685 preparation gaps and baseline freeze UNACCEPTED remain unchanged; independent
final full-source and policy review precedes any PR/integration.


The [2026-11-05 accepted-main integration receipt](../performance/graph-picked-target-main-integration-2026-11-05/README.md)
records the normal merge of R10 `24ab6804` with accepted #889 main `5e00c6b9`
(reviewed tree `2bb6a0c3`). The merge preserves the picked-target source and
all inherited receipts, incorporates the accepted static-output fixes, and
regenerates release inventory through its official generator. Both native and
WASM require fresh producers because #889 changes shared Rust source. The
existing 1882/768-KiB gates apply to the combined artifact; historical 1878/765
main limits do not supersede the explicit picked-target decision above. No
further size allowance, public hover integration, #36/M4/#108 acceptance or
publication follows from this integration. The receipt records actual current
results and any remaining blockers; independent final review and fresh remote
CI remain parent-owned acceptance requirements.


With `load.progressive: true`, this attachment now schedules retained opcode 15
in the packaged Worker after initial paint, using the existing chunk/wall limits.
See [the bounded continuation contract](graph-interaction.md#bounded-public-browser-continuation-35-release-108-preparation).
This is a #35 slice; Python notebooks, the full rendered ladder and #108 acceptance
remain open. Ordinary one-shot rendering and all admission limits are unchanged.


`attachWasmGraphSession` now accepts an explicit temporal controller/binding and
work budget through its existing exclusive Worker lane. The named XYTG
create/frame operations, Rust Bind and matching render share ownership and
reply guards; ordinary public temporal commands still cannot bypass the claim.
See [the bounded retained temporal contract](temporal-graph.md#retained-automatic-presentation-bounded-45-slice)
for scheduling, publication/refusal, UUID-state and disposal semantics. No ABI,
package cap, layout/pick authority or runtime arena limit changes.

### Frozen graph single-module profile (WASM36)

The WASM36 qualification used target-only Rust `opt-level=2` and LLVM inline
threshold50 for the single browser module. Native release remains O3. Fat LTO,
one codegen unit, stripping, pinned Binaryen132 `-O3 --all-features`, exports,
validation, 16/384-MiB runtime bounds, deadlines and the 1,927,168 raw / 786,432
gzip6 packaging caps remain unchanged. This supersedes the historical compiler
profile measurements above; the old receipts are immutable. No optional export
module or second renderer is introduced. At the historical Worker-export
checkpoint, the adapter disabled raster because the attempted shared PNG build
exceeded those caps. That refusal and its receipts remain historical evidence.

The [shared-PNG continuation](../performance/temporal-shared-png-2026-11-07/README.md)
enables the shared Rust `frozen-raster` capability in this same module. Native,
module Worker and offline Blob Worker PNG exports use the shared Scene/raster/
PNG implementation. The qualified module is 1,886,125 raw / 784,655 Node22 gzip6
bytes, below the unchanged caps. This standalone source qualification does not
establish fit for a future combined-source/ABI module or full #45 acceptance.

The [append-only continuation receipt](../performance/temporal-worker-export-2026-11-07/README.md)
records same-source O3/inline50 versus O2/inline50 bytes, code/data attribution,
complete output oracles, ABBA runtime observations, failed raster and optimizer
attempts, normal packaging and full strict-CSP foundation. The profile is a
size/runtime tradeoff, with no comparative speed or whole-#45 acceptance claim.
The [frozen graph protocol](temporal-graph-frozen.md) owns XYFGv2, XYFX, accepted
Worker/controller capture, CSS focus and offline Scene/XYPB ChartView HTML.

### Combined filtering, catalog and frozen-export ABI

The combined module uses native ABI405 and WASM ABI38. The declaration union
retains all 551 native symbols and all 68 Worker exports, including XYFC
filtering, XYTM temporal Scene compilation and XYFX frozen graph operations.
Existing shared declarations retain their signatures. Both prior native403 and
native404 fixture bytes remain append-only predecessors; only top-level ABI
metadata may change when the normal fixture generators run. New adapters reject
older incompatible native/Worker ABIs rather than silently dropping a feature.

At the initial combined source checkpoint, the target compiler settings, native
optimization, renderer, shared raster/PNG implementation and single-module size
caps were unchanged. Standalone parent
measurements do not qualify the combination; fresh combined native/WASM builds,
package-size checks, cross-host packets, Scene/painter exports and actual Worker
journeys are required. Integration evidence is retained in
[the combined receipt](../performance/frozen-combined-module-2026-11-07/README.md).

### Combined module function layout (WASM38)

The wasm32 producer uses O2 with LLVM inlining threshold 0 and retains compiler
function names until the pinned Binaryen132 `-O3 --all-features` pass completes.
It then orders functions by name and strips debug/name sections. This supersedes
the historical threshold50/early-stripping setting for this combined module;
native O3 and stripping, Rust1.96, fat LTO, codegen1, dependencies, public
declarations, validation, runtime budgets and packaging limits remain unchanged.
The final single module has all 68 function exports, no imports, and measures
1,897,244 raw /784,226 Node22 gzip6 bytes against 1,927,168 /786,432 caps.

The [layout qualification receipt](../performance/combined-wasm-layout-2026-11-07/README.md)
preserves the over-cap baseline and compiler/layout attribution separately.
Same-source admitted outputs match; runtime samples include slower cases and
do not establish a speed or competitor win. A selective projection hint and
error-copy outlining were not retained. No optional module, second renderer,
missing export, validator bypass or larger allowance supplies the size fit.
Matching producer paths and affected browser/native/WASM journeys remain the
required evidence; package fit alone does not close any milestone or issue.
