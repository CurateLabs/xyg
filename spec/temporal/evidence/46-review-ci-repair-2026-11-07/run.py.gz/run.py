import os,sys,subprocess,json,time
from pathlib import Path
root=Path(__file__).resolve().parents[3];out=root/'target/task-tmp/catalog-review-and-ci-repair';phase=sys.argv[1]
env=dict(os.environ,TMPDIR='/var/tmp',PYTHONPATH=str(root/'python'),XYG_NATIVE_LIB=str(root/'target/catalog-review-repair/release/libxyg_core.so'),XYG_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome',XYG_TEST_CHROMIUM='/home/ubuntu/.cache/ms-playwright/chromium-1248/chrome-linux64/chrome')
env['PATH']='/home/ubuntu/.t3/worktrees/xyg/t3-1b0dd836/target/task-tmp/node-v22.23.4-linux-x64/bin:/home/ubuntu/.cargo/bin:'+env['PATH']
commands={
'before-wasm':[['node','scripts/temporal_catalog_wasm_parity.mjs','target/task-tmp/catalog-review-and-ci-repair/before/xyg-wasm.wasm']],
'before-finite':[['uv','run','pytest','-q','tests/test_temporal_catalog.py','-k','extreme_finite']],
'before-constructor-selected':[['uv','run','pytest','-o','pythonpath=','-q','target/task-tmp/catalog-review-and-ci-repair/test_catalog_old_source.py','-k','public_constructor']],
'before-constructor-exact':[['uv','run','pytest','-o','pythonpath=','-q','target/task-tmp/catalog-review-and-ci-repair/test_public_constructor_negative.py','-k','public_constructor']],
'before-constructor':[['uv','run','pytest','-o','pythonpath=','-q','tests/test_temporal_catalog.py','-k','public_constructor']],
'floor':[['/home/ubuntu/.t3/worktrees/xyg/t3-150befc0/.venv/bin/python','-m','pytest','-o','pythonpath=','-q','tests/test_temporal_catalog.py','tests/test_check_typing.py','tests/test_stage_node_packages.py','tests/test_stale_names.py']],
'build':[['cargo','build','--release','--target-dir','target/catalog-review-repair','-j','2']],
'clippy':[['cargo','clippy','--workspace','--all-targets','--','-D','warnings']],
'focused':[['uv','run','pytest','-q','tests/test_temporal_catalog.py','tests/test_check_typing.py','tests/test_stage_node_packages.py'],['node','--test','packages/xy-node/test/temporal-catalog.test.mjs'],['cargo','test','-p','xyg-engine','temporal_scene','--','--nocapture']],
'browser-final':[['node','scripts/temporal_catalog_wasm_parity.mjs','packages/xy-client/dist/xyg-wasm.wasm'],['node','scripts/wasm_foundation_smoke.mjs']],
'browser-diagnostic':[['node','scripts/wasm_foundation_smoke.mjs']],
'qualification':[['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_ownership_audit.py','tests/test_temporal_catalog.py','tests/test_temporal_catalog_geo_integration.py','tests/test_html_transport.py','tests/test_static_document_contract.py','tests/test_cross_host_abi_transition.py']],
'qualification-final':[['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py','tests/test_release_inventory.py','tests/test_verify_ownership.py','tests/test_temporal_catalog.py','tests/test_temporal_catalog_geo_integration.py','tests/test_html_transport.py','tests/test_static_document_contract.py','tests/test_cross_host_abi_transition.py']],
'core-final':[['uv','run','pytest','-q','tests/test_graphforge_contract_corpus.py']],
'ci':[['make','check-ci']],
'gates':[['uv','run','--with','pre-commit','pre-commit','run','--all-files'],['uv','run','ruff','check','.'],['uv','run','ruff','format','--check','.']],
'node-full':[['npm','test','--prefix','packages/xy-node']],
'contracts':[['uv','run','ty','check'],['python3','scripts/gen_abi_manifest.py','--check'],['python3','scripts/gen_wasm_abi.py','--check'],['python3','scripts/abi_smoke.py'],['uv','run','python','scripts/check_release_inventory.py']],
'browser':[['node','scripts/temporal_catalog_wasm_parity.mjs','packages/xy-client/dist/xyg-wasm.wasm'],['node','scripts/wasm_foundation_smoke.mjs','--report','target/task-tmp/catalog-review-and-ci-repair/foundation.json']],
'client':[['node','js/build.mjs']],
'wasm':[['cargo','build','-p','xyg-wasm','--release','--target','wasm32-unknown-unknown','-j','2'],['node','js/package-wasm.mjs']],
}
if phase in ('before-constructor','before-constructor-exact','before-constructor-selected'):
 env['PYTHONPATH']=str(out/'before-python/python');env['XYG_NATIVE_LIB']=str(root/'target/release/libxyg_core.so')
if phase=='before-finite':env['XYG_NATIVE_LIB']=str(root/'target/release/libxyg_core.so')
if phase in ('browser','browser-diagnostic','browser-final'):env['XYG_WASM_FOUNDATION_REPORT']=str(out/'foundation.json')
results=[]
for i,cmd in enumerate(commands[phase]):
 log=out/f'{phase}-{i}.log';start=time.time()
 with log.open('wb') as stream:p=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row={'command':cmd,'exit':p.returncode,'seconds':time.time()-start,'log':str(log)};results.append(row);print(json.dumps(row),flush=True)
(out/f'{phase}-results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(any(r['exit'] for r in results))
